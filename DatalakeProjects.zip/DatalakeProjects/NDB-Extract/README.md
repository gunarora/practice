DataProvisionFramework-It is spark-scala based framework which generates the extracts from various tables or entities on basis of queries configured through hbase meta tables(PEI,PSC,PLC). In case of complex logic involving multiple queries, entities and queries are configured through json file.

Below are the three Hbase Meta tables that are required to be configured to run the extraction process:
1) Provisioning Extract Info(provisioning_extract_info): 
All the information related to extract inputs output files, entities involved ,Queries, Is complex extract or simple, if complex then json path --  is configured here
Row-Key = <Feed Name>-<Extract Name>
 
2) Provisioning LastRun Info(provisiong_lastrun_info):
All the information about the frequency of extract and last run time is configured here.
Row-Key = <Feed Name>-<Extract Name>
 
3) Provisioning Snapshot Config(provisioning_snapshot_config):
All the information related to entities involved and their primary keys for a particular extract are configured there.
Row-Key = <Feed Name>-<Extract Name>-<Entity Name>
Note: The number of records in HBase will be equal to number of entities involved
 
Rest Configurations are done in the properties file available in resources folder of jar file.
 

The Process:
After all the initial configurations, the whole process is automated and scheduled through oozie job.
All we need to provide are the aforementioned configurations.

The Entry point:
src/main/scala/com/uhg/optum/provider/PEMain.scala: It is the entry point to initiate the extraction process
It takes 4 parameters:
1.	FeedName-ExtractName 
2.	Environment =>e.g.(dev/tst/prod)
3.	EXTRACT_EIT_FLG => e.g.Y/N 
4.	MetaURI





