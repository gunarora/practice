package com.uhg.optum.provider

import com.mapr.db.spark._
import com.uhg.optum.common.CustomFunctions.filterList
import com.uhg.optum.common.{CustomFunctions, GlobalContext, Logger}
import org.apache.hadoop.hbase.TableName
import org.apache.hadoop.hbase.client.{HTable, Scan}
import org.apache.hadoop.hbase.filter.CompareFilter.CompareOp
import org.apache.hadoop.hbase.filter.{PrefixFilter, SingleColumnValueFilter}
import org.apache.hadoop.hbase.util.Bytes
import org.apache.spark.sql.functions._
/**
  *
  * Created by vshrest1 on 4/4/2018.
  */
object PJSExtractTest {

  def getPJSExtract(plcTabName:String,lastrunConfigTab:HTable,entityMetaDataTab:String,entitySet:String,peiRowKey:String,prtnrCd:String,srcCd:String,incEndTs:String,pitRowKey:String,rootDir:String,peiTabName:String,pitTab:HTable,pitTabName:String,securityfileLoc:String,workingDir:String):Unit ={

    val isMultiGroup = entitySet.contains (";")
    Logger.log.info("Test : "+entitySet)
    val ptnr = s"${prtnrCd}".toUpperCase
    val src = s"${srcCd}".toUpperCase
    if (! isMultiGroup) {
      val grpDtls = entitySet.split ('|')
      val grpNm = grpDtls(0)
      val denormSnapshotEntityName = CustomFunctions.getEntityMetaDataInfo (ptnr, src, grpNm,entityMetaDataTab)
      val readJsonDF=CustomFunctions.loadFromMapRDBTbl(denormSnapshotEntityName)
      Logger.log.info("Count of readJsonDFis ::: "+readJsonDF.count());
      for (i <- 1 until grpDtls.length) {
        val genPJSExtractPerEntFlg=CustomFunctions.genPJSExtractPerEnt (readJsonDF, grpDtls(i) )
        Logger.log.info("the generation of temp View for entity "+grpDtls(i)+" is "+genPJSExtractPerEntFlg)
      }

    }
    else {
      val grpEntList = entitySet.split(';')
      Logger.log.info(s"==========>  Multi-Group, MultiEntity Snapshot creation based on PJS data <===========")
      grpEntList.foreach { ent =>
        Logger.log.info("test"+ent)
        val grpDtls = ent.split ('|')
        val grpNm = grpDtls(0)
        val denormSnapshotEntityName = CustomFunctions.getEntityMetaDataInfo (ptnr, src, grpNm,entityMetaDataTab)
        /*
                val pjsSnap = globalContext.spark.loadFromMapRDB (denormSnapshotEntityName).map (a => a.toString () )
                val readJsonDF = sparkSession.read.json (pjsSnap)*/
        val readJsonDF=CustomFunctions.loadFromMapRDBTbl(denormSnapshotEntityName)
        Logger.log.info("Count of readJsonDFis ::: "+readJsonDF.count());
        for (i <- 1 until grpDtls.length) {
          val genPJSExtractPerEntFlg=CustomFunctions.genPJSExtractPerEnt (readJsonDF, grpDtls(i) )
          Logger.log.info("the generation of temp View for entity "+grpDtls(i)+" is "+genPJSExtractPerEntFlg)

        }

      }
    }
    Logger.log.info(s"==========> Invoking getExtract for Multi-Entity  <===========")
    CustomFunctions.generateExtract(plcTabName,lastrunConfigTab,peiRowKey, pitRowKey,rootDir,peiTabName,pitTab,pitTabName,securityfileLoc,workingDir)
    CustomFunctions.hbasePITEndStage(pitTab,"success",pitRowKey)


  }
}