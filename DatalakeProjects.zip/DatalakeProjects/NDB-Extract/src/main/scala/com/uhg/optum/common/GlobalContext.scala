package com.uhg.optum.common

import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.hbase.HBaseConfiguration
import org.apache.hadoop.hbase.spark.HBaseContext
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession

/**
  * Description : Program to create spark session on runtime and used wherever needed
  */
class GlobalContext {

  var spark: SparkContext = {
    if(DPOConstants.METAURI==null)
      this.createSparkSession("ProvExtract").sparkContext
    else
      this.createSparkSession(DPOConstants.PEIROWKEY,DPOConstants.METAURI).sparkContext
  }

  def createSparkSession (appName: String,metastoreUri: String): SparkSession = {
    try {

      //val sparkSession = SparkSession.builder().appName(appName).master("local[1]").enableHiveSupport().getOrCreate()
      val sparkSession = SparkSession.builder().appName(appName).config("hive.metastore.uris", metastoreUri).enableHiveSupport().getOrCreate()
      //val sparkSession = SparkSession.builder().appName(appName).getOrCreate()
      Logger.log.info(s" GlobalContext: sparkSession is created with thriftServer ($metastoreUri) : $sparkSession")
      sparkSession.conf.set( "spark.serializer", "org.apache.spark.serializer.KryoSerializer" )
      sparkSession.conf.set("spark.crossjoin","spark.sql.crossJoin.enabled")
      sparkSession
    } catch {
      case e: Exception => {
        Logger.log.info(s"Exception at GlobalContext CreateSparkSession function with metaURI : " + e.getMessage)
        Logger.log.error("Error occured : " + e.getStackTrace.mkString("\n"))
      }
        throw e
    }
  }
  //var sparkSession : SparkSession = this.createSparkSession("ProvExtract")
  //var spark: SparkContext = this.createSparkSession("ProvExtract").sparkContext
  //var spark = sparkSession.sparkContext

  def createSparkSession (appName: String): SparkSession = {
    try {

     // val sparkSession = SparkSession.builder().appName(appName).master("local[1]").enableHiveSupport().getOrCreate()
      val sparkSession = SparkSession.builder().appName(appName).enableHiveSupport().getOrCreate()
   //   val sparkSession = SparkSession.builder().appName(appName).master("local[1]").getOrCreate()
      Logger.log.info(" GlobalContext: sparkSession is created " + sparkSession)
      sparkSession.conf.set( "spark.serializer", "org.apache.spark.serializer.KryoSerializer" )
      sparkSession.conf.set("spark.crossjoin","spark.sql.crossJoin.enabled")
      sparkSession
    } catch {
      case e: Exception => Logger.log.info( s"Exception at GlobalContext CreateSparkSession function:" + e.getStackTrace.toString )
        throw e
    }
  }

  val hBaseConf:org.apache.hadoop.conf.Configuration = HBaseConfiguration.create()
  val hbaseContext = new HBaseContext(spark, hBaseConf)

  val fs: FileSystem = FileSystem.get(spark.hadoopConfiguration)

}