package com.uhg.optum.provider

import com.uhg.optum.common.{CustomFunctions, DPOConstants, GlobalContext, Logger}
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.hbase.client.HBaseAdmin
import org.apache.hadoop.hbase.mapreduce.TableOutputFormat
import org.apache.hadoop.hbase.util.Bytes
import org.apache.hadoop.hbase.{HBaseConfiguration, HColumnDescriptor, HTableDescriptor}
import org.apache.hadoop.io.{LongWritable, Text}

object ProvExractPEIPSCLoadMain {
  def main (args: Array[String]): Unit = {
    val globalContext = new GlobalContext
    val sparkSession = globalContext.createSparkSession("ProvExtract")
    val sqlContext = sparkSession.sqlContext
    Logger.log.info("=============> Starting Prov Extract WorkFlow For Hbase Tables PEI PSC Load <=============")
    if (args.length != 3) {
      Logger.log.info( "Please Pass env and HBase Table Name that needs to be updated \"Tst pei \" for Provisioning extract" )
      Logger.log.error( "===> Since No args(FeedName,ExtractName,env)  is Passed ending Provisioning extract <===" )
      sparkSession.stop()
    } else {
      val env = args( 0 ).trim.toLowerCase
      val TableName=args(1).trim

      DPOConstants.PEIROWKEY = args(1).trim
      DPOConstants.METAURI =args(2).trim.toUpperCase()

      // Read properties file
      val rootDir = CustomFunctions.readProperties( s"rootDir" ,env)
      val peiTabName=CustomFunctions.readProperties( s"peiTableName",env )
      val pitTabName = CustomFunctions.readProperties( s"pitTableName",env )
      val pscTabName = CustomFunctions.readProperties( s"pscTableName" ,env)
      val pitDatLocation=CustomFunctions.readProperties( s"pitDatLocation",env )
      val peiDatLocation=CustomFunctions.readProperties( s"DSVConfigLocation",env )
      val peDatArchiveLocation=CustomFunctions.readProperties( s"peDatArchiveLocation" ,env)
      val securityfileLoc=CustomFunctions.readProperties( s"securityfileLoc" ,env)
      val hbase_zookeeper_quorum=CustomFunctions.readProperties( s"hbase_zookeeper_quorum",env )
      val lakeEppTableName=CustomFunctions.readProperties( s"lakeEppTableName",env )
      val lakeEitTableName=CustomFunctions.readProperties( s"lakeEitTableName" ,env)
      val mountPath=CustomFunctions.readProperties( s"mountPath",env )
      val workingDir=CustomFunctions.readProperties( s"workingDir" ,env)
      val securityVal=CustomFunctions.readProperties( s"securityVal" ,env)


      Logger.log.info( s"  PEI Dat File Location  : ${peiDatLocation} " )

      val hBaseConf = HBaseConfiguration.create()

      hBaseConf.set( "hbase.zookeeper.quorum", hbase_zookeeper_quorum )

      try{
        val admin = new HBaseAdmin( hBaseConf )
        val flag = admin.tableExists( peiTabName )
        Logger.log.info( s"  hbase Table FlagValue  : $flag " )


        //PEI Table Creation

        if(TableName.equalsIgnoreCase("pei")){

          val PEIfileRDD = sparkSession.sparkContext.textFile( peiDatLocation ).mapPartitionsWithIndex { (idx, iter) => if (idx == 0) iter.drop( 1 ) else iter }
          Logger.log.info( s" PEIfileRDD count : "+ PEIfileRDD.count())
          val PEItransformedRDD = PEIfileRDD.map { line => CustomFunctions.PEIconvertToKeyValuePairs( line ) }

          if (admin.tableExists( peiTabName )) {
            Logger.log.info( s" PEI htable already exists" )
            Logger.log.info( s" Table will get loaded if there is any DAT File provided as the input" )
            val tableDesc = new HTableDescriptor( Bytes.toBytes( peiTabName ) )
            val idsColumnFamilyDesc = new HColumnDescriptor( Bytes.toBytes( "pei" ) )
            tableDesc.addFamily( idsColumnFamilyDesc )
            hBaseConf.set( TableOutputFormat.OUTPUT_TABLE, peiTabName )
            val jobConf = new Configuration( hBaseConf )
            jobConf.set( "mapreduce.job.output.key.class", classOf[Text].getName )
            jobConf.set( "mapreduce.job.output.value.class", classOf[LongWritable].getName )
            jobConf.set( "mapreduce.outputformat.class", classOf[TableOutputFormat[Text]].getName )
            PEItransformedRDD.saveAsNewAPIHadoopDataset( jobConf )
          }

          if (!admin.tableExists( peiTabName )) {
            Logger.log.info( s" PEI htable does not exists.Hence creating table" )
            val tableDesc = new HTableDescriptor( Bytes.toBytes( peiTabName ) )
            val idsColumnFamilyDesc = new HColumnDescriptor( Bytes.toBytes( "pei" ) )
            tableDesc.addFamily( idsColumnFamilyDesc )
            admin.createTable( tableDesc )
            hBaseConf.set( TableOutputFormat.OUTPUT_TABLE, peiTabName )
            val jobConf = new Configuration( hBaseConf )
            jobConf.set( "mapreduce.job.output.key.class", classOf[Text].getName )
            jobConf.set( "mapreduce.job.output.value.class", classOf[LongWritable].getName )
            jobConf.set( "mapreduce.outputformat.class", classOf[TableOutputFormat[Text]].getName )
            PEItransformedRDD.saveAsNewAPIHadoopDataset( jobConf )
          }

        }
        //PIT table creation  ==> fix this by automating this steps
        Logger.log.info( s"  PIT Dat File Location  : ${pitDatLocation} " )
        val PITfileRDD = sparkSession.sparkContext.textFile( pitDatLocation ).mapPartitionsWithIndex { (idx, iter) => if (idx == 0) iter.drop( 1 ) else iter }
        val PITTransformedRDD = PITfileRDD.map { line => CustomFunctions.PITConvertToKeyValuePairs(line) }

        // val plcTabName = "/datalake/uhclake/tst/developer/pankaj/scripts/ndb_extract/hbase_tables/provisioning_lastrun_config"

        if (admin.tableExists( pitTabName )) {
          Logger.log.info( s" PIT htable already exists" )
        }

        if (!admin.tableExists( pitTabName )) {
          Logger.log.info( s" PIT htable does not exists.Hence creating table" )
          val tableDesc = new HTableDescriptor(Bytes.toBytes(pitTabName ))
          val exiColumnFamilyDesc = new HColumnDescriptor(Bytes.toBytes("exi"))
          val fiColumnFamilyDesc = new HColumnDescriptor(Bytes.toBytes("fi"))
          tableDesc.addFamily(exiColumnFamilyDesc)
          tableDesc.addFamily(fiColumnFamilyDesc)
          admin.createTable(tableDesc)
          hBaseConf.set(TableOutputFormat.OUTPUT_TABLE, pitTabName )
          val jobConf = new Configuration(hBaseConf)
          jobConf.set("mapreduce.job.output.key.class", classOf[Text].getName)
          jobConf.set("mapreduce.job.output.value.class", classOf[LongWritable].getName)
          jobConf.set("mapreduce.outputformat.class", classOf[TableOutputFormat[Text]].getName)
          PITTransformedRDD.saveAsNewAPIHadoopDataset(jobConf)
        }

        //PSC Table Creation
        if(TableName.equalsIgnoreCase("psc")){

          val PSCfileRDD = sparkSession.sparkContext.textFile( peiDatLocation ).mapPartitionsWithIndex { (idx, iter) => if (idx == 0) iter.drop( 1 ) else iter }
          val PSCtransformedRDD = PSCfileRDD.map { line => CustomFunctions.PSCconvertToKeyValuePairs( line ) }

          if (admin.tableExists(pscTabName )) {
            Logger.log.info( s" PSC htable already exists" )
            Logger.log.info( s" Table will get loaded if there is any DAT File provided as the input" )
            val tableDesc = new HTableDescriptor( Bytes.toBytes( pscTabName ) )
            val idsColumnFamilyDesc = new HColumnDescriptor( Bytes.toBytes( "psc" ) )
            tableDesc.addFamily( idsColumnFamilyDesc )
            hBaseConf.set( TableOutputFormat.OUTPUT_TABLE, pscTabName )
            val jobConf = new Configuration( hBaseConf )
            jobConf.set( "mapreduce.job.output.key.class", classOf[Text].getName )
            jobConf.set( "mapreduce.job.output.value.class", classOf[LongWritable].getName )
            jobConf.set( "mapreduce.outputformat.class", classOf[TableOutputFormat[Text]].getName )
            PSCtransformedRDD.saveAsNewAPIHadoopDataset( jobConf )
          }

          if (!admin.tableExists( pscTabName )) {
            Logger.log.info( s" PSC htable does not exists.Hence creating table" )
            Logger.log.info( s" Table will get loaded if there is any DAT File provided as the input" )
            val tableDesc = new HTableDescriptor( Bytes.toBytes( pscTabName ) )
            val idsColumnFamilyDesc = new HColumnDescriptor( Bytes.toBytes( "psc" ) )
            tableDesc.addFamily( idsColumnFamilyDesc )
            admin.createTable( tableDesc )
            hBaseConf.set( TableOutputFormat.OUTPUT_TABLE, pscTabName )
            val jobConf = new Configuration( hBaseConf )
            jobConf.set( "mapreduce.job.output.key.class", classOf[Text].getName )
            jobConf.set( "mapreduce.job.output.value.class", classOf[LongWritable].getName )
            jobConf.set( "mapreduce.outputformat.class", classOf[TableOutputFormat[Text]].getName )
            PSCtransformedRDD.saveAsNewAPIHadoopDataset( jobConf )
          }
        }

        /*	    //Moving input Dat file (PEI) to Archive Location
                  if(CustomFunctions.fileExists(peiDatLocation) == 0) {
                    val currentTs = CustomFunctions.getCurrentTsFormat
                    val archLocWithTS = (peDatArchiveLocation + "/" + currentTs).replace( "/mapr/", "/" )
                    try {
                      CustomFunctions.createPath( archLocWithTS )
                      CustomFunctions.renameFile( peiDatLocation, archLocWithTS )
                    }
                    catch{
                      case e: Exception => Logger.log.info( "Exception while moving files to Archive Location" + e.getMessage )
                        throw e
                    }
                  }*/
        else{
          Logger.log.info(s"Dat File Not exists at given path ${peiDatLocation} ")
        }

        globalContext.spark.stop()
      }
      catch {
        case e: Exception => Logger.log.info( "Exception while processing working Area" + e.getMessage )
          throw e
      }

    }
  }
}
