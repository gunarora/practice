package com.uhg.optum.provider

import com.uhg.optum.common.CustomFunctions._
import com.uhg.optum.common.{CustomFunctions, DPOConstants, Logger}

object CreateSnapshot {
  def main (args: Array[String]): Unit = {

    try {

      Logger.log.info("=============> Starting Snapshot Creation WorkFlow for Common Snapshots <=============")
      if (args.length != 3) {
        Logger.log.info("===> Please Pass Arg1: Feed name for Entity list file path Arg2: Environment <===")
        Logger.log.error("===> Since No args(Feed Name,Environment)  is Passed ending Snapshot creation <===")
        //System.exit(-1)
      }

      val feedName = args(0).trim
      val env = args(1).trim

      DPOConstants.PEIROWKEY = args(0).trim
      DPOConstants.METAURI =args(2).trim.toUpperCase()

      //val feedName = "UHN _Reporting"
      //val env = "dev"
      val fdNm=feedName.split('_')(0)+"_"+feedName.split('_')(1)
      Logger.log.info(s"Processing for feedname : ${fdNm}")

      val lakeEppTableName = CustomFunctions.readProperties(s"lakeEppTableName", env)
      val lakeEitTableName = CustomFunctions.readProperties(s"lakeEitTableName", env)
      val mountPath = CustomFunctions.readProperties(s"mountPath", env)
      val workingDir = CustomFunctions.readProperties(s"workingDir", env)
      Logger.log.info(s"Entity List going to execute: /common_snapshot/$feedName")
      val inputPath = this.getClass.getResourceAsStream("/common_snapshot/"+env+"/" + feedName )


      //val inputPath = this.getClass.getResourceAsStream("/"+feedName + "_Entity_List")
      //println(inputPath)
      //.substring(1).replace(s"/",s"\\").replace(s"%20",s" ")

      val entityTabList = scala.io.Source.fromInputStream(inputPath).getLines().toList

      for (entDetails <- entityTabList) {
        val entityArr: Array[String] = entDetails.mkString("").split('|')
        val prtnrCd = entityArr(0).trim
        val srcCd = entityArr(1).trim
        val ent = entityArr(2).trim
        val pKeys = entityArr(3).trim
        //        val dmlCol = entityArr(4).toString
        //        val modTsCol = entityArr(5).toString
        //println(entityArr + "---" + prtnrCd +"---" + srcCd +"---" + ent +"---" + pKeys)
        Logger.log.info(s"==========>  Multi-Entity( " + ent + " ) Snapshot creation based on Raw data <===========")
        //Logger.log.info(s"==========>   Snapshot creation for the Entity : $ent  <===========")
        val snapBuildType = CustomFunctions.readFeedBasedProperties("common_snapshot",fdNm,s"COMMON_SNAP_BUILD_TYPE",env)
        val dmlCol=CustomFunctions.readFeedBasedProperties("common_snapshot",fdNm,s"DML_COL",env)
        val modTsCol=CustomFunctions.readFeedBasedProperties("common_snapshot",fdNm,s"MOD_TS_COL",env)
        getSnapshotCommonPerEntity(snapBuildType, pKeys, lakeEitTableName, mountPath, workingDir, lakeEppTableName, ent, prtnrCd, srcCd, dmlCol,modTsCol)
      }
      Logger.log.info("=============> Completed Snapshot Creation WorkFlow for Common Snapshots <=============")

    } catch {
      case e: Exception => Logger.log.info(s" Exception while generating common snapshot" :+ e.getStackTrace.mkString)
        throw e
    }
  }


}