package com.uhg.optum.provider

import com.uhg.optum.common.{CustomFunctions, GlobalContext, Logger}
/**
  * Description : Program to generate the PJS
  */
object PJSExtract {

  val globalContext = new GlobalContext

  def getPjsGroupInfo(entityMetaDataTabName: String, entitySet:String, prtnrCd:String, srcCd:String) : Unit = {
    try {

      val isMultiGroup = entitySet.contains(";")
      if (!isMultiGroup) {
        val rowKeyConfig = prtnrCd + "-" + srcCd
        val grpNm = entitySet
        Logger.log.info(s"==========>  Single Group PJS creation Flow Started <===========")
        Logger.log.info(s" Scanning EntityMetaDataInfo HTable for the Group "+ grpNm)
        val grpInfoRDD = CustomFunctions.getEntityMetaDataInfo(rowKeyConfig,grpNm,entityMetaDataTabName)
        Logger.log.info(s" gropInfo RDD count : ${grpInfoRDD.count()} ")
        if(!grpInfoRDD.isEmpty)
        {
          Logger.log.info(s" Invoking getGrpDenorSnap View Creation for the Group "+ grpNm)
          CustomFunctions.getGrpDenorSnap(grpInfoRDD,grpNm)
        }
        else {
          Logger.log.info(s"ERROR: not able to retrieve values from $entityMetaDataTabName for group : $grpNm")
          false
        }
      } else {
        val grpList = entitySet.toUpperCase.split(';')
        Logger.log.info(s"==========>  Multi Group PJS creation Flow Started <===========")
        grpList.foreach { grp =>
          val rowKeyConfig = prtnrCd + "-" + srcCd
          Logger.log.info(s" Scanning EntityMetaDataInfo HTable for the Group "+ grp)
          val grpInfoRDD = CustomFunctions.getEntityMetaDataInfo(rowKeyConfig,grp,entityMetaDataTabName)
          Logger.log.info(s" gropInfo RDD count : ${grpInfoRDD.count()} ")
          if(!grpInfoRDD.isEmpty)
          {
            Logger.log.info(s" Invoking getGrpDenorSnap View Creation for the Group "+ grp)
            CustomFunctions.getGrpDenorSnap(grpInfoRDD,grp)
          }
          else {
            Logger.log.info(s"ERROR: not able to retrieve values from $entityMetaDataTabName for group : $grp")
            false
          }

        }
      }
    }catch {
      case e: Exception => Logger.log.info("Exception at <def Main if block>from PEGeneration Object" :+ e.getMessage)
        throw e
    }
  }
}



