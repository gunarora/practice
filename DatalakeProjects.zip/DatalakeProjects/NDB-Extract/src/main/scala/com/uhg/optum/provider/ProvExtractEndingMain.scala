package com.uhg.optum.provider

import com.uhg.optum.common.{CustomFunctions, DPOConstants, GlobalContext, Logger}
import org.apache.hadoop.hbase.HBaseConfiguration
import org.apache.hadoop.hbase.client.{HTable, Put}
import org.apache.hadoop.hbase.mapreduce.TableInputFormat

import scala.io.Source

object ProvExtractEndingMain {
  def main (args: Array[String]): Unit = {

    Logger.log.info("=============> Starting Prov Extract WorkFlow For ProvExtractEndingMain <=============")
    if (args.length != 5) {
      Logger.log.info( "Please Pass extractLoc env pitprovStatus filename for ProvExtractEndingMain" )
      Logger.log.error( "===> Since No args(extractLoc,env,pitprovStatus,filename)  is Passed ending Provisioning extract <===" )
    } else {
      try {
        val extractLoc=args( 0 ).trim.replaceAll("/mapr","")
        val env=args(1).trim.toLowerCase()
        val PitProvStatus=args(2).trim.toLowerCase()
        val allRowKeyFileNm=args(3).trim

        DPOConstants.PEIROWKEY = "ProvExtractEndingMain"
        DPOConstants.METAURI =args(4).trim.toUpperCase()

        val globalContext = new GlobalContext

        Logger.log.info(s" extractLoc " + extractLoc);
        Logger.log.info(s" env " + env);
        Logger.log.info(s" PitProvStatus " + PitProvStatus);
        Logger.log.info(s" allRowKeyFileNm " + allRowKeyFileNm);
        Logger.log.info(s" logFileName constructed " + extractLoc.concat(allRowKeyFileNm))

        val logFile = globalContext.spark.textFile(extractLoc.concat(allRowKeyFileNm))

        // Configure Hbase meta tables

        val pitTabName=CustomFunctions.readProperties( s"pitTableName",env )

        logFile.foreachPartition{iter =>
          val hBaseConf1: org.apache.hadoop.conf.Configuration = HBaseConfiguration.create()
          hBaseConf1.set(TableInputFormat.INPUT_TABLE, pitTabName)
          val pitTab: HTable = new HTable(hBaseConf1, pitTabName)
          iter.foreach {lines =>
            try {
              val pitRowKey=lines.split('|')(2)
              val colFm="exi"
              val colNm="provCompSts"
              val value=PitProvStatus
              val p = new Put(s"$pitRowKey".getBytes())
              p.addColumn(s"$colFm".getBytes(), s"$colNm".getBytes(), s"$value".getBytes())
              pitTab.put(p)
            } catch {
              case e: Exception => Logger.log.info(" Exception at HBase PIT Put Commands " :+ e.getStackTrace.mkString)
                throw e
            }
          }
        }

      } catch {
        case e: Exception => Logger.log.info( "Exception while ProvExtractEndingMain working Area" + e.getMessage )
          throw e
      }

    }
  }
}
