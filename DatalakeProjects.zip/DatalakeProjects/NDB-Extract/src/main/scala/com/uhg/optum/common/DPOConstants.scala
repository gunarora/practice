package com.uhg.optum.common

object DPOConstants {
  val FIELD_DELIMITER_HBASE_TABLES = "\\^\\~\\^";
  val CUSTROWDELIM_5c7530303032="""\\u0002"""
  val CUSTROWDELIM_5c75303030325c6e=""""\\u0002\\u000A"""
  var PEIROWKEY : String = null
  var METAURI : String = null

  //Constants for common snapshots
  val COMMON_SNAP_BUILD_TYPE="raw"
  val DML_COL="CDC_FLAG"
  val MOD_TS_COL="CDC_TS"
}
