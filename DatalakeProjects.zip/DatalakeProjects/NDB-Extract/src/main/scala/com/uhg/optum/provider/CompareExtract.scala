package  com.uhg.optum.provider

import com.uhg.optum.common.{GlobalContext, CustomFunctions, Logger}

/*DESCRIPTION:
* Input: MainFrame File Location, DataLake File Location, Output Folder Location
* Output: Missed Records File, Mismatched Records File
* It will take the inputs(files to compare and output location) as mentioned above, perform the comparison and save the output files at the location provided in input.
* */
object CompareExtract {

  def main(args: Array[String]): Unit = {

    val globalContext = new GlobalContext
    val sparkSession = globalContext.createSparkSession("ProvExtract")
    val sqlContext = sparkSession.sqlContext
    Logger.log.info("=============> Starting Prov Extract Comparision of Source and Extracted Data WorkFlow <=============")
    val sc = sparkSession.sparkContext
    Logger.log.info(s"=============> SparkContext initiated  : $sparkSession<=============")
    //Checking if all the required arguments are passed. If not, throw error and exit.
    if (args.length != 3) {
      Logger.log.info("Please Pass all three arguments : MainFrame File Location, DataLake File Location and the Output File Location")
      Logger.log.error("===> Since No args(MainFrame File Location, DataLake File Location, Output File Location)  is Passed ending Provisioning extract <===")
      sparkSession.stop()
    }
    //if all the required arguments are passed.
    else {

      val file1loc = args(0)
      val file2loc = args(1)
      val outFileLoc = args(2)
      val MainframeFile = sc.textFile(file1loc)
      val DatalakeFile = sc.textFile(file2loc)

      import sparkSession.sqlContext.implicits._
      val diffRec1 = MainframeFile.toDF.except(DatalakeFile.toDF)

      val diffRec2 = DatalakeFile.toDF.except(MainframeFile.toDF)
      //checking if diffRec1 count is not zero, if not, it means there are some missing records in Datalake file and those missed records will be saved into a file.
      if (diffRec1.count != 0) {
        var missedRec =  outFileLoc + "/Missed_Records"
        Logger.log.info("There are some missing Records")
        //diffRec1.rdd.coalesce(1).saveAsTextFile("/datalake/other/rdfcoe_dev/sjain144/ComparisonCode/Missing_Records")
        //diffRec2.rdd.coalesce(1).saveAsTextFile("/datalake/other/rdfcoe_dev/sjain144/ComparisonCode/Mismatched_Records")
        //val mergedRDD=diffRec1.rdd.++(diffRec2.rdd)
        //val mergeDF = diffRec1.union(diffRec2)
        CustomFunctions.saveDFOutputToMapR(diffRec1, missedRec)
        //CustomFunction.saveOutputToMapR(mergeDF, outFileLoc)
        Logger.log.info("Missed records are saved into file under the provided Output Location.")
      }
      //checking if diffRec2 count is not zero, if not, it means there are some mismatched/bad records in Datalake file and those records will be saved into a file.
      if(diffRec2.count != 0){
        var mismatchedRec =  outFileLoc + "/Mismatched_Records"
        Logger.log.info("There are some Mismatched/Bad Records")
        CustomFunctions.saveDFOutputToMapR(diffRec2, mismatchedRec)
        Logger.log.info("Mismatched/Bad records are saved into file under the provided Output Location.")
      }

      //if both diffRec1 and diffRec2 count is zero, it means there are no missed and mismatched/bad records in Datalake file.
      if (diffRec1.count == 0 && diffRec2.count == 0) {
        Logger.log.info("There is no mismatch of records in both the files")
      }
    }
  }
}

