package com.uhg.optum.provider

import com.uhg.optum.common.{CustomFunctions, DPOConstants, GlobalContext, Logger}
import org.apache.hadoop.hbase.HBaseConfiguration
import org.apache.hadoop.hbase.client.HTable
import org.apache.hadoop.hbase.mapreduce.TableInputFormat

/**
  * Description : Program to generate the extract based on PEI, PSC configurations with snapBudType raw / snapshot / pjs
  */
object PEMain {
  def main (args: Array[String]): Unit = {
    try {
      Logger.log.info("=============> Starting Prov Extract WorkFlow <=============")
      if (args.length != 4) {
        Logger.log.info("===> Please Pass FeedName-ExtractName Environment \" UHN_Reporting-F5938P_PROD_HCAPACSS_ZIP  dev/tst/prod EXTRACT_EIT_FLG=Y/N MetaURI\" for Provisioning extract <===")
        Logger.log.error("===> Since No args(FeedName-ExtractName,Environment)  is Passed ending Provisioning extract <===")

      }
      val peiRowKey = args(0).trim
      DPOConstants.PEIROWKEY = args(0).trim

      //Taking environment type
      val env = args(1).trim.toLowerCase
      val EXTRACT_EIT_FLG=args(2).trim.toUpperCase()
      //val EXTRACT_EIT_FLG="N"
      Logger.log.info(s" Arg - EXTRACT_EIT_FLG value is : $EXTRACT_EIT_FLG")

      DPOConstants.METAURI =args(3).trim.toUpperCase()
      val metastoreUri = DPOConstants.METAURI
      Logger.log.info(s" Value for metastoreUri in PEMain  : $metastoreUri")

      // val globalContext = new GlobalContext
      val prcStTm = CustomFunctions.getCurrentTimeFormat //capture prov start time
      Logger.log.info(s" Prov Extract Process Start Time: $prcStTm ")
      // val bv = globalContext.spark.broadcast(peiRowKey)

      // Read properties file
      val rootDir = CustomFunctions.readProperties( s"rootDir" ,env)
      val allExtractsPitRowKeys = CustomFunctions.readProperties( s"allExtractsPitRowKeys" ,env)
      val peiTabName=CustomFunctions.readProperties( s"peiTableName",env )
      val pitTabName = CustomFunctions.readProperties( s"pitTableName",env )
      val pscTabName = CustomFunctions.readProperties( s"pscTableName" ,env)
      val plcTabName = CustomFunctions.readProperties( s"plcTableName" ,env)
      val entityMetaDataTabName = CustomFunctions.readProperties(s"entityMetaDataTabName",env)
      val pitDatLocation=CustomFunctions.readProperties( s"pitDatLocation",env )
      val peiDatLocation=CustomFunctions.readProperties( s"peiDatLocation",env )
      val peDatArchiveLocation=CustomFunctions.readProperties( s"peDatArchiveLocation" ,env)
      val securityfileLoc=CustomFunctions.readProperties( s"securityfileLoc" ,env)
      val hbase_zookeeper_quorum=CustomFunctions.readProperties( s"hbase_zookeeper_quorum",env )
      val lakeEppTableName=CustomFunctions.readProperties( s"lakeEppTableName",env )
      val lakeEitTableName=CustomFunctions.readProperties( s"lakeEitTableName" ,env)
      val mountPath=CustomFunctions.readProperties( s"mountPath",env )
      val workingDir=CustomFunctions.readProperties( s"workingDir" ,env)
      val dataownr=CustomFunctions.readProperties(s"dataownr" ,env)


      // Configure Hbate meta tables
      val hBaseConf1:org.apache.hadoop.conf.Configuration = HBaseConfiguration.create()
      hBaseConf1.set(TableInputFormat.INPUT_TABLE, peiTabName)
      val peiTab: HTable = new HTable(hBaseConf1, peiTabName)

      val hBaseConf2:org.apache.hadoop.conf.Configuration = HBaseConfiguration.create()
      hBaseConf2.set(TableInputFormat.INPUT_TABLE, pitTabName)
      val pitTab: HTable = new HTable(hBaseConf1, pitTabName)

      val hBaseConf3:org.apache.hadoop.conf.Configuration = HBaseConfiguration.create()
      hBaseConf3.set(TableInputFormat.INPUT_TABLE, pscTabName)
      val snapConfigTab: HTable = new HTable(hBaseConf3, pscTabName)

      val hBaseConf4:org.apache.hadoop.conf.Configuration = HBaseConfiguration.create()
      hBaseConf4.set(TableInputFormat.INPUT_TABLE, plcTabName)
      val lastrunConfigTab: HTable = new HTable(hBaseConf1, plcTabName)

      //  val hBaseConf4:org.apache.hadoop.conf.Configuration = HBaseConfiguration.create()
      //   hBaseConf4.set(TableInputFormat.INPUT_TABLE, entityMetaDataTabName)
      // val entityMetaDataTab: HTable = new HTable(hBaseConf3, entityMetaDataTabName)


      val pitRowKey = s"$peiRowKey-${java.util.UUID.randomUUID.toString}"
      CustomFunctions.hbasePITInitialStage(pitTab,pitRowKey, prcStTm,dataownr) //

      // val workingDir = s"${globalContext.workingDir}" // temp directory for storing intermediate results , and at the end of the workflow, making sure of cleanup
      val incEndTs = CustomFunctions.getCurrentTimeFormat //capture current time as run time snapshot incremental end time
      /*val peiScanDF = CustomFunctions.getPEIIntoDF(peiRowKey,peiTabName)
      if(peiScanDF.count != 1){
        Logger.log.info(" Failed at PEI table scan for first 21 columns , unable to retriving the columns based on rowkey, so ending the Provisioning with Failed status")
        CustomFunctions.hbasePITEndStage(pitTab,"Fail", pitRowKey)
        System.exit(1)
      }*/
      val peiRmngColsDF = CustomFunctions.getPEIInfoDF(peiRowKey,peiTabName)
      if(peiRmngColsDF.count != 1) {
        Logger.log.info(" Failed at PEI remaining table scan, unable to retriving the remainng columns based on rowkey, so ending the Provisioning with Failed status")
        CustomFunctions.hbasePITEndStage(pitTab,"Fail", pitRowKey)
        System.exit(1)
      }
      val feedName = peiRmngColsDF.select("_1").head.getString(0)
      val extractName = peiRmngColsDF.select("_2").head.getString(0)
      val hdrDesc = peiRmngColsDF.select("_3").head.getString(0)
      val hdrDateFormat = peiRmngColsDF.select("_4").head.getString(0)
      val trlDesc = peiRmngColsDF.select("_5").head.getString(0)
      val isJsonProp = peiRmngColsDF.select("_6").head.getString(0)
      val jsonPropFileLoc = peiRmngColsDF.select("_7").head.getString(0)
      val sqlQuery = peiRmngColsDF.select("_8").head.getString(0)
      val transQuery = peiRmngColsDF.select("_9").head.getString(0)
      val trgColumn = peiRmngColsDF.select("_10").head.getString(0)
      val trgDataTypeLen = peiRmngColsDF.select("_11").head.getString(0)
      var outFileName = peiRmngColsDF.select("_12").head.getString(0)
      val outFileExt = peiRmngColsDF.select("_13").head.getString(0)
      val outFileLoc = peiRmngColsDF.select("_14").head.getString(0)
      val archLoc = peiRmngColsDF.select("_15").head.getString(0)
      val isOutFileColDelim = peiRmngColsDF.select("_16").head.getString(0)
      val outFileColDelim = peiRmngColsDF.select("_17").head.getString(0)
      val isFixedWidth = peiRmngColsDF.select("_18").head.getString(0)
      val entitySet = peiRmngColsDF.select("_19").head.getString(0)
      val snapBuildType = peiRmngColsDF.select("_20").head.getString(0)
      val isOutFileRowDelim = peiRmngColsDF.select("_21").head.getString(0)
      val outFileRowDelim = peiRmngColsDF.select("_22").head.getString(0)
      val consumingApp = CustomFunctions.readFeedBasedProperties("common_snapshot",feedName,s"consumingApp",env)
      val inputFileName = CustomFunctions.readFeedBasedProperties("common_snapshot",feedName,s"inputFileName",env)
      val inputFileLocation = CustomFunctions.readFeedBasedProperties("common_snapshot",feedName,s"inputFileLocation",env)
      val srcCd = CustomFunctions.readFeedBasedProperties("common_snapshot",feedName,s"srcCd",env)
      val prtnrCd = CustomFunctions.readFeedBasedProperties("common_snapshot",feedName,s"prtnrCd",env)
      Logger.log.info(s" snapBuildType : "+snapBuildType)
      Logger.log.info(s" ipFileName : "+inputFileName)
      var zipFileName = ""

      //added to handle output file name and zipfilename -starts
      Logger.log.info(s" pei:outFileName value is  : "+outFileName)
      val outFileNamelen = outFileName.split('|').size
      Logger.log.info(s" pei:outFileName number of parts is  : "+outFileName)
      if(outFileNamelen>1)
      {
        zipFileName=outFileName.split('|')(1)
        Logger.log.info(s" Zip File Name value is  : "+zipFileName)
      }
      outFileName=outFileName.split('|')(0)
      Logger.log.info(s" OutFileName value is  : "+outFileName)

      //added to handle output file name and zipfilename -ends

      Logger.log.info(s"----------------- PEI  outFileColDelim value is  : "+outFileColDelim)
      //checking the PE workflow type,
      CustomFunctions.hbasePITInProgressStage(pitTab,pitRowKey,feedName,extractName,outFileColDelim,srcCd,prtnrCd,prcStTm,consumingApp,inputFileName,inputFileLocation,entitySet,outFileRowDelim,outFileLoc,zipFileName)

      //checking the PE workflow type,
      if(snapBuildType.equalsIgnoreCase("raw") || snapBuildType.equalsIgnoreCase("parquet")) {
      RawExtract.getRawExtract(EXTRACT_EIT_FLG,env,zipFileName,snapBuildType,plcTabName,lastrunConfigTab,peiTabName,pscTabName,lakeEitTableName,mountPath,workingDir,lakeEppTableName,entitySet,peiRowKey,prtnrCd,srcCd,incEndTs,pitRowKey,rootDir,snapConfigTab,pitTab,pitTabName,securityfileLoc,allExtractsPitRowKeys)
      //  RawExtract.getRawExtract(env,zipFileName,snapBuildType,plcTabName,lastrunConfigTab,peiTabName,pscTabName,lakeEitTableName,mountPath,workingDir,lakeEppTableName,entitySet,peiRowKey,prtnrCd,srcCd,incEndTs,pitRowKey,rootDir,snapConfigTab,pitTab,pitTabName,securityfileLoc,allExtractsPitRowKeys)
        val isMultiEntity = entitySet.contains(";")
        // Removing of intermediate data
        if (!isMultiEntity) {
          //removing intermediate parquet data
          CustomFunctions.rmPathIfExist(workingDir + "/" + entitySet.toUpperCase)
        } else {
          val entityTabList = entitySet.toUpperCase.split(';')
          Logger.log.info(s"==========>  Multi-Entity( " + entitySet.toUpperCase + " ) Removing of intermediate parquet data <===========")
          entityTabList.foreach { ent =>
            //removing intermediate parquet data
            CustomFunctions.rmPathIfExist(workingDir + "/" + ent.toUpperCase)
          }
        }
      } else if(snapBuildType.equalsIgnoreCase("pjs")){
        Logger.log.info(s"==========> Triggering Prov Extract PJS Snapshot Process for $entitySet <===========")
        //PJSExtract.getPjsGroupInfo(entityMetaDataTabName, entitySet, prtnrCd, srcCd)
        PJSExtractTest.getPJSExtract(plcTabName,lastrunConfigTab,entityMetaDataTabName,entitySet,peiRowKey,prtnrCd,srcCd,incEndTs,pitRowKey,rootDir,peiTabName,pitTab,pitTabName,securityfileLoc,workingDir)
      }
      else{
        Logger.log.info(s"==========> Triggering Prov Extract DataLake Snapshot Process for $entitySet <===========")
        CustomFunctions.generateExtract(plcTabName,lastrunConfigTab,peiRowKey,pitRowKey,rootDir,peiTabName, pitTab,pitTabName,securityfileLoc,workingDir)
      }
      System.out.println("Extract Generation Completed Successfully")
      Logger.log.info(s"==========> Extract Generation Completed Successfully for $entitySet <===========")
    } catch {
      case e: Exception => Logger.log.info(" Exception at <def Main> from PEMain Object" :+ e.getMessage)
        throw e
    }
  }
}