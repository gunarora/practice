package com.uhg.optum.provider
import com.uhg.optum.common.CustomFunctions.{fileSystem, getHtableValByRowKey, hbasePLCPut, hbasePitPut}
import com.uhg.optum.common.{CustomFunctions, Logger}
import org.apache.hadoop.hbase.client.HTable
import java.io._
import java.io.{FileNotFoundException, IOException}

import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}
/**
  * Description : Program to generate the runtime snapshot from a raw data
  */
object RawExtract {

  /* val globalContext = new GlobalContext
   val sparkSession = globalContext.createSparkSession("ProvExtract")
 */
  def getRawExtract (EXTRACT_EIT_FLG:String,env:String,zipFileName:String,snapBuildType:String,plcTabName:String,plcTab:HTable,peiTabName:String,pscTabName:String,lakeEitTableName:String,mountPath:String,workingDir:String,lakeEppTableName:String,entitySet: String, peiRowKey: String, prtnrCd: String, srcCd: String, incEndTs: String, pitRowKey: String,rootDir:String,snapConfigTab:HTable,pitTab:HTable,pitTabName:String,securityfileLoc:String,allExtractsPitRowKeys:String): Unit = {
  //  def getRawExtract (env:String,zipFileName:String,snapBuildType:String,plcTabName:String,plcTab:HTable,peiTabName:String,pscTabName:String,lakeEitTableName:String,mountPath:String,workingDir:String,lakeEppTableName:String,entitySet: String, peiRowKey: String, prtnrCd: String, srcCd: String, incEndTs: String, pitRowKey: String,rootDir:String,snapConfigTab:HTable,pitTab:HTable,pitTabName:String,securityfileLoc:String,allExtractsPitRowKeys:String): Unit = {
    val isMultiEntity = entitySet.contains(";")
    var getSnapRes=""
    var peiFullLoadFlg=""
    var pitRawRowDelim=""
    var pitRawPartnFlr=""
    var pitRawFileCnt=""
    val inputPath = this.getClass.getResourceAsStream("/" + pitRowKey.split("-")(0) + "_Entity_List"+"_"+env)
    var fsConf = new Configuration()
    var fileSystem = FileSystem.get(fsConf)
    //println(inputPath)
    val entityTableList = scala.io.Source.fromInputStream(inputPath).getLines().toList
    var entityNameArr : List[String]=Nil
    for (entDetails <- entityTableList) {
      //print("entity details" + entDetails + "\n")
      val entityArr = entDetails.mkString("").split('|')
      entityNameArr=entityNameArr :+ entityArr(2).trim
    }
    // if the entitySet having more than one entity then invoke the raw snapshot creation for each of the entity else continue for creating raw snapshot for single entity
    if (!isMultiEntity) {
      val rowKeyConfig = peiRowKey + "-" + entitySet.toUpperCase
      Logger.log.info(s"==========>  Single Entity( "+entitySet.toUpperCase+" ) Snapshot creation based on Raw data <===========")
      if(entityNameArr.contains(entitySet) && fileSystem.exists(new Path(workingDir+"/snapshot/"+entitySet))){
        Logger.log.info(s"==========>   Calling for common snapshot for entity: $entitySet <===========")
        CustomFunctions.getCommonSnapshotPerEntity(workingDir,entitySet)
      }else {
        Logger.log.info(s"Calling for new snapshot generation for entity: $entitySet ")
        getSnapRes = CustomFunctions.getSnapshotExtractPerEntity(EXTRACT_EIT_FLG,snapBuildType, plcTabName, plcTab: HTable, pscTabName, lakeEitTableName, mountPath, workingDir, lakeEppTableName, rowKeyConfig, entitySet, prtnrCd, srcCd, incEndTs, pitRowKey, snapConfigTab, pitTab)
        //getSnapRes = CustomFunctions.getSnapshotExtractPerEntity(snapBuildType, plcTabName, plcTab: HTable, pscTabName, lakeEitTableName, mountPath, workingDir, lakeEppTableName, rowKeyConfig, entitySet, prtnrCd, srcCd, incEndTs, pitRowKey, snapConfigTab, pitTab)
        Logger.log.info(s"result from GenSnapshot :: "+getSnapRes)
        peiFullLoadFlg=getSnapRes.split(';')(0)
        pitRawRowDelim=getSnapRes.split(';')(1)
        pitRawPartnFlr=getSnapRes.split(';')(2)
        pitRawFileCnt=getSnapRes.split(';')(3)
        hbasePitPut(pitTab, pitRowKey, "exi", "fullLoadFlg", peiFullLoadFlg)
        hbasePitPut(pitTab, pitRowKey, "fi", "rawRowDelim", pitRawRowDelim)
        hbasePitPut(pitTab, pitRowKey, "fi", "rawPartnFldr", pitRawPartnFlr)
        hbasePitPut(pitTab, pitRowKey, "fi", "rawFileCnt", pitRawFileCnt)
      }

      Logger.log.info(s"==========> Invoking getExtract for single entity <===========")

      CustomFunctions.generateExtract(plcTabName:String,plcTab:HTable,peiRowKey, pitRowKey,rootDir,peiTabName,pitTab,pitTabName,securityfileLoc,workingDir)
      CustomFunctions.hbasePITEndStage(pitTab,"success",pitRowKey)
      //removing intermediate parquet data
      //CustomFunctions.rmPathIfExist(workingDir + "/" + entitySet.toUpperCase)

    } else {
      val entityTabList = entitySet.toUpperCase.split(';')
      Logger.log.info(s"==========>  Multi-Entity( "+entitySet.toUpperCase+" ) Snapshot creation based on Raw data <===========")
      entityTabList.foreach { ent =>
        val rowKeyConfig = peiRowKey + "-" + ent
        if(entityNameArr.contains(ent) && fileSystem.exists(new Path(workingDir+"/snapshot/"+ent))){
          Logger.log.info(s"==========>   Calling for common snapshot for entity: $ent <===========")
          CustomFunctions.getCommonSnapshotPerEntity(workingDir,ent)
        }else {
          Logger.log.info(s"==========>   Snapshot creation for the Entity : $ent  <===========")
          var getSnapRes = CustomFunctions.getSnapshotExtractPerEntity(EXTRACT_EIT_FLG,snapBuildType, plcTabName, plcTab: HTable, pscTabName, lakeEitTableName, mountPath, workingDir, lakeEppTableName, rowKeyConfig, ent, prtnrCd, srcCd, incEndTs, pitRowKey, snapConfigTab, pitTab)
          //var getSnapRes = CustomFunctions.getSnapshotExtractPerEntity(snapBuildType, plcTabName, plcTab: HTable, pscTabName, lakeEitTableName, mountPath, workingDir, lakeEppTableName, rowKeyConfig, ent, prtnrCd, srcCd, incEndTs, pitRowKey, snapConfigTab, pitTab)
          Logger.log.info(s"result from GenSnapshot :: "+getSnapRes)
          var peiFullLoadFlgT=getSnapRes.split(';')(0)
          peiFullLoadFlg = peiFullLoadFlg + peiFullLoadFlgT + ";"

          var pitRawRowDelimT=getSnapRes.split(';')(1)
          pitRawRowDelim = pitRawRowDelim + pitRawRowDelimT + ";"

          var pitRawPartnFlrT=getSnapRes.split(';')(2)
          pitRawPartnFlr = pitRawPartnFlr + pitRawPartnFlrT + ";"

          var pitRawFileCntT=getSnapRes.split(';')(3)
          pitRawFileCnt = pitRawFileCnt + pitRawFileCntT + ";"

        }//removing intermediate parquet data
        //CustomFunctions.rmPathIfExist(workingDir + "/" + ent.toUpperCase)
      }
      Logger.log.info(s"-------peiFullLoadFlg :: "+peiFullLoadFlg)
      Logger.log.info(s"-------pitRawRowDelim :: "+pitRawRowDelim)
      Logger.log.info(s"-------pitRawPartnFlr :: "+pitRawPartnFlr)
      Logger.log.info(s"-------pitRawFileCnt :: "+pitRawFileCnt)
      hbasePitPut(pitTab, pitRowKey, "exi", "fullLoadFlg", peiFullLoadFlg.dropRight(1))
      hbasePitPut(pitTab, pitRowKey, "fi", "rawRowDelim", pitRawRowDelim.dropRight(1))
      hbasePitPut(pitTab, pitRowKey, "fi", "rawPartnFldr", pitRawPartnFlr.dropRight(1))
      hbasePitPut(pitTab, pitRowKey, "fi", "rawFileCnt", pitRawFileCnt.dropRight(1))
      Logger.log.info(s"==========> Invoking getExtract for Multi-Entity  <===========")
      CustomFunctions.generateExtract(plcTabName:String,plcTab,peiRowKey, pitRowKey,rootDir,peiTabName,pitTab,pitTabName,securityfileLoc,workingDir)

      CustomFunctions.hbasePITEndStage(pitTab,"success",pitRowKey)
    }
    val lastRunDtAsProvStrTs = getHtableValByRowKey(pitTabName: String, pitRowKey: String, "exi", "provStrTs")
    //added for common query.. shfted from meta file creation
    val plcRowKey = peiRowKey
    Logger.log.info(" PIT ProvStrTs AS lastRunDt : " + lastRunDtAsProvStrTs)
    hbasePLCPut(plcTab, plcRowKey, "plc", "lastRunDt", lastRunDtAsProvStrTs)
    CustomFunctions.extractDuration(zipFileName,peiRowKey,allExtractsPitRowKeys,pitTabName,pitRowKey)

  }
}
