package com.uhg.optum.common

import java.io._
import java.text.SimpleDateFormat
import java.time.format.DateTimeFormatter
import java.time.{LocalDateTime, ZoneId, ZoneOffset}
import java.util.{Calendar, Properties}

import com.mapr.db.spark._
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, FileUtil, Path}
import org.apache.hadoop.hbase.client.{Get, HTable, Result, _}
import org.apache.hadoop.hbase.filter.CompareFilter.CompareOp
import org.apache.hadoop.hbase.filter.{BinaryComparator, RowFilter, _}
import org.apache.hadoop.hbase.io.ImmutableBytesWritable
import org.apache.hadoop.hbase.mapreduce.TableInputFormat
import org.apache.hadoop.hbase.util.Bytes
import org.apache.hadoop.hbase.{CellUtil, HBaseConfiguration, TableName}
import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{DataFrame, Row, SaveMode}
/*import com.itextpdf.text._
import com.itextpdf.text.pdf.PdfWriter*/
import scala.collection.mutable.ListBuffer
import scala.io.Source


/**
  * Description : Added custom functions / reusable components  based on the business use case
  */
object CustomFunctions {

  val metastoreUri = DPOConstants.METAURI
  val appName = DPOConstants.PEIROWKEY
  Logger.log.info(s" Value for metastoreUri in CustomFunctions  : $metastoreUri")
  val globalContext = new GlobalContext
  // Below line is commented to keep uniformity of using 1 spark-session
  val sparkSession = globalContext.createSparkSession(appName,metastoreUri)
  val sqlContext = sparkSession.sqlContext

  val hBaseConf: org.apache.hadoop.conf.Configuration = HBaseConfiguration.create()
  val selectStKeyWd = "SELECT".trim()
  val tabDelim = "\t"
  private var fsConf = new Configuration()
  private var fileSystem = FileSystem.get(fsConf)

  /*PJS Functions starts*/
  //Purpose : Def to get current date in a specific format
  def getCurrentDateFormat: String = getCurrentDateTime("yyyy-MM-dd")

  /** Purpose : Def to load json data from the MaprDB table
    * input : path of the MaprDB table
    * output: json data from the MaprDB table in the form of DataFrame */
  def loadFromMapRDBTbl (denormSnapshotEntityName: String): org.apache.spark.sql.DataFrame = {
    Logger.log.info(s"STARTS : Loading of Json data from the PJS MapRDB Table $denormSnapshotEntityName")
    var readJsonDF: org.apache.spark.sql.DataFrame = sparkSession.emptyDataFrame;
    try {
      val pjsSnap = globalContext.spark.loadFromMapRDB(denormSnapshotEntityName).map(a => a.toString())
      readJsonDF = sparkSession.read.json(pjsSnap)
    } catch {
      case e: Exception => Logger.log.info("Exception at executing loadFromMapRDBTbl " :+ e.getMessage)
        throw e
    }
    Logger.log.info(s"ENDS : Loading of Json data from the PJS MapRDB Table $denormSnapshotEntityName")
    readJsonDF
  }

  /** Purpose : Def to get details from entityMetaDataTable for the given prtnrCd, srcCd and GroupName which should be active
    * input : partner Code, source Code, GroupName and EntityMetaData Hbase Table
    * output: denormSnapshotEntityName containing the MapRDB table Path */
  def getEntityMetaDataInfo (prtnrCd: String, srcCd: String, grpNm: String, entityMetaDataTab: String): String = {

    Logger.log.info(s"STARTS : getting the EntityMetaDataInfo for the group $grpNm")

    /*
    val prtnrCd="uhG"
    val srcCd="ndb"
    val grpNm="provider"
    //      val grpNm=args( 0 ).trim
    */ var denormSnapshotEntityName = ""
    val rowKeyConfig = prtnrCd + "-" + srcCd
    val scan = new Scan()
    try {
      val filter = new PrefixFilter(Bytes.toBytes(rowKeyConfig))
      val filter1 = new SingleColumnValueFilter(Bytes.toBytes("ci"), Bytes.toBytes("denormSnapshot"), CompareOp.EQUAL, Bytes.toBytes(s"${grpNm}"));
      val filter2 = new SingleColumnValueFilter(Bytes.toBytes("ci"), Bytes.toBytes("activeflag"), CompareOp.EQUAL, Bytes.toBytes("Y"));
      scan.setCaching(10000)
      scan.setCacheBlocks(false)
      filter1.setFilterIfMissing(true)
      filter2.setFilterIfMissing(true)
      scan.setFilter(filterList(filter1, filter2, filter))

      val grpVal = globalContext.hbaseContext.hbaseRDD(TableName.valueOf(entityMetaDataTab), scan).cache
      val grpInfo = grpVal.map(tuple => {
        val result = tuple._2
        (Bytes.toString(result.getValue(Bytes.toBytes("ci"), Bytes.toBytes("denormSnapshotEntityName"))), (Bytes.toString(result.getValue(Bytes.toBytes("ci"), Bytes.toBytes("sourceEntityName")))))
      })
      print(grpInfo.count())
      Logger.log.info(s" Group count : ${grpInfo.count()} ")
      if (!grpInfo.isEmpty) {
        //val denormSnapshotEntityName="/datalake/uhclake/tst/t_hdfs/uhg/Enriched/standard_access/pjs/ndb/data/provider_snapshot"
        /*val denormSnpEntList = grpInfo.first.map(x => (x._1, x._2)).collect.toList.map(x => (x._1, s"${x._2}"))
      val pjsRdd = globalContext.spark.parallelize(denormSnpEntList)
      val pjsArrayRdd = pjsRdd.groupByKey.mapValues(_.mkString(","))
      val denormSnapshotEntityName = pjsArrayRdd.map(kv => {kv._1})
           val entList = pjsArrayRdd.map(kv => {kv._2})
      try {
        val df1 = globalContext.spark.loadFromMapRDB(s"${denormSnapshotEntityName.first.toString}").map(line => line.toString());
        val readJson = sqlContext.read.json(df1)
     readJson.printSchema()
      readJson.show(10, false)
      readJson.createOrReplaceTempView(s"${grpNm}")
      val getRes = sqlContext.sql("select * from provider")
        println(getRes.count)
      }
      catch {
        case e: Exception => Logger.log.info("Exception at executing loadFromMapRDB " :+ e.getMessage)
          throw e
      }
      */ denormSnapshotEntityName = grpInfo.first._1
      } else {
        Logger.log.info(s"ERROR: not able to retrieve values from $entityMetaDataTab for group : $grpNm")

      }
      Logger.log.info(s"OUTPUT : denormSnapshotEntityName: $denormSnapshotEntityName")
      Logger.log.info(s"ENDS : getting the EntityMetaDataInfo for the group $grpNm")
    } catch {
      case e: Exception => Logger.log.info(s"Exception at getting EntityMetaDataInfo for the group $grpNm" + e.getMessage)
        throw e
    }
    denormSnapshotEntityName
  }

  /** Purpose : Def to consolidate the data for a particular entity and  register its as a temp View
    * input : DataFrame containing th loaded Json Data and entityname
    * output: registered tempView for the particular entity */
  def genPJSExtractPerEnt (readJsonDF: org.apache.spark.sql.DataFrame, entity: String): Boolean = {
    var genPJSExtractPerEntFlg: Boolean = false
    Logger.log.info(s"STARTS : consolidating and registering temp view for the entity : $entity")
    try {
      readJsonDF.columns.filter(t => t == s"${entity}").map(x => x.mkString).foreach(a => {
        val entName = a.toString;
        Logger.log.info("Entity / Table Name : " + entName)
        if (entName != "_id" && entName != "doc_crt_ts") {
          var colNameRes = "";
          val entityDType = readJsonDF.select(entName).schema.map(_.dataType.typeName).take(1).mkString; //val tempMaprDBVw = readJsonDF.select(entName).createOrReplaceTempView("maprdbview");
          if (entityDType.equals("array")) {
            Logger.log.info("datatypeof the Json  is array")
            val rt = readJsonDF.select(col(entName).getItem(0)).toDF("xdf").createOrReplaceTempView("maprdbview");
            colNameRes = "xdf"
            Logger.log.info("column to be considered for array type is : " + colNameRes)
          } else {
            colNameRes = entName
            val tempMaprDBVw = readJsonDF.select(entName).createOrReplaceTempView("maprdbview");
            Logger.log.info("datatype of the Json is struct")
            Logger.log.info("column to be considered for array type is : " + colNameRes)
          }
          var entitySelectStr = "select " + colNameRes.toString + ".* from maprdbview";
          Logger.log.info("CONSTRUCTED SQL String to create Entity specific dataframe with respective columns   : " + entitySelectStr);
          var colNameDF = sparkSession.sql(entitySelectStr)
          colNameDF.createOrReplaceTempView(entName);
          Logger.log.info("Created Temp View called " + entName + "for the  Entity(" + entName + ")");
          Logger.log.info("Retrieving Data from Temporary View");

          Logger.log.info("Count is ::: "+colNameDF.count());
          // val getRes = sparkSession.sql("select count(*) from " + entName).show(false);
          //Logger.log.info("Count of "+entName+"is ::: "+getRes.count());
          genPJSExtractPerEntFlg = true
        }
        //getRes.write.format("csv").mode(SaveMode.Overwrite).option("delimiter", "|").save("/datalake/uhclake/tst/developer/vshrest1/SparkCode/"+colName)
      })
    } catch {
      case e: Exception => Logger.log.info(s"Exception at genrating and registering the temp view for entity : " + entity + " :::" + e.getMessage)
        throw e

    }
    Logger.log.info(s"ENDS : consolidating and registering temp view for the entity : $entity")
    genPJSExtractPerEntFlg
  }

  /// PJS Functions ends
  //Purpose : Def to get current time in a specific format
  def getCurrentTimeFormat: String = getCurrentDateTime("yyyy-MM-dd HH:mm:ss")

  //Purpose : Def to get current time in a specific format
  def getCurrentTsFormat: String = getCurrentDateTime("yyyyMMddHHmmssSS").substring(0, 16)

  /** Purpose : Def to get current date/time in a specified format
    * input : dateField
    * output: Returns DateField as specified format */
  def getCurrentDateTime (dateTimeFormat: String): String = {
    val dateFormat = new SimpleDateFormat(dateTimeFormat)
    val cal = Calendar.getInstance()
    dateFormat.format(cal.getTime)
  }


  /** Purpose : Def to get current date/time in a specified format
    * input : dateField
    * output: Returns DateField as specified format */
  def getTimestamp (DateFormat: String): Long = {
    try {
      val timestampformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
      timestampformat.parse(DateFormat).getTime
    } catch {
      case e: Exception => Logger.log.info(" Exception while getting current date/time" :+ e.getMessage)
        0
    }
  }

  /** Purpose : Def to get the list of directories from MapR FileSystem
    * input : path of the folder
    * output: Returns List which includes the list of directories present in the given path */
  def getListOfFiles (dir: String): List[File] = {
    val d = new File(dir)
    if (d.exists && d.isDirectory) {
      d.listFiles.toList
    } else {
      List[File]()
    }
  }

  /** Purpose : Def to get the latest direcory based on the creation date from MapR FileSystem folder path
    * input : path of the folder(which includes /mapr
    * output: Returns the  last modified directory name */
  def getLastModifiedDir (dirPath: String): String = {
    Logger.log.info(s" Path : " + dirPath)
    var dataPath = dirPath
    if (!dirPath.contains("/mapr/")) {
      dataPath = dirPath.replace("/datalake/", "/mapr/datalake/")
    }
    val files = getListOfFiles(dataPath)
    Logger.log.info(s" List f files inside the Path : " + files)
    files.maxBy(_.lastModified).toString.replace("/mapr", "")

  }


  /** Purpose : Def to create folder(s)/directories in MapR FileSystem
    * input : path of the folder
    * output: Given folder path should be created in FileSystem */
  def mkdirs (folderPath: String): Unit = {
    try {
      Logger.log.info(s" Created Path : " + folderPath)
      fileSystem.mkdirs(new Path(folderPath))

    } catch {
      case e: Exception => Logger.log.info(" Exception at mkdirs definition" :+ e.getStackTrace.toString)
        throw e
    }
  }


  /** Purpose : Def to get the duration in  seconds
    * input : two dates
    * output: returns duration */
  def getDuration (endDate: String, startDate: String): String = {
    val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")
    val startDatefrmt = LocalDateTime.parse(startDate, formatter)
    val endDatefrmt = LocalDateTime.parse(endDate, formatter)
    //val zoneId = ZoneId.systemDefault
    val zoneId = ZoneId.ofOffset("UTC", ZoneOffset.ofHours(0))
    (endDatefrmt.atZone(zoneId).toEpochSecond() - startDatefrmt.atZone(zoneId).toEpochSecond()).toString
    //println(newDate.toEpochDay() - oldDate.toEpochDay())
  }


  /** Purpose : Def to update the PIT htable as per the InProgress Stage
    * input : PIT RowKey, feedName, extractName, outputFileColDelim, sourceCode,partenerCode, processStartTime
    * output: PIT RowKey respective column(s) data should be updated in PIT htable */
  def hbasePITInProgressStage (pitTab: HTable, pitRowKey: String, feedName: String, extractName: String, outFileColDelim: String, srcCd: String, prtnrCd: String, prcStTm: String,consumingApp: String,inputFileName: String,inputFileLocation: String,entitySet: String,outFileRowDelim: String,outFileLoc: String,zipFileName: String): Unit = {

    Logger.log.info("=============> Updating PIT table status to inProgress   <=============")
    hbasePitPut(pitTab, pitRowKey, "exi", "provCompSts", "inProgress")

    Logger.log.info(s" Updating PIT table for the column : provCompSts as inProgress , cf : exi, RowKey : $pitRowKey ")
    hbasePitPut(pitTab, pitRowKey, "fi", "provFeedName", feedName)
    Logger.log.info(s" Updating PIT table for the column : provFeedName as $feedName , cf : fi, RowKey : $pitRowKey ")

    hbasePitPut(pitTab, pitRowKey, "fi", "provExtractName", extractName)
    Logger.log.info(s" Updating PIT table for the column : provExtractName as $extractName , cf : fi, RowKey : $pitRowKey ")

    hbasePitPut(pitTab, pitRowKey, "fi", "provOutFileColDelim", outFileColDelim)
    Logger.log.info(s" Updating PIT table for the column : provOutFileColDelim as $outFileColDelim , cf : fi, RowKey : $pitRowKey ")

    /* hbasePitPut(  eitRowKey, "fi", "provOutFileRowDelim", curExtOutFileRowDelim )
     Logger.log.info( s" Updating PIT table for the column : provOutFileRowDelim as $curExtOutFileRowDelim , cf : fi, RowKey : $pitRowKey " )
*/
    hbasePitPut(pitTab, pitRowKey, "fi", "srcCd", srcCd)
    Logger.log.info(s" Updating PIT table for the column : srcDd as $srcCd , cf : fi, RowKey : $pitRowKey ")

    hbasePitPut(pitTab, pitRowKey, "fi", "prtnCd", prtnrCd)
    Logger.log.info(s" Updating PIT table for the column : prtnCd as $prtnrCd , cf : fi, RowKey : $pitRowKey ")

    /*    hbasePitPut(pitTab, pitRowKey, "fi", "dataownr", "TBD")
        Logger.log.info(s" Updating PIT table for the column : dataownr as TBD , cf : fi, RowKey : $pitRowKey ")*/

    hbasePitPut(pitTab, pitRowKey, "fi", "consumingApp", consumingApp)
    Logger.log.info(s" Updating PIT table for the column : consumingApp as $consumingApp , cf : fi, RowKey : $pitRowKey ")
    hbasePitPut(pitTab, pitRowKey, "fi", "inputFileName", inputFileName)
    Logger.log.info(s" Updating PIT table for the column : inputFileName as $inputFileName , cf : fi, RowKey : $pitRowKey ")
    hbasePitPut(pitTab, pitRowKey, "fi", "inputFileLocation", inputFileLocation)
    Logger.log.info(s" Updating PIT table for the column : inputFileLocation as $inputFileLocation , cf : fi, RowKey : $pitRowKey ")
    hbasePitPut(pitTab, pitRowKey, "fi", "entitySet", entitySet)
    Logger.log.info(s" Updating PIT table for the column : entitySet as $entitySet , cf : fi, RowKey : $pitRowKey ")
    var outFileRowDelimTmp=outFileRowDelim
    if(outFileRowDelimTmp == "NA")
    {
      outFileRowDelimTmp="\\n"
      Logger.log.info(s" Updating PIT table with Default valuefor the column : provOutFileRowDelim as $outFileRowDelimTmp , cf : fi, RowKey : $pitRowKey ")
    }
    else{
      Logger.log.info(s" Updating PIT table for the column : provOutFileRowDelim as $outFileRowDelimTmp , cf : fi, RowKey : $pitRowKey ")
    }
    hbasePitPut(pitTab, pitRowKey, "fi", "provOutFileRowDelim", outFileRowDelimTmp)

    hbasePitPut(pitTab, pitRowKey, "fi", "provOutFileLoc", outFileLoc)
    Logger.log.info(s" Updating PIT table for the column : provOutFileLoc as $outFileLoc , cf : fi, RowKey : $pitRowKey ")

    hbasePitPut(pitTab, pitRowKey, "fi", "provOutFileNm", zipFileName)
    Logger.log.info(s" Updating PIT table for the column : provOutFileNm as $zipFileName , cf : fi, RowKey : $pitRowKey ")

  }

  /** Purpose : Def to update the PIT htable as per the Initial Stage
    * input : PIT RowKey, processStartTime
    * output: PIT RowKey respective column(s) data should be updated in PIT htable */
  def hbasePITInitialStage (pitTab: HTable, pitRowKey: String, prcStTm: String,dataownr:String): Unit = {

    Logger.log.info("=============> Updating PIT table before hitting to PEI & Snapshot Config table in Hbase <=============")
    hbasePitPut(pitTab, pitRowKey, "exi", "provCompSts", "registered")
    Logger.log.info(s" Updating PIT table for the column : provCompSts as Registered , cf : exi, RowKey : $pitRowKey ")

    hbasePitPut(pitTab, pitRowKey, "exi", "provStrTs", prcStTm)
    Logger.log.info(s" Updating PIT table for the column : provStrTs as $prcStTm , cf : exi, RowKey : $pitRowKey ")

    hbasePitPut(pitTab, pitRowKey, "exi", "provExecTrkId", pitRowKey)
    Logger.log.info(s" Updating PIT table for the column : provExecTrkId as $pitRowKey , cf : exi, RowKey : $pitRowKey ")
    hbasePitPut(pitTab, pitRowKey, "fi", "dataownr", dataownr)
    Logger.log.info(s" Updating PIT table for the column : dataownr as $dataownr , cf : fi, RowKey : $pitRowKey ")
  }

  /** Purpose : Def to filter htable with given filtersList
    * input : filters list
    * output: returns filtered Htable */
  def filterList (filters: Filter*) = new FilterList(FilterList.Operator.MUST_PASS_ALL, filters: _*)

  /** Purpose : Def to get the schema versions from Datalake EPP htable
    * input : LakeEPP RowKey i.e sourceCode, partnerCode, entityName
    * output: Returns LakeEPP RowKey respective Schemaversions RDD */
  def getEppLakeTabSchma (eppTab: String, patnrCd: String, srcCd: String, entNm: String): org.apache.spark.rdd.RDD[(String, String)] = {
    try {
      //val eppTableName = "/datalake/uhclake/prd/p_mtables/entity_partner_profile"
      //   val eppTab = globalContext.lakeEppTableName
      Logger.log.info(s" Scanning EPP HBase Table $eppTab for Entity: $entNm")
      val rdd = globalContext.spark.parallelize(Array(Bytes.toBytes(s"${patnrCd}-${srcCd}-${entNm}")))
      val getRdd = globalContext.hbaseContext.bulkGet[Array[Byte], List[(String, String)]](TableName.valueOf(eppTab), 2, rdd, record => {
        val get = new Get(record)
        get.setMaxVersions(99)
      }, (result: Result) => {
        val it = result.listCells().iterator()
        var schver = new ListBuffer[String]()
        var schm = new ListBuffer[String]()
        while (it.hasNext) {
          val cell = it.next()
          val q = Bytes.toString(CellUtil.cloneQualifier(cell))
          if (q.equals("schmVer")) schver += Bytes.toString(CellUtil.cloneValue(cell)) else if (q.equals("schm")) schm += Bytes.toString(CellUtil.cloneValue(cell))
        }
        (schver zip schm).toList
      })
      getRdd.flatMap(x => x)
    } catch {
      case e: Exception => Logger.log.info(" Exception at saveDFversionTables" :+ e.getMessage)
        throw e
    }
  }


  /** Purpose : Def to save Dataframe to resultant location, Also renaming the outfile with given name instead of part-00000
    * input : DataFrame, outputLocation, outputFileName
    * output: Output file should be created in specified location with specified filename */
  def saveFileToMapRFS (ExtDF: DataFrame, outFileLoc: String, curExtOutFileName: String,outFileColDelim: String): Unit = {

    val outLoc = outFileLoc.replace("/mapr/", "/")
    mkdirs(outLoc)
    //Logger.log.info(s" Displaying first 20records after Sorting  if any : ${resDF.show()}")
    Logger.log.info(s" Saving DF to /mapr$outLoc/$curExtOutFileName  =")

    /*ExtDF.repartition(1).write.mode("overwrite")
      .option("delimiter", outFileColDelim).option("timestampFormat", "yyyy-MM-dd'T'HH:mm:ss.SSSZZZZZ")
      .csv(outLoc)*/
    ExtDF.repartition(1).write.mode("overwrite")
      .option("delimiter", outFileColDelim)
      .csv(outLoc)
    //by using this step , the temporary output .csv file will be renamed to curExtOutFileName
    val savedFileName = fileSystem.globStatus(new Path(outLoc + "/*.csv"))(0).getPath.getName
    Logger.log.info(s" Data DF file Name before renaming " + savedFileName)
    //renamePath(outLoc + "/part*", outLoc + "/" + curExtOutFileName)
    renamePath(outLoc + "/" + savedFileName, outLoc + "/" + curExtOutFileName)
    Logger.log.info(s" Renamed DF part output to  $outLoc/$curExtOutFileName")
    rmPathIfExist(outLoc + "/_SUCCESS")
    getTotalLines(outLoc + "/" + curExtOutFileName)

  }

  /** Purpose : Def to get file name dynamically saved by spark context
    * input : Directory path
    * output : file name
    */
  def getSavedFileName (outFileLoc: String): String = {
    val savedFileName = fileSystem.globStatus(new Path(outFileLoc + "/p*"))(0).getPath.getName
    savedFileName
  }

  /** Purpose : Def to save the EPP Htable schema versions results into spark dataframe with parquet file format
    * input : schemaVersion(s), schema, filesList, entityName, sparkConfiguration
    * output: DF should be created and saves resultant versions in the form of parquet */
  def saveToDataFrame (workingDir: String, schmVer: String, schm: String, fileList: String, entNm: String, sparkConfig: SparkContext): Unit = {
    try {
      val jsonFile = schm.split("(?<=\\}),(?=\\{)")
      val jsonRddSchm = globalContext.spark.parallelize(jsonFile)
      val jsonRdd = sqlContext.read.json(jsonRddSchm).rdd.map(x => (x(1).toString)).collect.toList
      val fields = jsonRdd.map(fieldName => StructField(fieldName, StringType, nullable = true))
      val schema = StructType(fields) //
      val loadFiles = sparkConfig.textFile(fileList).map(_.split("\u0001", -1)).map(x => Row(x: _*))
      val verDf = sqlContext.createDataFrame(loadFiles, schema)
      //val workingDir = globalContext.workingDir
      verDf.write.mode(SaveMode.Append).parquet(s"$workingDir/${entNm.toUpperCase()}")
    } catch {
      case e: Exception => Logger.log.info(" Exception at saveDFversionTables" :+ e.getMessage)
        throw e
    }
  }

  /** Purpose : Def to get DataLake EIT Htable data based on rowkey provided
    * input : Lake EIT RowKey i.e. partnerCode, sourceCode, entityName , lastRunDateFlag, incrementalStartTime,incrementalEndTime, application PIT rowKey
    * output: Returns boolean value, if Lake EIT RowKey respective data found then 0 else 1 */
  def eitLakeTabScan (snapBuildType:String,eitTable: String, mountPath: String, eppTable: String, workingDir: String, patnrCd: String, srcCd: String, entNm: String, lstrundateFlg: Boolean, incStTime: String, incEndTs: String, pitRowKey: String, pitTab: HTable): String = {
    try {
      //val eitTable = globalContext.lakeEitTableName
      val ptnr = s"${patnrCd}".toUpperCase
      val src = s"${srcCd}".toUpperCase
      //val mountPath = globalContext.mountPath
      val raw_path = s"maprfs://$mountPath/${ptnr.toLowerCase}/raw/standard_access/${src.toLowerCase}/data/"
      val entName = s"${entNm}".toUpperCase
      Logger.log.info(s" Retrieving Files for $entName from Raw: $raw_path")
      Logger.log.info(s" Processing Entity:${entName} with patnrCd:${ptnr} srcCd:${src}")
      Logger.log.info(s" Scanning Eit HBase Table: $eitTable")
      var startTime = ""
      if (incStTime.isEmpty) {
        Logger.log.info(s" Incremental start time($incStTime) is empty , so overriding startTime with incEndTm to  $incEndTs")
        startTime = s"$incEndTs"
      } else {
        Logger.log.info(s" Incremental start time($incStTime) is not empty , so overriding startTime with incStTime  $incEndTs")
        startTime = s"$incStTime"
      }

      val endTime = s"$incEndTs"
      Logger.log.info(s" Endtime : $incEndTs ")
      Logger.log.info(s" startTime : $startTime ")
      Logger.log.info(s" Capturing if any Changes reflected for $entName from $startTime to $endTime")
      val rowKey = s"${ptnr}-${src}-${entName}"
      val sppRowKey = s"${ptnr}-${src}"
      var pitRawPartnFlr=""
      var pitRawRowDelim=""
      var pitRawFileCnt=""

      if (snapBuildType.equalsIgnoreCase("parquet")) {
        try {
          Logger.log.info(s" starting EIT scan for Parquet files")
          import org.apache.hadoop.hbase.client.Scan
          val scan = new Scan()
          val filter = new PrefixFilter(Bytes.toBytes(s"${ptnr}-${src}-${entName}-"))
          //val filter1 = new SingleColumnValueFilter(Bytes.toBytes("exi"), Bytes.toBytes("ingProcLogSts"), CompareOp.EQUAL, Bytes.toBytes("Success")); //val filter2 = new SingleColumnValueFilter(Bytes.toBytes("fi"), Bytes.toBytes("iscustrowdelim"), CompareOp.EQUAL, Bytes.toBytes("No"));
          val filter1 = new SingleColumnValueFilter(Bytes.toBytes("exi"), Bytes.toBytes("ingProcLogSts"), CompareOp.EQUAL, Bytes.toBytes("Success")); //val filter2 = new SingleColumnValueFilter(Bytes.toBytes("fi"), Bytes.toBytes("iscustrowdelim"), CompareOp.EQUAL, Bytes.toBytes("No"));
          //check//val filter1 = new SingleColumnValueFilter(Bytes.toBytes("exi"), Bytes.toBytes("ingProcLogSts"), CompareOp.NOT_EQUAL, Bytes.toBytes("Registered")); //val filter2 = new SingleColumnValueFilter(Bytes.toBytes("fi"), Bytes.toBytes("iscustrowdelim"), CompareOp.EQUAL, Bytes.toBytes("No"));
          import org.apache.hadoop.hbase.filter.CompareFilter.CompareOp
          scan.setCaching(10000)
          scan.setCacheBlocks(false)
          filter1.setFilterIfMissing(true)
          scan.setFilter(filterList(filter1, filter))
          if (lstrundateFlg) {
            scan.setTimeRange(getTimestamp(startTime), getTimestamp(endTime))
          }

          val eitVal = globalContext.hbaseContext.hbaseRDD(TableName.valueOf(eitTable), scan).cache
          Logger.log.info(s" DL eitVal count : ${eitVal.count()} ")
          val eitInfo = eitVal.map(tuple => {
            val result = tuple._2
            //(Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("schmVer"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("ingstdFileNm"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("entprtnfldr"))))
            (Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("schmVer"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("entprtnfldr"))))
          })


          if (lstrundateFlg) {
            Logger.log.info(s" Number of Entries Captured for $entName from EIT SCAN b/w $startTime and $endTime :" + eitVal.count())
          } else {
            Logger.log.info(s" Number of Entries Captured for $entName from EIT SCAN full load :" + eitVal.count())
          }

          if (!eitInfo.isEmpty) {
            val eitFileList = eitInfo.map(x => (x._1, x._2)).collect.toList.map(x => ( s"${raw_path}${entNm}/${x._2}")).distinct
            //val eitRawFileList = eitFileList.filter(x => filterRawFileExist(x))
            val eitRawFileListNtEmp = eitFileList.filter(x => isEmptyDir(x))

            Logger.log.info(s" Number of PARQUET Files exist in Raw for $entName from EIT SCAN b/w $startTime and $endTime :" + eitRawFileListNtEmp.length)
            Logger.log.info(s" List of PARQUET Files from Raw : ${eitRawFileListNtEmp.mkString}")
            val eitRdd = globalContext.spark.parallelize(eitRawFileListNtEmp)

            eitRdd.collect.map(x => saveToDataFrameP("PARQUET", workingDir, x, entName))
            pitRawRowDelim="NA|"
            pitRawPartnFlr="NA|"
            pitRawFileCnt="NA|"


            /*
                        val eitFileList = eitInfo.map(x => (x._1, x._3, x._2)).collect.toList.map(x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._2}/${x._3}"))
                        val eitRawFileList = eitFileList.filter(x => filterRawFileExist(x._2))

                        Logger.log.info(s" Number of PARQUET Files exist in Raw for $entName from EIT SCAN b/w $startTime and $endTime :" + eitRawFileList.length)
                        Logger.log.info(s" List of PARQUET Files from Raw : ${eitRawFileList.mkString}")
                        val eitRdd = globalContext.spark.parallelize(eitRawFileList)
                        val eitFileRdd = eitRdd.groupByKey.mapValues(_.mkString(","))
                        eitFileRdd.collect.map(x => saveToDataFrameP(x._1, workingDir, x._2, entName))*/
            // eitFileList.map(x => saveToDataFrameP(x._1, workingDir, x._2, entName))

            eitVal.unpersist()
            "true;"+entName+"-"+pitRawRowDelim+";"+entName+"-"+pitRawPartnFlr+";"+entName+"-"+pitRawFileCnt;
          } else {
            Logger.log.info(s" Since, No Changes Captured for $entName from $startTime to $endTime, datasets will not be generated")
            "false;"+entName+"-ERROR|;"+entName+"-ERROR|;"+entName+"-ERROR|";
          }


        } catch {
          case e: Exception => Logger.log.info(s" Exception while Scanning Files from DL EIT for $entNm" :+ e.getStackTrace.mkString)
            hbasePITEndStage(pitTab, "Fail", pitRowKey)
            throw e
        }
      }
      else{
        Logger.log.info(s" starting EIT scan for dat files")
        var rsltFlg1=false
        var rsltFlg2=false

        try {
          import org.apache.hadoop.hbase.client.Scan
          val eppRdd: org.apache.spark.rdd.RDD[(String, String)] = getEppLakeTabSchma(eppTable, ptnr, src, entName).cache
          Logger.log.info(s" scanning EIT for isCustRowlim as No for dat files")
          val scan_N = new Scan()
          val filter_N = new PrefixFilter(Bytes.toBytes(s"${ptnr}-${src}-${entName}-"))
          val filter1_N = new SingleColumnValueFilter(Bytes.toBytes("exi"), Bytes.toBytes("ingProcLogSts"), CompareOp.EQUAL, Bytes.toBytes("Success"));
          val filter2_N = new SingleColumnValueFilter(Bytes.toBytes("fi"), Bytes.toBytes("iscustrowdelim"), CompareOp.EQUAL, Bytes.toBytes("No"));
          scan_N.setCaching(10000)
          scan_N.setCacheBlocks(false)
          filter1_N.setFilterIfMissing(true)
          filter2_N.setFilterIfMissing(true)
          scan_N.setFilter(filterList(filter1_N, filter_N,filter2_N))

          if (lstrundateFlg) {
            scan_N.setTimeRange(getTimestamp(startTime), getTimestamp(endTime))
          }

          val eitVal_N = globalContext.hbaseContext.hbaseRDD(TableName.valueOf(eitTable), scan_N).cache
          Logger.log.info(s" DL eitVal count with isCustRowlim as No is  : ${eitVal_N.count()} ")

          if(eitVal_N.count()>0){
            val eitInfo = eitVal_N.map(tuple => {
              val result = tuple._2
              (Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("schmVer"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("srcFileNm"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("entprtnfldr"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("iscustrowdelim"))))
            })
            val isCustDelim = eitInfo.map(kv => {
              kv._4
            }).first.toString

            Logger.log.info(s" Processing ${entName} Files with Delimiter: \\n as isCustDelim is ${isCustDelim}")
            if (lstrundateFlg) {
              Logger.log.info(s" Number of Entries Captured for $entName from EIT SCAN b/w $startTime and $endTime :" + eitVal_N.count())
            } else {
              Logger.log.info(s" Number of Entries Captured for $entName from EIT SCAN full load :" + eitVal_N.count())
            }
            if (!eitInfo.isEmpty) {
              //  val eitFileList: List[(String, String)] = eitInfo.collect.toList.map(x => (x, s"${raw_path}${entName}/${entName}.v${x}//*"))
              //val eitFileList = eitInfo.map(x => (x._1,x._3, x._2)).collect.toList.map(x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._2}/${x._3}"))

              val eitFileListT = eitInfo.map(x => (x._1,x._3, x._2)).collect.toList
              val eitFileList = eitFileListT.map(x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._2}/${x._3}"))


              val eitRawFileList = eitFileList.filter(x => filterRawFileExist(x._2))
              Logger.log.info(s" Number of Files exist in Raw with \\n record delim for $entName from EIT SCAN b/w $startTime and $endTime :" + eitRawFileList.length)

              val eitPartnFlr=eitFileListT.map(x=> (x._2,1))
              val eitPartnFlrCnt= globalContext.spark.parallelize(eitPartnFlr).reduceByKey(_+_).collect().mkString("~")
              pitRawFileCnt=pitRawFileCnt+"\n-"+eitRawFileList.length+"|"
              pitRawRowDelim=pitRawRowDelim+"\n|"
              pitRawPartnFlr=pitRawPartnFlr+"\n-"+eitPartnFlrCnt+"|"

              Logger.log.info(s" List of Files from Raw with \\n record delim: ${eitRawFileList.mkString}")
              val eitRdd = globalContext.spark.parallelize(eitRawFileList)
              val eitFileRdd = eitRdd.groupByKey.mapValues(_.mkString(","))
              //  val eppRdd: org.apache.spark.rdd.RDD[(String, String)] = getEppLakeTabSchma(eppTable, ptnr, src, entName).cache
              Logger.log.info(s" Number of Schema Versions for ${entName} retrieved from EPP HBase Table:" + eppRdd.count())
              val sparkConfig = globalContext.spark
              eppRdd.join(eitFileRdd).collect.foreach { case (schmVer, (schm, fileList)) => saveToDataFrame(workingDir, schmVer, schm, fileList, entName, sparkConfig)
              }
              eitVal_N.unpersist()
              //  eppRdd.unpersist()
              rsltFlg1=true
            } else {
              Logger.log.info(s" Since, No Changes Captured for $entName from $startTime to $endTime, datasets will not be generated")
              rsltFlg1=false
            }
          }
          else
          {
            Logger.log.info(s" since DL eitVal count with isCustRowlim as No is  : ${eitVal_N.count()} , skipping the process")
            rsltFlg1=false
          }


          Logger.log.info(s" scanning EIT for isCustRowlim as Yes for dat files")
          val scan_Y = new Scan()
          val filter_Y = new PrefixFilter(Bytes.toBytes(s"${ptnr}-${src}-${entName}-"))
          val filter1_Y = new SingleColumnValueFilter(Bytes.toBytes("exi"), Bytes.toBytes("ingProcLogSts"), CompareOp.EQUAL, Bytes.toBytes("Success"));
          val filter2_Y = new SingleColumnValueFilter(Bytes.toBytes("fi"), Bytes.toBytes("iscustrowdelim"), CompareOp.EQUAL, Bytes.toBytes("Yes"));
          scan_Y.setCaching(10000)
          scan_Y.setCacheBlocks(false)
          filter1_Y.setFilterIfMissing(true)
          filter2_Y.setFilterIfMissing(true)
          scan_Y.setFilter(filterList(filter1_Y, filter_Y,filter2_Y))

          if (lstrundateFlg) {
            scan_Y.setTimeRange(getTimestamp(startTime), getTimestamp(endTime))
          }

          val eitVal_Y = globalContext.hbaseContext.hbaseRDD(TableName.valueOf(eitTable), scan_Y).cache
          Logger.log.info(s" DL eitVal count with isCustRowlim as Yes is  : ${eitVal_Y.count()} ")
          if(eitVal_Y.count()>0){

            val eitInfo = eitVal_Y.map(tuple => {
              val result = tuple._2
              (Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("schmVer"))), Bytes.toHex(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("rowdelim"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("entprtnfldr"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("srcFileNm"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("iscustrowdelim"))))
            })
            //     (Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("schmVer"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("srcFileNm"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("entprtnfldr"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("iscustrowdelim"))))

            Logger.log.info(s" Processing ${entName} Files with Row Delimiter: \\u0002 & \\u0002\\u000A")
            val isCustDelim = eitInfo.map(kv => {
              kv._5
            }).first.toString

            Logger.log.info(s" Processing ${entName} Files with Delimiter:\\u0002 OR  \\u0002\\u000A  isCustDelim is ${isCustDelim}")

            if (lstrundateFlg) {
              Logger.log.info(s" Number of Entries Captured for $entName from EIT SCAN b/w $startTime and $endTime :" + eitVal_Y.count())
            } else {
              Logger.log.info(s" Number of Entries Captured for $entName from EIT SCAN full load :" + eitVal_Y.count())
            }
            if (!eitInfo.isEmpty()) {

              //val rwDelimLst: List[(String,String)] = eitInfo.map(x => (x._1,x._2, x._3, x._4)).collect.toList.map(x => (x._2,"1"))
              //val rddRwDelim = globalContext.spark.parallelize(rwDelimLst)
              //val rddRwDelimLst = rddRwDelim.groupByKey.mapValues(_.mkString(","))

              //val eppRdd: org.apache.spark.rdd.RDD[(String, String)] = getEppLakeTabSchma(eppTable, ptnr, src, entName).cache
              // val rsltFlg2=rddRwDelimLst.collect.map(x => genExtDelim(x._1,eppRdd, eitInfo,entNm,raw_path,workingDir,startTime, endTime))

              ///val eitFileListCtlB: List[(String, String)] = eitInfo.filter(x => x._2 == "2" || x._2 == "5c7530303032").map(x => (x._1, x._3, x._4)).collect.toList.map(x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._2}/${x._3}"))

              //PITEntry//val eitFileListCtlB: List[(String, String)] = eitInfo.filter(x =>  x._2 == "5c7530303032").map(x => (x._1, x._3, x._4)).collect.toList.map(x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._2}/${x._3}"))

              //val eitFileListCtlBT = eitInfo.filter(x =>  x._2 == "5c7530303032").map(x => (x._1, x._3, x._4)).collect.toList
              val eitFileListCtlBT = eitInfo.filter(x => x._2 == "2" || x._2 == "5c7530303032").map(x => (x._1, x._3, x._4)).collect.toList
              val eitFileListCtlB= eitFileListCtlBT.map(x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._2}/${x._3}"))

              Logger.log.info(s" CustomRowDelim :List of Files from Raw with \\u0002 record delim: ${eitFileListCtlB.mkString}")
              //val eitFileListCtlB: List[(String, String)] = eitInfo.filter( x => x._2 == "2" || x._2 == "5c7530303032" ).map( x => (x._1, x._4, x._3) ).collect.toList.map( x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._4}/${x._3}") )
              val eitRawFileListCtlB = eitFileListCtlB.filter(x => filterRawFileExist(x._2))
              Logger.log.info(s" CustomRowDelim :ACTUAL Number of Files exist in Raw with \\u0002 record delim for $entName from EIT SCAN b/w $startTime and $endTime :" + eitRawFileListCtlB.length)
              Logger.log.info(s" CustomRowDelim :List of Files from Raw with \\u0002 record delim: ${eitRawFileListCtlB.mkString}")

              if(eitRawFileListCtlB.length>0){

                val eitPartnFlrCtlB=eitFileListCtlBT.map(x=> (x._2,1))
                val eitPartnFlrCtlBCnt= globalContext.spark.parallelize(eitPartnFlrCtlB).reduceByKey(_+_).collect().mkString("~")
                pitRawFileCnt=pitRawFileCnt+"CtlB-"+eitRawFileListCtlB.length+"|"
                pitRawRowDelim=pitRawRowDelim+"CtlB|"
                pitRawPartnFlr=pitRawPartnFlr+"CtlB-"+eitPartnFlrCtlBCnt+"|"

                val rddCtlB = globalContext.spark.parallelize(eitRawFileListCtlB)
                val eitFileRddCtlB = rddCtlB.groupByKey.mapValues(_.mkString(","))
                //            val eppRdd: org.apache.spark.rdd.RDD[(String, String)] = getEppLakeTabSchma(eppTable, ptnr, src, entName).cache
                Logger.log.info(s" CustomRowDelim :Number of Schema Versions for ${entName} retrieved from EPP HBase Table:" + eppRdd.count())
                val sparkConfigCtlB = globalContext.spark
                sparkConfigCtlB.hadoopConfiguration.set("textinputformat.record.delimiter", "\u0002")
                eppRdd.join(eitFileRddCtlB).collect.foreach { case (schmVer, (schm, fileList)) => saveToDataFrame(workingDir, schmVer, schm, fileList, entName, sparkConfigCtlB)
                }
              }
              else
              {
                Logger.log.info(s" Skipping the process as ACTUAL Number of Files exist in Raw with \\u0002 record delim is :" + eitRawFileListCtlB.length)
              }


              //val eitFileListCtlBNL: List[(String, String)] = eitInfo.filter(x => x._2 == "25c6e" || x._2 == "20a" || x._2 == "5c75303030325c6e").map(x => (x._1, x._3, x._4)).collect.toList.map(x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._2}/${x._3}"))
              //PitEntry// val eitFileListCtlBNL: List[(String, String)] = eitInfo.filter(x => x._2 == "5c75303030325c6e").map(x => (x._1, x._3, x._4)).collect.toList.map(x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._2}/${x._3}"))
              //val eitFileListCtlBNLT = eitInfo.filter(x => x._2 == "5c75303030325c6e").map(x => (x._1, x._3, x._4)).collect.toList
              val eitFileListCtlBNLT = eitInfo.filter(x => x._2 == "25c6e" || x._2 == "20a" || x._2 == "5c75303030325c6e").map(x => (x._1, x._3, x._4)).collect.toList
              val eitFileListCtlBNL=eitFileListCtlBNLT.map(x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._2}/${x._3}"))

              Logger.log.info(s" CustomRowDelim :Number of Files exist in Raw with \\u0002\\u000A record delim for $entName from EIT SCAN b/w $startTime and $endTime :" + eitFileListCtlBNL.length)

              val eitRawFileListCtlBNL = eitFileListCtlBNL.filter(x => filterRawFileExist(x._2))
              Logger.log.info(s" CustomRowDelim :Number of ACTUAL Files exist in Raw with \\u0002\\u000A record delim for $entName from EIT SCAN b/w $startTime and $endTime :" + eitRawFileListCtlBNL.length)
              Logger.log.info(s" CustomRowDelim :List of ACTUAL Files from Raw with \\u0002\\u000A record delim: ${eitRawFileListCtlBNL.mkString}")
              if(eitRawFileListCtlBNL.length>0){

                val eitPartnFlrCtlBNL=eitFileListCtlBNLT.map(x=> (x._2,1))
                val eitPartnFlrCtlBNLCnt= globalContext.spark.parallelize(eitPartnFlrCtlBNL).reduceByKey(_+_).collect().mkString("~")
                pitRawFileCnt=pitRawFileCnt+"CtlB\n-"+eitRawFileListCtlBNL.length+"|"
                pitRawRowDelim=pitRawRowDelim+"CtlB\n|"
                pitRawPartnFlr=pitRawPartnFlr+"CtlB\n-"+eitPartnFlrCtlBNLCnt+"|"

                val rddCtlBNL = globalContext.spark.parallelize(eitRawFileListCtlBNL)
                val eitFileRddCtlBNL = rddCtlBNL.groupByKey.mapValues(_.mkString(","))
                val sparkConfigCtlBNL = globalContext.spark
                sparkConfigCtlBNL.hadoopConfiguration.set("textinputformat.record.delimiter", "\u0002\u000A")
                eppRdd.join(eitFileRddCtlBNL).collect.foreach { case (schmVer, (schm, fileList)) => saveToDataFrame(workingDir, schmVer, schm, fileList, entName, sparkConfigCtlBNL)
                  //eppRdd.unpersist()
                }

              }
              else
              {
                Logger.log.info(s" Skipping the process as ACTUAL Number of Files exist in Raw with \\u0002\\u000A  record delim is :" + eitRawFileListCtlBNL.length)
              }


              eitVal_Y.unpersist()
              rsltFlg2=true

            }
            else {
              Logger.log.info(s" Number of Files Captured for $entName from EIT SCAN b/w $startTime and $endTime :" + 0)
              Logger.log.info(s" Since, No Changes Captured for $entName from $startTime to $endTime,datasets will not be generated")
              rsltFlg2=false
            }

          }
          else {
            Logger.log.info(s" since DL eitVal count with isCustRowlim as Yes is  : ${eitVal_Y.count()} , skipping the process")
            rsltFlg2=false

          }
          eppRdd.unpersist()

          var res="false;;;"
          if(rsltFlg2==true || rsltFlg1 == true)
          {
            /*            hbasePitPut(pitTab, pitRowKey, "fi", "rawRowDelim", pitRawRowDelim.dropRight(1))
                        hbasePitPut(pitTab, pitRowKey, "fi", "rawPartnFldr", pitRawPartnFlr.dropRight(1))
                        hbasePitPut(pitTab, pitRowKey, "fi", "rawFileCnt", pitRawFileCnt.dropRight(1))*/

            res="true;"+entName+"-"+pitRawRowDelim+";"+entName+"-"+pitRawPartnFlr+";"+entName+"-"+pitRawFileCnt;
          }
          else
          {
            /*            hbasePitPut(pitTab, pitRowKey, "fi", "rawRowDelim", "")
                        hbasePitPut(pitTab, pitRowKey, "fi", "rawPartnFldr", "")
                        hbasePitPut(pitTab, pitRowKey, "fi", "rawFileCnt", "0")*/
            res="false;"+entName+"- ;"+entName+"- ;"+entName+"-0";

          }
          res
        } catch {
          case e: Exception => Logger.log.info(s" Exception while Scanning Files from DL EIT for $entNm" :+ e.getStackTrace.mkString)
            hbasePITEndStage(pitTab, "Fail", pitRowKey)
            throw e
        }
      }
    } catch {
      case e: Exception => Logger.log.info(s" Exception while Scanning Files from DL EIT for $entNm from eitTabScan" :+ e.getStackTrace.mkString)
        hbasePITEndStage(pitTab, "Fail", pitRowKey)
        throw e
    }

  }

  /** Purpose : Def to get PSC Htable data based on rowkey provided
    * input : PSC RowKey i.e. feedName-extractName-entityName
    * output: PSC RowKey respective column(s) data should be retrieved */
  def getPkTs (rowKeyConfig: String, snapConfigTab: String): org.apache.spark.rdd.RDD[(String, String, String, String, String, String, String, String)] = {
    try {
      // val snapConfigTab = globalContext.pscTabName
      Logger.log.info(s" Snapshot Config table : $snapConfigTab")
      val scanner = new Scan()
      scanner.setCaching(1000)
      scanner.setCacheBlocks(false)
      val filter1 = new RowFilter(CompareOp.EQUAL, new BinaryComparator(Bytes.toBytes(s"$rowKeyConfig")))
      val filter2 = new SingleColumnValueFilter(Bytes.toBytes("psc"), Bytes.toBytes("activeflag"), CompareOp.EQUAL, Bytes.toBytes("Y"));
      scanner.setFilter(filterList(filter1, filter2))
      val snapInfo = globalContext.hbaseContext.hbaseRDD(TableName.valueOf(snapConfigTab), scanner)
      Logger.log.info(s" SnapConfigTab Filter count : ${snapInfo.count()} ")
      val snapRDD = snapInfo.map(tuple => {
        val result = tuple._2
        (
          Bytes.toString(result.getValue(Bytes.toBytes("psc"), Bytes.toBytes("feedName"))),
          Bytes.toString(result.getValue(Bytes.toBytes("psc"), Bytes.toBytes("extractName"))),
          Bytes.toString(result.getValue(Bytes.toBytes("psc"), Bytes.toBytes("entNm"))),
          Bytes.toString(result.getValue(Bytes.toBytes("psc"), Bytes.toBytes("prikeycols"))),
          Bytes.toString(result.getValue(Bytes.toBytes("psc"), Bytes.toBytes("dmlcol"))),
          Bytes.toString(result.getValue(Bytes.toBytes("psc"), Bytes.toBytes("activeflag"))),
          Bytes.toString(result.getValue(Bytes.toBytes("psc"), Bytes.toBytes("modtscol"))),
          Bytes.toString(result.getValue(Bytes.toBytes("psc"), Bytes.toBytes("fullLoadflg"))))

      })

      snapRDD
    } catch {
      case e: Exception => Logger.log.error(s" Exception while retriving Pk's from Snapshot Config Tab for $rowKeyConfig" :+ e.getMessage)
        throw e
    }
  }


  /** Purpose : Def to get PLC Htable remaining columns based on rowkey provided
    * input : PLC RowKey i.e. feedName-extractName
    * output: Returns PLC RowKey respective remaining column(s) data in the form of Dataframe */
  /// for getting the PLC values
  def getPLCInfoDF (rowKeyPLC: String, plcTab: String): DataFrame = {

    try {
      // val peiTab = globalContext.peiTabName
      Logger.log.info(s" Scanning PLC HBase Table $plcTab for remaining columns based on ROWKEY :  ${rowKeyPLC} ")
      val scanner = new Scan()
      scanner.setCaching(1000)
      scanner.setCacheBlocks(false)
      val filter1 = new RowFilter(CompareOp.EQUAL, new BinaryComparator(Bytes.toBytes(s"$rowKeyPLC")))
      scanner.setFilter(filter1)
      val extInfo = globalContext.hbaseContext.hbaseRDD(TableName.valueOf(plcTab), scanner).cache()
      val extRDD = extInfo.map(tuple => {
        val result = tuple._2
        (Bytes.toString(result.getValue(Bytes.toBytes("plc"), Bytes.toBytes("lastRunDt"))))

      })
      import sqlContext.implicits._ // Fix this import
      extRDD.toDF()
    } catch {
      case e: Exception => Logger.log.error(s" Exception while getting columns info from PLC Tab" :+ e.getMessage)
        throw e
    }
  }


  //get the PEI Htable columns data into  a Dataframe
  def getPEIIntoDF (rowKeyPEI: String,peiTab:String):  DataFrame= {

    try {
      // val peiTab = globalContext.peiTabName
      Logger.log.info(s" Scanning PEI HBase Table $peiTab for the columns based on ROWKEY :  ${rowKeyPEI} ")
      val scanner = new Scan()
      scanner.setCaching(1000)
      scanner.setCacheBlocks(false)
      val filter1 = new RowFilter(CompareOp.EQUAL, new BinaryComparator(Bytes.toBytes(s"$rowKeyPEI")))
      scanner.setFilter(filter1)
      val extInfo = globalContext.hbaseContext.hbaseRDD(TableName.valueOf(peiTab), scanner).cache()
      val extRDD = extInfo.map(tuple => {
        val result = tuple._2
        (Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("feedName"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("extractName"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("hdrDesc"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("hdrDateFormat"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("trlDesc"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("isJsonProp"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("jsonPropFileLoc"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("sqlQuery"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("transQuery"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("trgColumn"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("trgDataTypeLen"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("outFileName"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("outFileExt"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("outFileLoc"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("archLoc"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("isOutFileColDelim"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("outFileColDelim"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("isFixedWidth"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("srcCd"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("prtnrCd"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("entitySet"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("snapBuildType")))
        )

      })
      import sqlContext.implicits._ // Fix this import
      extRDD.toDF()
    } catch {
      case e: Exception => Logger.log.error(s" Exception while getting the columns info from PEI Tab" :+ e.getMessage)
        throw e
    }
  }







  /** Purpose : Def to get PEI Htable remaining columns based on rowkey provided
    * input : PEI RowKey i.e. feedName-extractName
    * output: Returns PEI RowKey respective remaining column(s) data in the form of Dataframe */
  /// for getting the PEI values(22 values) except row delim fields ==> Fix , check , whether we can able to retrive all the PEI values from this def or not
  def getPEIInfoDF (rowKeyPEI: String, peiTab: String): DataFrame = {

    try {
      // val peiTab = globalContext.peiTabName
      Logger.log.info(s" Scanning PEI HBase Table $peiTab for remaining columns based on ROWKEY :  ${rowKeyPEI} ")
      val scanner = new Scan()
      scanner.setCaching(1000)
      scanner.setCacheBlocks(false)
      val filter1 = new RowFilter(CompareOp.EQUAL, new BinaryComparator(Bytes.toBytes(s"$rowKeyPEI")))
      scanner.setFilter(filter1)
      val extInfo = globalContext.hbaseContext.hbaseRDD(TableName.valueOf(peiTab), scanner).cache()
      val extRDD = extInfo.map(tuple => {
        val result = tuple._2
        (Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("feedName"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("extractName"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("hdrDesc"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("hdrDateFormat"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("trlDesc"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("isJsonProp"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("jsonPropFileLoc"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("sqlQuery"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("transQuery"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("trgColumn"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("trgDataTypeLen"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("outFileName"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("outFileExt"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("outFileLoc"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("archLoc"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("isOutFileColDelim"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("outFileColDelim"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("isFixedWidth"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("entitySet"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("snapBuildType"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"),Bytes.toBytes("isOutFileRowDelim"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("outFileRowDelim")))
        )
      })
      import sqlContext.implicits._ // Fix this import
      extRDD.toDF()
      /* //Fix : automate the schema
       val PEISchema = List(StructField("isOutFileRowDelim", StringType, true), StructField("outFileRowDelim", StringType, true))
       val PEIDF = sqlContext.createDataFrame(globalContext.spark.parallelize(Seq(Row(extRDD))), StructType(PEISchema))

       PEIDF.registerTempTable("peiTempDFTable")
       val peiTempTabDF  = sqlContext.sql("SELECT * from peiTempDFTable")
       peiTempTabDF*/


    } catch {
      case e: Exception => Logger.log.error(s" Exception while getting remaining columns info from PEI Tab" :+ e.getMessage)
        throw e
    }
  }


  /** Purpose : Def to get PEI Htable data based on rowkey provided
    * input : PEI RowKey i.e. feedName-extractName
    * output: Returns PEI RowKey respective column(s) data in the form of Array[Strings] */
  /// for getting the PEI values(22 values) except row delim fields ==> Fix , check , whether we can able to retrive all the PEI values from this def or not
  def getEntityInfoPEI (rowKeyPEI: String, peiTab: String): Array[(String, String, String, String, String, String, String, String, String, String, String, String, String, String, String, String, String, String, String, String, String, String)] = {

    try {
      // val peiTab = globalContext.peiTabName
      Logger.log.info(s" Scanning PEI HBase Table $peiTab for ROWKEY :  ${rowKeyPEI} ")
      val scanner = new Scan()
      scanner.setCaching(1000)
      scanner.setCacheBlocks(false)
      val filter1 = new RowFilter(CompareOp.EQUAL, new BinaryComparator(Bytes.toBytes(s"$rowKeyPEI")))
      scanner.setFilter(filter1)
      val extInfo = globalContext.hbaseContext.hbaseRDD(TableName.valueOf(peiTab), scanner).cache()
      val extRDD = extInfo.map(tuple => {
        val result = tuple._2
        (Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("feedName"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("extractName"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("hdrDesc"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("hdrDateFormat"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("trlDesc"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("isJsonProp"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("jsonPropFileLoc"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("sqlQuery"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("transQuery"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("trgColumn"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("trgDataTypeLen"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("outFileName"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("outFileExt"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("outFileLoc"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("archLoc"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("isOutFileColDelim"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("outFileColDelim"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("isFixedWidth"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("srcCd"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("prtnrCd"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("entitySet"))),
          Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("snapBuildType")))
        )

      })

      if (extRDD.isEmpty()) {
        Logger.log.info(s" Please Provide Appropriate RowKey to Check PEI table Properties for $rowKeyPEI properly")
        extRDD.collect()
      } else {
        extRDD.collect()
      }
    } catch {
      case e: Exception => Logger.log.error(s" Exception while getting entity info from PEI Tab" :+ e.getMessage)
        throw e
    }
  }


  /** Purpose : Def to update the PSC htable
    * input : PSC RowKey, PSC CF, PSC ColumnName, PSC ColumnData
    * output: PSC RowKey respective column data should be updated */
  def hbasePSCPut (snapConfigTab: HTable, rowKey: String, colFm: String, colNm: String, value: String): Unit = {
    try {
      val p = new Put(s"$rowKey".getBytes())
      p.addColumn(s"$colFm".getBytes(), s"$colNm".getBytes(), s"$value".getBytes())
      snapConfigTab.put(p)
    } catch {
      case e: Exception => Logger.log.info(" Exception at HBase  Put Commands at PSC entity_info" :+ e.getStackTrace.toString)
        throw e
    }
  }


  /** Purpose : Def to get the hbase column data based on rowkey provided
    * input : hbaseTabNameAsStr:String, rowKey:String,colFm: String, colNm: String
    * output: Should return respective column value */
  def getHtableValByRowKey (hbaseTabNameAsStr: String, rowKey: String, colFm: String, colNm: String): String = {
    try {
      hBaseConf.set(TableInputFormat.INPUT_TABLE, hbaseTabNameAsStr)
      val hbaseTab: HTable = new HTable(hBaseConf, hbaseTabNameAsStr)

      // Instantiating Get class
      val g = new Get(Bytes.toBytes(rowKey));

      // Reading the data
      val result = hbaseTab.get(g);

      // Reading values from Result class object
      val colValue = Bytes.toString(result.getValue(Bytes.toBytes(colFm.toString), Bytes.toBytes(colNm.toString)));
      colValue

    } catch {
      case e: Exception => Logger.log.info(" Exception at HBase  Get Command for hTable(" + hbaseTabNameAsStr + " )" :+ e.getStackTrace.toString)
        throw e
    }
  }


  /** Purpose : Def to update the PLC htable
    * input : PLC RowKey, PLC CF, PLC ColumnName, PLC ColumnData (lastRunDt)
    * output: PLC RowKey respective column data should be updated */
  def hbasePLCPut (lastrunConfigTab: HTable, rowKey: String, colFm: String, colNm: String, lastRunDtAsProvStrTs: String): Unit = {
    try {
      val p = new Put(s"$rowKey".getBytes())
      p.addColumn(s"$colFm".getBytes(), s"$colNm".getBytes(), s"$lastRunDtAsProvStrTs".getBytes())
      lastrunConfigTab.put(p)
    } catch {
      case e: Exception => Logger.log.info(" Exception at HBase  Put Commands at PLC entity_info" :+ e.getStackTrace.toString)
        throw e
    }
  }

  /** Purpose : Def to update the PIT htable
    * input : PIT RowKey, PIT CF, PIT ColumnName, PIT ColumnData
    * output: PIT RowKey respective column data should be updated */
  def hbasePitPut (pitTab: HTable, pitRowKey: String, colFm: String, colNm: String, value: String): Unit = {
    try {
      val p = new Put(s"$pitRowKey".getBytes())
      p.addColumn(s"$colFm".getBytes(), s"$colNm".getBytes(), s"$value".getBytes())
      pitTab.put(p)
    } catch {
      case e: Exception => Logger.log.info(" Exception at HBase PIT Put Commands " :+ e.getStackTrace.mkString)
        throw e
    }
  }

  /** Purpose : Def to remove hadoop directory if exists
    * input : hadoopDirectoryPath
    * output: Returns Boolean value as 0 if the file is exists else 1 for not exists */
  //Fix : not used anywhere, later we can use this instead of commandline commands
  def rmPathIfExist (path: String): Unit = {
    try {
      if (fileSystem.exists(new Path(path))) {
        Logger.log.info(s" Deleted intermediate file/dir : " + path)
        fileSystem.delete(new Path(path.replace("/mapr/", "/")), true)
        //fileSystem.deleteOnExit(new Path(path))
      } else {
        Logger.log.info(s" Path: $path doesn't exist, Not proceeding for removing.")
      }
    } catch {
      case e: Exception => Logger.log.info(" Exception at rmPathIfExist definition" :+ e.getStackTrace.toString)
        throw e
    }
  }


  /** Purpose : Def to rename  hadoop file path
    * input : filePath
    * output: Returns integer value 0 for successful file renaming , 1 for error */
  def renamePath (srcPath: String, destPath: String): Unit = {
    try {
      if (fileSystem.exists(new Path(s"$srcPath"))) {
        Logger.log.info(s" Renaming/Move from ( $srcPath ) to ( $destPath )")
        var success = fileSystem.rename(new Path(srcPath), new Path(destPath))
        Logger.log.info(s" success flag--( $success )")
      } else {
        Logger.log.info(s" Path : $srcPath doesn't exist, Not proceeding for move/Rename .")
      }
    } catch {
      case e: Exception => Logger.log.info(" Exception at renamePath definition" :+ e.getStackTrace.toString)
        throw e
    }

  }


  /** Purpose : Def to move  hadoop file from one to another path
    * input : filePath
    * output: Returns integer value 0 for successful file renaming , 1 for error */
  def copyFSFile (srcPath: String, destPath: String): Unit = {
    try {
      Logger.log.info(s" Given srcPath ( $srcPath ) ")
      if (fileSystem.exists(new Path(srcPath))) {
        Logger.log.info(s" Copying from ( $srcPath ) to ( $destPath )")
        FileUtil.copy(fileSystem, new Path(srcPath.replace("/mapr/", "/")), fileSystem, new Path(destPath.replace("/mapr/", "/")), false, fsConf)
        //FileUtil.copy(fileSystem, new Path(srcPath), fileSystem, new Path(destPath), false, fsConf, null)
        //fileSystem.cop(new Path(srcPath),new Path(destPath))
      } else {
        Logger.log.info(s" Path : $srcPath doesn't exist, Not proceeding for Copy .")
      }
    } catch {
      case e: Exception => Logger.log.info(" Exception at renamePath definition" :+ e.getStackTrace.toString)
        throw e
    }

  }


  /** Purpose : Def to check  hadoop file path
    * input : hadoopFilePath
    * output: Returns Boolean value as 0 if the file is exists else 1 for not exists */
  def filterRawFileExist (filePath: String): Boolean = {
    globalContext.fs.exists(new Path(s"$filePath"))
  }
  /*added to check directory is empty or not */
  def isEmptyDir (filePath: String): Boolean = {
    var resFlg=false
    val filePathT=filePath.replace("maprfs://","/mapr/")
    var file= new File(filePathT)
    /*if(file.isDirectory()){*/
    if (globalContext.fs.exists(new Path(s"$filePath"))){
      if(file.list().length>0){
        Logger.log.info(s" Directory is not empty! " +filePathT);
        resFlg=true
      }else{
        resFlg=false
        Logger.log.info(s" Directory is  empty! " +filePathT);
      }
    }else
    {
      resFlg=false
      Logger.log.info(s" Directory path not present! " +filePathT);

    }
    /*}else{
      resFlg=false
      Logger.log.info(s" Not a Directory  " +filePathT);
    }*/
    resFlg}

  /** Purpose : Def to merge hadoop files
    * input : sourceFilesPath, destinationFilePath
    * output: Returns Boolean value as 0 if the merge is success else 1 for error */
  def merge (srcPath: String, dstPath: String): Boolean = {
    val hdfs = FileSystem.get(globalContext.spark.hadoopConfiguration)
    FileUtil.copyMerge(hdfs, new Path(srcPath), hdfs, new Path(dstPath), false, globalContext.spark.hadoopConfiguration, null)
  }

  /** Purpose : Def to add PEI Htable columns data
    * input : record/row/line from input .dat file
    * output: PEI RowKey respective column data should be updated with given input file values */
  def PEIconvertToKeyValuePairs (line: String): (ImmutableBytesWritable, Put) = {
    val peicfDataBytes = Bytes.toBytes("pei")

    def split_bytes (line: String): String = {
      val row = line.split("\\^\\~\\^")
      //val row = line.split("~^~")
      Logger.log.info(s" Row Value : " + row)
      row(0) + "-" + row(1)
    }

    val row = split_bytes(line)
    val rowkey = row.getBytes()
    val put = new Put(rowkey)
    put.add(peicfDataBytes, Bytes.toBytes("feedName"), Bytes.toBytes(line.split("\\^\\~\\^")(0)))
    put.add(peicfDataBytes, Bytes.toBytes("extractName"), Bytes.toBytes(line.split("\\^\\~\\^")(1)))
    put.add(peicfDataBytes, Bytes.toBytes("hdrDesc"), Bytes.toBytes(line.split("\\^\\~\\^")(2)))
    put.add(peicfDataBytes, Bytes.toBytes("hdrDateFormat"), Bytes.toBytes(line.split("\\^\\~\\^")(3)))
    put.add(peicfDataBytes, Bytes.toBytes("trlDesc"), Bytes.toBytes(line.split("\\^\\~\\^")(4)))
    put.add(peicfDataBytes, Bytes.toBytes("isJsonProp"), Bytes.toBytes(line.split("\\^\\~\\^")(5)))
    put.add(peicfDataBytes, Bytes.toBytes("jsonPropFileLoc"), Bytes.toBytes(line.split("\\^\\~\\^")(6)))
    put.add(peicfDataBytes, Bytes.toBytes("sqlQuery"), Bytes.toBytes(line.split("\\^\\~\\^")(7)))
    put.add(peicfDataBytes, Bytes.toBytes("transQuery"), Bytes.toBytes(line.split("\\^\\~\\^")(8)))
    put.add(peicfDataBytes, Bytes.toBytes("trgColumn"), Bytes.toBytes(line.split("\\^\\~\\^")(9)))
    put.add(peicfDataBytes, Bytes.toBytes("trgDataTypeLen"), Bytes.toBytes(line.split("\\^\\~\\^")(10)))
    put.add(peicfDataBytes, Bytes.toBytes("outFileName"), Bytes.toBytes(line.split("\\^\\~\\^")(11)))
    put.add(peicfDataBytes, Bytes.toBytes("outFileExt"), Bytes.toBytes(line.split("\\^\\~\\^")(12)))
    put.add(peicfDataBytes, Bytes.toBytes("outFileLoc"), Bytes.toBytes(line.split("\\^\\~\\^")(13)))
    put.add(peicfDataBytes, Bytes.toBytes("archLoc"), Bytes.toBytes(line.split("\\^\\~\\^")(14)))
    put.add(peicfDataBytes, Bytes.toBytes("isOutFileColDelim"), Bytes.toBytes(line.split("\\^\\~\\^")(15)))
    put.add(peicfDataBytes, Bytes.toBytes("outFileColDelim"), Bytes.toBytes(line.split("\\^\\~\\^")(16)))
    put.add(peicfDataBytes, Bytes.toBytes("isOutFileRowDelim"), Bytes.toBytes(line.split("\\^\\~\\^")(17)))
    put.add(peicfDataBytes, Bytes.toBytes("outFileRowDelim"), Bytes.toBytes(line.split("\\^\\~\\^")(18)))
    put.add(peicfDataBytes, Bytes.toBytes("isFixedWidth"), Bytes.toBytes(line.split("\\^\\~\\^")(19)))
    put.add(peicfDataBytes, Bytes.toBytes("srcCd"), Bytes.toBytes(line.split("\\^\\~\\^")(20)))
    put.add(peicfDataBytes, Bytes.toBytes("prtnrCd"), Bytes.toBytes(line.split("\\^\\~\\^")(21)))
    put.add(peicfDataBytes, Bytes.toBytes("entitySet"), Bytes.toBytes(line.split("\\^\\~\\^")(22)))
    put.add(peicfDataBytes, Bytes.toBytes("snapBuildType"), Bytes.toBytes(line.split("\\^\\~\\^")(23)))
    return (new ImmutableBytesWritable(rowkey), put)
  }


  /** Purpose : Def to add PIT Htable columns data
    * input : record/row/line from input .dat file
    * output: PIT RowKey respective column data should be updated with given input file values */
  def PITConvertToKeyValuePairs (line: String): (ImmutableBytesWritable, Put) = {
    val exicfDataBytes = Bytes.toBytes("exi")

    Logger.log.info(s" COLFAMILY exi Value : $exicfDataBytes")

    def split_bytes (line: String): String = {
      val row = line.split("\\^\\~\\^")
      row(0)
    }

    val ficfDataBytes = Bytes.toBytes("fi")
    Logger.log.info(s" COLFAMILY fi Value : $ficfDataBytes")
    val row = split_bytes(line)
    val rowkey = row.getBytes()
    val put = new Put(rowkey)
    put.add(exicfDataBytes, Bytes.toBytes("provExecTrkId"), Bytes.toBytes(line.split("\\^\\~\\^")(0)))
    put.add(exicfDataBytes, Bytes.toBytes("provDur"), Bytes.toBytes(line.split("\\^\\~\\^")(1)))
    put.add(exicfDataBytes, Bytes.toBytes("provStrTs"), Bytes.toBytes(line.split("\\^\\~\\^")(2)))
    put.add(exicfDataBytes, Bytes.toBytes("provEndTs"), Bytes.toBytes(line.split("\\^\\~\\^")(3)))
    put.add(exicfDataBytes, Bytes.toBytes("provCompSts"), Bytes.toBytes(line.split("\\^\\~\\^")(4)))
    put.add(exicfDataBytes, Bytes.toBytes("provRecCnt"), Bytes.toBytes(line.split("\\^\\~\\^")(5)))
    put.add(ficfDataBytes, Bytes.toBytes("FeedName"), Bytes.toBytes(line.split("\\^\\~\\^")(6)))
    put.add(ficfDataBytes, Bytes.toBytes("ExtractName"), Bytes.toBytes(line.split("\\^\\~\\^")(7)))
    put.add(ficfDataBytes, Bytes.toBytes("provFileNames"), Bytes.toBytes(line.split("\\^\\~\\^")(8)))
    put.add(ficfDataBytes, Bytes.toBytes("provFileCnt"), Bytes.toBytes(line.split("\\^\\~\\^")(9)))
    put.add(ficfDataBytes, Bytes.toBytes("provOutFileColDelim"), Bytes.toBytes(line.split("\\^\\~\\^")(10)))
    put.add(ficfDataBytes, Bytes.toBytes("provOutFileRowDelim"), Bytes.toBytes(line.split("\\^\\~\\^")(11)))
    put.add(ficfDataBytes, Bytes.toBytes("provOutFileLoc"), Bytes.toBytes(line.split("\\^\\~\\^")(12)))
    put.add(ficfDataBytes, Bytes.toBytes("srcCd"), Bytes.toBytes(line.split("\\^\\~\\^")(13)))
    put.add(ficfDataBytes, Bytes.toBytes("ptnrCd"), Bytes.toBytes(line.split("\\^\\~\\^")(14)))
    put.add(ficfDataBytes, Bytes.toBytes("dataOwnr"), Bytes.toBytes(line.split("\\^\\~\\^")(15)))
    put.add(ficfDataBytes, Bytes.toBytes("entitySet"), Bytes.toBytes(line.split("\\^\\~\\^")(16)))
    put.add(ficfDataBytes, Bytes.toBytes("rawRowDelim"), Bytes.toBytes(line.split("\\^\\~\\^")(17)))
    put.add(ficfDataBytes, Bytes.toBytes("rawPartnFldr"), Bytes.toBytes(line.split("\\^\\~\\^")(18)))
    put.add(ficfDataBytes, Bytes.toBytes("rawFileCnt"), Bytes.toBytes(line.split("\\^\\~\\^")(19)))
    put.add(exicfDataBytes, Bytes.toBytes("lastRunDt"), Bytes.toBytes(line.split("\\^\\~\\^")(20)))
    put.add(exicfDataBytes, Bytes.toBytes("fullLoadflg"), Bytes.toBytes(line.split("\\^\\~\\^")(21)))

    return (new ImmutableBytesWritable(rowkey), put)
  }

  /** Purpose : Def to add PSC Htable columns data
    * input : record/row/line from input .dat file
    * output: PSC RowKey respective column data should be updated with given input file values */
  def PSCconvertToKeyValuePairs (line: String): (ImmutableBytesWritable, Put) = {
    val psccfDataBytes = Bytes.toBytes("psc")

    def split_bytes (line: String): String = {
      val row = line.split("\\^\\~\\^")
      row(0) + "-" + row(1) + "-" + row(2)
    }

    val row = split_bytes(line)
    val rowkey = row.getBytes()
    val put = new Put(rowkey)
    put.add(psccfDataBytes, Bytes.toBytes("feedName"), Bytes.toBytes(line.split("\\^\\~\\^")(0)))
    put.add(psccfDataBytes, Bytes.toBytes("extractName"), Bytes.toBytes(line.split("\\^\\~\\^")(1)))
    put.add(psccfDataBytes, Bytes.toBytes("entNm"), Bytes.toBytes(line.split("\\^\\~\\^")(2)))
    put.add(psccfDataBytes, Bytes.toBytes("prikeycols"), Bytes.toBytes(line.split("\\^\\~\\^")(3)))
    put.add(psccfDataBytes, Bytes.toBytes("dmlcol"), Bytes.toBytes(line.split("\\^\\~\\^")(4)))
    put.add(psccfDataBytes, Bytes.toBytes("activeflag"), Bytes.toBytes(line.split("\\^\\~\\^")(5)))
    put.add(psccfDataBytes, Bytes.toBytes("modtscol"), Bytes.toBytes(line.split("\\^\\~\\^")(6)))
    put.add(psccfDataBytes, Bytes.toBytes("fullLoadflg"), Bytes.toBytes(line.split("\\^\\~\\^")(7)))
    //  put.add(psccfDataBytes, Bytes.toBytes("lastRunDt"), Bytes.toBytes(line.split("\\^\\~\\^")(8)))
    return (new ImmutableBytesWritable(rowkey), put)
  }


  /** Purpose : Def to get header dataframe
    * input : headerDelimiter, headerDateFormat , headerDescription
    * output: Returns headerDF */
  def getHdrInfo (hdrDesc: String, hdrDateFormat: String, curExtOutFileColDelim: String): DataFrame = {

    //Handlng SELECT Query in hdrDesc

    if(hdrDesc.contains(selectStKeyWd)){
      Logger.log.info(s" hdrDesc contains Select Query Senario: " )
      val Data = Seq(Row(hdrDesc))
      val Schema = List(StructField("hdrQuery", StringType, true))
      val DF = sqlContext.createDataFrame(globalContext.spark.parallelize(Data), StructType(Schema))
      DF.createOrReplaceTempView("HDRV")
      val HD =sqlContext.sql("select * FROM HDRV")
      HD
    }else {
      //import sc.sqlContext.implicits._ // Fix this import
      val format = new SimpleDateFormat(hdrDateFormat)
      val hdrRowID = hdrDesc.split(';')(0)
      val dateFrom = hdrDesc.split(';')(1)
      val hdrFileName = hdrDesc.split(';')(2)

      val hdrDate = format.format(Calendar.getInstance().getTime())
      Logger.log.info(s" hdrDate : " + hdrDate)
      /*else{
      var hdrRowID = ""
      var dateFrom = ""
      var hdrDate = ""
      var hdrFileName=""
    }*/

      import org.apache.spark.sql._ // to get rid of  Row is ambiguous from import org.apache.hadoop.hbase.client._
      val HDRData = Seq(Row(hdrRowID, hdrDate, hdrFileName))

      //Fix : automate the schema
      val HDFSchema = List(StructField("DATA_ID", StringType, true), StructField("HdrDate", StringType, true), StructField("HdrDes", StringType, true))

      val HDRDF = sqlContext.createDataFrame(globalContext.spark.parallelize(HDRData), StructType(HDFSchema))

      HDRDF.registerTempTable("headerTable")
      //val HD = sqlContext.sql("SELECT concat_ws('" + curExtOutFileColDelim + "'" + ",DATA_ID,HdrDate,HdrDes) AS RID from headerTable")
      val HD = sqlContext.sql("SELECT DATA_ID,HdrDate,HdrDes from headerTable")
      HD
    }
  }

  /** Purpose : Def to get trailer dataframe
    * input : trailerDelimiter, dataDataFrame for record count , trailerDescription
    * output: Returns trailerDF */
  def getTrlInfo (trlDelimeter: String, dataDF: DataFrame, trlDesc: String): DataFrame = {
    //Handlng SELECT Query in hdrDesc

    if(trlDesc.contains(selectStKeyWd)){
      Logger.log.info(s" trlDesc contains Select Query Senario: " )
      val Data = Seq(Row(trlDesc))
      val Schema = List(StructField("trlQuery", StringType, true))
      val DF = sqlContext.createDataFrame(globalContext.spark.parallelize(Data), StructType(Schema))
      DF.createOrReplaceTempView("TRLV")
      val TD =sqlContext.sql("select * FROM TRLV")
      TD
    }else {
      //  import sc.sqlContext.implicits._ // Fix this import
      val trlRowID = trlDesc.split(';')(0)
      val leadingNumber = trlDesc.split(';')(1)
      val wildCharac = trlDesc.split(';')(2)
      val delim = trlDelimeter
      val trlRecCnt = s"%${wildCharac}${leadingNumber}d".format(dataDF.count())
      import org.apache.spark.sql._ // to get rid of  Row is ambiguous from import org.apache.hadoop.hbase.client._
      val trlData = Seq(Row(trlRowID, trlRecCnt))
      val trlSchema = List(StructField("DATA_ID", StringType, true), StructField("RecCnt", StringType, true))
      val trlDF = sqlContext.createDataFrame(globalContext.spark.parallelize(trlData), StructType(trlSchema))

      trlDF.registerTempTable("trailerTable")
      //val TD = sqlContext.sql("select concat_ws('" + trlDelimeter + "'" + ",DATA_ID,RecCnt) AS RID from trailerTable")
      val TD = sqlContext.sql("select DATA_ID,RecCnt from trailerTable")
      TD
    }
  }

  /*
get the total number of lines present in a file
 */
  def getTotalLines (dataFilePath: String): Int = {
    var dataPath = dataFilePath
    if (!dataFilePath.contains("/mapr/")) {
      dataPath = dataFilePath.replace("/datalake/", "/mapr/datalake/")
    }
    val dataFileTotalRecords = scala.io.Source.fromFile(dataPath).getLines.size
    Logger.log.info("s total Count For ( " + dataFilePath + " ) : " + dataFileTotalRecords)
    dataFileTotalRecords
  }


  /** Purpose : Def to get trailer dataframe when the extract is file not the dataframe
    * input : trailerDelimiter, file for record count , trailerDescription
    * output: Returns trailerDF */
  def getFileTrlInfo (trlDelimeter: String, dataFilePath: String, trlDesc: String): DataFrame = {

    //  import sc.sqlContext.implicits._ // Fix this import
    val trlRowID = trlDesc.split(';')(0)
    val leadingNumber = trlDesc.split(';')(1)
    val wildCharac = trlDesc.split(';')(2)
    val delim = trlDelimeter
    var dataPath = dataFilePath
    if (!dataFilePath.contains("/mapr/")) {
      dataPath = dataFilePath.replace("/datalake/", "/mapr/datalake/")
    }
    val dataFileTotalRecords = scala.io.Source.fromFile(dataPath).getLines.size
    Logger.log.info("s dataFile total Count " + dataFileTotalRecords)

    /*
        val dataFileRDD = globalContext.spark.textFile(dataFilePath)
        Logger.log.info("s dataFileRDD Data " + dataFileRDD.collect())
        Logger.log.info("s dataFileRDD Data Count " + dataFileRDD.count())*/ val trlRecCnt = s"%${wildCharac}${leadingNumber}d".format(dataFileTotalRecords)
    import org.apache.spark.sql._ // to get rid of  Row is ambiguous from import org.apache.hadoop.hbase.client._
    val trlData = Seq(Row(trlRowID, trlRecCnt))

    val trlSchema = List(StructField("DATA_ID", StringType, true), StructField("RecCnt", StringType, true))
    val trlDF = sqlContext.createDataFrame(globalContext.spark.parallelize(trlData), StructType(trlSchema))

    trlDF.registerTempTable("trailerTable")
    val TD = sqlContext.sql("select concat_ws('" + trlDelimeter + "'" + ",DATA_ID,RecCnt) AS RID from trailerTable")
    TD

  }


  /** Purpose : Def to check given hadoop file path exists or not
    * input : filePath
    * output: Returns integer value 0 for file exists, 1 for not exists */
  // Fix : use existing def filterRawFileExist
  def fileExists (filePath: String): Unit = {

    try {
      Logger.log.info(s" Path Existence Check for : " + filePath)
      fileSystem.exists(new Path(filePath))

    } catch {
      case e: Exception => Logger.log.info(" Exception at fileExists definition" :+ e.getStackTrace.toString)
        throw e
    }
  }


  /** Purpose : Def to read the configuration values from the properties file mentioned under resources
    * input : configurationProperty
    * output: Returns the given configurationProperty value as string */
  def readProperties (input: String, enviParam: String): String = {
    val prop = new Properties()
    val path = "/prov_" + enviParam + ".properties"
    val in = this.getClass.getResourceAsStream(path)
    prop.load(in)
    val value = prop.getProperty(s"$input")
    // println( value )
    value
  }

  /** Purpose : Def to update the PIT htable as per the prov Extract end status
    * input : provRecCnt, provFileNames, provFileCount
    * output: PIT RowKey respective column(s) data should be updated in PIT htable with flow end time */
  def hbasePITEndStageUpdateProv (pitTab: HTable, jobStatusTmp: String, pitRowKey: String,  provFileNames: String, provFileCount: String): Unit = {
    val jobStatus=jobStatusTmp.toLowerCase;

    hbasePitPut(pitTab, pitRowKey, "fi", "provFileNames", provFileNames)
    Logger.log.info(s" Updating PIT table for the column : provFileNames as $provFileNames , cf : f1, RowKey : $pitRowKey ")

    hbasePitPut(pitTab, pitRowKey, "fi", "provFileCnt", provFileCount)
    Logger.log.info(s" Updating PIT table for the column : provFileCnt as $provFileCount , cf : f1, RowKey : $pitRowKey ")

    Logger.log.info(s" Ending Provisioning extract PIT table with status as $jobStatus  ")

    hbasePitPut(pitTab, pitRowKey, "exi", "provCompSts", jobStatus)
    globalContext.spark.stop()
  }


  /** Purpose : Def to update the PIT htable as per the End Stage
    * input : jobStatus(Success / Fail) , PIT RowKey
    * output: PIT RowKey respective column(s)(status,endTS) data should be updated in PIT htable with flow end time */
  def hbasePITEndStage (pitTab: HTable, jobStatusTmp: String, pitRowKey: String): Unit = {
    val jobStatus=jobStatusTmp.toLowerCase;
    val provEndTs = CustomFunctions.getCurrentTimeFormat
    if(jobStatus.equalsIgnoreCase("fail")) {
      //Find the duration
      val pitTabName = pitTab.getName.getNameAsString
      Logger.log.info(s"===================> for pitTableName  : " + pitTabName);
      val provStartTime = CustomFunctions.getHtableValByRowKey(pitTabName, pitRowKey, "exi", "provStrTs")

      val duration = CustomFunctions.getDuration(provEndTs, provStartTime)
      Logger.log.info(s"===================> duration : " + duration);

      hbasePitPut(pitTab, pitRowKey, "exi", "provDur", duration)
      Logger.log.info(s" Updating PIT table for the column : provDur as $duration , cf : exi, RowKey : $pitRowKey ")
      hbasePitPut(pitTab, pitRowKey, "exi", "provEndTs", provEndTs)
      Logger.log.info(s" Updating PIT table for the column : provEndTs as $getCurrentTimeFormat , cf : exi, RowKey : $pitRowKey ")
    }
    else
    {
      hbasePitPut(pitTab, pitRowKey, "exi", "lastRunDt", provEndTs)
    }
    hbasePitPut(pitTab, pitRowKey, "exi", "provCompSts", jobStatus)
    Logger.log.info(s" Updating PIT table for the column : provCompSts as $jobStatus , cf : exi, RowKey : $pitRowKey ")

    Logger.log.info(s"==============> Ending Provisioning extract PIT table with status as $jobStatus<==============")

    globalContext.spark.stop()

  }

  /* def CreatePEIDir (sparkSession: SparkSession, provisioningDatLocation: String): Unit = {

     val conf = sparkSession.sparkContext.hadoopConfiguration
     val fileSystem = org.apache.hadoop.fs.FileSystem.get( conf )

     val path = new Path( provisioningDatLocation )
     if (!fileSystem.exists( path )) {
       fileSystem.mkdirs( path )
     }
   }
 */
  /** Purpose : Def to get FixedWidth columns lpad query based on target columns and lengths
    * input : targetColumns, targetDataTypeLengths, transformationsViewName, pitRowKey
    * output: Returns resultant lpad query */
  def getFixedWidth (trgColumns: String, trgDataTypeLens: String, viewName: String, pitRowKey: String, pitTab: HTable): String = {
    val spTrgCols = trgColumns.split(';')
    val spTrgColsLen = trgDataTypeLens.split(';')
    val ColLen = spTrgCols.length
    val datatypeLen = spTrgColsLen.length

    //if target column dataType length is not matching with the number of columns , then end the workflow, else continue to create lpad query
    if (ColLen != datatypeLen) {
      Logger.log.info(s" Number of target columns do not match with the number of target Data Type lengths provided, hence ending the workflow with Failed staus")
      hbasePITEndStage(pitTab, "Fail", pitRowKey)
    }
    var i = 0
    var sqlString = ""
    while (i < ColLen) {
      var colName = spTrgCols(i)
      // println( colName )
      var colLen = spTrgColsLen(i)
      //println( colLen )
      //sqlString = sqlString + "RPAD(TRIM(" + colName + ")," + colLen.toInt + "," + "' '" + ")" + " AS " + colName + " , "
      sqlString = sqlString + "RPAD(" + colName + "," + colLen.toInt + "," + "' '" + ")" + " AS " + colName + " , "
      i = i + 1
    }
    Logger.log.info(s" Constructed sql String is" + sqlString)
    val RPADString = "SELECT " + sqlString.dropRight(2) + " from " + viewName
    RPADString
  }

  /** Purpose : Def to merge the header, trailer and data dataframs into one data frame
    * input : headerDF,DataDF, trailerDF
    * output: Returns the merged data frame */
  def mergeDFs (hdrDF: DataFrame, dataDF: DataFrame, trlDF: DataFrame): DataFrame = {
    hdrDF.union(dataDF).union(trlDF)
  }

  /** Purpose : Def to get the final extract
    * input : all the PEI columns and PIT RowKey
    * output: Final extract should be saved in a given path with given output file delimiter */
  def invokeExtraction (jsonOrTransView: String, isFixedWidth: String, trgColumn: String, trgDataTypeLen: String, pitRowKey: String, outFileColDelimGiven: String, hdrDesc: String, hdrDateFormat: String, trlDesc: String, outFileName: String, feedName: String, extractName: String, outFileLoc: String, outFileExt: String, archLoc: String, rootDir: String, pitTab: HTable, peiTab: String, workingDir: String): String = {
    var outFileColDelim=outFileColDelimGiven;
    try {
      val peiRmngColsDF = getPEIInfoDF(feedName + "-" + extractName, peiTab)
      if (peiRmngColsDF.count == 1) {
        val isOutFileRowDelim = peiRmngColsDF.select("_1").head.getString(0)
        val outFileRowDelim = peiRmngColsDF.select("_2").head.getString(0)
        Logger.log.info(s" isOutFileRowDelim : " + isOutFileRowDelim)
        Logger.log.info(s" outFileRowDelim : " + outFileRowDelim)
      }
    } catch {
      case e: Exception => Logger.log.info(" Exception at PEI table scan is not done properly while retriving the remainng columns based on rowkey, so ending the Provisioning with Failed status" :+ e.getMessage)
        hbasePITEndStage(pitTab, "Fail", pitRowKey)
        throw e
    }
    var viewTransSQL = jsonOrTransView //consider latest view
    val removeSplChrDFT=sqlContext.sql("select * from "+viewTransSQL)
    val removeSplChrDF1: RDD[Row] = removeSplChrDFT.rdd.map { rec =>
      val recStr: String = rec.mkString("~^~")
      var tempStr = ""
      for (c <- recStr) {
        if ((c >= 0x20 && c <= 0x7E) || c=='\n') {
          tempStr = tempStr + c
        }
      }

      val row: Array[String] = tempStr.split("\\~\\^\\~",-1)
      Row.fromSeq(row.toSeq)
    }
    val removeSplChrDF = sqlContext.createDataFrame(removeSplChrDF1, removeSplChrDFT.schema)
    removeSplChrDF.createOrReplaceTempView(jsonOrTransView)
    viewTransSQL=jsonOrTransView
    //Adding Fixed width based on IsFixedWidth
    // if isFixedWidth value as "Y" then construct lpad based on target column(s) length(s) else continue to generate the extract
    if (isFixedWidth == "Y") {
      Logger.log.info(" Constructing Fixed Width Query   ")
      val sqlRPADString = getFixedWidth(trgColumn, trgDataTypeLen, viewTransSQL, pitRowKey, pitTab)
      //executing the Fixed Width transformation
      Logger.log.info(s" Executing the  FixedWidth Constructed Query transformation : ${sqlRPADString}  ")

      val curExtFWDFT = sqlContext.sql(sqlRPADString)
      Logger.log.info(s" Successfully  executed  FixedWidth Query  ")
      curExtFWDFT.createOrReplaceTempView("dffwtv")

      Logger.log.info(s" Successfully  created view on top of FixedWidth Query  : dffwtv   ")
      viewTransSQL = "dffwtv"
    }

    //Adding output file delim
    //val sqlOPDQuery = "SELECT concat_ws('" + outFileColDelim + "'" + "," + trgColumn.replace(';', ',') + ") AS RID FROM " + viewTransSQL
    val sqlOPDQuery = "SELECT "+trgColumn.replace(';', ',')+"  FROM " + viewTransSQL
    Logger.log.info(s" Executing the  Output file delimiter Query transformation : ${sqlOPDQuery}  ")

    val curExtOPDT = sqlContext.sql(sqlOPDQuery)
    val provCount = curExtOPDT.count()
    Logger.log.info(s" Output file delimiter  Query Record Count : $provCount  ")
    Logger.log.info(s" Successfully  executed  Output file delimiter  Query  ")

    hbasePitPut(pitTab, pitRowKey, "exi", "provRecCnt", provCount.toString)
    Logger.log.info(s" Updating PIT table for the column : provRecCnt as ${provCount.toString} , cf : exi, RowKey : $pitRowKey ")

    val currentTs = getCurrentTsFormat // for directory name purpose storing current time in a varaible
    val provTempLoc = rootDir + "/" + feedName + "/" + extractName + "/temp_" + currentTs
    val provTempWorkLoc = workingDir + "/" + feedName + "/" + extractName + "/temp_" + currentTs

    Logger.log.info(" Given outFileColDelim is :"+outFileColDelim )
    // added by vshrest1 to handle colDelim
    /*    if(outFileColDelim.toString.getBytes.length == 2){
          outFileColDelim = tabDelim
          Logger.log.info(" Converted  outFileColDelim is :"+outFileColDelim )
        }*/

    if(outFileColDelim.toString.equalsIgnoreCase("NA")){
      outFileColDelim = tabDelim
      Logger.log.info(" Converted  outFileColDelim to default tab delim  :"+outFileColDelim )
    }
    else if(outFileColDelim.toString.equalsIgnoreCase("\\t")){
      outFileColDelim = tabDelim
      Logger.log.info(" slashes Converted  outFileColDelim to default tab delim  :"+outFileColDelim )
    }
    else {
      Logger.log.info("inside else PART row delim ===========>")
      //outFileColDelim = tabDelim
      Logger.log.info(" Else  outFileColDelim to default tab delim  :"+outFileColDelim )
    }
    Logger.log.info(" Considered  outFileColDelim  is  :"+outFileColDelim )

    if (hdrDesc == "NA" || trlDesc == "NA") {
      Logger.log.info(s" Header Description is NA, so not framing the header Dataframe  ")
      Logger.log.info(s" Trailer Description is NA, so not framing the header Dataframe  ")
      Logger.log.info(s" Executing the extract save function   ")


      curExtOPDT.rdd.map(rec => rec.mkString(outFileColDelim)).repartition(1).saveAsTextFile(provTempLoc)
      val savedFileName = fileSystem.globStatus(new Path(provTempLoc + "/p*"))(0).getPath.getName
      Logger.log.info(s" RDD file Name before renaming " + savedFileName)
      //renamePath(outLoc + "/part*", outLoc + "/" + curExtOutFileName)
      renamePath(provTempLoc + "/" + savedFileName, provTempLoc + "/"+outFileName )
      Logger.log.info(s" Renamed DF part output to  $provTempLoc/$outFileName ")
      rmPathIfExist(provTempLoc + "/_SUCCESS")
      getTotalLines(provTempLoc + "/"+outFileName)



      // val provExtractRecCount = saveFileToMapRFS(curExtOPDT, provTempLoc, outFileName,outFileColDelim)
      Logger.log.info(s" Successfully  Saved extract(Without Hdr &  Trl) to given path ${provTempLoc}   ")
      provCount + ";" + provTempLoc + ";" + outFileName

    } else {
      //get header RDD
      val headerDF = getHdrInfo(hdrDesc, hdrDateFormat, outFileColDelim)
      Logger.log.info(s" Successfully  constructed headerDF : ${headerDF.show(false)}  ")
      //get trailer RDD
      val trailerDF = getTrlInfo(outFileColDelim, curExtOPDT, trlDesc)
      Logger.log.info(s" Successfully  constructed trailerDF : ${trailerDF.show(false)}   ")

      Logger.log.info(s" Saving Data DF , HDR DF, TRL DF tp temp location as a files   ")

      rmPathIfExist(provTempWorkLoc + "/data/file2data.csv")
      Logger.log.info(s" Saving DataDF to data location ( " + provTempWorkLoc + "/data/file2data.csv )  ")

      curExtOPDT.dropDuplicates()
      curExtOPDT.rdd.map(rec => rec.mkString(outFileColDelim)).repartition(1).saveAsTextFile(provTempWorkLoc + "/data")
      val savedFileName = fileSystem.globStatus(new Path(provTempWorkLoc + "/data/p*"))(0).getPath.getName
      Logger.log.info(s" RDD file Name before renaming " + savedFileName)
      //renamePath(outLoc + "/part*", outLoc + "/" + curExtOutFileName)
      renamePath(provTempWorkLoc + "/data/" + savedFileName, provTempWorkLoc + "/data/file2data.csv" )
      Logger.log.info(s" Renamed DF part output to  $provTempWorkLoc/data/file2data.csv")
      rmPathIfExist(provTempWorkLoc + "/data/_SUCCESS")
      getTotalLines(provTempWorkLoc + "/data/file2data.csv")



      //saveFileToMapRFS(curExtOPDT, provTempLoc + "/data", "file2data.csv",outFileColDelim)

      rmPathIfExist(provTempWorkLoc + "/hdr/file1header.csv")
      Logger.log.info(s" Saving headerDF to hdr location ( " + provTempWorkLoc + "/hdr/file1header.csv )  ")
      saveFileToMapRFS(headerDF, provTempWorkLoc + "/hdr", "file1header.csv",outFileColDelim)

      rmPathIfExist(provTempWorkLoc + "/trl/file3trailer.csv")
      Logger.log.info(s" Saving trailerDF to trl location ( " + provTempWorkLoc + "/trl/file3trailer.csv )  ")
      saveFileToMapRFS(trailerDF, provTempWorkLoc + "/trl", "file3trailer.csv",outFileColDelim)

      mkdirs(provTempLoc)
      fileOrder(provTempWorkLoc, provTempLoc, outFileName)
      Logger.log.info(s" Successfully  Saved extract to given path ${provTempLoc}   ")
      Logger.log.info(s" Removing temp working location  ****Pankaj****  " + workingDir +  "/" + feedName + "/" + extractName)
      rmPathIfExist(workingDir +  "/" + feedName + "/" + extractName)
      provCount + ";" + provTempLoc + ";" + outFileName
    }
  }
  def invokeExtractionCom (isCommonFlg: String,jsonOrTransView: String, isFixedWidth: String, trgColumn: String, trgDataTypeLen: String, pitRowKey: String, outFileColDelimGiven: String, hdrDesc: String, hdrDateFormat: String, trlDesc: String, outFileName: String, feedName: String, extractName: String, outFileLoc: String, outFileExt: String, archLoc: String, rootDir: String, pitTab: HTable, peiTab: String, workingDir: String,securityfileLoc:String): String = {
    /*commonQry*/
    Logger.log.info(s"Inside invokeExtraction with isCommonFlg as $isCommonFlg")
    var extractName_temp:String=extractName
    var extrctJsonNm:String=""
    var outFileNm:String=outFileName
    var zipFileNm=""

    var prtFileNameLen=outFileName.split('|').size;
    if(prtFileNameLen>1) {
      Logger.log.info(s"OutFilename /ProvName has more filename and extract name")
      outFileNm = outFileName.split('|')(0)
      extrctJsonNm = outFileName.split('|')(1)
      zipFileNm = outFileName.split('|')(2)
      Logger.log.info(s"outFileNm :: "+outFileNm)
      Logger.log.info(s"extrctJsonNm :: "+extrctJsonNm)
      Logger.log.info(s"zipFileNm :: "+zipFileNm)
    }

    /*commonQry*/

    var outFileColDelim=outFileColDelimGiven;
    try {
      val peiRmngColsDF = getPEIInfoDF(feedName + "-" + extractName, peiTab)
      if (peiRmngColsDF.count == 1) {
        val isOutFileRowDelim = peiRmngColsDF.select("_1").head.getString(0)
        val outFileRowDelim = peiRmngColsDF.select("_2").head.getString(0)
        Logger.log.info(s" isOutFileRowDelim : " + isOutFileRowDelim)
        Logger.log.info(s" outFileRowDelim : " + outFileRowDelim)
      }
    } catch {
      case e: Exception => Logger.log.info(" Exception at PEI table scan is not done properly while retriving the remainng columns based on rowkey, so ending the Provisioning with Failed status" :+ e.getMessage)
        hbasePITEndStage(pitTab, "Fail", pitRowKey)
        throw e
    }
    var viewTransSQL = jsonOrTransView //consider latest view
    val removeSplChrDFT=sqlContext.sql("select * from "+viewTransSQL)
    val removeSplChrDF1: RDD[Row] = removeSplChrDFT.rdd.map { rec =>
      val recStr: String = rec.mkString("~^~")
      var tempStr = ""
      for (c <- recStr) {
        if ((c >= 0x20 && c <= 0x7E) || c=='\n') {
          tempStr = tempStr + c
        }
      }

      val row: Array[String] = tempStr.split("\\~\\^\\~",-1)
      Row.fromSeq(row.toSeq)
    }
    val removeSplChrDF = sqlContext.createDataFrame(removeSplChrDF1, removeSplChrDFT.schema)
    removeSplChrDF.createOrReplaceTempView(jsonOrTransView)
    viewTransSQL=jsonOrTransView
    //Adding Fixed width based on IsFixedWidth
    // if isFixedWidth value as "Y" then construct lpad based on target column(s) length(s) else continue to generate the extract
    if (isFixedWidth == "Y") {
      Logger.log.info(" Constructing Fixed Width Query   ")
      val sqlRPADString = getFixedWidth(trgColumn, trgDataTypeLen, viewTransSQL, pitRowKey, pitTab)
      //executing the Fixed Width transformation
      Logger.log.info(s" Executing the  FixedWidth Constructed Query transformation : ${sqlRPADString}  ")

      val curExtFWDFT = sqlContext.sql(sqlRPADString)
      Logger.log.info(s" Successfully  executed  FixedWidth Query  ")
      curExtFWDFT.createOrReplaceTempView("dffwtv")

      Logger.log.info(s" Successfully  created view on top of FixedWidth Query  : dffwtv   ")
      viewTransSQL = "dffwtv"
    }

    //Adding output file delim
    //val sqlOPDQuery = "SELECT concat_ws('" + outFileColDelim + "'" + "," + trgColumn.replace(';', ',') + ") AS RID FROM " + viewTransSQL
    val sqlOPDQuery = "SELECT "+trgColumn.replace(';', ',')+"  FROM " + viewTransSQL
    Logger.log.info(s" Executing the  Output file delimiter Query transformation : ${sqlOPDQuery}  ")

    val curExtOPDT = sqlContext.sql(sqlOPDQuery)
    val provCount = curExtOPDT.count()
    Logger.log.info(s" Output file delimiter  Query Record Count : $provCount  ")
    Logger.log.info(s" Successfully  executed  Output file delimiter  Query  ")

    hbasePitPut(pitTab, pitRowKey, "exi", "provRecCnt", provCount.toString)
    Logger.log.info(s" Updating PIT table for the column : provRecCnt as ${provCount.toString} , cf : exi, RowKey : $pitRowKey ")

    val currentTs = getCurrentTsFormat // for directory name purpose storing current time in a varaible

    /*commonQry*/
    //added isCommonFlg var to handle common queries in json for function invokeExtraction
    //added for commonQueries Handling

    //if(isCommonFlg.equalsIgnoreCase("Yes"))
    if(prtFileNameLen>1)
    {
      extractName_temp=extrctJsonNm
    }
    else {
      extractName_temp=extractName
    }
    val provTempLoc = rootDir + feedName + "/" + extractName_temp + "/temp_" + currentTs

    //val provTempLoc = rootDir + "/" + feedName + "/" + extractName + "/temp_" + currentTs
    /*commonQry*/
    val provTempWorkLoc = workingDir + "/" + feedName + "/" + extractName + "/temp_" + currentTs

    Logger.log.info(" Given outFileColDelim is :"+outFileColDelim )
    // added by vshrest1 to handle colDelim
    /*    if(outFileColDelim.toString.getBytes.length == 2){
          outFileColDelim = tabDelim
          Logger.log.info(" Converted  outFileColDelim is :"+outFileColDelim )
        }*/

    if(outFileColDelim.toString.equalsIgnoreCase("NA")){
      outFileColDelim = tabDelim
      Logger.log.info(" Converted  outFileColDelim to default tab delim  :"+outFileColDelim )
    }
    else if(outFileColDelim.toString.equalsIgnoreCase("\\t")){
      outFileColDelim = tabDelim
      Logger.log.info(" slashes Converted  outFileColDelim to default tab delim  :"+outFileColDelim )
    }
    else {
      Logger.log.info("inside else PART row delim ===========>")
      //outFileColDelim = tabDelim
      Logger.log.info(" Else  outFileColDelim to given delim  :"+outFileColDelim )
    }
    Logger.log.info(" Considered  outFileColDelim  is  :"+outFileColDelim )

    if (hdrDesc == "NA" || trlDesc == "NA") {
      Logger.log.info(s" Header Description is NA, so not framing the header Dataframe  ")
      Logger.log.info(s" Trailer Description is NA, so not framing the header Dataframe  ")
      Logger.log.info(s" Executing the extract save function   ")


      curExtOPDT.rdd.map(rec => rec.mkString(outFileColDelim)).repartition(1).saveAsTextFile(provTempLoc)
      val savedFileName = fileSystem.globStatus(new Path(provTempLoc + "/p*"))(0).getPath.getName
      Logger.log.info(s" RDD file Name before renaming " + savedFileName)
      //renamePath(outLoc + "/part*", outLoc + "/" + curExtOutFileName)
      /*CommonQry
            renamePath(provTempLoc + "/" + savedFileName, provTempLoc + "/"+outFileName )
            Logger.log.info(s" Renamed DF part output to  $provTempLoc/$outFileName ")
            rmPathIfExist(provTempLoc + "/_SUCCESS")
            getTotalLines(provTempLoc + "/"+outFileName)
      */
      renamePath(provTempLoc + "/" + savedFileName, provTempLoc + "/"+outFileNm )
      Logger.log.info(s" Renamed DF part output to  $provTempLoc/$outFileNm ")
      rmPathIfExist(provTempLoc + "/_SUCCESS")
      getTotalLines(provTempLoc + "/"+outFileNm)

      // val provExtractRecCount = saveFileToMapRFS(curExtOPDT, provTempLoc, outFileName,outFileColDelim)
      Logger.log.info(s" Successfully  Saved extract(Without Hdr &  Trl) to given path ${provTempLoc}   ")
      //provCount + ";" + provTempLoc + ";" + outFileName
      provCount + ";" + provTempLoc + ";" + outFileNm

    } else {
      //get header RDD
      val headerDF = getHdrInfo(hdrDesc, hdrDateFormat, outFileColDelim)
      Logger.log.info(s" Successfully  constructed headerDF : ${headerDF.show(false)}  ")
      //get trailer RDD
      val trailerDF = getTrlInfo(outFileColDelim, curExtOPDT, trlDesc)
      Logger.log.info(s" Successfully  constructed trailerDF : ${trailerDF.show(false)}   ")

      Logger.log.info(s" Saving Data DF , HDR DF, TRL DF tp temp location as a files   ")

      rmPathIfExist(provTempWorkLoc + "/data/file2data.csv")
      Logger.log.info(s" Saving DataDF to data location ( " + provTempWorkLoc + "/data/file2data.csv )  ")

      curExtOPDT.dropDuplicates()
      curExtOPDT.rdd.map(rec => rec.mkString(outFileColDelim)).repartition(1).saveAsTextFile(provTempWorkLoc + "/data")
      val savedFileName = fileSystem.globStatus(new Path(provTempWorkLoc + "/data/p*"))(0).getPath.getName
      Logger.log.info(s" RDD file Name before renaming " + savedFileName)
      //renamePath(outLoc + "/part*", outLoc + "/" + curExtOutFileName)
      renamePath(provTempWorkLoc + "/data/" + savedFileName, provTempWorkLoc + "/data/file2data.csv" )
      Logger.log.info(s" Renamed DF part output to  $provTempWorkLoc/data/file2data.csv")
      rmPathIfExist(provTempWorkLoc + "/data/_SUCCESS")
      getTotalLines(provTempWorkLoc + "/data/file2data.csv")



      //saveFileToMapRFS(curExtOPDT, provTempLoc + "/data", "file2data.csv",outFileColDelim)

      rmPathIfExist(provTempWorkLoc + "/hdr/file1header.csv")
      Logger.log.info(s" Saving headerDF to hdr location ( " + provTempWorkLoc + "/hdr/file1header.csv )  ")
      saveFileToMapRFS(headerDF, provTempWorkLoc + "/hdr", "file1header.csv",outFileColDelim)

      rmPathIfExist(provTempWorkLoc + "/trl/file3trailer.csv")
      Logger.log.info(s" Saving trailerDF to trl location ( " + provTempWorkLoc + "/trl/file3trailer.csv )  ")
      saveFileToMapRFS(trailerDF, provTempWorkLoc + "/trl", "file3trailer.csv",outFileColDelim)

      mkdirs(provTempLoc)
      /*CommonQry fileOrder(provTempWorkLoc, provTempLoc, outFileName)*/
      fileOrder(provTempWorkLoc, provTempLoc, outFileNm)
      Logger.log.info(s" Successfully  Saved extract to given path ${provTempLoc}   ")
      Logger.log.info(s" Removing temp working location  ****Pankaj****  " + workingDir +  "/" + feedName + "/" + extractName)
      rmPathIfExist(workingDir +  "/" + feedName + "/" + extractName)
      provCount + ";" + provTempLoc + ";" + outFileNm
    }
  }


  /** Purpose : Def to get the final extract
    * input : all the PEI columns and PIT RowKey
    * output: Final extract should be saved in a given path with given output file delimiter */
  def generateExtract (plcTabName: String, plcTab: HTable, peiRowKey: String, pitRowKey: String, rootDir: String, peiTab: String, pitTab: HTable, pitTabName: String, securityfileLoc: String, workingDir: String): Unit = {
    //feedName: String, extractName: String, pitRowKey: String, outFileColDelim: String, srcCd: String, prtnrCd: String, isJsonProp: String, sqlQuery: String, transQuery: String, isFixedWidth: String, trgColumn: String, trgDataTypeLen: String, hdrDesc: String, hdrDateFormat: String, trlDesc: String, outFileName: String, prcStTm: String, outFileLoc: String, outFileExt: String, archLoc: String):
    try {
      //return values // fix: this  return value is input for the Unix shell script
      Logger.log.info(s"generateExtract inititated with values -> plcTabName : $plcTabName, plcTab : $plcTab, peiRowKey : $peiRowKey , pitRowKey : $pitRowKey, rootDir : $rootDir , peiTab : $peiTab, pitTab : $pitTab , pitTabName : $pitTabName , securityfileLoc : $securityfileLoc , workingDir : $workingDir ")

      val peiRDD = CustomFunctions.getEntityInfoPEI(peiRowKey, peiTab)

    if (!peiRDD.isEmpty) {
      //save individual columns
      val feedName = peiRDD.map(arrayVals => arrayVals._1).mkString
      val extractName = peiRDD.map(arrayVals => arrayVals._2).mkString
      val hdrDesc = peiRDD.map(arrayVals => arrayVals._3).mkString
      val hdrDateFormat = peiRDD.map(arrayVals => arrayVals._4).mkString
      val trlDesc = peiRDD.map(arrayVals => arrayVals._5).mkString
      val isJsonProp = peiRDD.map(arrayVals => arrayVals._6).mkString
      val jsonPropLoc = peiRDD.map(arrayVals => arrayVals._7).mkString
      val sqlQuery = peiRDD.map(arrayVals => arrayVals._8).mkString
      val transQuery = peiRDD.map(arrayVals => arrayVals._9).mkString
      val trgColumn = peiRDD.map(arrayVals => arrayVals._10).mkString
      val trgDataTypeLen = peiRDD.map(arrayVals => arrayVals._11).mkString
      var outFileName = peiRDD.map(arrayVals => arrayVals._12).mkString
      val outFileExt = peiRDD.map(arrayVals => arrayVals._13).mkString
      val outFileLoc = peiRDD.map(arrayVals => arrayVals._14).mkString
      val archLoc = peiRDD.map(arrayVals => arrayVals._15).mkString
      val IsOutFileColDelim = peiRDD.map(arrayVals => arrayVals._16).mkString
      var outFileColDelim = peiRDD.map(arrayVals => arrayVals._17).mkString
      val isFixedWidth = peiRDD.map(arrayVals => arrayVals._18).mkString
      val srcCd = peiRDD.map(arrayVals => arrayVals._19).mkString
      val prtnrCd = peiRDD.map(arrayVals => arrayVals._20).mkString
      val entitySet = peiRDD.map(arrayVals => arrayVals._21).mkString
      val snapBuildType = peiRDD.map(arrayVals => arrayVals._22).mkString

      var zipFileName=""
      var isCommonFlg=""
      //added to handle output file name and zipfilename -starts
      Logger.log.info(s" pei:outFileName value is  : "+outFileName)
      var outFileNamelen = outFileName.split('|').size

      Logger.log.info(s" pei:outFileName number of parts is  : "+outFileNamelen)
      if(outFileNamelen>1)
      {
        zipFileName=outFileName.split('|')(1)
        Logger.log.info(s" Zip File Name value is  : "+zipFileName)
      }
      outFileName=outFileName.split('|')(0)
      Logger.log.info(s" OutFileName value is  : "+outFileName)

      if (outFileName.equalsIgnoreCase("y"))
      {
        isCommonFlg="Y"
      }
      else {
        isCommonFlg="N"
      }
      Logger.log.info(s" --------------------------------Inside generate Extract :: outFileColDelim value is  : "+outFileColDelim)
      //added to handle output file name and zipfilename -ends

      var viewTransSQL = ""
      var provRes=""

      val plcRowKey = feedName + "-" + extractName
      // if isJsonProperty is "No" then proceed with executing the sqlQueries from PEI Htable , else consider the Queries from JSON file location and proceed for Step by step execution
      if (isJsonProp == "N") {
        Logger.log.info(s" this extract not having the Json file as input, so continuing to execute sqlQuery transformations mentioned in pei table")

        // executing the transformation by including pre-checks
        // if sqlQuery is equals to "NA" then ending the workflow with Failed state, else continue to generate the extract
        if (sqlQuery == "NA") {
          Logger.log.error(" SQLQuery is Passed as Empty string,ending Provisioning extract  ")
          hbasePITEndStage(pitTab, "Fail", pitRowKey)
        } else {
          // After each sqlQuery and transQuery execution , save the results in a view instead of data frames
          try {
            Logger.log.info(" Executing the  SQLQuery transformation  ")
            Logger.log.info(s" curExtSqlQuery is   : ${sqlQuery}  ")
            val curExtDFT = sqlContext.sql(sqlQuery)
            Logger.log.info(" Successfully  executed transformation of SQLQuery  : "+sqlQuery)
            Logger.log.info(" count for the query is   : "+curExtDFT.count())
            curExtDFT.createOrReplaceTempView("dftv")
            Logger.log.info(" Successfully  created view on top of sqlQuery  : dftv   ")
            var transView = "dftv"

            // if transQuery is equals to "NA" then consider latest view as sqlQuery view , else consider the transQuery view to generate the extract
            if (transQuery == "NA") {
              Logger.log.info(" Additional transformations query(substr,case etc) is Passed as Empty string,continuing Provisioning extract  ")
            } else {
              val curExtDFAT: DataFrame = sqlContext.sql(transQuery)

              curExtDFAT.createOrReplaceTempView("dfatv")
              Logger.log.info(" Successfully  created view on top of transQuery  : dfatv   ")
              var transView = "dfatv" //consider latest view
            }

            provRes = invokeExtraction(transView, isFixedWidth, trgColumn, trgDataTypeLen, pitRowKey, outFileColDelim, hdrDesc, hdrDateFormat, trlDesc, outFileName, feedName, extractName, outFileLoc, outFileExt, archLoc, rootDir, pitTab, peiTab, workingDir)

            Logger.log.info("output of InvokeExraction "+provRes)
            val prtFileRecCount =  provRes.split(';')(0)
            val provFileName = outFileName

            hbasePITEndStageUpdateProv(pitTab, "extracted", pitRowKey, provFileName,"1");

            Logger.log.info(s" Using PEI sqlQuery/transQuery , Extract generated successfully  =");
            createMetaFileReturnVals(zipFileName,plcRowKey, plcTab, pitTabName, pitRowKey, provRes.split(';')(1), provRes.split(';')(2), outFileLoc, outFileName, outFileExt, archLoc, peiTab, securityfileLoc, pitTab)
            Logger.log.info(s" Successfully Ending Provisioning extract  ")

          } catch {
            case e: Exception => {
              Logger.log.info(" Exception while invoking the sqlQueries through Spark " + e.getMessage)
              Logger.log.error("Error occured : " + e.getStackTrace.mkString("\n"))
            }
              hbasePITEndStage(pitTab, "Fail", pitRowKey)
              throw e
          }

        }
      } else {
        try {
          Logger.log.info(s" Considering the JSON data from JSON File location")
          val provRes = readJSON(isCommonFlg,plcRowKey, plcTab, pitTabName,plcTabName, peiRowKey, jsonPropLoc, pitRowKey, isFixedWidth, trgColumn, trgDataTypeLen, outFileColDelim, hdrDesc, hdrDateFormat, trlDesc, outFileName, feedName, extractName, outFileLoc, outFileExt, archLoc, rootDir, pitTab, peiTab, workingDir,securityfileLoc)
          Logger.log.info(s" Using JSON part files , Extract generated successfully  =");
          var exName = provRes.split(';')(1).dropRight(1)

          if (provRes.split(';').size == 3) {
            //if (provRes.split(';').size == 2) {
            Logger.log.info(" provRes size is 3 , so not deleting the ")
            exName = provRes.split(';')(1)
          }
          /*CommonQry        if (provRes.split(';').size == 2) {
                    Logger.log.info(" provRes size is 2 , so not deleting the ")
                    exName = provRes.split(';')(1)
                    createMetaFileReturnVals(zipFileName,plcRowKey, plcTab, pitTabName, pitRowKey, provRes.split(';')(0), exName, outFileLoc, outFileName, outFileExt, archLoc, peiTab, securityfileLoc, pitTab)
                  }*/

          val comMetaFlg=provRes.split(';')(2)
          if(comMetaFlg.equals("Y")) {
            Logger.log.info(" Executing Common Meta function ")
            createMetaFileReturnVals(zipFileName,plcRowKey, plcTab, pitTabName, pitRowKey, provRes.split(';')(0), exName, outFileLoc, outFileName, outFileExt, archLoc, peiTab, securityfileLoc, pitTab)
          }
          else{
            Logger.log.info(" NOT executing Common Meta function ")
          }
          Logger.log.info(s" Successfully Ending Provisioning extract  ")

        } catch {
          case e: Exception => Logger.log.info(" Exception while invoking the readJSON " + e.getMessage)
            hbasePITEndStage(pitTab, "Fail", pitRowKey)
            throw e
        }

      }
    } else {
      Logger.log.info(s">>>>> PEI rowkey($peiTab) respective entity is not found, Please Check PEI HTable <<<<< ")
      hbasePITEndStage(pitTab, "Fail", pitRowKey)

    }
    } catch {
      case e: Exception => {
        Logger.log.info(" Exception at generateExtract definition : " + e.getMessage)
        Logger.log.error("Error occured : " + e.getStackTrace.mkString("\n"))
      }
        throw e
    }
  }

  /** Purpose : Def to send the reurn values to next script
    * input : lastRunDate, fullLoadFlag, entityName
    * output: returns the values in an extractmeta file */
  def createMetaFileReturnVals (zipFileName:String,plcRowKey: String, plcTab: HTable, pitTabName: String, pitRowKey: String, extractFilePath: String, extractFileName: String, outFileLoc: String, outFileName: String, outFileExt: String, archLoc: String, peiTab: String, securityfileLoc: String, pitTab: HTable): Unit = {
    try {
      //return values // fix: this  return value is input for the Unix shell script
      Logger.log.info(s" tempory metadata file content for this extract are..");
      Logger.log.info(s" zipFileName : " + zipFileName);
      Logger.log.info(s" pitTabName : " + pitTabName);
      Logger.log.info(s" pitRowKey : " + pitRowKey);
      Logger.log.info(s" extractFilePath : " + extractFilePath);
      Logger.log.info(s" extractFileName : " + extractFileName);
      Logger.log.info(s" outFileLoc : " + outFileLoc);
      Logger.log.info(s" outFileName : " + outFileName);
      Logger.log.info(s" outFileExt : " + outFileExt);
      Logger.log.info(s" archLoc : " + archLoc);
      Logger.log.info(s" PEITabName : " + peiTab);
      Logger.log.info(s" SecurityFileLoc : " + securityfileLoc);
      val returnVal = "pitTabName="+pitTabName + "\npitRowKey=" + pitRowKey + "\nextractFilePath=" + extractFilePath + "\nextractFileName=" + extractFileName + "\noutFileLoc=" + outFileLoc + "\noutFileName=" + outFileName + "\noutFileExt=" + outFileExt + "\narchLoc=" + archLoc + "\npeiTab=" + peiTab + "\nsecurityfileLoc=" + securityfileLoc+"\nzipFileName="+zipFileName
      Logger.log.info(s" Framed MetaContent :")
      Logger.log.info(s"-------------------------------------------------------------------------------------------------- ")
      Logger.log.info(returnVal)
      Logger.log.info(s"-------------------------------------------------------------------------------------------------- ")
      createHDFSFile(extractFilePath + "/extractmeta.txt", returnVal)

      //FIX: Update the LastRUNDT as per the approach
      /* for CommonQuery  moving the update command to generateExtract
      val lastRunDtAsProvStrTs = getHtableValByRowKey(pitTabName: String, pitRowKey: String, "exi", "provStrTs")
      Logger.log.info(" PIT ProvStrTs AS lastRunDt : " + lastRunDtAsProvStrTs)
      hbasePLCPut(plcTab, plcRowKey, "plc", "lastRunDt", lastRunDtAsProvStrTs)
     */
    } catch {
      case e: Exception => {
        Logger.log.info(s">>>>> Exception at creating extractmeta.txt file  <<<<< : " + e.getMessage)
        Logger.log.error("Error occured : " + e.getStackTrace.mkString("\n"))
      }
        hbasePITEndStage(pitTab, "Fail", pitRowKey)
        throw e

    }
  }


  /** Purpose : Def to get lastRunDateFlag
    * input : lastRunDate, fullLoadFlag, entityName
    * output: Returns lastRunDateFlag based on input fields lastRunDate & fullLoadFlag  criteria */
  def getLstRunDtFlag (lstrundate: String, fullLoadFlg: String, entity: String): Boolean = {
    var lstrundateFlg = false
    Logger.log.info(s" Given fullLoadFlg value : $fullLoadFlg")

    // if lastRunDate is empty , then consider this load as Full load and make lastRunDateFlag as False,
    // else check the given  fullLoadFlag value is Yes then consider this load as Full load and make lastRunDateFlag as False,
    // else consider this load as Incremental load and make lastRunDateFlag as True
    if (lstrundate.isEmpty) {
      Logger.log.info(s" performing full load runtime snapshot for the entity ${entity}")
      lstrundateFlg = false
    } else {
      if (fullLoadFlg.equalsIgnoreCase("Y")) {
        Logger.log.info(s" performing full load runtime snapshot for the entity ${entity}")
        lstrundateFlg = false
      } else {
        Logger.log.info(s" performing Incremental load runtime snapshot for the entity ${entity} with last rundate as ${lstrundate}")
        lstrundateFlg = true
      }
    }
    lstrundateFlg
  }

  /** Purpose : Def to get raw snapshot per entity
    * input : snapBuildType, PSC RowKey, PEI entity, partnerCode, sourceCode, incrementalEndTime, PIT RowKey
    * output: Raw or parquet (based on snapBuildType ) snapshot should be created based on lastRunDateFlag */
  def getSnapshotExtractPerEntity (EXTRACT_EIT_FLG:String,snapBuildType:String,plcTabName:String,plcTab: HTable, pscTabName: String, lakeEitTableName: String, mountPath: String, workingDir: String, lakeEppTableName: String, rowKeyConfig: String, entity: String, prtnrCd: String, srcCd: String, incEndTs: String, pitRowKey: String, snapConfigTab: HTable, pitTab: HTable): String = {
  //def getSnapshotExtractPerEntity (snapBuildType:String,plcTabName:String,plcTab: HTable, pscTabName: String, lakeEitTableName: String, mountPath: String, workingDir: String, lakeEppTableName: String, rowKeyConfig: String, entity: String, prtnrCd: String, srcCd: String, incEndTs: String, pitRowKey: String, snapConfigTab: HTable, pitTab: HTable): String = {
  Logger.log.info(s" Scanning PSC for rowKeyConfig provided:$rowKeyConfig")
    //val workingDir = s"${globalContext.workingDir}"
    // Get PSC scanned rowKey entity
    val snpCfgScan = getPkTs(rowKeyConfig, pscTabName)
    var peiFullLoadFlg=" "
    var pitRawRowDelim=" "
    var pitRawPartnFlr=" "
    var pitRawFileCnt=" "

    //if PSC scanned rowKey entity is empty then end the workflow with Failed Status, else continue to generate raw snapshot
    if (!snpCfgScan.isEmpty()) {
      try {
        val primaryKeys = snpCfgScan.map(_._4.split(";")).collect.flatten
        Logger.log.info(s" Primary Key Columns for $entity : ${primaryKeys.mkString}")

        val dmlCol = snpCfgScan.map(_._5).collect.mkString
        val modTsCol = snpCfgScan.map(_._7).collect.mkString
        //val lstrundate = snpCfgScan.map( _._9 ).collect.mkString.trim
        val plcRowKey = rowKeyConfig.split("-")(0) + "-" + rowKeyConfig.split("-")(1)

        val lstrundate = getHtableValByRowKey(plcTabName: String, plcRowKey: String, "plc", "lastRunDt").trim

        Logger.log.info(s" last run date From PLC : $lstrundate")
        val fullLoadFlg = snpCfgScan.map(_._8).collect.mkString
        var lstrundateFlg = getLstRunDtFlag(lstrundate, fullLoadFlg, entity)
        Logger.log.info(s" last run date Flag : $lstrundateFlg")
        // if lstrundateFlg true then Incremental will run
        if(lstrundateFlg)
        {
          peiFullLoadFlg=entity+"-N"
        }else
        {
          peiFullLoadFlg=entity+"-Y"
        }


        // Get LakeEIT scanned rowKey entity
        //var result: Boolean=false
        //var result:String = eitLakeTabScan(snapBuildType,lakeEitTableName, mountPath, lakeEppTableName, workingDir, prtnrCd, srcCd, entity, lstrundateFlg, lstrundate, incEndTs, pitRowKey, pitTab)
  //      var EXTRACT_EIT_FLG="N"
        var result:String = eitLakeTabScanMod(EXTRACT_EIT_FLG,snapBuildType,lakeEitTableName, mountPath, lakeEppTableName, workingDir, prtnrCd, srcCd, entity, lstrundateFlg, lstrundate, incEndTs, pitRowKey, pitTab)

        Logger.log.info(s"result retrieved from eitTabScan :: " +result)

        val resultFlg= result.split(';')(0)
        pitRawRowDelim=pitRawRowDelim+result.split(';')(1).dropRight(1)
        pitRawPartnFlr=pitRawPartnFlr+result.split(';')(2).dropRight(1)
        pitRawFileCnt=pitRawFileCnt+result.split(';')(3).dropRight(1)



        val ptnrCd = s"${prtnrCd.toUpperCase()}"
        val src = s"${srcCd.toUpperCase()}"
        val entName = s"${entity.toUpperCase()}"
        Logger.log.info(s" Working Directory path for Incremental extract: $workingDir")

        //if LakeEIT scanned rowKey entity is empty then end the workflow with Success Status , else continue to save the raw snapshot merged files into a dataframe as entity name
        if (resultFlg.equalsIgnoreCase("true")) {
          try {
            Logger.log.info(s" Captured Incremental Extract for ${entName}")
            Logger.log.info(s" Merging Schema for $entName from $workingDir/$entName")
            Logger.log.info(s" checking existence of working directory")
            val merDir = workingDir + "/" + entName
            mkdirs(merDir)
            val mergeDF = sqlContext.read.option("mergeSchema", true).parquet(s"$workingDir/$entName").persist(org.apache.spark.api.java.StorageLevels.MEMORY_AND_DISK_SER)
            Logger.log.info(s" Merge Schema Record Count for $entName :" + mergeDF.count)

            try {
              snpCfgScan.unpersist()
              val userWindow = Window.partitionBy(concat_ws("-", primaryKeys.map(c => col(c)): _*), lit("")).orderBy(col(s"$modTsCol").desc)
              val dedupDF = mergeDF.withColumn("rank", row_number().over(userWindow)).where(col("rank") === 1).drop("rank")
              Logger.log.info(s"Schema: "+dedupDF.printSchema() +s"Count::"+dedupDF.count())
              /*val noCdcFlg=dedupDF.filter(dedupDF("CDC_FLAG") =!= 'D'
              ).persist(org.apache.spark.api.java.StorageLevels.MEMORY_AND_DISK_SER)*/
              dedupDF.createOrReplaceTempView("dedupDf")
              val noCdcFlg=sqlContext.sql(s"select * from dedupDf where cdc_flag != 'D'")
              val dedupCnt = noCdcFlg.count()
              Logger.log.info(s"Number of Records Extracted for $entName  with Dedup Logic:" + dedupCnt)
              noCdcFlg.createOrReplaceTempView(s"${entName}")

              /*Logger.log.info( s" Updating lastRnTs as ${incEndTs} in PSC HTable for EntNm:$entName" )
            hbasePSCPut( rowKeyConfig, "psc", "lastRunDt", incEndTs )*/ dedupDF.unpersist()

            } catch {
              case e: Exception => Logger.log.info(s">>>>> Exception at Main Loading MergeSchema/SqlStatement for $entName <<<<<" :+ e.getMessage)
                //removing intermediate parquet data
                rmPathIfExist(workingDir + "/" + entName)
                hbasePITEndStage(pitTab, "Fail", pitRowKey)
                throw e
            }


          } catch {
            case e: Exception => Logger.log.info(s">>>>> Exception at Main Loading Merge Parquet Schema/SqlStatement for $entName <<<<<" :+ e.getMessage)
              //removing intermediate parquet data
              rmPathIfExist(workingDir + "/" + entName)
              hbasePITEndStage(pitTab, "Fail", pitRowKey)
              throw e
          }


        } else {
          Logger.log.info(s" Since there are No Changes reflected for the $entName in a given time range, hence ending the workflow  ")

          peiFullLoadFlg=entName+"-ERROR"
          pitRawRowDelim=entName+"-ERROR"
          pitRawPartnFlr=entName+"-ERROR"
          pitRawFileCnt=entName+"-0"
          hbasePITEndStage(pitTab, "Fail", pitRowKey)
          Logger.log.info(s" Updating lastRnTs as ${incEndTs} in PLC HTable for EntNm:$entName")
          hbasePitPut(plcTab, plcRowKey, "plc", "lastRunDt", incEndTs)
          // hbasePSCPut(snapConfigTab, rowKeyConfig, "psc", "lastRunDt", incEndTs)

        }
      } catch {
        case e: Exception => Logger.log.info(" Exception at DataLake Snapshot Scan , Failed due to " :+ e.getMessage)
          hbasePITEndStage(pitTab, "Fail", pitRowKey)
          throw e

      }
    } else {
      Logger.log.info(">>>>> Snapshot config(PSC) PrimaryKeys / CDC Timestamp not found, Please Check PSC HTable <<<<< ")
      hbasePITEndStage(pitTab, "Fail", pitRowKey)
    }

    peiFullLoadFlg+";"+pitRawRowDelim+";"+pitRawPartnFlr+";"+pitRawFileCnt
  }

  /** Purpose : Def to save Dataframe to resultant location with default files part-00000
    * input : DataFrame, outputLocation
    * output: Output file should be created in specified location */
  def saveDFOutputToMapR (diffRec: DataFrame, outFileLoc: String): Unit = {
    val outLoc = outFileLoc.replace("/mapr/", "/")
    mkdirs(outLoc)
    Logger.log.info(s" OutputLocation is : ${outLoc}  ")
    diffRec.repartition(1).write.mode("overwrite").csv(outLoc)
  }


  /*def getJSONValueByKey(jsonFilePath:String): Unit= {
    val readNDBJson = globalContext.spark.wholeTextFiles(jsonFilePath).map(x => x._2).map(data => data.replaceAll("\n", ""))
    val readJsonDF = sqlContext.read.json(readNDBJson)
    val flattenedDF = jsDF.select(col("feedName"), explode(col("ExtractDetails")).as("ExtractDetailsFl"), col("extractName"))
    readJsonDF.columns.filter(t => t == "F5938DBE_PROV_TIN_PAY_AFFIL").map(x => x.mkString).foreach(a => {
      val colName = a.toString;
      println("Entity / Table Name : " + colName);
      if (colName != "_id" && colName != "doc_crt_ts") {
        var colNameRes = "";
        val entityDType = readJsonDF.select(colName).schema.map(_.dataType.typeName).take(1).mkString;
        readJsonDF.select(colName).createOrReplaceTempView("maprdbview");
        if (entityDType.equals("array")) {
          println("dtype is array")
          readJsonDF.select(col(colName).getItem(0)).toDF("xdf").createOrReplaceTempView("maprdbview");
          colNameRes = "xdf"
          println("column to be considered for array type is : " + colNameRes)
        } else {
          colNameRes = colName
          println("dtype is struct")
          println("column to be considered for array type is : " + colNameRes)
        }
        var entitySelectStr = "select " + colNameRes.toString + ".* from maprdbview";
        println("CONSTRUCTED SQL String to create Entity specific dataframe with respective columns   : " + entitySelectStr);
        var colNameDF = spark.sql(entitySelectStr)
        colNameDF.createOrReplaceTempView(colName);
        println("Created Temp View called " + colName + "on top of Entity(" + colName + ")");
        println("Retrieving Data from Temporary View");
        spark.sql("select * from " + colName).show(false);
        println("======================");
      }
    })
  }
*/
  /** Purpose : Def to read the JSON data from .json file
    * input : json file path takes from properties file
    * output: Returns the Dataframes for each sqlQueries */
  def readJSON (isCommonFlg :String,plcRowKey:String, plcTab:HTable, pitTabName:String,plcTabName: String, peiRowKey: String, jsonFilePath: String, pitRowKey: String, isFixedWidth: String, trgColumn: String, trgDataTypeLen: String, outFileColDelim: String, hdrDesc: String, hdrDateFormat: String, trlDesc: String, outFileNameIp: String, feedName: String, extractName: String, outFileLoc: String, outFileExt: String, archLoc: String, rootDir: String, pitTab: HTable, peiTab: String, workingDir: String, securityfileLoc:String): String = {
    try {
      Logger.log.info(s" saveDFOutputToMapR inintiated with input arguments -> peiRowKey : $peiRowKey , jsonFilePath : $jsonFilePath , pitRowKey : $pitRowKey , isFixedWidth : $isFixedWidth , trgColumn : $trgColumn , trgDataTypeLen : $trgDataTypeLen , outFileColDelim : $outFileColDelim")
      Logger.log.info(s" jsonInputPath  : $jsonFilePath ")
    /*   val readNDBJson =  globalContext.spark.wholeTextFiles(jsonFilePath).map(x => x._2).map(data => data.replaceAll("\n", ""))
       val jsDF = sqlContext.read.json(readNDBJson)
       val flattenedDF = jsDF.select(col("feedName"),explode(col("ExtractDetails")).as("ExtractDetailsFl"),col("extractName"))
       val dflat = flattenedDF.select("feedName","extractName","ExtractDetailsFl.prtNo","ExtractDetailsFl.prtNm","ExtractDetailsFl.dataQueries")
   */ val readNDBJson = globalContext.spark.wholeTextFiles(jsonFilePath).map(x => x._2).map(data => data.replaceAll("\n", ""))
    val readJsonDF = sqlContext.read.json(readNDBJson)
    val fields = readJsonDF.schema.filter(c => c.name == "_corrupt_record");
    var outFileName=outFileNameIp

    if (!fields.isEmpty) {
      Logger.log.info(" Given JSON file is not valid, check the json validation from this url https://jsonlint.com/ ")
      hbasePITEndStage(pitTab, "Fail", pitRowKey)
    }
    val exFeedName = feedName

    val getExtractString = "select * from JSONfeedV where feedName='" + exFeedName + "'"
    readJsonDF.createOrReplaceTempView("JSONfeedV")
    //gives the feed Specfic DF
    val feedDF = sqlContext.sql(getExtractString)
    val flattenedDF = feedDF.select(col("feedName"), explode(col("extraction")).as("extraction"))
    //filter the given extraction
    val filtertedExDF = flattenedDF.filter(col("extraction.extractName") === extractName)

      //added isCommonFlg var to handle common queries in json for function invokeExtraction
      if (isCommonFlg.equalsIgnoreCase("Y") ) {
        Logger.log.info(s" Inside isCommonFlg as Y ReadJson")
        val exComDF = filtertedExDF.select("extraction.commonQueries")
        val flattndComDF = exComDF.select(explode(col("commonQueries")).as("commonQueries"))
        val comNested_flds = flattndComDF.schema.filter(c => c.name == "commonQueries").flatMap(_.dataType.asInstanceOf[StructType].fields);
        val totalComSqlQry = globalContext.spark.parallelize(comNested_flds).map(x => x.name).count;
        var i = 1;
        val n = totalComSqlQry.toInt;
        for (i <- 1 to n) {
          val sqlQryName = "comSqlQuery" + i;
          val sqlQ = flattndComDF.select(col("commonQueries").getField(sqlQryName)).toDF(sqlQryName);
          Logger.log.info(s" ComsqlQuery columnName : " + sqlQryName);
          //Logger.log.info(s" Query : " + sqlQ);
          val res = sqlQ.where(sqlQ.col(sqlQryName).isNotNull);
          //Logger.log.info(sqlQryName + " key fetch count of Common Qry " + res.count);
          if (res.count > 0) {
            var comQryString = sqlQ.head.getString(0).mkString
            val comQryStrVal = sqlQ.head.getString(0).mkString
            if (comQryStrVal.contains("$LAST_RUN_DATE")) {
              try {
                val plcColsDF = getPLCInfoDF(feedName + "-" + extractName, plcTabName)
                if (plcColsDF.count == 1) {
                  var plcLastRunDt = plcColsDF.select("value").head.getString(0)
                  Logger.log.info(s" last Run Date From PLC entry  of Common Qry: " + plcLastRunDt)

                  if (plcLastRunDt.isEmpty) {
                    plcLastRunDt = getCurrentDateFormat
                    Logger.log.info(s" last Run Date as current date since blank value in PLC entry  of Common Qry: " + plcLastRunDt)
                  }
                  comQryString = comQryStrVal.replace("$LAST_RUN_DATE", plcLastRunDt)
                  Logger.log.info(s" sqlQuery String After replacing LAST_RUN_DATE of Common Qry: " + comQryString)
                }
              } catch {
                case e: Exception => Logger.log.info(" Exception at PEI table scan is not done properly while retriving the remaining columns based on rowkey, so ending the Provisioning with Failed status" :+ e.getMessage)
                  hbasePITEndStage(pitTab, "Fail", pitRowKey)
                  throw e
              }
            }
            val singleQueryDF = sqlContext.sql(comQryString);
            Logger.log.info(s" Able to Execute  Common Qry" + singleQueryDF)
            singleQueryDF.createOrReplaceTempView(sqlQryName);
            Logger.log.info(" count for the Common query is   : " + "for entity " + sqlQryName + " is " + singleQueryDF.count())

            Logger.log.info(s" Able to Create Temporary View of Common Qry as  " + sqlQryName)
          }
          //invoke extraction after completion of last common SQL query in the JSON
          if (i == n) {
            Logger.log.info(s"Finished executing common sql queries")
          }

        }

      }
    //save the  isOutputMerge to stringVariable
    val isOutputMerge = filtertedExDF.select("extraction.isOutputMerge").head.getString(0)
    Logger.log.info("isOutputMerge : " + isOutputMerge)

    //save the  isOutputMerge to stringVariable
    val isHdrTrlReqFlag = filtertedExDF.select("extraction.extractHeaderTrailerRequired").head.getString(0)
    Logger.log.info("isHdrTrlReqFlag : " + isHdrTrlReqFlag)


    //save the  isOutputMerge to stringVariable
    val isSchemaChangeFlag = filtertedExDF.select("extraction.isSchemaChange").head.getString(0)
    Logger.log.info("isSchemaChangeFlag : " + isSchemaChangeFlag)


    // save the extractDetails into seperate DF in order to explode
    val exDetailsDF = filtertedExDF.select("extraction.extractDetails")
    val flattndDetailsDF = exDetailsDF.select(explode(col("extractDetails")).as("extractDetails"))

    val dflat = flattndDetailsDF.select("extractDetails.provNo", "extractDetails.provName", "extractDetails.provHeaderDesc", "extractDetails.provHeaderDateFormat", "extractDetails.provTrailerDesc", "extractDetails.provOutFileColDelim", "extractDetails.provTrgColumn", "extractDetails.provTrgDataTypeLen", "extractDetails.provDataQueries")


    var finalResSqlViewName = "";

    //code for updating PIT at the end of the successful extraction
    var prtFileRecCount = "";
    var provFileName = "";
    var provFilesPath = "";
    var provFilesCount = dflat.count()
    var provRes =""
    var prtFileNm=""
    var extrctJsonNm=""
    var zipFileNm=""
    var prtFileNameLen=0 // all parts in json should have same length otherwise it will consider the length of the last part
    dflat.collect.foreach(partFiles => {
      Logger.log.info(s" For Loop of partFiles in JSON  ")
      val prtFileNo = partFiles.getString(0);
      Logger.log.info(s" provFileNo : " + prtFileNo);
      var prtFileName = partFiles.getString(1);
      Logger.log.info("prtFileName : " + prtFileName)
      //var prtFileNameLen=0 // all parts in json should have same length otherwise it will consider the length of the last part
      prtFileNameLen = prtFileName.split('|').size
      Logger.log.info("prtFileNameLen : " + prtFileNameLen)
      if(prtFileNameLen>1) {
        prtFileNm = prtFileName.split('|')(0)
        extrctJsonNm = prtFileName.split('|')(1)
        zipFileNm = prtFileName.split('|')(2)
        Logger.log.info(s" prtFileNm : " + prtFileNm)
        Logger.log.info(s" extrctJsonNm : " + extrctJsonNm)
        Logger.log.info(s" zipFileNm : " + zipFileNm)
      }
      Logger.log.info(s" prtFileName : " + prtFileName)
      Logger.log.info(s" isOutputMerge : " + isOutputMerge)

      var hdrDescNew = partFiles.getString(2);
      var hdrDateFormatNew = partFiles.getString(3);
      var trlDescNew = partFiles.getString(4);
      var outFileColDelimNew = partFiles.getString(5);

      var trgColumnNew = trgColumn
      var trgDataTypeLenNew = trgDataTypeLen
      if (isSchemaChangeFlag.equalsIgnoreCase("yes")) {
        trgColumnNew = partFiles.getString(6);
        trgDataTypeLenNew = partFiles.getString(7);

      }

      if (isCommonFlg.equalsIgnoreCase("Y") ) {
        Logger.log.info(s" considering the json TRG column and length")
        trgColumnNew = partFiles.getString(6);
        trgDataTypeLenNew = partFiles.getString(7);
      }
      Logger.log.info(s" trgColumnNew : " + trgColumnNew)
      Logger.log.info(s" trgDataTypeLenNew : " + trgDataTypeLenNew)

      if (isOutputMerge.equalsIgnoreCase("Yes") ) {
        hdrDescNew = "NA"
        hdrDateFormatNew = "NA"
        trlDescNew = "NA"
        outFileColDelimNew = outFileColDelim
      }

      val prtQueriesDF = dflat.filter(dflat("provNo") === prtFileNo).select(col("provDataQueries"));
      val partFileQueriesDF = prtQueriesDF.select(explode(prtQueriesDF("provDataQueries"))).toDF("provDataQueries");
      val nested_fields = partFileQueriesDF.schema.filter(c => c.name == "provDataQueries").flatMap(_.dataType.asInstanceOf[StructType].fields);
      val totalSqlQueries = globalContext.spark.parallelize(nested_fields).map(x => x.name).count;
      Logger.log.info(s" totalSqlQueries : " + totalSqlQueries);
      var i = 1;
      val n = totalSqlQueries.toInt;
      for (i <- 1 to n) {
        val colName = "sqlQuery" + i;
        val sqlQ = partFileQueriesDF.select(col("provDataQueries").getField(colName)).toDF(colName);
        Logger.log.info(s" sqlQuery columnName : " + colName);
        val res = sqlQ.where(sqlQ.col(colName).isNotNull);
        //        Logger.log.info(colName + " key fetch count " + res.count);
        if (res.count > 0) {
          var queryString = sqlQ.head.getString(0).mkString
          val queryStringVal = sqlQ.head.getString(0).mkString
          if (queryStringVal.contains("$LAST_RUN_DATE")) {
            try {
              val plcColsDF = getPLCInfoDF(feedName + "-" + extractName, plcTabName)
              if (plcColsDF.count == 1) {
                var plcLastRunDt = plcColsDF.select("value").head.getString(0)
                Logger.log.info(s" last Run Date From PLC entry  : " + plcLastRunDt)

                if (plcLastRunDt.isEmpty) {
                  plcLastRunDt = getCurrentDateFormat
                  Logger.log.info(s" last Run Date as Current Date as blank value in PLC entry  : " + plcLastRunDt)
                }
                queryString = queryStringVal.replace("$LAST_RUN_DATE", plcLastRunDt)
                Logger.log.info(s" sqlQuery String After replacing LAST_RUN_DATE : " + queryString)
              }
            } catch {
              case e: Exception => Logger.log.info(" Exception at PEI table scan is not done properly while retriving the remainng columns based on rowkey, so ending the Provisioning with Failed status" :+ e.getMessage)
                hbasePITEndStage(pitTab, "Fail", pitRowKey)
                throw e
            }
          }
          val singleQueryDF = sqlContext.sql(queryString);

          Logger.log.info(s" Able to Execute " + colName)
          singleQueryDF.createOrReplaceTempView(colName);
          Logger.log.info(" count for the query is   : "+"for entity "+colName+" is "+singleQueryDF.count())

          Logger.log.info(s" Able to Create Temporary View as  " + colName)
          finalResSqlViewName = colName;
        }
        if(outFileColDelimNew.toString.equalsIgnoreCase("NA")){
          outFileColDelimNew = tabDelim
          Logger.log.info(" Converted  outFileColDelim to default tab delim  :"+outFileColDelimNew )
        }
        //invoke extraction after completion of last SQL query in the JSON
        Logger.log.info(" current loop value:: "+ i+"Max loop value ::"+n )

        if (i == n) {
          Logger.log.info(s" FINAL VIEW to be considered as : " + finalResSqlViewName);
          Logger.log.info(s" FINAL hdrDesc to be considered as : " + hdrDescNew);
          Logger.log.info(s" FINAL hdrDateFormat to be considered as : " + hdrDateFormatNew);
          Logger.log.info(s" FINAL trlDesc to be considered as : " + trlDescNew);
          Logger.log.info(s" FINAL outFileColDelimNew to be considered as : " + outFileColDelimNew);
          Logger.log.info(s" FINAL trgColumnNew to be considered as : " + trgColumnNew);
          Logger.log.info(s" FINAL trgDataTypeLenNew to be considered as : " + trgDataTypeLenNew);
          Logger.log.info(" B4 generating extract isOutputMerge : " + isOutputMerge)
          Logger.log.info(" B4 generating extract isHdrTrlReqFlag : " + isHdrTrlReqFlag)

          Logger.log.info(" B4 generating extract isOutputMerge : " + isSchemaChangeFlag)
          if (isCommonFlg.equalsIgnoreCase("y"))
          {
            provRes = invokeExtractionCom(isCommonFlg,finalResSqlViewName, isFixedWidth, trgColumnNew, trgDataTypeLenNew, pitRowKey, outFileColDelimNew, hdrDescNew, hdrDateFormatNew, trlDescNew, prtFileName, feedName, extractName, outFileLoc, outFileExt, archLoc, rootDir, pitTab, peiTab, workingDir,securityfileLoc)
          }
          else
          {
            provRes = invokeExtraction(finalResSqlViewName, isFixedWidth, trgColumnNew, trgDataTypeLenNew, pitRowKey, outFileColDelimNew, hdrDescNew, hdrDateFormatNew, trlDescNew, prtFileName, feedName, extractName, outFileLoc, outFileExt, archLoc, rootDir, pitTab, peiTab, workingDir)
          }

          Logger.log.info(s" Using JSON file , return value of invokeExtraction " + provRes);

          //added (at end)to indicate executing common meta generation for different parts starts
          val extractFilePath = provRes.split(';')(1)
          val extractFileName = provRes.split(';')(2)
          if (!isOutputMerge.equalsIgnoreCase("yes")) {
            if(prtFileNameLen>1) {
              Logger.log.info(s" Generating separate meta file : $extractFilePath :: ::$extractFileName");
              //createMetaFileReturnVals(zipFileNm,plcRowKey, plcTab, pitTabName, pitRowKey, extractFilePath, extractFileName, outFileLoc, outFileName, outFileExt, archLoc, peiTab, securityfileLoc, pitTab)
              createMetaFileReturnVals(zipFileNm,plcRowKey, plcTab, pitTabName, pitRowKey, extractFilePath, extractFileName, outFileLoc, extractFileName, outFileExt, archLoc, peiTab, securityfileLoc, pitTab)

            }

          }

          //added (at end)to indicate executing common meta generation for different parts ends

          Logger.log.info(s" Using JSON file , Extract generated for this partFileNo: " + prtFileNo);
          prtFileRecCount = prtFileRecCount + provRes.split(';')(0) + ";";
          provFileName = provFileName + prtFileName + ";";
          provFilesPath = provFilesPath + provRes.split(';')(1) + "/" + provRes.split(';')(2) + "~";
        }

      }
    })


    if (provFilesCount > 1) {

      Logger.log.info(s" More than one part :: Invoking def to move each provs extraction to main extraction and prtFileNameLen is $prtFileNameLen");
      val currentTs = getCurrentTsFormat // for directory name purpose storing current time in a varaible
      // val provTempLoc = rootDir + feedName + "/" + extractName + "/temp_" + currentTs
      val provTempLoc = rootDir + "/" + feedName + "/" + extractName + "/temp_" + currentTs
      val provTempWorkLoc = workingDir + "/" + feedName + "/" + extractName + "/temp_" + currentTs
      if(prtFileNameLen<1) {
        Logger.log.info(s" Executing the extract save function for moving to one folder   ")
        moveProvsToOneLoc(provFilesPath, provTempLoc)
      }
      else
      {
        Logger.log.info(s" NOT Executing the extract save function for moving to one folder since provname in json has two parts")
      }
      /*CommonQry      Logger.log.info(s" Invoking def to move each provs extraction to main extraction  ");
            val currentTs = getCurrentTsFormat // for directory name purpose storing current time in a varaible
            Logger.log.info(s" Executing the extract save function for moving to one folder   ")
            val provTempLoc = rootDir + "/" + feedName + "/" + extractName + "/temp_" + currentTs
            val provTempWorkLoc = workingDir + "/" + feedName + "/" + extractName + "/temp_" + currentTs
            moveProvsToOneLoc(provFilesPath, provTempLoc)*/
      //if isOutputMerge is yes then combining all the provisions to one file

      var res = provTempLoc + ";" + provFileName.replace(';', '|')
      Logger.log.info(s" Check #1 : "+res)
      if (isOutputMerge.equalsIgnoreCase("yes")) {
        Logger.log.info(s" isOutputMerge is Yes, for this scenario, checking  isHdrTrlReqFlag is Yes or not, if yes, considering hdr, trl frpm PEI   ")
        //generate header and trailer based on isHdrtrlFlag
        if ((isHdrTrlReqFlag.equalsIgnoreCase("yes")) && (!hdrDesc.equalsIgnoreCase("NA")) && (!trlDesc.equalsIgnoreCase("NA"))) {
          Logger.log.info(s" hdrDesc & trlDesc is not equals to NA scenario")

          Logger.log.info(s" merging the files from( " + provTempWorkLoc + " ) to ( " + provTempWorkLoc + "/temp/file2data.csv )   ")
          mkdirs(provTempWorkLoc + "/data")
          mergeToOneFile(provTempWorkLoc, provTempWorkLoc + "/data/file2data.csv")

          // renamePath(provTempLoc)
          Logger.log.info(s" removing files from Dir( " + provTempWorkLoc + " ), FileNames ( " + provFileName + " )   ")
          removeSpecFiles(provTempWorkLoc, provFileName)

          Logger.log.info(s" Generating header DF by considering hdrDesc( " + hdrDesc + " ), hdrDateFormat ( " + hdrDateFormat + "),outFileColDelim ( " + outFileColDelim + " )   ")
          val headerDF = getHdrInfo(hdrDesc, hdrDateFormat, outFileColDelim)
          Logger.log.info(s" Successfully  constructed headerDF : ${headerDF.show(false)}  ")

          Logger.log.info(s" Generating trailerDF DF by considering outFileColDelim( " + outFileColDelim + " ), Data FileName as ( " + provTempWorkLoc + "/temp/file2data.csv )")
          val trailerDF = getFileTrlInfo(outFileColDelim, provTempWorkLoc + "/data/file2data.csv", trlDesc)
          Logger.log.info(s" Successfully  constructed trailerDF : ${trailerDF.show(false)}   ")

          rmPathIfExist(provTempWorkLoc + "/hdr/file1header.csv")
          Logger.log.info(s" Saving headerDF to one location ( " + provTempWorkLoc + "/hdr/file1header.csv )  ")
          saveFileToMapRFS(headerDF, provTempWorkLoc + "/hdr", "file1header.csv",outFileColDelim)
          rmPathIfExist(provTempWorkLoc + "/trl/file3trailer.csv")
          Logger.log.info(s" Saving trailerDF to one location ( " + provTempWorkLoc + "/trl/file3trailer.csv )  ")
          saveFileToMapRFS(trailerDF, provTempWorkLoc + "/trl", "file3trailer.csv",outFileColDelim)
          mkdirs(provTempLoc)
          fileOrder(provTempWorkLoc, provTempLoc, outFileName)
          Logger.log.info(s" Successfully  Saved extract to geven path ${provTempLoc}   ")
          Logger.log.info(s" Removing temp working location  ****Pankaj JSON****  " + workingDir +  "/" + feedName + "/" + extractName)
          rmPathIfExist(workingDir +  "/" + feedName + "/" + extractName)


        } else {
          Logger.log.info(s" hdrDesc & trlDesc is equals to NA scenario")
          Logger.log.info(s" merging the files from( " + provTempLoc + " ) to ( " + provTempLoc + "/" + outFileName + " )   ")
          mergeToOneFile(provTempLoc, provTempLoc + "/" + outFileName)
          // renamePath(provTempLoc)
          Logger.log.info(s" removing files from Dir( " + provTempLoc + " ), FileNames ( " + provFileName + " )   ")
          removeSpecFiles(provTempLoc, provFileName)
        }


      } /*else {
        Logger.log.info(s" isOutputMerge is NO  scenario")
        Logger.log.info(s" merging the files from( " + provTempLoc + " ) to ( " + provTempLoc + "/" + outFileName + " )   ")
        mergeToOneFile(provTempLoc, provTempLoc + "/" + outFileName)
        // renamePath(provTempLoc)
        Logger.log.info(s" removing files from Dir( " + provTempLoc + " ), FileNames ( " + provFileName + " )   ")
        removeSpecFiles(provTempLoc, provFileName)

      }*/
      /*CommonQry */
      //added (at end)to indicate executing common meta generation for different parts
      // res = provTempLoc + ";" + outFileName
      if (!isOutputMerge.equalsIgnoreCase("yes")) {
        if(prtFileNameLen>1) {
          res = provTempLoc + ";" + outFileName+";N"
        }
      }
      else{
        res = provTempLoc + ";" + outFileName+";Y"
      }

      //res = provTempLoc + ";" + outFileName
      hbasePITEndStageUpdateProv(pitTab, "extracted", pitRowKey,provFileName.dropRight(1), provFilesCount.toString);
      Logger.log.info(s" END of Looping the sqlQueries inside JSON  : return value :: $res");
      res

    }else{
      /*CommonQry */
      //added (at end)to indicate executing common meta generation for different parts
      provRes.split(';')(1)+";"+provRes.split(';')(2)+";Y"

      //provRes.split(';')(1)+";"+provRes.split(';')(2)
      //provCount + ";" + provTempLoc + ";" + outFileName
    }
    } catch {
      case e: Exception => {
        Logger.log.info(" Exception at readJSON definition : " + e.getMessage)
        Logger.log.error("Error occured : " + e.getStackTrace.mkString("\n"))
      }
        throw e
    }
  }

  /*
  Purpose to generate merge hdr, trl data files in the order by avoiding sort operation
   */

  def fileOrder(provTempWorkLoc: String,provTempLoc: String,outFileName:String):Unit={
    Logger.log.info(s" Merging the DF's / Files as per Order Sequence i.e HDR -> DATA -> TRL ")
    Logger.log.info(s" Step1 : moving files from data, hdr, trl locations to temp folder location ")
    renamePath(provTempWorkLoc+"/data/file2data.csv",provTempWorkLoc+"/2.csv")
    renamePath(provTempWorkLoc+"/hdr/file1header.csv",provTempWorkLoc+"/1.csv")
    renamePath(provTempWorkLoc+"/trl/file3trailer.csv",provTempWorkLoc+"/3.csv")
    Logger.log.info(s" Step2 : removing files from data, hdr, trl folders from temp folder location ")
    rmPathIfExist(provTempWorkLoc+"/data")
    rmPathIfExist(provTempWorkLoc+"/hdr")
    rmPathIfExist(provTempWorkLoc+"/trl")

    Logger.log.info(s" Before Merging the 3 files, counts are")
    Logger.log.info(s" Data File Count"+getTotalLines(provTempWorkLoc+"/2.csv"))
    Logger.log.info(s" HDR File Count"+getTotalLines(provTempWorkLoc+"/1.csv"))
    Logger.log.info(s" DTRLata File Count"+getTotalLines(provTempWorkLoc+"/3.csv"))

    val currentTs = getCurrentTsFormat // for directory name purpose storing current time in a varaible
    val provTempLocDest = provTempWorkLoc + "/temp_" + currentTs

    Logger.log.info(s" Step3 :merging the files from( "+provTempWorkLoc+" ) to ( "+provTempLocDest+ "/"+outFileName+" )   ")

    mergeToOneFile(provTempWorkLoc, provTempLocDest + "/" + outFileName)


    val provFileNames = "1.csv;2.csv;3.csv;"
    Logger.log.info(s" Step3 :removing renamed files from Dir( "+provTempWorkLoc+" ), FileNames ( "+provFileNames+ " )   ")

    removeSpecFiles(provTempWorkLoc,provFileNames)

    Logger.log.info(s" Data File Count"+getTotalLines(provTempLocDest+"/"+outFileName))
    Logger.log.info(s" Step4 : moving merged file to actual temp location   ")
    renamePath(provTempLocDest+"/"+outFileName,provTempLoc+"/"+outFileName)

    Logger.log.info(s" Step5 : Removing merged temp location    ")
    rmPathIfExist(provTempLocDest)
    rmPathIfExist(provTempWorkLoc)

  }




  /** Purpose : Def to merge files in MapR FileSystem to one file in particular location
    * input :  provFilesPath
    * output: number of provisioned files should be merged to one file extract location in FileSystem */

  def mergeToOneFile(srcPath: String, dstPath: String): Unit =  {
    /*    val hadoopConfig = new Configuration()
    val hdfs = FileSystem.get(hadoopConfig)*/

    Logger.log.info(s" Files copied to ( "+dstPath+" ) one location  ");
    FileUtil.copyMerge(fileSystem, new Path(srcPath), fileSystem, new Path(dstPath), false, fsConf, null)
    Logger.log.info(s" Files copied to ( "+dstPath+" ) one location  ");
  }


  /** Purpose : Def to remove files in MapR FileSystem from particular location
    * input :   specified filenames separated by ;
    * output: specified files should be removed from FileSystem */
  def removeSpecFiles(provFilesPath:String,fileNames:String): Unit = {
    val totalFilePaths = fileNames.split(';').length
    Logger.log.info(s" total number of Prov files : "+totalFilePaths)
    var i = 1;
    val n = totalFilePaths;
    for( i <- 1 to n ) {
      Logger.log.info(s" Source File to remove "+fileNames.split(';')(i-1))
      rmPathIfExist(provFilesPath+"/"+fileNames.split(';')(i-1))
    }
    Logger.log.info(s" Removed Successfully")

  }

  /** Purpose : Def to move files in MapR FileSystem to one particular location
    * input :  provFilesPath
    * output: number of provisioned files should be moved to one extract location in FileSystem */
  def moveProvsToOneLoc(provFilesPath:String,provTempLoc:String): Unit = {
    mkdirs(provTempLoc)
    val totalFilePaths = provFilesPath.split('~').length
    Logger.log.info(s" total number of Prov files : "+totalFilePaths)
    var i = 1;
    val n = totalFilePaths;
    for( i <- 1 to n ) {
      Logger.log.info(s" Source File to move "+provFilesPath.split('~')(i-1))
      renamePath(provFilesPath.split('~')(i-1), provTempLoc + "/")
    }
    Logger.log.info(s" Multiple ProvExtarcts saved under : "+provTempLoc)

  }


  /** Purpose : Def to create file in MapR FileSystem
    * input : path , content of the file
    * output: Given file should be created in FileSystem */
  def createHDFSFile(filePath:String,content:String) {
    Logger.log.info(s" Trying to write to HDFS..." )
    val output = fileSystem.create(new Path(filePath))
    val writer = new PrintWriter(output)
    try {
      writer.write(content)
    }
    finally {
      writer.close()
      Logger.log.info(s" Writer Closed..")
    }
  }


  /** Purpose : Def to get entityMetaDataTab Htable data based on rowkey provided
    * input : entityMetaDataTab RowKey i.e. partnerCode-sourceCode
    * output: entityMetaDataTab RowKey respective column(s) data based on group filters should be retrieved */

  def getEntityMetaDataInfo(rowKeyMetaDataTab:String, grpName:String,entityMetaDataTab:String):org.apache.spark.rdd.RDD[(String, String)]={
    try{
      val scan = new Scan()
      val filter = new PrefixFilter(Bytes.toBytes(rowKeyMetaDataTab))
      val filter1 = new SingleColumnValueFilter(Bytes.toBytes("ci"), Bytes.toBytes("denormSnapshot"), CompareOp.EQUAL, Bytes.toBytes(s"${grpName}"));
      val filter2 = new SingleColumnValueFilter(Bytes.toBytes("ci"), Bytes.toBytes("activeflag"), CompareOp.EQUAL, Bytes.toBytes("Y"));
      scan.setCaching(10000)
      scan.setCacheBlocks(false)
      filter1.setFilterIfMissing(true)
      filter2.setFilterIfMissing(true)
      scan.setFilter(filterList(filter1,filter2, filter))
      val grpVal = globalContext.hbaseContext.hbaseRDD(TableName.valueOf(entityMetaDataTab), scan).cache
      val grpInfoRDD = grpVal.map(tuple => {
        val result = tuple._2
        (Bytes.toString(result.getValue(Bytes.toBytes("ci"), Bytes.toBytes("denormSnapshotEntityName"))),
          (Bytes.toString(result.getValue(Bytes.toBytes("ci"), Bytes.toBytes("sourceEntityName")))))
      })
      grpInfoRDD
    } catch {
      case e: Exception => Logger.log.error(s" Exception while retriving denormSnapshotEntityName/sourceEntityName from entityMetadata table for $rowKeyMetaDataTab" :+ e.getMessage)
        throw e
    }

  }

  /** Purpose : Def to create group view , by fetching the denormSnapshotEntityName/sourceEntityName from maprDB using groupRDD provided
    * input : groupRDD, and goupName
    * output: group view should be created */

  def getGrpDenorSnap(grpInfoRDD: RDD[(String, String)],grpNm:String):Unit={

    val denormSnpEntList = grpInfoRDD.map(x => (x._1, x._2)).collect.toList.map(x => (x._1, s"${x._2}"))
    val pjsRdd = globalContext.spark.parallelize(denormSnpEntList)
    val pjsArrayRdd = pjsRdd.groupByKey.mapValues(_.mkString(","))

    val denormSnapshotEntityName = pjsArrayRdd.map(kv => {kv._1})
    Logger.log.info(s"denormSnapshotEntityName: "+denormSnapshotEntityName.first.toString)
    val entList = pjsArrayRdd.map(kv => {kv._2})
    try {
      val df1 = globalContext.spark.loadFromMapRDB(s"${denormSnapshotEntityName.first.toString}").map(line => line.toString());
      val readJson = sqlContext.read.json(df1)
      readJson.printSchema()
      readJson.show(10, false)
      readJson.createOrReplaceTempView(s"${grpNm}")
      val getRes = sqlContext.sql(s"select * from ${grpNm} ")

    }
    catch {
      case e: Exception => Logger.log.info("Exception at executing loadFromMapRDB " :+ e.getMessage)
        throw e
    }

  }



  def readSrcAsFile(feedName:String,extractName:String,inputFileName:String,rootDir:String,inputFileLocation:String,jsonPropFileLoc:String): Unit= {
    try{
      import sqlContext.implicits._ // Fix this import
      val currentTs = CustomFunctions.getCurrentTsFormat
      val rmcharInputFileName = inputFileName.replace("_*", "")
      var InputSchemaLoc = rootDir.replace("/mapr", "") + feedName + "/" + extractName + "/InputSchemaLocation_" + currentTs
      val inputFileLoc = inputFileLocation.replace("/mapr", "")
      Logger.log.info(s" inputFileLocation with feed TimesStamp: " + inputFileLoc)

      Logger.log.info(s" inputFileLocation : " + inputFileLocation)

      val jsonFilePath = jsonPropFileLoc.replace("/mapr", "")
      val readNDBJson = globalContext.spark.wholeTextFiles(jsonFilePath).map(x => x._2).map(data => data.replaceAll("\n", ""))
      val readJsonDF = sqlContext.read.json(readNDBJson)
      val exFeedName = feedName
      readJsonDF.createOrReplaceTempView("JSONfeedV")
      val getExtractString = "select * from JSONfeedV where feedName='" + exFeedName + "'"
      val feedDF = sqlContext.sql(getExtractString)
      val flattenedDF = feedDF.select($"feedName", explode($"extraction").as("extraction"))
      val filtertedExDF = flattenedDF.filter("extraction.extractName == '" + extractName + "'")

      case class trlHdrSchema (desc: String)


      InputSchemaLoc = rootDir.replace("/mapr", "") + feedName + "/" + extractName + "/InputSchemaLocation_" + currentTs
      var inDetailsDF = filtertedExDF.select("extraction.InputFileDetails")
      var inflattndDetailsDF = inDetailsDF.select(explode($"InputFileDetails").as("InputFileDetails"))
      var indflat = inflattndDetailsDF.select("InputFileDetails.inputFileColumns", "InputFileDetails.inputFiledataTypeLength", "InputFileDetails.IsInputFileRowDelimited", "InputFileDetails.InputFileRowDelimiter", "InputFileDetails.isInputFileFixedWidth", "InputFileDetails.isInputFileColumnDelimited", "InputFileDetails.inputFileColumnDelimiter", "InputFileDetails.isInputFileValidationRequired", "InputFileDetails.inputFileValidationRules")
      var inputFileColumns = inflattndDetailsDF.select("InputFileDetails.inputFileColumns").first.mkString
      var inputFiledataTypeLength = inflattndDetailsDF.select("InputFileDetails.inputFiledataTypeLength").first.mkString
      var IsInputFileRowDelimited = inflattndDetailsDF.select("InputFileDetails.IsInputFileRowDelimited").first.mkString
      var InputFileRowDelimiter = inflattndDetailsDF.select("InputFileDetails.InputFileRowDelimiter").first.mkString
      var isInputFileFixedWidth = inflattndDetailsDF.select("InputFileDetails.isInputFileFixedWidth").first.mkString
      var isInputFileColumnDelimited = inflattndDetailsDF.select("InputFileDetails.isInputFileColumnDelimited").first.mkString
      var inputFileColumnDelimiter = inflattndDetailsDF.select("InputFileDetails.inputFileColumnDelimiter").first.mkString
      var isInputFileValidationRequired = inflattndDetailsDF.select("InputFileDetails.isInputFileValidationRequired").first.mkString
      var inputFileValidationRules = inflattndDetailsDF.select("InputFileDetails.inputFileValidationRules").first.mkString
      var createschema = globalContext.spark.parallelize(Seq(inputFileColumns))
      createschema.saveAsTextFile(InputSchemaLoc)
      var loadinputFileColumn = sqlContext.read.format("csv").option("delimiter", ";").option("header", "true").load(InputSchemaLoc)
      var inputFileColumnsschema = loadinputFileColumn.schema
      var dataDF = sqlContext.read.format("csv").option("delimiter", inputFileColumnDelimiter).schema(inputFileColumnsschema).load(inputFileLocation.replace("/mapr", "")).filter($"DTL".contains("DTL"))
      dataDF.createOrReplaceTempView(rmcharInputFileName)

      if (isInputFileValidationRequired == "Y") {
        srcFileValidations(inputFileLoc,inflattndDetailsDF)
      }


    }
    catch
      {
        case e: Exception => Logger.log.error(s" Exception at while reading/creating File View  " :+ e.getMessage)
          throw e
      }
  }

  case class trlHdrSchema(desc:String)

  def srcFileValidations(inputFileLoc:String, inflattndDetailsDF:DataFrame ):Unit= {
    try {


      var inFileRDD = globalContext.spark.textFile(inputFileLoc)
      var hdrDataRDD = inFileRDD.filter(_.startsWith("HDR"))
      var hdrRDDWithSchema = hdrDataRDD.map(a => trlHdrSchema(a.toString))
      import sqlContext.implicits._ // Fix this import
      var hdrDataDF = hdrRDDWithSchema.toDF()
      hdrDataDF.createOrReplaceTempView("InHdrRec")

      var trlDataRDD = inFileRDD.filter(_.startsWith("TRL"))
      var trlRDDWithSchema = trlDataRDD.map(a => trlHdrSchema(a.toString))
      var trlDataDF = trlRDDWithSchema.rdd.toDF()
      trlDataDF.createOrReplaceTempView("InTrlRec")

      var InputFileQueriesDF = inflattndDetailsDF.select(explode(inflattndDetailsDF("InputFileDetails.inputFileValidationRules"))).toDF("inputFileValidationRules");
      var inputHeaderValidationRulesqlQ = InputFileQueriesDF.select(col("inputFileValidationRules").getField("InputHeaderValidationRule")).toDF("InputHeaderValidationRule");
      var inputDataValidationRulesqlQ = InputFileQueriesDF.select(col("inputFileValidationRules").getField("InputDataValidationRule")).toDF("InputDataValidationRule");
      var inputTrailerValidationRulesqlQ = InputFileQueriesDF.select(col("inputFileValidationRules").getField("InputTrailerValidationRule")).toDF("InputTrailerValidationRule");
      var InputHeaderValidationRuleQueryString = inputHeaderValidationRulesqlQ.head.getString(0).mkString
      var InputDataValidationRuleQueryString = inputDataValidationRulesqlQ.head.getString(0).mkString
      var InputTrailerValidationRuleQueryString = inputTrailerValidationRulesqlQ.head.getString(0).mkString

      var InErrVal = sqlContext.sql(InputHeaderValidationRuleQueryString)
      var errorValidation = InErrVal.filter($"status".contains("FAILED INPUT HDR VALIDATION"))
      if (errorValidation.count >= 1) {
        println("FAILED INPUT HDR VALIDATION")
        globalContext.spark.stop
      }
      InErrVal = sqlContext.sql(InputDataValidationRuleQueryString)
      errorValidation = InErrVal.filter($"status".contains("FAILED INPUT DTL VALIDATION"))
      if (errorValidation.count >= 1) {
        println("FAILED INPUT DTL VALIDATION")
        globalContext.spark.stop
      }
      InErrVal = sqlContext.sql(InputTrailerValidationRuleQueryString)
      errorValidation = InErrVal.filter($"status".contains("FAILED INPUT TRL VALIDATION"))
      if (errorValidation.count >= 1) {
        println("FAILED INPUT TRL VALIDATION")
        globalContext.spark.stop
      }
    } catch {
      case e: Exception => Logger.log.info(" Exception at Src File Validation " :+ e.getMessage)
        throw e
    }
  }



  /*  This Def used for generating the pdf by taking the input */

  def generatePDF(inputFile:String,outputFilePath: String ): Unit = {
    import com.itextpdf.text._
    import com.itextpdf.text.pdf.PdfWriter   /*Fix this Import */
    val pdfDoc = new Document(PageSize.A4)
    PdfWriter.getInstance(pdfDoc, new FileOutputStream(outputFilePath)).setPdfVersion(PdfWriter.PDF_VERSION_1_7)
    val one = new Rectangle(1850, 700)
    pdfDoc.setPageSize(one)
    pdfDoc.setMargins(1, 1, 1, 1)
    pdfDoc.open()
    val myfont = new Font
    //System.out.println("Hello Scala")
    myfont.setStyle(Font.NORMAL)
    //myfont.setSize(11)
    pdfDoc.add(new Paragraph("\n"))
    //System.out.println("Hello Scala..1")
    Logger.log.info("=============> Reading the Input File <=============")
    val br = new BufferedReader(new FileReader(inputFile))
    //System.out.println("Hello Scala..2")
    var strLine: String = null
    while ( {
      strLine = br.readLine; strLine != null
    }) {
      val para = new Paragraph(strLine + "\n", myfont)
      para.setAlignment(Element.ALIGN_LEFT)
      pdfDoc.add(para)
      //pdfDoc.add(new Paragraph("\n"))
    }
    pdfDoc.close()
    br.close()
    Logger.log.info("=============> Converted the Input file into PDF <=============")

  }
  // added for Datalake parquet files handling - STARTS- 27/5/2018 - vshrest1 //
  /** Purpose : Def to parquet fileList into spark dataframe with parquet file format version wise
    * input : schemaVersion(s), workingDir, filesList, entityName
    * output: DF should be created and saves resultant versions in the form of parquet */

  def saveToDataFrameP(schmVer: String,workingDir: String,fileList: String, entNm: String): Unit = {
    var resCnt="0"
    try {
      Logger.log.info(s" FileList in  saveDFversionTablesParquet for entity $entNm of partition Folder $schmVer is $fileList" )

      val fileLstTkn=fileList.split(",").map(x=>sparkSession.read.parquet(x))
      val df = fileLstTkn.reduce(_.union(_))
      resCnt=df.count().toString
      Logger.log.info(s" count for  entity $entNm of partition folder is "+resCnt )

      df.write.mode(SaveMode.Append).parquet(s"$workingDir/${entNm.toUpperCase()}")
    } catch {
      case e: Exception => Logger.log.info(" Exception at saveDFversionTablesParquet" :+ e.getMessage)
        throw e
    }

  }
  def genExtDelim(rwdelim: String,eppRdd: org.apache.spark.rdd.RDD[(String, String)], eitInfo :org.apache.spark.rdd.RDD[(String,String, String,String, String)],entNm: String,raw_path: String,workingDir: String,startTime: String, endTime: String): Boolean = {

    Logger.log.info("filtering files with row delimeter " + rwdelim)
    var custRowDelim = "0"
    var rsltFlg1: Boolean = false
    if (rwdelim.equals("5c7530303032")) {
      custRowDelim = DPOConstants.CUSTROWDELIM_5c7530303032
    }
    else if (rwdelim.equals("5c75303030325c6e")) {
      custRowDelim = DPOConstants.CUSTROWDELIM_5c75303030325c6e
    }
    else {
      custRowDelim = "0"

    }
    Logger.log.info("textinput.record.delimeter set is " + custRowDelim + " and row delim value is " + rwdelim)
    if (!custRowDelim.equals("0")) {

      val isCustDelim = eitInfo.map(kv => {
        kv._5
      }).first.toString

      Logger.log.info(s" Processing ${entNm} Files with Delimiter:${custRowDelim}  isCustDelim is ${isCustDelim}")

      val eitFileList: List[(String, String)] = eitInfo.filter(x => x._2 == s"$rwdelim").map(x => (x._1, x._3, x._4)).collect.toList.map(x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._2}/${x._3}"))
      // Logger.log.info(s" CustomRowDelim :List of Files from Raw with customRowDelim record delim: ${eitFileList.mkString}")
      //val eitFileListCtlB: List[(String, String)] = eitInfo.filter( x => x._2 == "2" || x._2 == "5c7530303032" ).map( x => (x._1, x._4, x._3) ).collect.toList.map( x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._4}/${x._3}") )
      val eitRawFileList = eitFileList.filter(x => filterRawFileExist(x._2))

      Logger.log.info(s" CustomRowDelim :Yes with file count  : ${eitRawFileList.length} ::::: List of Files from Raw with ${custRowDelim} record delim: ${eitRawFileList.mkString}")

      if (eitRawFileList.length > 0) {
        Logger.log.info(s" Inside ifBloack");
        val rddCtlB = globalContext.spark.parallelize(eitRawFileList)
        Logger.log.info(s" Inside afterBloack");
        val eitFileRdd = rddCtlB.groupByKey.mapValues(_.mkString(","))
        //            val eppRdd: org.apache.spark.rdd.RDD[(String, String)] = getEppLakeTabSchma(eppTable, ptnr, src, entName).cache
        Logger.log.info(s" CustomRowDelim :Number of Schema Versions for ${entNm} retrieved from EPP HBase Table:" + eppRdd.count())
        var sparkConfigCust = globalContext.spark
        Logger.log.info(s" Inside VSSSSS");
        //sparkConfigCust.hadoopConfiguration.set("textinputformat.record.delimiter",s"$custRowDelim")

        if (custRowDelim.equals("\\u0002")) {
          sparkConfigCust.hadoopConfiguration.set("textinputformat.record.delimiter", "\u0002")
        }
        else {
          sparkConfigCust.hadoopConfiguration.set("textinputformat.record.delimiter", "\u0002\u000A")
        }


        Logger.log.info(s" Inside VSSSSS123456");
        eppRdd.join(eitFileRdd).collect.foreach { case (schmVer, (schm, fileList)) => saveToDataFrame(workingDir, schmVer, schm, fileList, entNm, sparkConfigCust)
          Logger.log.info(s" Inside VSSSSS1234567");
        }
        rsltFlg1 = true
      } else {
        Logger.log.info(s" Since, No Changes Captured for $entNm from $startTime to $endTime, datasets will not be generated")
        rsltFlg1 = false
      }
    }
    else {
      Logger.log.info("The record delimeter defined is not ctrlB or ctrlBn with isCustRowDelim as Yes. Hence not proceeding further")
      rsltFlg1=false
    }

    rsltFlg1
  }

  /** Purpose : Def to compute duration of the extract and save it in a file
    * input : peiRowKey,rootDir,pitTable Name,pitRowKey:String
    * output: file should be created in t_outbox location namely, fdNm-AllExtractsPitRowKeys.txt */
  def extractDuration(zipFileName:String, peiRowKey:String,allExtractsPitRowKeys:String,pitTabName:String,pitRowKey:String):Unit={
    System.out.println("===================> Inside Extract Generation :")
    val fdNm =peiRowKey.split("-")(0)
    //val outboxDir ="/mapr"+rootDir.replaceFirst("t_data","t_outbox").concat(fdNm+"-AllExtractsPitRowKeys.txt")
    //val outboxDir ="/mapr"+rootDir.concat(fdNm+"-AllExtractsPitRowKeys.txt")
    val provEndTs = getCurrentTimeFormat
    Logger.log.info(s"===================> inside extractDuration for pitTableName  : " + pitTabName);
    val provStartTime = getHtableValByRowKey(pitTabName, pitRowKey, "exi", "provStrTs")

    try {
      val duration = CustomFunctions.getDuration(provEndTs, provStartTime)
      System.out.println("===================> Extract Generation duration :" + duration)
      Logger.log.info(s"===================> Extract Generation duration : " + duration)
      val writer=new PrintWriter(new FileOutputStream(new File(allExtractsPitRowKeys),true))
      writer.write(zipFileName+"|"+duration+"|"+pitRowKey+"\n")
      writer.close()
    }
    catch {
      case e: FileNotFoundException => Logger.log.info(s"ERROR : extractDuration : Couldn't find that file.")
      case e: IOException => Logger.log.info(s"ERROR : extractDuration : Got an IOException!")
    }

  }
  /** Purpose : Def to create snapshot for a entity full
    * input : snapBuildType:String,pKeys:String,lakeEitTableName: String, mountPath: String, workingDir: String, lakeEppTableName: String,entity: String, prtnrCd: String, srcCd: String,dmlCol:String,modTsCol:String
    * output: parquet files should be created in working_dir/snapshot/Entity_name namely, fdNm-AllExtractsPitRowKeys.txt */
  def getSnapshotCommonPerEntity (snapBuildType:String,pKeys:String,lakeEitTableName: String, mountPath: String, workingDir: String, lakeEppTableName: String,entity: String, prtnrCd: String, srcCd: String,dmlCol:String,modTsCol:String): Unit = {

    try {
      val primaryKeys: Array[String] = pKeys.split(";")
      Logger.log.info(s" Primary Key Columns for $entity : ${pKeys}")
      // Get LakeEIT scanned rowKey entity
      var result: Boolean=false
      //result = eitLakeTabScanCommonSnap(snapBuildType,lakeEitTableName, mountPath, lakeEppTableName, workingDir, prtnrCd, srcCd, entity)
      result = eitLakeTabScanCommonSnapMod(snapBuildType,lakeEitTableName, mountPath, lakeEppTableName, workingDir, prtnrCd, srcCd, entity)
      val ptnrCd = s"${prtnrCd.toUpperCase()}"
      val src = s"${srcCd.toUpperCase()}"
      val entName = s"${entity.toUpperCase()}"
      Logger.log.info(s" Working Directory path for Incremental extract: $workingDir")

      //if LakeEIT scanned rowKey entity is empty then end the workflow with Success Status , else continue to save the raw snapshot merged files into a dataframe as entity name
      if (result) {
        try {
          Logger.log.info(s" Captured Incremental Extract for ${entName}")
          Logger.log.info(s" Merging Schema for $entName from $workingDir/$entName")
          Logger.log.info(s" checking existence of working directory")
          val merDir = workingDir + "/" + entName
          mkdirs(merDir)
          val mergeDF = sqlContext.read.option("mergeSchema", true).parquet(s"$workingDir/$entName").persist(org.apache.spark.api.java.StorageLevels.MEMORY_AND_DISK_SER)
          //Temp// Logger.log.info(s" Merge Schema Record Count for $entName :" + mergeDF.count)

          try {
            val userWindow = Window.partitionBy(concat_ws("-", primaryKeys.map(c => col(c)): _*), lit("")).orderBy(col(s"$modTsCol").desc)
            val dedupDF = mergeDF.withColumn("rank", row_number().over(userWindow)).where(col("rank") === 1).drop("rank")
           // val noCdcFlg=dedupDF.toDF.filter(dedupDF("CDC_FLAG") =!= 'D').persist(org.apache.spark.api.java.StorageLevels.MEMORY_AND_DISK_SER)
            dedupDF.createOrReplaceTempView(s"dedupDf")
            val noCdcFlg=sqlContext.sql(s"select * from dedupDf where trim(${dmlCol}) != 'D'")
            val snapDir = workingDir + "/snapshot/" + entName
            mkdirs(snapDir)
            //dedupDF.createOrReplaceGlobalTempView(s"${entName}")
            noCdcFlg.write.mode(SaveMode.Overwrite).parquet(snapDir)
            Logger.log.info(s"==========> Delete raw data after snapshot generated for $entName <===========")
            rmPathIfExist(merDir)
            Logger.log.info(s"==========> Directory $merDir removed <===========")
            Logger.log.info(s"==========> Snapshot creation completed for ${entName} <===========")
          } catch {
            case e: Exception => Logger.log.info(s">>>>> Exception at Main Loading MergeSchema/SqlStatement for $entName <<<<<" :+ e.getMessage)
              //removing intermediate parquet data
              rmPathIfExist(workingDir + "/" + entName)
              rmPathIfExist(workingDir + "/snapshot/" + entName)
              //hbasePITEndStage(pitTab, "Fail", pitRowKey)
              throw e
          }


        } catch {
          case e: Exception => Logger.log.info(s">>>>> Exception at Main Loading Merge Parquet Schema/SqlStatement for $entName <<<<<" :+ e.getMessage)
            //removing intermediate parquet data
            rmPathIfExist(workingDir + "/" + entName)
            throw e
        }
      } else {
        Logger.log.info(s" Since there are No Changes reflected for the $entName in a given time range, hence ending the workflow  ")
      }
    } catch {
      case e: Exception => Logger.log.info(" Exception at DataLake Snapshot Scan , Failed due to " :+ e.getMessage)
        throw e

    }
  }

  /** Purpose : Def to EIT scan for one entity to create snapshot
    * input : snapBuildType:String,eitTable: String, mountPath: String, eppTable: String, workingDir: String, patnrCd: String, srcCd: String, entNm: String
    * output: provide EITs */
  def eitLakeTabScanCommonSnap (snapBuildType:String,eitTable: String, mountPath: String, eppTable: String, workingDir: String, patnrCd: String, srcCd: String, entNm: String): Boolean = {
    try {
      //val eitTable = globalContext.lakeEitTableName
      val ptnr = s"${patnrCd}".toUpperCase
      val src = s"${srcCd}".toUpperCase
      //val mountPath = globalContext.mountPath
      val raw_path = s"maprfs://$mountPath/${ptnr.toLowerCase}/raw/standard_access/${src.toLowerCase}/data/"
      val entName = s"${entNm}".toUpperCase
      Logger.log.info(s" Retrieving Files for $entName from Raw: $raw_path")
      Logger.log.info(s" Processing Entity:${entName} with patnrCd:${ptnr} srcCd:${src}")
      Logger.log.info(s" Scanning Eit HBase Table: $eitTable")
      var startTime = getCurrentTimeFormat
      //val endTime = s"$incEndTs"
      //Logger.log.info(s" Endtime : $incEndTs ")
      Logger.log.info(s" startTime : $startTime ")
      //Logger.log.info(s" Capturing if any Changes reflected for $entName from $startTime to $endTime")
      val rowKey = s"${ptnr}-${src}-${entName}"
      val sppRowKey = s"${ptnr}-${src}"

      Logger.log.info(s" starting EIT scan for dat files")
      var rsltFlg1=false
      var rsltFlg2=false
      var rsltFlg0=false
      //var pitRawPartnFlr=""
      //var pitRawRowDelim=""
      //var pitRawFileCnt=""

      import org.apache.hadoop.hbase.client.Scan
      if (snapBuildType.equalsIgnoreCase("parquet")) {
        try {
          Logger.log.info(s" starting EIT scan for Parquet files")
          import org.apache.hadoop.hbase.client.Scan
          val scan = new Scan()
          val filter = new PrefixFilter(Bytes.toBytes(s"${ptnr}-${src}-${entName}-"))
          val filter1 = new SingleColumnValueFilter(Bytes.toBytes("exi"), Bytes.toBytes("ingProcLogSts"), CompareOp.EQUAL, Bytes.toBytes("Success")); //val filter2 = new SingleColumnValueFilter(Bytes.toBytes("fi"), Bytes.toBytes("iscustrowdelim"), CompareOp.EQUAL, Bytes.toBytes("No"));

          import org.apache.hadoop.hbase.filter.CompareFilter.CompareOp
          scan.setCaching(10000)
          scan.setCacheBlocks(false)
          filter1.setFilterIfMissing(true)
          scan.setFilter(filterList(filter1, filter))
          val eitVal = globalContext.hbaseContext.hbaseRDD(TableName.valueOf(eitTable), scan).cache
          Logger.log.info(s" DL eitVal count : ${eitVal.count()} ")
          val eitInfo = eitVal.map(tuple => {
            val result = tuple._2
            //(Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("schmVer"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("ingstdFileNm"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("entprtnfldr"))))
            (Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("schmVer"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("entprtnfldr"))))
          })


          if (!eitInfo.isEmpty) {
            /*val eitFileList = eitInfo.map(x => (x._1, x._2)).collect.toList.map(x => (x._2, s"${raw_path}${entNm}/${x._2}"))
            val eitRawFileList = eitFileList.filter(x => filterRawFileExist(x._2))
            val eitRawFileListNtEmp = eitRawFileList.filter(x => isEmptyDir(x._2))

            Logger.log.info(s" Number of PARQUET Files exist in Raw for $entName from EIT SCAN :" + eitRawFileListNtEmp.length)
            Logger.log.info(s" List of PARQUET Files from Raw : ${eitRawFileListNtEmp.mkString}")

            val eitRdd = globalContext.spark.parallelize(eitRawFileListNtEmp)
            val eitFileRdd = eitRdd.groupByKey.mapValues(_.mkString(","))
            Logger.log.info(s" saving the files ")
            eitFileRdd.collect.map(x => saveToDataFrameP(x._1, workingDir, x._2, entName))*/
            val eitFileList = eitInfo.map(x => (x._1, x._2)).collect.toList.map(x => ( s"${raw_path}${entNm}/${x._2}")).distinct
            //val eitRawFileList = eitFileList.filter(x => filterRawFileExist(x))
            val eitRawFileListNtEmp = eitFileList.filter(x => isEmptyDir(x))

            Logger.log.info(s" Number of PARQUET Files exist in Raw for $entName from EIT SCAN  :" + eitRawFileListNtEmp.length)
            Logger.log.info(s" List of PARQUET Files from Raw : ${eitRawFileListNtEmp.mkString}")
            val eitRdd = globalContext.spark.parallelize(eitRawFileListNtEmp)

            eitRdd.collect.map(x => saveToDataFrameP("PARQUET", workingDir, x, entName))

            eitVal.unpersist()
            rsltFlg0 = true
          } else {
            Logger.log.info(s" Since,COMMON No Changes Captured for $entName , datasets will not be generated")
            rsltFlg0 = false
          }
          rsltFlg0

        } catch {
          case e: Exception => Logger.log.info(s" Exception while COMMON Scanning Files from DL EIT for $entNm" :+ e.getStackTrace.mkString)
            //hbasePITEndStage(pitTab, "Fail", pitRowKey)
            throw e
        }
      }
      else
      {
        val eppRdd: org.apache.spark.rdd.RDD[(String, String)] = getEppLakeTabSchma(eppTable, ptnr, src, entName).cache
        try {
          Logger.log.info(s" scanning EIT for isCustRowlim as No for dat files")
          val scan_N = new Scan()
          val filter_N = new PrefixFilter(Bytes.toBytes(s"${ptnr}-${src}-${entName}-"))
          val filter1_N = new SingleColumnValueFilter(Bytes.toBytes("exi"), Bytes.toBytes("ingProcLogSts"), CompareOp.EQUAL, Bytes.toBytes("Success"));
          val filter2_N = new SingleColumnValueFilter(Bytes.toBytes("fi"), Bytes.toBytes("iscustrowdelim"), CompareOp.EQUAL, Bytes.toBytes("No"));
          scan_N.setCaching(10000)
          scan_N.setCacheBlocks(false)
          filter1_N.setFilterIfMissing(true)
          filter2_N.setFilterIfMissing(true)
          scan_N.setFilter(filterList(filter1_N, filter_N, filter2_N))

          val eitVal_N = globalContext.hbaseContext.hbaseRDD(TableName.valueOf(eitTable), scan_N).cache
          Logger.log.info(s" DL eitVal count with isCustRowlim as No is  : ${eitVal_N.count()} ")

          if (eitVal_N.count() > 0) {
            val eitInfo = eitVal_N.map(tuple => {
              val result = tuple._2
              (Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("schmVer"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("srcFileNm"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("entprtnfldr"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("iscustrowdelim"))))
            })
            val isCustDelim = eitInfo.map(kv => {
              kv._4
            }).first.toString

            Logger.log.info(s" Processing ${entName} Files with Delimiter: \\n as isCustDelim is ${isCustDelim}")

            if (!eitInfo.isEmpty) {
              val eitFileListT = eitInfo.map(x => (x._1, x._3, x._2)).collect.toList
              val eitFileList = eitFileListT.map(x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._2}/${x._3}"))
              val eitRawFileList = eitFileList.filter(x => filterRawFileExist(x._2))
              val eitPartnFlr = eitFileListT.map(x => (x._2, 1))
              val eitPartnFlrCnt = globalContext.spark.parallelize(eitPartnFlr).reduceByKey(_ + _).collect().mkString(";")
              Logger.log.info(s" List of Files from Raw with \\n record delim: ${eitRawFileList.mkString}")
              val eitRdd = globalContext.spark.parallelize(eitRawFileList)
              val eitFileRdd = eitRdd.groupByKey.mapValues(_.mkString(","))
              //  val eppRdd: org.apache.spark.rdd.RDD[(String, String)] = getEppLakeTabSchma(eppTable, ptnr, src, entName).cache
              Logger.log.info(s" Number of Schema Versions for ${entName} retrieved from EPP HBase Table:" + eppRdd.count())
              val sparkConfig = globalContext.spark
              eppRdd.join(eitFileRdd).collect.foreach { case (schmVer, (schm, fileList)) => saveToDataFrame(workingDir, schmVer, schm, fileList, entName, sparkConfig)
              }
              eitVal_N.unpersist()
              //  eppRdd.unpersist()
              rsltFlg1 = true
            } else {
              Logger.log.info(s" Since, No Changes Captured for $entName, datasets will not be generated")
              rsltFlg1 = false
            }
          }
          else {
            Logger.log.info(s" since DL eitVal count with isCustRowlim as No is  : ${eitVal_N.count()} , skipping the process")
            rsltFlg1 = false
          }


          Logger.log.info(s" scanning EIT for isCustRowlim as Yes for dat files")
          val scan_Y = new Scan()
          val filter_Y = new PrefixFilter(Bytes.toBytes(s"${ptnr}-${src}-${entName}-"))
          val filter1_Y = new SingleColumnValueFilter(Bytes.toBytes("exi"), Bytes.toBytes("ingProcLogSts"), CompareOp.EQUAL, Bytes.toBytes("Success"));
          val filter2_Y = new SingleColumnValueFilter(Bytes.toBytes("fi"), Bytes.toBytes("iscustrowdelim"), CompareOp.EQUAL, Bytes.toBytes("Yes"));
          scan_Y.setCaching(10000)
          scan_Y.setCacheBlocks(false)
          filter1_Y.setFilterIfMissing(true)
          filter2_Y.setFilterIfMissing(true)
          scan_Y.setFilter(filterList(filter1_Y, filter_Y, filter2_Y))

          val eitVal_Y = globalContext.hbaseContext.hbaseRDD(TableName.valueOf(eitTable), scan_Y).cache
          Logger.log.info(s" DL eitVal count with isCustRowlim as Yes is  : ${eitVal_Y.count()} ")
          if (eitVal_Y.count() > 0) {

            val eitInfo = eitVal_Y.map(tuple => {
              val result = tuple._2
              (Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("schmVer"))), Bytes.toHex(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("rowdelim"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("entprtnfldr"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("srcFileNm"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("iscustrowdelim"))))
            })
            //     (Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("schmVer"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("srcFileNm"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("entprtnfldr"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("iscustrowdelim"))))

            Logger.log.info(s" Processing ${entName} Files with Row Delimiter: \\u0002 & \\u0002\\u000A")
            val isCustDelim = eitInfo.map(kv => {
              kv._5
            }).first.toString

            Logger.log.info(s" Processing ${entName} Files with Delimiter:\\u0002 OR  \\u0002\\u000A  isCustDelim is ${isCustDelim}")

            if (!eitInfo.isEmpty()) {

              //val eitFileListCtlBT = eitInfo.filter(x => x._2 == "5c7530303032").map(x => (x._1, x._3, x._4)).collect.toList
              val eitFileListCtlBT = eitInfo.filter(x => x._2 == "2" || x._2 == "5c7530303032").map(x => (x._1, x._3, x._4)).collect.toList
              val eitFileListCtlB = eitFileListCtlBT.map(x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._2}/${x._3}"))

              Logger.log.info(s" CustomRowDelim :List of Files from Raw with \\u0002 record delim: ${eitFileListCtlB.mkString}")
              //val eitFileListCtlB: List[(String, String)] = eitInfo.filter( x => x._2 == "2" || x._2 == "5c7530303032" ).map( x => (x._1, x._4, x._3) ).collect.toList.map( x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._4}/${x._3}") )
              val eitRawFileListCtlB = eitFileListCtlB.filter(x => filterRawFileExist(x._2))
              //Logger.log.info(s" CustomRowDelim :ACTUAL Number of Files exist in Raw with \\u0002 record delim for $entName from EIT SCAN b/w $startTime and $endTime :" + eitRawFileListCtlB.length)
              Logger.log.info(s" CustomRowDelim :ACTUAL List of Files from Raw with \\u0002 record delim: ${eitRawFileListCtlB.mkString}")

              if (eitRawFileListCtlB.length > 0) {

                val eitPartnFlrCtlB = eitFileListCtlBT.map(x => (x._2, 1))
                val eitPartnFlrCtlBCnt = globalContext.spark.parallelize(eitPartnFlrCtlB).reduceByKey(_ + _).collect().mkString(";")
                /*pitRawFileCnt = pitRawFileCnt + "CtlB - " + eitRawFileListCtlB.length + ";"
              pitRawRowDelim = pitRawRowDelim + "CtlB ;"
              pitRawPartnFlr = pitRawPartnFlr + "CtlB - " + eitPartnFlrCtlBCnt + ";"*/

                val rddCtlB = globalContext.spark.parallelize(eitRawFileListCtlB)
                val eitFileRddCtlB = rddCtlB.groupByKey.mapValues(_.mkString(","))
                //            val eppRdd: org.apache.spark.rdd.RDD[(String, String)] = getEppLakeTabSchma(eppTable, ptnr, src, entName).cache
                //Logger.log.info(s" CustomRowDelim :Number of Schema Versions for ${entName} retrieved from EPP HBase Table:" + eppRdd.count())
                val sparkConfigCtlB = globalContext.spark
                sparkConfigCtlB.hadoopConfiguration.set("textinputformat.record.delimiter", "\u0002")
                eppRdd.join(eitFileRddCtlB).collect.foreach { case (schmVer, (schm, fileList)) => saveToDataFrame(workingDir, schmVer, schm, fileList, entName, sparkConfigCtlB)
                }
              }
              else {
                Logger.log.info(s" Skipping the process as ACTUAL Number of Files exist in Raw with \\u0002 record delim is :" + eitRawFileListCtlB.length)
              }


              //val eitFileListCtlBNL: List[(String, String)] = eitInfo.filter(x => x._2 == "25c6e" || x._2 == "20a" || x._2 == "5c75303030325c6e").map(x => (x._1, x._3, x._4)).collect.toList.map(x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._2}/${x._3}"))
              //PitEntry// val eitFileListCtlBNL: List[(String, String)] = eitInfo.filter(x => x._2 == "5c75303030325c6e").map(x => (x._1, x._3, x._4)).collect.toList.map(x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._2}/${x._3}"))
              //val eitFileListCtlBNLT = eitInfo.filter(x => x._2 == "5c75303030325c6e").map(x => (x._1, x._3, x._4)).collect.toList
              val eitFileListCtlBNLT = eitInfo.filter(x => x._2 == "25c6e" || x._2 == "20a" || x._2 == "5c75303030325c6e").map(x => (x._1, x._3, x._4)).collect.toList
              val eitFileListCtlBNL = eitFileListCtlBNLT.map(x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._2}/${x._3}"))

              //Logger.log.info(s" CustomRowDelim :Number of Files exist in Raw with \\u0002\\u000A record delim for $entName from EIT SCAN b/w $startTime and $endTime :" + eitFileListCtlBNL.length)
              Logger.log.info(s" CustomRowDelim :List of Files from Raw with \\u0002 record delim: ${eitFileListCtlBNL.mkString}")
              val eitRawFileListCtlBNL = eitFileListCtlBNL.filter(x => filterRawFileExist(x._2))
              //Logger.log.info(s" CustomRowDelim :Number of Files exist in Raw with \\u0002\\u000A record delim for $entName from EIT SCAN b/w $startTime and $endTime :" + eitRawFileListCtlBNL.length)
              Logger.log.info(s" CustomRowDelim : ACTUAL List of Files from Raw with \\u0002\\u000A record delim: ${eitRawFileListCtlBNL.mkString}")
              if (eitRawFileListCtlBNL.length > 0) {

                val eitPartnFlrCtlBNL = eitFileListCtlBNLT.map(x => (x._2, 1))
                val eitPartnFlrCtlBNLCnt = globalContext.spark.parallelize(eitPartnFlrCtlBNL).reduceByKey(_ + _).collect().mkString(";")
                /*pitRawFileCnt = pitRawFileCnt + "CtlB\n - " + eitRawFileListCtlBNL.length + ";"
              pitRawRowDelim = pitRawRowDelim + "CtlB\n ;"
              pitRawPartnFlr = pitRawPartnFlr + "CtlB\n - " + eitPartnFlrCtlBNLCnt + ";"*/

                val rddCtlBNL = globalContext.spark.parallelize(eitRawFileListCtlBNL)
                val eitFileRddCtlBNL = rddCtlBNL.groupByKey.mapValues(_.mkString(","))
                val sparkConfigCtlBNL = globalContext.spark
                sparkConfigCtlBNL.hadoopConfiguration.set("textinputformat.record.delimiter", "\u0002\u000A")
                eppRdd.join(eitFileRddCtlBNL).collect.foreach { case (schmVer, (schm, fileList)) => saveToDataFrame(workingDir, schmVer, schm, fileList, entName, sparkConfigCtlBNL)
                  //eppRdd.unpersist()
                }
              }
              else {
                Logger.log.info(s" Skipping the process as ACTUAL Number of Files exist in Raw with \\u0002\\u000A  record delim is :" + eitRawFileListCtlBNL.length)
              }
              eitVal_Y.unpersist()
              rsltFlg2 = true
            }
            else {
              //Logger.log.info(s" Number of Files Captured for $entName from EIT SCAN b/w $startTime and $endTime :" + 0)
              Logger.log.info(s" Since, No Changes Captured for $entName datasets will not be generated")
              rsltFlg2 = false
            }
          }
          else {
            Logger.log.info(s" since DL eitVal count with isCustRowlim as Yes is  : ${eitVal_Y.count()} , skipping the process")
            rsltFlg2 = false
          }
          //eppRdd.unpersist()
          true
        } catch {
          case e: Exception => Logger.log.info(s" Exception while Scanning Files from DL EIT for $entNm" :+ e.getStackTrace.mkString)
            //    hbasePITEndStage(pitTab, "Fail", pitRowKey)
            throw e
        }
      }
    } catch {
      case e: Exception => Logger.log.info(s" Exception while Scanning Files from DL EIT for $entNm from eitTabScan" :+ e.getStackTrace.mkString)
        //hbasePITEndStage(pitTab, "Fail", pitRowKey)
        throw e
    }
  }
  /** Purpose : Def to read snapshot for a entity full
    * input : workingDir:String,entity:String
    * output: snapshot dataframe */
  def getCommonSnapshotPerEntity(workingDir:String,entity:String): Unit={
    val dedupDF=sqlContext.read.parquet(workingDir+"/snapshot/"+entity)
    dedupDF.createOrReplaceTempView(s"${entity}")
    Logger.log.info(entity+s" count from common snapshot: "+dedupDF.count())
  }


  def eitLakeTabScanCommonSnapMod (snapBuildType:String,eitTable: String, mountPath: String, eppTable: String, workingDir: String, patnrCd: String, srcCd: String, entNm: String): Boolean = {
    try {
      //val eitTable = globalContext.lakeEitTableName
      val ptnr = s"${patnrCd}".toUpperCase
      val src = s"${srcCd}".toUpperCase
      //val mountPath = globalContext.mountPath
      val raw_path = s"maprfs://$mountPath/${ptnr.toLowerCase}/raw/standard_access/${src.toLowerCase}/data/"
      val entName = s"${entNm}".toUpperCase
      Logger.log.info(s" Retrieving Files for $entName from Raw: $raw_path")
      Logger.log.info(s" Processing Entity:${entName} with patnrCd:${ptnr} srcCd:${src}")
      Logger.log.info(s" Reading Saved Eit HBase file: $eitTable")
      var startTime = getCurrentTimeFormat
      Logger.log.info(s" startTime : $startTime ")
      val rowKey = s"${ptnr}-${src}-${entName}"
      val sppRowKey = s"${ptnr}-${src}"

      Logger.log.info(s" =====================> starting EIT scan <=====================")
      var rsltFlg1=false
      var rsltFlg2=false
      var rsltFlg0=false


      import org.apache.hadoop.hbase.client.Scan
      if (snapBuildType.equalsIgnoreCase("parquet")) {
        try {
          //var filename="/mapr/datalake/uhclake/tst/developer/pankaj/scripts/ndb_extract/workingtemp/EIT/HbaseEit.txt"
          var filename=s"/mapr/${workingDir}/EIT/HbaseEit.txt"
          val lines = Source.fromFile(filename).getLines.toList
          var splitLine =lines.map(x=> x.split('|'))
          val eitFileList =splitLine.filter(x=>x(2)==entName).map(x=>s"${raw_path}${entNm}/${x(1)}").distinct
            if(eitFileList.size>0){
            //val eitFileList = eitInfo.map(x => (x._1, x._2)).collect.toList.map(x => ( s"${raw_path}${entNm}/${x._2}")).distinct
            //val eitRawFileList = eitFileList.filter(x => filterRawFileExist(x))
            val eitRawFileListNtEmp = eitFileList.filter(x => isEmptyDir(x))

            Logger.log.info(s" Number of PARQUET Files exist in Raw for $entName from EIT SCAN  :" + eitRawFileListNtEmp.length)
            Logger.log.info(s" List of PARQUET Files from Raw : ${eitRawFileListNtEmp.mkString}")
            val eitRdd = globalContext.spark.parallelize(eitRawFileListNtEmp)

            eitRdd.collect.map(x => saveToDataFrameP("PARQUET", workingDir, x, entName))

            rsltFlg0 = true
          } else {
            Logger.log.info(s" Since,COMMON No Changes Captured for $entName , datasets will not be generated")
            rsltFlg0 = false
          }
          rsltFlg0

        } catch {
          case e: Exception => Logger.log.info(s" Exception while COMMON Scanning Files from DL EIT for $entNm" :+ e.getStackTrace.mkString)
            //hbasePITEndStage(pitTab, "Fail", pitRowKey)
            throw e
        }
      }
      else
      {
        val eppRdd: org.apache.spark.rdd.RDD[(String, String)] = getEppLakeTabSchma(eppTable, ptnr, src, entName).cache
        try {
          Logger.log.info(s" scanning EIT for isCustRowlim as No for dat files")
          val scan_N = new Scan()
          val filter_N = new PrefixFilter(Bytes.toBytes(s"${ptnr}-${src}-${entName}-"))
          val filter1_N = new SingleColumnValueFilter(Bytes.toBytes("exi"), Bytes.toBytes("ingProcLogSts"), CompareOp.EQUAL, Bytes.toBytes("Success"));
          val filter2_N = new SingleColumnValueFilter(Bytes.toBytes("fi"), Bytes.toBytes("iscustrowdelim"), CompareOp.EQUAL, Bytes.toBytes("No"));
          scan_N.setCaching(10000)
          scan_N.setCacheBlocks(false)
          filter1_N.setFilterIfMissing(true)
          filter2_N.setFilterIfMissing(true)
          scan_N.setFilter(filterList(filter1_N, filter_N, filter2_N))

          val eitVal_N = globalContext.hbaseContext.hbaseRDD(TableName.valueOf(eitTable), scan_N).cache
          Logger.log.info(s" DL eitVal count with isCustRowlim as No is  : ${eitVal_N.count()} ")

          if (eitVal_N.count() > 0) {
            val eitInfo = eitVal_N.map(tuple => {
              val result = tuple._2
              (Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("schmVer"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("srcFileNm"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("entprtnfldr"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("iscustrowdelim"))))
            })
            val isCustDelim = eitInfo.map(kv => {
              kv._4
            }).first.toString

            Logger.log.info(s" Processing ${entName} Files with Delimiter: \\n as isCustDelim is ${isCustDelim}")

            if (!eitInfo.isEmpty) {
              val eitFileListT = eitInfo.map(x => (x._1, x._3, x._2)).collect.toList
              val eitFileList = eitFileListT.map(x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._2}/${x._3}"))
              val eitRawFileList = eitFileList.filter(x => filterRawFileExist(x._2))
              val eitPartnFlr = eitFileListT.map(x => (x._2, 1))
              val eitPartnFlrCnt = globalContext.spark.parallelize(eitPartnFlr).reduceByKey(_ + _).collect().mkString(";")
              Logger.log.info(s" List of Files from Raw with \\n record delim: ${eitRawFileList.mkString}")
              val eitRdd = globalContext.spark.parallelize(eitRawFileList)
              val eitFileRdd = eitRdd.groupByKey.mapValues(_.mkString(","))
              //  val eppRdd: org.apache.spark.rdd.RDD[(String, String)] = getEppLakeTabSchma(eppTable, ptnr, src, entName).cache
              Logger.log.info(s" Number of Schema Versions for ${entName} retrieved from EPP HBase Table:" + eppRdd.count())
              val sparkConfig = globalContext.spark
              eppRdd.join(eitFileRdd).collect.foreach { case (schmVer, (schm, fileList)) => saveToDataFrame(workingDir, schmVer, schm, fileList, entName, sparkConfig)
              }
              eitVal_N.unpersist()
              //  eppRdd.unpersist()
              rsltFlg1 = true
            } else {
              Logger.log.info(s" Since, No Changes Captured for $entName, datasets will not be generated")
              rsltFlg1 = false
            }
          }
          else {
            Logger.log.info(s" since DL eitVal count with isCustRowlim as No is  : ${eitVal_N.count()} , skipping the process")
            rsltFlg1 = false
          }


          Logger.log.info(s" scanning EIT for isCustRowlim as Yes for dat files")
          val scan_Y = new Scan()
          val filter_Y = new PrefixFilter(Bytes.toBytes(s"${ptnr}-${src}-${entName}-"))
          val filter1_Y = new SingleColumnValueFilter(Bytes.toBytes("exi"), Bytes.toBytes("ingProcLogSts"), CompareOp.EQUAL, Bytes.toBytes("Success"));
          val filter2_Y = new SingleColumnValueFilter(Bytes.toBytes("fi"), Bytes.toBytes("iscustrowdelim"), CompareOp.EQUAL, Bytes.toBytes("Yes"));
          scan_Y.setCaching(10000)
          scan_Y.setCacheBlocks(false)
          filter1_Y.setFilterIfMissing(true)
          filter2_Y.setFilterIfMissing(true)
          scan_Y.setFilter(filterList(filter1_Y, filter_Y, filter2_Y))

          val eitVal_Y = globalContext.hbaseContext.hbaseRDD(TableName.valueOf(eitTable), scan_Y).cache
          Logger.log.info(s" DL eitVal count with isCustRowlim as Yes is  : ${eitVal_Y.count()} ")
          if (eitVal_Y.count() > 0) {

            val eitInfo = eitVal_Y.map(tuple => {
              val result = tuple._2
              (Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("schmVer"))), Bytes.toHex(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("rowdelim"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("entprtnfldr"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("srcFileNm"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("iscustrowdelim"))))
            })
            //     (Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("schmVer"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("srcFileNm"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("entprtnfldr"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("iscustrowdelim"))))

            Logger.log.info(s" Processing ${entName} Files with Row Delimiter: \\u0002 & \\u0002\\u000A")
            val isCustDelim = eitInfo.map(kv => {
              kv._5
            }).first.toString

            Logger.log.info(s" Processing ${entName} Files with Delimiter:\\u0002 OR  \\u0002\\u000A  isCustDelim is ${isCustDelim}")

            if (!eitInfo.isEmpty()) {

              //val eitFileListCtlBT = eitInfo.filter(x => x._2 == "5c7530303032").map(x => (x._1, x._3, x._4)).collect.toList
              val eitFileListCtlBT = eitInfo.filter(x => x._2 == "2" || x._2 == "5c7530303032").map(x => (x._1, x._3, x._4)).collect.toList
              val eitFileListCtlB = eitFileListCtlBT.map(x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._2}/${x._3}"))

              Logger.log.info(s" CustomRowDelim :List of Files from Raw with \\u0002 record delim: ${eitFileListCtlB.mkString}")
              //val eitFileListCtlB: List[(String, String)] = eitInfo.filter( x => x._2 == "2" || x._2 == "5c7530303032" ).map( x => (x._1, x._4, x._3) ).collect.toList.map( x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._4}/${x._3}") )
              val eitRawFileListCtlB = eitFileListCtlB.filter(x => filterRawFileExist(x._2))
              //Logger.log.info(s" CustomRowDelim :ACTUAL Number of Files exist in Raw with \\u0002 record delim for $entName from EIT SCAN b/w $startTime and $endTime :" + eitRawFileListCtlB.length)
              Logger.log.info(s" CustomRowDelim :ACTUAL List of Files from Raw with \\u0002 record delim: ${eitRawFileListCtlB.mkString}")

              if (eitRawFileListCtlB.length > 0) {

                val eitPartnFlrCtlB = eitFileListCtlBT.map(x => (x._2, 1))
                val eitPartnFlrCtlBCnt = globalContext.spark.parallelize(eitPartnFlrCtlB).reduceByKey(_ + _).collect().mkString(";")
                /*pitRawFileCnt = pitRawFileCnt + "CtlB - " + eitRawFileListCtlB.length + ";"
              pitRawRowDelim = pitRawRowDelim + "CtlB ;"
              pitRawPartnFlr = pitRawPartnFlr + "CtlB - " + eitPartnFlrCtlBCnt + ";"*/

                val rddCtlB = globalContext.spark.parallelize(eitRawFileListCtlB)
                val eitFileRddCtlB = rddCtlB.groupByKey.mapValues(_.mkString(","))
                //            val eppRdd: org.apache.spark.rdd.RDD[(String, String)] = getEppLakeTabSchma(eppTable, ptnr, src, entName).cache
                //Logger.log.info(s" CustomRowDelim :Number of Schema Versions for ${entName} retrieved from EPP HBase Table:" + eppRdd.count())
                val sparkConfigCtlB = globalContext.spark
                sparkConfigCtlB.hadoopConfiguration.set("textinputformat.record.delimiter", "\u0002")
                eppRdd.join(eitFileRddCtlB).collect.foreach { case (schmVer, (schm, fileList)) => saveToDataFrame(workingDir, schmVer, schm, fileList, entName, sparkConfigCtlB)
                }
              }
              else {
                Logger.log.info(s" Skipping the process as ACTUAL Number of Files exist in Raw with \\u0002 record delim is :" + eitRawFileListCtlB.length)
              }


              //val eitFileListCtlBNL: List[(String, String)] = eitInfo.filter(x => x._2 == "25c6e" || x._2 == "20a" || x._2 == "5c75303030325c6e").map(x => (x._1, x._3, x._4)).collect.toList.map(x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._2}/${x._3}"))
              //PitEntry// val eitFileListCtlBNL: List[(String, String)] = eitInfo.filter(x => x._2 == "5c75303030325c6e").map(x => (x._1, x._3, x._4)).collect.toList.map(x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._2}/${x._3}"))
              //val eitFileListCtlBNLT = eitInfo.filter(x => x._2 == "5c75303030325c6e").map(x => (x._1, x._3, x._4)).collect.toList
              val eitFileListCtlBNLT = eitInfo.filter(x => x._2 == "25c6e" || x._2 == "20a" || x._2 == "5c75303030325c6e").map(x => (x._1, x._3, x._4)).collect.toList
              val eitFileListCtlBNL = eitFileListCtlBNLT.map(x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._2}/${x._3}"))

              //Logger.log.info(s" CustomRowDelim :Number of Files exist in Raw with \\u0002\\u000A record delim for $entName from EIT SCAN b/w $startTime and $endTime :" + eitFileListCtlBNL.length)
              Logger.log.info(s" CustomRowDelim :List of Files from Raw with \\u0002 record delim: ${eitFileListCtlBNL.mkString}")
              val eitRawFileListCtlBNL = eitFileListCtlBNL.filter(x => filterRawFileExist(x._2))
              //Logger.log.info(s" CustomRowDelim :Number of Files exist in Raw with \\u0002\\u000A record delim for $entName from EIT SCAN b/w $startTime and $endTime :" + eitRawFileListCtlBNL.length)
              Logger.log.info(s" CustomRowDelim : ACTUAL List of Files from Raw with \\u0002\\u000A record delim: ${eitRawFileListCtlBNL.mkString}")
              if (eitRawFileListCtlBNL.length > 0) {

                val eitPartnFlrCtlBNL = eitFileListCtlBNLT.map(x => (x._2, 1))
                val eitPartnFlrCtlBNLCnt = globalContext.spark.parallelize(eitPartnFlrCtlBNL).reduceByKey(_ + _).collect().mkString(";")
                /*pitRawFileCnt = pitRawFileCnt + "CtlB\n - " + eitRawFileListCtlBNL.length + ";"
              pitRawRowDelim = pitRawRowDelim + "CtlB\n ;"
              pitRawPartnFlr = pitRawPartnFlr + "CtlB\n - " + eitPartnFlrCtlBNLCnt + ";"*/

                val rddCtlBNL = globalContext.spark.parallelize(eitRawFileListCtlBNL)
                val eitFileRddCtlBNL = rddCtlBNL.groupByKey.mapValues(_.mkString(","))
                val sparkConfigCtlBNL = globalContext.spark
                sparkConfigCtlBNL.hadoopConfiguration.set("textinputformat.record.delimiter", "\u0002\u000A")
                eppRdd.join(eitFileRddCtlBNL).collect.foreach { case (schmVer, (schm, fileList)) => saveToDataFrame(workingDir, schmVer, schm, fileList, entName, sparkConfigCtlBNL)
                  //eppRdd.unpersist()
                }
              }
              else {
                Logger.log.info(s" Skipping the process as ACTUAL Number of Files exist in Raw with \\u0002\\u000A  record delim is :" + eitRawFileListCtlBNL.length)
              }
              eitVal_Y.unpersist()
              rsltFlg2 = true
            }
            else {
              //Logger.log.info(s" Number of Files Captured for $entName from EIT SCAN b/w $startTime and $endTime :" + 0)
              Logger.log.info(s" Since, No Changes Captured for $entName datasets will not be generated")
              rsltFlg2 = false
            }
          }
          else {
            Logger.log.info(s" since DL eitVal count with isCustRowlim as Yes is  : ${eitVal_Y.count()} , skipping the process")
            rsltFlg2 = false
          }
          //eppRdd.unpersist()
          true
        } catch {
          case e: Exception => Logger.log.info(s" Exception while Scanning Files from DL EIT for $entNm" :+ e.getStackTrace.mkString)
            //    hbasePITEndStage(pitTab, "Fail", pitRowKey)
            throw e
        }
      }
    } catch {
      case e: Exception => Logger.log.info(s" Exception while Scanning Files from DL EIT for $entNm from eitTabScan" :+ e.getStackTrace.mkString)
        //hbasePITEndStage(pitTab, "Fail", pitRowKey)
        throw e
    }
  }
  /** Purpose : Def to read from the  DataLake EIT file data based on entity name
    * input : Lake EIT RowKey i.e. partnerCode, sourceCode, entityName , lastRunDateFlag, incrementalStartTime,incrementalEndTime, application PIT rowKey
    * output: Returns boolean value, if Lake EIT RowKey respective data found then 0 else 1 */
  def eitLakeTabScanMod (EXTRACT_EIT_FLG:String,snapBuildType:String,eitTable: String, mountPath: String, eppTable: String, workingDir: String, patnrCd: String, srcCd: String, entNm: String, lstrundateFlg: Boolean, incStTime: String, incEndTs: String, pitRowKey: String, pitTab: HTable): String = {
    try {
      Logger.log.info(s"INSIDE eitLakeTabScanMod def ")
      //val eitTable = globalContext.lakeEitTableName
      val ptnr = s"${patnrCd}".toUpperCase
      val src = s"${srcCd}".toUpperCase
      //val mountPath = globalContext.mountPath
      val raw_path = s"maprfs://$mountPath/${ptnr.toLowerCase}/raw/standard_access/${src.toLowerCase}/data/"
      val entName = s"${entNm}".toUpperCase
      Logger.log.info(s" Retrieving Files for $entName from Raw: $raw_path")
      Logger.log.info(s" Processing Entity:${entName} with patnrCd:${ptnr} srcCd:${src}")
      var startTime = ""
      if (incStTime.isEmpty) {
        Logger.log.info(s" Incremental start time($incStTime) is empty , so overriding startTime with incEndTm to  $incEndTs")
        startTime = s"$incEndTs"
      } else {
        Logger.log.info(s" Incremental start time($incStTime) is not empty , so overriding startTime with incStTime  $incEndTs")
        startTime = s"$incStTime"
      }

      val endTime = s"$incEndTs"
      Logger.log.info(s" Endtime : $incEndTs ")
      Logger.log.info(s" startTime : $startTime ")
      Logger.log.info(s" Capturing if any Changes reflected for $entName from $startTime to $endTime")
      val rowKey = s"${ptnr}-${src}-${entName}"
      val sppRowKey = s"${ptnr}-${src}"
      var pitRawPartnFlr=""
      var pitRawRowDelim=""
      var pitRawFileCnt=""
      var refEitTblFlg="N"
      var resFlg="false"


      if (snapBuildType.equalsIgnoreCase("parquet")) {

          Logger.log.info(s" starting EIT scan for Parquet files")
          Logger.log.info(s"EXTRACT_EIT_FLG value is $EXTRACT_EIT_FLG")
          if (EXTRACT_EIT_FLG.equalsIgnoreCase("N")){
              try {
              Logger.log.info(s"Since EXTRACT_EIT_FLG value is $EXTRACT_EIT_FLG then reading from HbaseEit.txt file ; refEitTblFlg : $refEitTblFlg")
              var filename=s"/mapr/${workingDir}/EIT/HbaseEit.txt"
              var fileNmChk=new File(filename).exists()
              if(fileNmChk) {


                Logger.log.info(s"Scanning HbaseEit file ;fileNmChk : $fileNmChk")
                val lines = Source.fromFile(filename).getLines.toList
                var splitLine = lines.map(x => x.split('|'))
                var eitFileList: List[String] = null
                if (lstrundateFlg) {
                  eitFileList = splitLine.filter(x => x(2) == entName && x(2) > startTime).map(x => s"${raw_path}${entNm}/${x(1)}").distinct
                  Logger.log.info(s" Number of Entries Captured for $entName from EIT SCAN b/w $startTime and $endTime :" + eitFileList.size)
                } else {
                  eitFileList = splitLine.filter(x => x(2) == entName).map(x => s"${raw_path}${entNm}/${x(1)}").distinct
                  Logger.log.info(s" Number of Entries Captured for $entName from EIT SCAN full load :" + eitFileList.size)
                }

                if (eitFileList.size > 0) {
                  //val eitFileList = eitInfo.map(x => (x._1, x._2)).collect.toList.map(x => ( s"${raw_path}${entNm}/${x._2}")).distinct
                  //val eitRawFileList = eitFileList.filter(x => filterRawFileExist(x))
                  val eitRawFileListNtEmp = eitFileList.filter(x => isEmptyDir(x))

                  Logger.log.info(s" Number of PARQUET Files exist in Raw for $entName from EIT SCAN  :" + eitRawFileListNtEmp.length)
                  Logger.log.info(s" List of PARQUET Files from Raw : ${eitRawFileListNtEmp.mkString}")
                  val eitRdd = globalContext.spark.parallelize(eitRawFileListNtEmp)

                  eitRdd.collect.map(x => saveToDataFrameP("PARQUET", workingDir, x, entName))

                  pitRawRowDelim = "NA|"
                  pitRawPartnFlr = "NA|"
                  pitRawFileCnt = "NA|"
                  refEitTblFlg = "N"

                  resFlg = "true"
                  /*
                            val eitFileList = eitInfo.map(x => (x._1, x._3, x._2)).collect.toList.map(x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._2}/${x._3}"))
                            val eitRawFileList = eitFileList.filter(x => filterRawFileExist(x._2))

                            Logger.log.info(s" Number of PARQUET Files exist in Raw for $entName from EIT SCAN b/w $startTime and $endTime :" + eitRawFileList.length)
                            Logger.log.info(s" List of PARQUET Files from Raw : ${eitRawFileList.mkString}")
                            val eitRdd = globalContext.spark.parallelize(eitRawFileList)
                            val eitFileRdd = eitRdd.groupByKey.mapValues(_.mkString(","))
                            eitFileRdd.collect.map(x => saveToDataFrameP(x._1, workingDir, x._2, entName))*/
                  // eitFileList.map(x => saveToDataFrameP(x._1, workingDir, x._2, entName))


                } else {
                  refEitTblFlg = "Y"
                  Logger.log.info(s" Since, No Changes Captured for $entName in the HbaseEIT File from $startTime to $endTime,")
                  pitRawRowDelim = "0|"
                  pitRawPartnFlr = "0|"
                  pitRawFileCnt = "0|"
                  resFlg = "false"
                }
              }
                else{
                refEitTblFlg = "Y"
                Logger.log.info(s" Since HbaseEIT file  not present at $filename, proceeding towards reading the EIT Hbase Table")
                pitRawRowDelim = "0|"
                pitRawPartnFlr = "0|"
                pitRawFileCnt = "0|"
                resFlg = "false"

              }
            }
              catch {
                case e: Exception => Logger.log.info(s" Exception while Reading HbaseEit.txt file for $entNm" :+ e.getStackTrace.mkString)
                  hbasePITEndStage(pitTab, "Fail", pitRowKey)
                  pitRawRowDelim="ERROR|"
                  pitRawPartnFlr="ERROR|"
                  pitRawFileCnt="ERROR|"
                  resFlg="false"
                  throw e
              }
            }
          else{
          refEitTblFlg="Y"
            Logger.log.info(s"Since EXTRACT_EIT_FLG value is $EXTRACT_EIT_FLG then proceeding towards scanning EIT Table ; refEitTblFlg : $refEitTblFlg")
            pitRawRowDelim="0|"
            pitRawPartnFlr="0|"
            pitRawFileCnt="0|"
            resFlg="false"

          }
        if(refEitTblFlg.equalsIgnoreCase("Y")) {
          try {

            Logger.log.info(s" Since refEitTblFlg is $refEitTblFlg then scanning the EIT Hbase Table $eitTable")
            import org.apache.hadoop.hbase.client.Scan
            val scan = new Scan()
            val filter = new PrefixFilter(Bytes.toBytes(s"${ptnr}-${src}-${entName}-"))
            val filter1 = new SingleColumnValueFilter(Bytes.toBytes("exi"), Bytes.toBytes("ingProcLogSts"), CompareOp.EQUAL, Bytes.toBytes("Success")); //val filter2 = new SingleColumnValueFilter(Bytes.toBytes("fi"), Bytes.toBytes("iscustrowdelim"), CompareOp.EQUAL, Bytes.toBytes("No"));
            import org.apache.hadoop.hbase.filter.CompareFilter.CompareOp
            scan.setCaching(10000)
            scan.setCacheBlocks(false)
            filter1.setFilterIfMissing(true)
            scan.setFilter(filterList(filter1, filter))
            if (lstrundateFlg) {
              scan.setTimeRange(getTimestamp(startTime), getTimestamp(endTime))
            }

            val eitVal = globalContext.hbaseContext.hbaseRDD(TableName.valueOf(eitTable), scan).cache
            Logger.log.info(s" DL eitVal count : ${eitVal.count()} ")
            val eitInfo = eitVal.map(tuple => {
              val result = tuple._2
              //(Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("schmVer"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("ingstdFileNm"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("entprtnfldr"))))
              (Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("schmVer"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("entprtnfldr"))))
            })


            if (lstrundateFlg) {
              Logger.log.info(s" Number of Entries Captured for $entName from EIT SCAN b/w $startTime and $endTime :" + eitVal.count())
            } else {
              Logger.log.info(s" Number of Entries Captured for $entName from EIT SCAN full load :" + eitVal.count())
            }

            if (!eitInfo.isEmpty) {
              val eitFileList = eitInfo.map(x => (x._1, x._2)).collect.toList.map(x => (s"${raw_path}${entNm}/${x._2}")).distinct
              //val eitRawFileList = eitFileList.filter(x => filterRawFileExist(x))
              val eitRawFileListNtEmp = eitFileList.filter(x => isEmptyDir(x))

              Logger.log.info(s" Number of PARQUET Files exist in Raw for $entName from EIT SCAN b/w $startTime and $endTime :" + eitRawFileListNtEmp.length)
              Logger.log.info(s" List of PARQUET Files from Raw : ${eitRawFileListNtEmp.mkString}")
              val eitRdd = globalContext.spark.parallelize(eitRawFileListNtEmp)

              eitRdd.collect.map(x => saveToDataFrameP("PARQUET", workingDir, x, entName))
              eitVal.unpersist()

              pitRawRowDelim="NA|"
              pitRawPartnFlr="NA|"
              pitRawFileCnt="NA|"
              resFlg="true"

              //"true;" + entName + "-" + pitRawRowDelim + ";" + entName + "-" + pitRawPartnFlr + ";" + entName + "-" + pitRawFileCnt;


            } else {
               Logger.log.info(s" Since, No Changes Captured for $entName in scanning EIT hbase table/ Hbase EIT File from $startTime to $endTime,No DataSets Generated")
              pitRawRowDelim="ERROR|"
              pitRawPartnFlr="ERROR|"
              pitRawFileCnt="ERROR|"
              resFlg="false"
              //"false;" + entName + "-ERROR|;" + entName + "-ERROR|;" + entName + "-ERROR|";
            }

          }  catch {
            case e: Exception => Logger.log.info(s" Exception while Scanning EIT Hbase Table for $entNm" :+ e.getStackTrace.mkString)
              hbasePITEndStage(pitTab, "Fail", pitRowKey)
              pitRawRowDelim="ERROR|"
              pitRawPartnFlr="ERROR|"
              pitRawFileCnt="ERROR|"
              resFlg="false"
              //"false;"+entName+"-ERROR|;"+entName+"-ERROR|;"+entName+"-ERROR|";
              throw e
          }

      }

        resFlg+";"+entName+"-"+pitRawRowDelim+";"+entName+"-"+pitRawPartnFlr+";"+entName+"-"+pitRawFileCnt;
      }else{
        Logger.log.info(s" starting EIT scan for dat files")
        var rsltFlg1=false
        var rsltFlg2=false

        try {
          import org.apache.hadoop.hbase.client.Scan
          val eppRdd: org.apache.spark.rdd.RDD[(String, String)] = getEppLakeTabSchma(eppTable, ptnr, src, entName).cache
          Logger.log.info(s" scanning EIT for isCustRowlim as No for dat files")
          val scan_N = new Scan()
          val filter_N = new PrefixFilter(Bytes.toBytes(s"${ptnr}-${src}-${entName}-"))
          val filter1_N = new SingleColumnValueFilter(Bytes.toBytes("exi"), Bytes.toBytes("ingProcLogSts"), CompareOp.EQUAL, Bytes.toBytes("Success"));
          val filter2_N = new SingleColumnValueFilter(Bytes.toBytes("fi"), Bytes.toBytes("iscustrowdelim"), CompareOp.EQUAL, Bytes.toBytes("No"));
          scan_N.setCaching(10000)
          scan_N.setCacheBlocks(false)
          filter1_N.setFilterIfMissing(true)
          filter2_N.setFilterIfMissing(true)
          scan_N.setFilter(filterList(filter1_N, filter_N,filter2_N))

          if (lstrundateFlg) {
            scan_N.setTimeRange(getTimestamp(startTime), getTimestamp(endTime))
          }

          val eitVal_N = globalContext.hbaseContext.hbaseRDD(TableName.valueOf(eitTable), scan_N).cache
          Logger.log.info(s" DL eitVal count with isCustRowlim as No is  : ${eitVal_N.count()} ")

          if(eitVal_N.count()>0){
            val eitInfo = eitVal_N.map(tuple => {
              val result = tuple._2
              (Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("schmVer"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("srcFileNm"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("entprtnfldr"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("iscustrowdelim"))))
            })
            val isCustDelim = eitInfo.map(kv => {
              kv._4
            }).first.toString

            Logger.log.info(s" Processing ${entName} Files with Delimiter: \\n as isCustDelim is ${isCustDelim}")
            if (lstrundateFlg) {
              Logger.log.info(s" Number of Entries Captured for $entName from EIT SCAN b/w $startTime and $endTime :" + eitVal_N.count())
            } else {
              Logger.log.info(s" Number of Entries Captured for $entName from EIT SCAN full load :" + eitVal_N.count())
            }
            if (!eitInfo.isEmpty) {
              //  val eitFileList: List[(String, String)] = eitInfo.collect.toList.map(x => (x, s"${raw_path}${entName}/${entName}.v${x}//*"))
              //val eitFileList = eitInfo.map(x => (x._1,x._3, x._2)).collect.toList.map(x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._2}/${x._3}"))

              val eitFileListT = eitInfo.map(x => (x._1,x._3, x._2)).collect.toList
              val eitFileList = eitFileListT.map(x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._2}/${x._3}"))


              val eitRawFileList = eitFileList.filter(x => filterRawFileExist(x._2))
              Logger.log.info(s" Number of Files exist in Raw with \\n record delim for $entName from EIT SCAN b/w $startTime and $endTime :" + eitRawFileList.length)

              val eitPartnFlr=eitFileListT.map(x=> (x._2,1))
              val eitPartnFlrCnt= globalContext.spark.parallelize(eitPartnFlr).reduceByKey(_+_).collect().mkString("~")
              pitRawFileCnt=pitRawFileCnt+"\n-"+eitRawFileList.length+"|"
              pitRawRowDelim=pitRawRowDelim+"\n|"
              pitRawPartnFlr=pitRawPartnFlr+"\n-"+eitPartnFlrCnt+"|"

              Logger.log.info(s" List of Files from Raw with \\n record delim: ${eitRawFileList.mkString}")
              val eitRdd = globalContext.spark.parallelize(eitRawFileList)
              val eitFileRdd = eitRdd.groupByKey.mapValues(_.mkString(","))
              //  val eppRdd: org.apache.spark.rdd.RDD[(String, String)] = getEppLakeTabSchma(eppTable, ptnr, src, entName).cache
              Logger.log.info(s" Number of Schema Versions for ${entName} retrieved from EPP HBase Table:" + eppRdd.count())
              val sparkConfig = globalContext.spark
              eppRdd.join(eitFileRdd).collect.foreach { case (schmVer, (schm, fileList)) => saveToDataFrame(workingDir, schmVer, schm, fileList, entName, sparkConfig)
              }
              eitVal_N.unpersist()
              //  eppRdd.unpersist()
              rsltFlg1=true
            } else {
              Logger.log.info(s" Since, No Changes Captured for $entName from $startTime to $endTime, datasets will not be generated")
              rsltFlg1=false
            }
          }
          else
          {
            Logger.log.info(s" since DL eitVal count with isCustRowlim as No is  : ${eitVal_N.count()} , skipping the process")
            rsltFlg1=false
          }


          Logger.log.info(s" scanning EIT for isCustRowlim as Yes for dat files")
          val scan_Y = new Scan()
          val filter_Y = new PrefixFilter(Bytes.toBytes(s"${ptnr}-${src}-${entName}-"))
          val filter1_Y = new SingleColumnValueFilter(Bytes.toBytes("exi"), Bytes.toBytes("ingProcLogSts"), CompareOp.EQUAL, Bytes.toBytes("Success"));
          val filter2_Y = new SingleColumnValueFilter(Bytes.toBytes("fi"), Bytes.toBytes("iscustrowdelim"), CompareOp.EQUAL, Bytes.toBytes("Yes"));
          scan_Y.setCaching(10000)
          scan_Y.setCacheBlocks(false)
          filter1_Y.setFilterIfMissing(true)
          filter2_Y.setFilterIfMissing(true)
          scan_Y.setFilter(filterList(filter1_Y, filter_Y,filter2_Y))

          if (lstrundateFlg) {
            scan_Y.setTimeRange(getTimestamp(startTime), getTimestamp(endTime))
          }

          val eitVal_Y = globalContext.hbaseContext.hbaseRDD(TableName.valueOf(eitTable), scan_Y).cache
          Logger.log.info(s" DL eitVal count with isCustRowlim as Yes is  : ${eitVal_Y.count()} ")
          if(eitVal_Y.count()>0){

            val eitInfo = eitVal_Y.map(tuple => {
              val result = tuple._2
              (Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("schmVer"))), Bytes.toHex(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("rowdelim"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("entprtnfldr"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("srcFileNm"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("iscustrowdelim"))))
            })
            //     (Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("schmVer"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("srcFileNm"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("entprtnfldr"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("iscustrowdelim"))))

            Logger.log.info(s" Processing ${entName} Files with Row Delimiter: \\u0002 & \\u0002\\u000A")
            val isCustDelim = eitInfo.map(kv => {
              kv._5
            }).first.toString

            Logger.log.info(s" Processing ${entName} Files with Delimiter:\\u0002 OR  \\u0002\\u000A  isCustDelim is ${isCustDelim}")

            if (lstrundateFlg) {
              Logger.log.info(s" Number of Entries Captured for $entName from EIT SCAN b/w $startTime and $endTime :" + eitVal_Y.count())
            } else {
              Logger.log.info(s" Number of Entries Captured for $entName from EIT SCAN full load :" + eitVal_Y.count())
            }
            if (!eitInfo.isEmpty()) {

              //val rwDelimLst: List[(String,String)] = eitInfo.map(x => (x._1,x._2, x._3, x._4)).collect.toList.map(x => (x._2,"1"))
              //val rddRwDelim = globalContext.spark.parallelize(rwDelimLst)
              //val rddRwDelimLst = rddRwDelim.groupByKey.mapValues(_.mkString(","))

              //val eppRdd: org.apache.spark.rdd.RDD[(String, String)] = getEppLakeTabSchma(eppTable, ptnr, src, entName).cache
              // val rsltFlg2=rddRwDelimLst.collect.map(x => genExtDelim(x._1,eppRdd, eitInfo,entNm,raw_path,workingDir,startTime, endTime))

              ///val eitFileListCtlB: List[(String, String)] = eitInfo.filter(x => x._2 == "2" || x._2 == "5c7530303032").map(x => (x._1, x._3, x._4)).collect.toList.map(x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._2}/${x._3}"))

              //PITEntry//val eitFileListCtlB: List[(String, String)] = eitInfo.filter(x =>  x._2 == "5c7530303032").map(x => (x._1, x._3, x._4)).collect.toList.map(x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._2}/${x._3}"))

              //val eitFileListCtlBT = eitInfo.filter(x =>  x._2 == "5c7530303032").map(x => (x._1, x._3, x._4)).collect.toList
              val eitFileListCtlBT = eitInfo.filter(x => x._2 == "2" || x._2 == "5c7530303032").map(x => (x._1, x._3, x._4)).collect.toList
              val eitFileListCtlB= eitFileListCtlBT.map(x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._2}/${x._3}"))

              Logger.log.info(s" CustomRowDelim :List of Files from Raw with \\u0002 record delim: ${eitFileListCtlB.mkString}")
              //val eitFileListCtlB: List[(String, String)] = eitInfo.filter( x => x._2 == "2" || x._2 == "5c7530303032" ).map( x => (x._1, x._4, x._3) ).collect.toList.map( x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._4}/${x._3}") )
              val eitRawFileListCtlB = eitFileListCtlB.filter(x => filterRawFileExist(x._2))
              Logger.log.info(s" CustomRowDelim :ACTUAL Number of Files exist in Raw with \\u0002 record delim for $entName from EIT SCAN b/w $startTime and $endTime :" + eitRawFileListCtlB.length)
              Logger.log.info(s" CustomRowDelim :List of Files from Raw with \\u0002 record delim: ${eitRawFileListCtlB.mkString}")

              if(eitRawFileListCtlB.length>0){

                val eitPartnFlrCtlB=eitFileListCtlBT.map(x=> (x._2,1))
                val eitPartnFlrCtlBCnt= globalContext.spark.parallelize(eitPartnFlrCtlB).reduceByKey(_+_).collect().mkString("~")
                pitRawFileCnt=pitRawFileCnt+"CtlB-"+eitRawFileListCtlB.length+"|"
                pitRawRowDelim=pitRawRowDelim+"CtlB|"
                pitRawPartnFlr=pitRawPartnFlr+"CtlB-"+eitPartnFlrCtlBCnt+"|"

                val rddCtlB = globalContext.spark.parallelize(eitRawFileListCtlB)
                val eitFileRddCtlB = rddCtlB.groupByKey.mapValues(_.mkString(","))
                //            val eppRdd: org.apache.spark.rdd.RDD[(String, String)] = getEppLakeTabSchma(eppTable, ptnr, src, entName).cache
                Logger.log.info(s" CustomRowDelim :Number of Schema Versions for ${entName} retrieved from EPP HBase Table:" + eppRdd.count())
                val sparkConfigCtlB = globalContext.spark
                sparkConfigCtlB.hadoopConfiguration.set("textinputformat.record.delimiter", "\u0002")
                eppRdd.join(eitFileRddCtlB).collect.foreach { case (schmVer, (schm, fileList)) => saveToDataFrame(workingDir, schmVer, schm, fileList, entName, sparkConfigCtlB)
                }
              }
              else
              {
                Logger.log.info(s" Skipping the process as ACTUAL Number of Files exist in Raw with \\u0002 record delim is :" + eitRawFileListCtlB.length)
              }


              //val eitFileListCtlBNL: List[(String, String)] = eitInfo.filter(x => x._2 == "25c6e" || x._2 == "20a" || x._2 == "5c75303030325c6e").map(x => (x._1, x._3, x._4)).collect.toList.map(x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._2}/${x._3}"))
              //PitEntry// val eitFileListCtlBNL: List[(String, String)] = eitInfo.filter(x => x._2 == "5c75303030325c6e").map(x => (x._1, x._3, x._4)).collect.toList.map(x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._2}/${x._3}"))
              //val eitFileListCtlBNLT = eitInfo.filter(x => x._2 == "5c75303030325c6e").map(x => (x._1, x._3, x._4)).collect.toList
              val eitFileListCtlBNLT = eitInfo.filter(x => x._2 == "25c6e" || x._2 == "20a" || x._2 == "5c75303030325c6e").map(x => (x._1, x._3, x._4)).collect.toList
              val eitFileListCtlBNL=eitFileListCtlBNLT.map(x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._2}/${x._3}"))

              Logger.log.info(s" CustomRowDelim :Number of Files exist in Raw with \\u0002\\u000A record delim for $entName from EIT SCAN b/w $startTime and $endTime :" + eitFileListCtlBNL.length)

              val eitRawFileListCtlBNL = eitFileListCtlBNL.filter(x => filterRawFileExist(x._2))
              Logger.log.info(s" CustomRowDelim :Number of ACTUAL Files exist in Raw with \\u0002\\u000A record delim for $entName from EIT SCAN b/w $startTime and $endTime :" + eitRawFileListCtlBNL.length)
              Logger.log.info(s" CustomRowDelim :List of ACTUAL Files from Raw with \\u0002\\u000A record delim: ${eitRawFileListCtlBNL.mkString}")
              if(eitRawFileListCtlBNL.length>0){

                val eitPartnFlrCtlBNL=eitFileListCtlBNLT.map(x=> (x._2,1))
                val eitPartnFlrCtlBNLCnt= globalContext.spark.parallelize(eitPartnFlrCtlBNL).reduceByKey(_+_).collect().mkString("~")
                pitRawFileCnt=pitRawFileCnt+"CtlB\n-"+eitRawFileListCtlBNL.length+"|"
                pitRawRowDelim=pitRawRowDelim+"CtlB\n|"
                pitRawPartnFlr=pitRawPartnFlr+"CtlB\n-"+eitPartnFlrCtlBNLCnt+"|"

                val rddCtlBNL = globalContext.spark.parallelize(eitRawFileListCtlBNL)
                val eitFileRddCtlBNL = rddCtlBNL.groupByKey.mapValues(_.mkString(","))
                val sparkConfigCtlBNL = globalContext.spark
                sparkConfigCtlBNL.hadoopConfiguration.set("textinputformat.record.delimiter", "\u0002\u000A")
                eppRdd.join(eitFileRddCtlBNL).collect.foreach { case (schmVer, (schm, fileList)) => saveToDataFrame(workingDir, schmVer, schm, fileList, entName, sparkConfigCtlBNL)
                  //eppRdd.unpersist()
                }

              }
              else
              {
                Logger.log.info(s" Skipping the process as ACTUAL Number of Files exist in Raw with \\u0002\\u000A  record delim is :" + eitRawFileListCtlBNL.length)
              }


              eitVal_Y.unpersist()
              rsltFlg2=true

            }
            else {
              Logger.log.info(s" Number of Files Captured for $entName from EIT SCAN b/w $startTime and $endTime :" + 0)
              Logger.log.info(s" Since, No Changes Captured for $entName from $startTime to $endTime,datasets will not be generated")
              rsltFlg2=false
            }

          }
          else {
            Logger.log.info(s" since DL eitVal count with isCustRowlim as Yes is  : ${eitVal_Y.count()} , skipping the process")
            rsltFlg2=false

          }
          eppRdd.unpersist()

          var res="false;;;"
          if(rsltFlg2==true || rsltFlg1 == true)
          {
            /*            hbasePitPut(pitTab, pitRowKey, "fi", "rawRowDelim", pitRawRowDelim.dropRight(1))
                        hbasePitPut(pitTab, pitRowKey, "fi", "rawPartnFldr", pitRawPartnFlr.dropRight(1))
                        hbasePitPut(pitTab, pitRowKey, "fi", "rawFileCnt", pitRawFileCnt.dropRight(1))*/

            res="true;"+entName+"-"+pitRawRowDelim+";"+entName+"-"+pitRawPartnFlr+";"+entName+"-"+pitRawFileCnt;
          }
          else
          {
            /*            hbasePitPut(pitTab, pitRowKey, "fi", "rawRowDelim", "")
                        hbasePitPut(pitTab, pitRowKey, "fi", "rawPartnFldr", "")
                        hbasePitPut(pitTab, pitRowKey, "fi", "rawFileCnt", "0")*/
            res="false;"+entName+"- ;"+entName+"- ;"+entName+"-0";

          }
          res
        } catch {
          case e: Exception => Logger.log.info(s" Exception while Scanning Files from DL EIT for $entNm" :+ e.getStackTrace.mkString)
            hbasePITEndStage(pitTab, "Fail", pitRowKey)
            throw e
        }
      }
    } catch {
      case e: Exception => Logger.log.info(s" Exception while Scanning Files from DL EIT for $entNm from eitTabScan" :+ e.getStackTrace.mkString)
        hbasePITEndStage(pitTab, "Fail", pitRowKey)
        throw e
    }

  }
  /** Purpose : Def to read the configuration values from the properties file based mentioned under resources
    * input : configurationProperty
    * output: Returns the given configurationProperty value as string */
  def readFeedBasedProperties (dirNm:String,feedName: String, input: String, envParam: String): String = {
    val prop = new Properties()
    val path = "/"+dirNm+"/"+feedName +"_"+ envParam + ".properties"
    val in = this.getClass.getResourceAsStream(path)
    prop.load(in)
    val value = prop.getProperty(s"$input")
    value
  }



}
