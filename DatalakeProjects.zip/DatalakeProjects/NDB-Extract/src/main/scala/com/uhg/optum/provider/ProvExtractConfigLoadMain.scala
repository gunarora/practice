package com.uhg.optum.provider

import com.uhg.optum.common.{CustomFunctions, DPOConstants, GlobalContext, Logger}
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.hbase.client.HBaseAdmin
import org.apache.hadoop.hbase.mapreduce.TableOutputFormat
import org.apache.hadoop.hbase.util.Bytes
import org.apache.hadoop.hbase.{HBaseConfiguration, HColumnDescriptor, HTableDescriptor}
import org.apache.hadoop.io.{LongWritable, Text}
import org.apache.hadoop.hbase.io.ImmutableBytesWritable
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.hbase.client.Put
import org.apache.hadoop.hbase.mapreduce.TableOutputFormat
import org.apache.hadoop.hbase.mapreduce.TableReducer
import org.apache.hadoop.hbase.util.Bytes
import org.apache.hadoop.io.LongWritable
import org.apache.hadoop.io.NullWritable
import org.apache.hadoop.io.Text
import org.apache.hadoop.mapreduce.Counter
import org.apache.hadoop.mapreduce.Counter
import org.apache.hadoop.mapreduce.Mapper
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat
import org.apache.hadoop.hbase.io.ImmutableBytesWritable
import org.apache.hadoop.hbase.client._

import scala.collection.JavaConverters._
import org.apache.hadoop.hbase.util.Bytes
import org.apache.hadoop.hbase.{CellUtil, HBaseConfiguration, TableName}
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.hbase.HTableDescriptor
import org.apache.hadoop.hbase.HColumnDescriptor


object ProvExtractConfigLoadMain {
  def main (args: Array[String]): Unit = {
    val globalContext = new GlobalContext
    val sparkSession = globalContext.createSparkSession("ProvExtract")
    val sqlContext = sparkSession.sqlContext

    if (args.length != 3) {
      Logger.log.info( "Please Pass env and HBase Table Name that needs to be updated \"Tst pei \" for Provisioning extract" )
      Logger.log.error( "===> Since No args(FeedName,ExtractName,env)  is Passed ending Provisioning extract <===" )
      sparkSession.stop()
    } else {
      val env = args( 0 ).trim.toLowerCase
      val TableName=args(1).trim

      DPOConstants.PEIROWKEY = args(1).trim
      DPOConstants.METAURI =args(2).trim.toUpperCase()

      // Read properties file
      val rootDir = CustomFunctions.readProperties( s"rootDir" ,env)
      val peiTabName=CustomFunctions.readProperties( s"peiTableName",env )
      val pitTabName = CustomFunctions.readProperties( s"pitTableName",env )
      val pscTabName = CustomFunctions.readProperties( s"pscTableName" ,env)
      val plcTabName = CustomFunctions.readProperties( s"plcTableName" ,env)
      val pitDatLocation=CustomFunctions.readProperties( s"pitDatLocation",env )
      val DSVConfigLocation=CustomFunctions.readProperties( s"DSVConfigLocation",env )
      val peDatArchiveLocation=CustomFunctions.readProperties( s"peDatArchiveLocation" ,env)
      val securityfileLoc=CustomFunctions.readProperties( s"securityfileLoc" ,env)
      val hbase_zookeeper_quorum=CustomFunctions.readProperties( s"hbase_zookeeper_quorum",env )
      val lakeEppTableName=CustomFunctions.readProperties( s"lakeEppTableName",env )
      val lakeEitTableName=CustomFunctions.readProperties( s"lakeEitTableName" ,env)
      val mountPath=CustomFunctions.readProperties( s"mountPath",env )
      val workingDir=CustomFunctions.readProperties( s"workingDir" ,env)
      val securityVal=CustomFunctions.readProperties( s"securityVal" ,env)


      Logger.log.info(s"=============> Starting HBase Config Load For Hbase Table :${TableName} <=============")




      val hBaseConf = HBaseConfiguration.create()
      hBaseConf.set( "hbase.zookeeper.quorum", hbase_zookeeper_quorum )

      try{
        val admin = new HBaseAdmin( hBaseConf )

       // val flag = admin.tableExists( peiTabName )
        //Logger.log.info( s"  hbase Table FlagValue  : $flag " )


        //PEI Table Creation

        if(TableName.equalsIgnoreCase("pei")){
          Logger.log.info( s" DSV File Location being considered as per properties file  : ${DSVConfigLocation} " )
          val PEIfileRDD = sparkSession.sparkContext.textFile( DSVConfigLocation ).mapPartitionsWithIndex { (idx, iter) => if (idx == 0) iter.drop( 1 ) else iter }
           Logger.log.info( s" PEIfileRDD count : "+ PEIfileRDD.count())

          // val PEItransformedRDD = PEIfileRDD.map { line => CustomFunctions.PEIconvertToKeyValuePairs( line ) }

          def PEIconvertToKeyValuePairs (line: String): (ImmutableBytesWritable, Put) = {
            val peicfDataBytes = Bytes.toBytes("pei")

            def split_bytes (line: String): String = {
              val row = line.split("\\^\\~\\^")
              //val row = line.split("~^~")
              Logger.log.info(s" Row Value : "+row)
              row(0) + "-" + row(1)
            }

            val row = split_bytes(line)
            val rowkey = row.getBytes()
            val put = new Put(rowkey)
            put.add(peicfDataBytes, Bytes.toBytes("feedName"), Bytes.toBytes(line.split("\\^\\~\\^")(0)))
            put.add(peicfDataBytes, Bytes.toBytes("extractName"), Bytes.toBytes(line.split("\\^\\~\\^")(1)))
            put.add(peicfDataBytes, Bytes.toBytes("hdrDesc"), Bytes.toBytes(line.split("\\^\\~\\^")(2)))
            put.add(peicfDataBytes, Bytes.toBytes("hdrDateFormat"), Bytes.toBytes(line.split("\\^\\~\\^")(3)))
            put.add(peicfDataBytes, Bytes.toBytes("trlDesc"), Bytes.toBytes(line.split("\\^\\~\\^")(4)))
            put.add(peicfDataBytes, Bytes.toBytes("isJsonProp"), Bytes.toBytes(line.split("\\^\\~\\^")(5)))
            put.add(peicfDataBytes, Bytes.toBytes("jsonPropFileLoc"), Bytes.toBytes(line.split("\\^\\~\\^")(6)))
            put.add(peicfDataBytes, Bytes.toBytes("sqlQuery"), Bytes.toBytes(line.split("\\^\\~\\^")(7)))
            put.add(peicfDataBytes, Bytes.toBytes("transQuery"), Bytes.toBytes(line.split("\\^\\~\\^")(8)))
            put.add(peicfDataBytes, Bytes.toBytes("trgColumn"), Bytes.toBytes(line.split("\\^\\~\\^")(9)))
            put.add(peicfDataBytes, Bytes.toBytes("trgDataTypeLen"), Bytes.toBytes(line.split("\\^\\~\\^")(10)))
            put.add(peicfDataBytes, Bytes.toBytes("outFileName"), Bytes.toBytes(line.split("\\^\\~\\^")(11)))
            put.add(peicfDataBytes, Bytes.toBytes("outFileExt"), Bytes.toBytes(line.split("\\^\\~\\^")(12)))
            put.add(peicfDataBytes, Bytes.toBytes("outFileLoc"), Bytes.toBytes(line.split("\\^\\~\\^")(13)))
            put.add(peicfDataBytes, Bytes.toBytes("archLoc"), Bytes.toBytes(line.split("\\^\\~\\^")(14)))
            put.add(peicfDataBytes, Bytes.toBytes("isOutFileColDelim"), Bytes.toBytes(line.split("\\^\\~\\^")(15)))
            put.add(peicfDataBytes, Bytes.toBytes("outFileColDelim"), Bytes.toBytes(line.split("\\^\\~\\^")(16)))
            put.add(peicfDataBytes, Bytes.toBytes("isOutFileRowDelim"), Bytes.toBytes(line.split("\\^\\~\\^")(17)))
            put.add(peicfDataBytes, Bytes.toBytes("outFileRowDelim"), Bytes.toBytes(line.split("\\^\\~\\^")(18)))
            put.add(peicfDataBytes, Bytes.toBytes("isFixedWidth"), Bytes.toBytes(line.split("\\^\\~\\^")(19)))
            put.add(peicfDataBytes, Bytes.toBytes("srcCd"), Bytes.toBytes(line.split("\\^\\~\\^")(20)))
            put.add(peicfDataBytes, Bytes.toBytes("prtnrCd"), Bytes.toBytes(line.split("\\^\\~\\^")(21)))
            put.add(peicfDataBytes, Bytes.toBytes("entitySet"), Bytes.toBytes(line.split("\\^\\~\\^")(22)))
            put.add(peicfDataBytes, Bytes.toBytes("snapBuildType"), Bytes.toBytes(line.split("\\^\\~\\^")(23)))
            put.add(peicfDataBytes, Bytes.toBytes("consumingApp"),Bytes.toBytes(line.split("\\^\\~\\^")(24)))
            put.add(peicfDataBytes, Bytes.toBytes("inputFileName"),Bytes.toBytes(line.split("\\^\\~\\^")(25)))
            put.add(peicfDataBytes, Bytes.toBytes("inputFileLocation"),Bytes.toBytes(line.split("\\^\\~\\^")(26)))
            return (new ImmutableBytesWritable(rowkey), put)
          }
          val PEItransformedRDD = PEIfileRDD.map { line => PEIconvertToKeyValuePairs(line) }

          if (admin.tableExists( peiTabName )) {
          Logger.log.info( s" PEI htable already exists" )
          Logger.log.info( s" Table will get loaded if there is any DAT File provided as the input" )
          val tableDesc = new HTableDescriptor( Bytes.toBytes( peiTabName ) )
          val idsColumnFamilyDesc = new HColumnDescriptor( Bytes.toBytes( "pei" ) )
          tableDesc.addFamily( idsColumnFamilyDesc )
          hBaseConf.set( TableOutputFormat.OUTPUT_TABLE, peiTabName )
          val jobConf = new Configuration( hBaseConf )
          jobConf.set( "mapreduce.job.output.key.class", classOf[Text].getName )
          jobConf.set( "mapreduce.job.output.value.class", classOf[LongWritable].getName )
          jobConf.set( "mapreduce.outputformat.class", classOf[TableOutputFormat[Text]].getName )
          PEItransformedRDD.saveAsNewAPIHadoopDataset( jobConf )
          }

          if (!admin.tableExists( peiTabName )) {
            Logger.log.info( s" PEI htable does not exists.Hence creating table" )
            val tableDesc = new HTableDescriptor( Bytes.toBytes( peiTabName ) )
            val idsColumnFamilyDesc = new HColumnDescriptor( Bytes.toBytes( "pei" ) )
            tableDesc.addFamily( idsColumnFamilyDesc )
            admin.createTable( tableDesc )
            hBaseConf.set( TableOutputFormat.OUTPUT_TABLE, peiTabName )
            val jobConf = new Configuration( hBaseConf )
            jobConf.set( "mapreduce.job.output.key.class", classOf[Text].getName )
            jobConf.set( "mapreduce.job.output.value.class", classOf[LongWritable].getName )
            jobConf.set( "mapreduce.outputformat.class", classOf[TableOutputFormat[Text]].getName )
            PEItransformedRDD.saveAsNewAPIHadoopDataset( jobConf )
          }

        }

        if(TableName.equalsIgnoreCase("pit")) {
          Logger.log.info(s"  PIT Dat File Location  : ${pitDatLocation} ")
          //val PITfileRDD = sparkSession.sparkContext.textFile(pitDatLocation).mapPartitionsWithIndex { (idx, iter) => if (idx == 0) iter.drop(1) else iter }
          //val PITTransformedRDD = PITfileRDD.map { line => CustomFunctions.PITConvertToKeyValuePairs(line) }

          if (admin.tableExists(pitTabName)) {
            Logger.log.info(s" PIT htable already exists")
          }

          if (!admin.tableExists(pitTabName)) {
            Logger.log.info(s" PIT htable does not exists.Hence creating table")
            val tableDesc = new HTableDescriptor(Bytes.toBytes(pitTabName))
            val exiColumnFamilyDesc = new HColumnDescriptor(Bytes.toBytes("exi"))
            val fiColumnFamilyDesc = new HColumnDescriptor(Bytes.toBytes("fi"))
            tableDesc.addFamily(exiColumnFamilyDesc)
            tableDesc.addFamily(fiColumnFamilyDesc)
            admin.createTable(tableDesc)
            //hBaseConf.set(TableOutputFormat.OUTPUT_TABLE, pitTabName)
            //val jobConf = new Configuration(hBaseConf)
            //jobConf.set("mapreduce.job.output.key.class", classOf[Text].getName)
            //jobConf.set("mapreduce.job.output.value.class", classOf[LongWritable].getName)
            //jobConf.set("mapreduce.outputformat.class", classOf[TableOutputFormat[Text]].getName)
            //PITTransformedRDD.saveAsNewAPIHadoopDataset(jobConf)
          }
        }

        //PSC Table Creation
        if(TableName.equalsIgnoreCase("psc")){
          Logger.log.info( s" DSV File Location being considered as per properties file  : ${DSVConfigLocation} " )
          val PSCfileRDD = sparkSession.sparkContext.textFile( DSVConfigLocation ).mapPartitionsWithIndex { (idx, iter) => if (idx == 0) iter.drop( 1 ) else iter }
          // val PSCtransformedRDD = PSCfileRDD.map { line => CustomFunctions.PSCconvertToKeyValuePairs( line ) }

          def PSCconvertToKeyValuePairs (line: String): (ImmutableBytesWritable, Put) = {
            val psccfDataBytes = Bytes.toBytes("psc")

            def split_bytes (line: String): String = {
              val row = line.split("\\^\\~\\^")
              row(0) + "-" + row(1) + "-" + row(2)
            }

            val row = split_bytes(line)
            val rowkey = row.getBytes()
            val put = new Put(rowkey)
            put.add(psccfDataBytes, Bytes.toBytes("feedName"), Bytes.toBytes(line.split("\\^\\~\\^")(0)))
            put.add(psccfDataBytes, Bytes.toBytes("extractName"), Bytes.toBytes(line.split("\\^\\~\\^")(1)))
            put.add(psccfDataBytes, Bytes.toBytes("entNm"), Bytes.toBytes(line.split("\\^\\~\\^")(2)))
            put.add(psccfDataBytes, Bytes.toBytes("prikeycols"), Bytes.toBytes(line.split("\\^\\~\\^")(3)))
            put.add(psccfDataBytes, Bytes.toBytes("dmlcol"), Bytes.toBytes(line.split("\\^\\~\\^")(4)))
            put.add(psccfDataBytes, Bytes.toBytes("activeflag"), Bytes.toBytes(line.split("\\^\\~\\^")(5)))
            put.add(psccfDataBytes, Bytes.toBytes("modtscol"), Bytes.toBytes(line.split("\\^\\~\\^")(6)))
            put.add(psccfDataBytes, Bytes.toBytes("fullLoadflg"), Bytes.toBytes(line.split("\\^\\~\\^")(7)))
            //put.add(psccfDataBytes, Bytes.toBytes("lastRunDt"), Bytes.toBytes(line.split("\\^\\~\\^")(8)))
            return (new ImmutableBytesWritable(rowkey), put)
          }
          val PSCtransformedRDD = PSCfileRDD.map { line => PSCconvertToKeyValuePairs(line) }
          if (admin.tableExists(pscTabName )) {
            Logger.log.info( s" PSC htable already exists" )
            Logger.log.info( s" Table will get loaded if there is any DAT File provided as the input" )
            val tableDesc = new HTableDescriptor( Bytes.toBytes( pscTabName ) )
            val idsColumnFamilyDesc = new HColumnDescriptor( Bytes.toBytes( "psc" ) )
            tableDesc.addFamily( idsColumnFamilyDesc )
            hBaseConf.set( TableOutputFormat.OUTPUT_TABLE, pscTabName )
            val jobConf = new Configuration( hBaseConf )
            jobConf.set( "mapreduce.job.output.key.class", classOf[Text].getName )
            jobConf.set( "mapreduce.job.output.value.class", classOf[LongWritable].getName )
            jobConf.set( "mapreduce.outputformat.class", classOf[TableOutputFormat[Text]].getName )
            PSCtransformedRDD.saveAsNewAPIHadoopDataset( jobConf )
          }

          if (!admin.tableExists( pscTabName )) {
            Logger.log.info( s" PSC htable does not exists.Hence creating table" )
            val tableDesc = new HTableDescriptor( Bytes.toBytes( pscTabName ) )
            val idsColumnFamilyDesc = new HColumnDescriptor( Bytes.toBytes( "psc" ) )
            tableDesc.addFamily( idsColumnFamilyDesc )
            admin.createTable( tableDesc )
            hBaseConf.set( TableOutputFormat.OUTPUT_TABLE, pscTabName )
            val jobConf = new Configuration( hBaseConf )
            jobConf.set( "mapreduce.job.output.key.class", classOf[Text].getName )
            jobConf.set( "mapreduce.job.output.value.class", classOf[LongWritable].getName )
            jobConf.set( "mapreduce.outputformat.class", classOf[TableOutputFormat[Text]].getName )
            PSCtransformedRDD.saveAsNewAPIHadoopDataset( jobConf )
          }
        }
        //PLC Configuration Load
        if(TableName.equalsIgnoreCase("plc")) {
          Logger.log.info( s" DSV File Location being considered as per properties file  : ${DSVConfigLocation} " )
          val PLCfileRDD = sparkSession.sparkContext.textFile( DSVConfigLocation ).mapPartitionsWithIndex { (idx, iter) => if (idx == 0) iter.drop( 1 ) else iter }

          def PLCconvertToKeyValuePairs (line: String): (ImmutableBytesWritable, Put) = {
            val plccfDataBytes = Bytes.toBytes("plc")

            def split_bytes(line: String): String = {
              val row = line.split("\\^\\~\\^")
              row(0) + "-" + row(1)
            }

            val row = split_bytes(line)
            val rowkey = row.getBytes()
            val put = new Put(rowkey)
            put.add(plccfDataBytes, Bytes.toBytes("feedName"), Bytes.toBytes(line.split("\\^\\~\\^")(0)))
            put.add(plccfDataBytes, Bytes.toBytes("extractName"), Bytes.toBytes(line.split("\\^\\~\\^")(1)))
            put.add(plccfDataBytes, Bytes.toBytes("lastRunDt"), Bytes.toBytes(line.split("\\^\\~\\^")(2)))
            put.add(plccfDataBytes, Bytes.toBytes("frequency"), Bytes.toBytes(line.split("\\^\\~\\^")(3)))
            return (new ImmutableBytesWritable(rowkey), put)
          }

          val PLCtransformedRDD = PLCfileRDD.map { line => PLCconvertToKeyValuePairs(line) }
          if (admin.tableExists(plcTabName)) {
            Logger.log.info( s" PLC htable already exists" )
            Logger.log.info( s" Table will get loaded if there is any DAT File provided as the input" )
            val tableDesc = new HTableDescriptor( Bytes.toBytes( plcTabName ) )
            val idsColumnFamilyDesc = new HColumnDescriptor( Bytes.toBytes( "plc" ) )
            tableDesc.addFamily( idsColumnFamilyDesc )
            hBaseConf.set( TableOutputFormat.OUTPUT_TABLE, plcTabName )
            val jobConf = new Configuration( hBaseConf )
            jobConf.set( "mapreduce.job.output.key.class", classOf[Text].getName )
            jobConf.set( "mapreduce.job.output.value.class", classOf[LongWritable].getName )
            jobConf.set( "mapreduce.outputformat.class", classOf[TableOutputFormat[Text]].getName )
            PLCtransformedRDD.saveAsNewAPIHadoopDataset( jobConf )
          }

          if (!admin.tableExists(plcTabName)) {
            Logger.log.info( s" PLC htable does not exists.Hence creating table" )
            Logger.log.info( s" Table will get loaded if there is any DAT File provided as the input" )
            val tableDesc = new HTableDescriptor( Bytes.toBytes( plcTabName ) )
            val idsColumnFamilyDesc = new HColumnDescriptor( Bytes.toBytes( "plc" ) )
            tableDesc.addFamily( idsColumnFamilyDesc )
            admin.createTable( tableDesc )
            hBaseConf.set( TableOutputFormat.OUTPUT_TABLE, plcTabName )
            val jobConf = new Configuration( hBaseConf )
            jobConf.set( "mapreduce.job.output.key.class", classOf[Text].getName )
            jobConf.set( "mapreduce.job.output.value.class", classOf[LongWritable].getName )
            jobConf.set( "mapreduce.outputformat.class", classOf[TableOutputFormat[Text]].getName )
            PLCtransformedRDD.saveAsNewAPIHadoopDataset( jobConf )
          }
        }


        /*	    //Moving input Dat file (PEI) to Archive Location
                  if(CustomFunctions.fileExists(DSVConfigLocation) == 0) {
                    val currentTs = CustomFunctions.getCurrentTsFormat
                    val archLocWithTS = (peDatArchiveLocation + "/" + currentTs).replace( "/mapr/", "/" )
                    try {
                      CustomFunctions.createPath( archLocWithTS )
                      CustomFunctions.renameFile( DSVConfigLocation, archLocWithTS )
                    }
                    catch{
                      case e: Exception => Logger.log.info( "Exception while moving files to Archive Location" + e.getMessage )
                        throw e
                    }
                  }*/

        globalContext.spark.stop()
      }
      catch {
        case e: Exception => Logger.log.info( "Exception while reading/loading the DSV Config.Please check if DSV File exists" + e.getMessage )
          throw e
      }

    }
  }
}
