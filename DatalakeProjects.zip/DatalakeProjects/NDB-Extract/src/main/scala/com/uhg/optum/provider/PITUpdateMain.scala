package com.uhg.optum.provider

import com.uhg.optum.common.{CustomFunctions, DPOConstants, GlobalContext, Logger}
import org.apache.hadoop.hbase.HBaseConfiguration
import org.apache.hadoop.hbase.client.HTable
import org.apache.hadoop.hbase.mapreduce.TableInputFormat


/**
  * Created by gsoujany on 5/2/2018.
  */
object PITUpdateMain {
  def main (args: Array[String]): Unit = {
    try {
      /*
      $ cat /mapr/datalake/uhclake/tst/developer/pankaj/scripts/ndb_extract/UHN_Reporting/F5938P_PROD_MAILTYP_ZIP/temp_2018050309025415/extractmeta.txt
      /datalake/uhclake/tst/developer/pankaj/scripts/ndb_extract/hbase_tables/provisioning_instance_tracking;
      UHN_Reporting-F5938P_PROD_MAILTYP_ZIP-3c6e0ccd-a49a-4cdb-9704-e690123d6bf1;
      /datalake/uhclake/tst/developer/pankaj/scripts/ndb_extract/UHN_Reporting/F5938P_PROD_MAILTYP_ZIP/temp_2018050309025415;MAILTYP_ZIP1|MAILTYP_ZIP2;/mapr/datalake/uhclake/prd/developer/OPS/pkuma100/scripts/ndb_extract/uhn_reporting/;F5938P.PROD.MAILTYP;ZIP;/mapr/datalake/uhclake/prd/developer/OPS/pkuma100/scripts/ndb_extract/hbase_tables/extrct/archive/UHN_Reporting/;/datalake/uhclake/tst/developer/pankaj/scripts/ndb_extract/hbase_tables/provisioning_extract_info;/mapr/datalake/uhclake/tst/developer/OPS/pkuma100/security/pkuma100@dbsls0306:/mapr/datalake/uhclake/tst/developer/pankaj/scripts/ndb_extract/UHN_Reporting
     */ Logger.log.info("=============> Starting Prov Extract PIT Update WorkFlow <=============")
      if (args.length != 5) {
        Logger.log.info("===> Please Pass FeedName-ExtractName Environment \" UHN_Reporting-F5938P_PROD_HCAPACSS_ZIP  dev/tst/prod Success\" for Provisioning extract <===")
        Logger.log.error("===> Since No args(FeedName-ExtractName,Environment)  is Passed ending Provisioning extract PIT Update WorkFlow  <===")

      } else {
        try {
          val peiRowKey = args(0).trim
          DPOConstants.PEIROWKEY = args(0).trim
          val feedName = peiRowKey.split("-")(0)
          val extractName = peiRowKey.split("-")(1)
          //Taking environment type
          val env = args(1).trim.toLowerCase
          val pitStatus = args(2).trim.toLowerCase
          val logFileName = args(3).trim.replaceAll("/mapr","")
          DPOConstants.METAURI =args(4).trim.toUpperCase()

          Logger.log.info(s" feedName " + feedName);
          Logger.log.info(s" extractName " + extractName);
          Logger.log.info(s" env " + env);
          Logger.log.info(s" pitStatus " + pitStatus);
          Logger.log.info(s" logFileName " + logFileName);

          //val appName = DPOConstants.PEIROWKEY
          //val metastoreUri = DPOConstants.METAURI
          //Logger.log.info(s" Value for metastoreUri in PEMain  : $metastoreUri")

          val globalContext = new GlobalContext
          // Below line is commented to keep uniformity of using 1 spark-session
          //val sparkSession = globalContext.createSparkSession(appName,metastoreUri)
          //val sqlContext = sparkSession.sqlContext

          // Read properties file
          val rootDir = CustomFunctions.readProperties(s"rootDir", env)
          Logger.log.info(s" rootDir : " + rootDir)

          // commented for not calculating the latest modified dir to avoid conflicts
          /*//Framing temp directory path
          val tempDirPath = rootDir + feedName + "/" + extractName
          Logger.log.info(s" tempDirPath : " + tempDirPath)
          //get the latest temp directory from root folder
          val extractTempPath = CustomFunctions.getLastModifiedDir(tempDirPath)*/

          val logFile = globalContext.spark.textFile(logFileName)

          //val extractTempPath = logFile.filter(_.contains("extractFilePath : ")).map(_.split(":")).map(x => x(4)).first.trim
          val extrctTmpPth = logFile.filter(_.contains("extractFilePath=")).map(_.split('=')(1).trim).collect()
          Logger.log.info(s" Extracted paths  " + extrctTmpPth.size)

          for(extractTempPath<- extrctTmpPth) {

            Logger.log.info(s" Found latest temp directory : " + extractTempPath)
            val txtPath = extractTempPath + "/extractmeta.txt"
            Logger.log.info(s" extractmeta Path to load in RDD " + txtPath);
            val metaRDD = globalContext.spark.textFile(txtPath)

            val metaRDD1 = metaRDD.map(x => x.split("="))
            val pitTabName = metaRDD1.filter(_.contains("pitTabName")).map(x => x(1)).first
            val pitRowKey = metaRDD1.filter(_.contains("pitRowKey")).map(x => x(1)).first
            val extractFilePath = metaRDD1.filter(_.contains("extractFilePath")).map(x => x(1)).first


            Logger.log.info(s" SC metaRDD count " + metaRDD.count());
            Logger.log.info(s" tempory metadata file content for this extract are..");

            Logger.log.info(s"===> pitTabName : " + pitTabName);
            Logger.log.info(s"===> pitRowKey : " + pitRowKey);
            Logger.log.info(s"===> extractFilePath : " + extractFilePath);
            /*
          Logger.log.info(s"===> extractFileName : " + extractFileName);
          Logger.log.info(s"===> outFileLoc : " + outFileLoc);
          Logger.log.info(s"===> outFileName : " + outFileName);
          Logger.log.info(s"===> outFileExt : " + outFileExt);
          Logger.log.info(s"===> archLoc : " + archLoc);
          Logger.log.info(s"===> PEITabName : " + PEITabName);
          Logger.log.info(s"===> SecurityFileLoc : " + SecurityFileLoc);
          */

            //Find the duration
            val provStartTime = CustomFunctions.getHtableValByRowKey(pitTabName, pitRowKey, "exi", "provStrTs")
            val provEndTs = CustomFunctions.getCurrentTimeFormat
            val duration = CustomFunctions.getDuration(provEndTs, provStartTime)
            Logger.log.info(s"===> duration : " + duration);



            // Configure Hbate meta tables

            val hBaseConf1: org.apache.hadoop.conf.Configuration = HBaseConfiguration.create()
            hBaseConf1.set(TableInputFormat.INPUT_TABLE, pitTabName)
            val pitTab: HTable = new HTable(hBaseConf1, pitTabName)


            //update duration
            CustomFunctions.hbasePitPut(pitTab, pitRowKey, "exi", "provCompSts", pitStatus)
            Logger.log.info(s"===> Updated provCompSts : " + pitStatus + "in PIT htable")
            if (!pitStatus.equalsIgnoreCase("Provisioned")) {
              CustomFunctions.hbasePitPut(pitTab, pitRowKey, "exi", "provDur", duration)
              Logger.log.info(s"===> Updated duration : " + duration + " in PIT htable");
              CustomFunctions.hbasePitPut(pitTab, pitRowKey, "exi", "provEndTs", provEndTs)
              Logger.log.info(s"===> Updated provEndTs : " + provEndTs + " in PIT htable")
            }
          }

        } catch {
          case e: Exception => Logger.log.info(" Exception while updating PIT " :+ e.getMessage)
            throw e
        }

      }

    }
    catch {
      case e: Exception => Logger.log.info(" Exception at main() for Pit Update Object" :+ e.getMessage)
        throw e
    }
  }
}