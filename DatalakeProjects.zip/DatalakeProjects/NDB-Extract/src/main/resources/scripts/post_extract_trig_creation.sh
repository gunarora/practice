#########################################################################################################################
# Script Name                   : post_extract_trig_creation.sh
# Author Name                   : Pankaj Kumar Vashistha
# Execution        		        : post_extract_trig_creation.sh <outFileLoc> <file_type> <count> <touch_file_name> <time_frequency> <max_time_count> <content> <logFileName>
##########################################################################################################################
# sh post_extract_trig_creation.sh /mapr/datalake/uhclake/tst/developer/pankaj/scripts/ndb_extract/oozie/final /mapr/datalake/uhclake/tst/developer/pankaj/scripts/ndb_extract/oozie/final/test ZIP /mapr/datalake/uhclake/dataplatform/ndb/t_logs/UHN_Reporting-F5938P_PROD_LANTYP_ZIP_0000246-180730073548993-oozie-mapr-W.log
#!/bin/bash

echo "########################################################################################" | tee -ai $8
echo "Post Extract Trigger File Creation Process Started" | tee -ai $8
echo "DEBUG : Move Extracts to Archive outFileLoc "$1 "  file_type:: "$2 "  count:: "$3 "  touch_file_name:: "$4 " time_frequency:: "$5 " max_time_count:: "$6 "  content:: "$7 "  logFileName:: "$8 | tee -ai $8

##===========================Assign Constant Val=======================================##
outFileLoc=$1
file_type=$2
count=$3
touch_file_name=$4
content=$7
logFileName=$8
##=====================================================================================##
##========================== Logic For Recursion ======================================##
time_cnt=0
time_frequency=$5
max_time_count=$6
##=====================================================================================##
echo "DEBUG : Move Extracts to Archive outFileLoc "$1 "  file_type:: "$2 "  count:: "$3 "  touch_file_name:: "$4 " time_frequency:: "$5 " max_time_count:: "$6 "  content:: "$7 "  logFileName:: "$8 | tee -ai ${logFileName}
##========================== Logic applied Below ======================================##
echo "DEBUG : Logic to create trigger file started" | tee -ai ${logFileName}

while [ $time_cnt -lt $max_time_count ]
do
	file_counts=` ls $outFileLoc/*.$file_type | wc -l `
	echo $file_counts

	if [ $file_counts -eq $count ]; then
		currentTs_file=`date +'%m/%d/%Y'`
		echo "Count Matches" | tee -ai ${logFileName}
		echo "$currentTs_file $content" >$outFileLoc/$touch_file_name
		echo "Post Extract Trigger File Creation Process Ended" | tee -ai ${logFileName}
		exit 0
	fi
	time_cnt=$(($time_cnt+1))
	sleep $time_frequency
done

echo "DEBUG : Logic to create trigger file Failed" | tee -ai ${logFileName}
##=====================================================================================##
echo "Post Extract Trigger File Creation Process Failed" | tee -ai ${logFileName}
echo "########################################################################################" | tee -ai ${logFileName}
exit 1
