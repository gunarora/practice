#########################################################################################################################
# Script Name                   : findMissingUHN_Extracts.sh
# Author Name                   : Pankaj Kumar Vashistha
# Execution        		        : findMissingUHN_Extracts.sh
##########################################################################################################################
# sh findMissingUHN_Extracts.sh
#!/bin/bash

echo "Process Started"
##===========================Assign Constant Val=======================================##
outFileLoc=/mapr/datalake/uhclake/dataplatform/ndb/p_outbox
UHN_Extract_List=/mapr/datalake/uhclake/dataplatform/ndb/p_conf/UHN_Extract_List
cur_date=`date +'%Y-%m-%d'`
##=====================================================================================##
##========================== Logic For Reading All files===============================##
file_cnt=0
for line in $(cat ${UHN_Extract_List}); do
	extractname=`echo ${line} ` 
	if [ ! -f "$outFileLoc/$extractname" ]; then
		file_cnt=$(($file_cnt+1))
		echo $extractname
	fi 
done	
##=====================================================================================##
echo "Total Missing files are : $file_cnt"
echo "Process Ended" 
exit 1
