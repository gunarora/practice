#########################################################################################################################
# Script Name                   : pre_extract_trigger_check.sh
# Author Name                   : Gunjan Arora
# Execution        		        : pre_extract_trigger_check.sh <logFileName>
##########################################################################################################################

#!/bin/bash

echo "########################################################################################" | tee -ai $5
echo "PRE EXTRACT TRIGGER FILE VERIFICATION PROCESS STARTED" | tee -ai $1
echo "DEBUG : Inputs to the pre_extract_trigger_check.sh logFileName:: "$1 | tee -ai $1

logFileName=$1
#__________________________________________Variables defined_____________#
fileloc="/mapr/datalake/uhclake/dataplatform/ndb/t_trigger/UHN_Reporting_TriggerFile.trig"
Iteration_count=1

echo "##=====================================================================================##"

echo "ENTRING INTO LOOP $Iteration_count" | tee -ai ${logFileName}
while [ $Iteration_count -le 12 ]
do
#echo  "while loop" | tee -ai ${logFileName}
echo $fileloc | tee -ai ${logFileName}
if [ -f "$fileloc" ]
then
    echo "TRIGGER FILE FOUND" | tee -ai ${logFileName}
    rm /mapr/datalake/uhclake/dataplatform/ndb/t_trigger/UHN_Reporting_TriggerFile.trig
    echo "TRIGGER FILE HAS BEEN REMOVED AND JOB WILL STARTS TO EXECUTE, PRE EXTRACT TRIGEER FILE PROCESS ENDED" | tee -ai ${logFileName}
    # echo /mapr/datalake/uhclake/dataplatform/ndb/t_oozie/properties/UHN_Reporting-All_Extracts_Generation_Bootstrap.properties > /mapr/datalake/uhclake/dataplatform/on-demand/oozie/jobname.lst
    exit 0
fi
echo "FILE IS NOT AVAILABLE , JOB WILL SLEEP FOR 5 MINUTES AND VERIFY AGAIN" | tee -ai ${logFileName}
#sleep 300;
date; sleep 30;
echo "AFTER 5 MINS, CHECK FILE IS AVAILABLE OR NOT" | tee -ai ${trigLogFileName}
Iteration_count=$(( Iteration_count + 1 ))
echo " ITERATION_COUNT IS $Iteration_count AFTER INCREMENT" | tee -ai ${logFileName}
done
##=============================File is not avaialable========================================================##
if [ "$Iteration_count" -ge 13 ] ;
then
echo "$Iteration_count  number of ocurances" | tee -ai ${logFileName}
echo "FILE IS NOT FOUND, PRE EXTRACT FILE PROCESSED ENDED- ERROR " | tee -ai ${logFileName}
echo "ERROR OCCURRED AS TRIGGER FILE IS NOT AVAILABLE AT LOCATION: CONTACT TO DATALAKE TEAM." | tee -ai ${logFileName}
exit 1
fi


