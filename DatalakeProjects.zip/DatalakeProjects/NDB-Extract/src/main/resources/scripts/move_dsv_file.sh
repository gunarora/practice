#########################################################################################################################
# Script Name                   : move_dsv_file.sh
# Author Name                   : Pankaj Kumar Vashistha
# Execution        		        : move_dsv_file.sh <fileLoc> <outFileLoc> <logFileName>
##########################################################################################################################
# sh move_dsv_file.sh /mapr/datalake/uhclake/dataplatform/ndb/t_datfiles/ /mapr/datalake/uhclake/dataplatform/ndb/t_archive/config/ /mapr/datalake/uhclake/dataplatform/ndb/t_logs/UHN_Reporting-F5938P_PROD_LANTYP_ZIP_0000246-180730073548993-oozie-mapr-W.log
#!/bin/bash

echo "########################################################################################" | tee -ai $3
echo "Move DSV Files to Archive Location Process Started" | tee -ai $3
echo "DEBUG : Inputs to the move_dsv_file.sh "$1" :: "$2" :: "$3 | tee -ai $3

##===========================Assign Constant Val=======================================##
fileLoc=$1
outFileLoc=$2
logFileName=$3
dt1=$(date +'%Y-%m-%d %H:%M:%S.%3N')
Tm="T";
dt=${dt1:0:4}${dt1:5:2}${dt1:8:2}$Tm${dt1:11:2}${dt1:14:2}${dt1:17:2};

##=====================================================================================##
##========================== Logic applied Below ======================================##
echo "DEBUG : Adding timestamp before moving to archive location" | tee -ai ${logFileName}

for input_property_file in `ls -1 ${fileLoc}/*`
do
	fullFileName=`basename $input_property_file`
	fileName=`echo $fullFileName | cut -d'.' -f 1`
	file_ext=`echo $fullFileName | cut -d'.' -f 2`
	archFileName=`echo ${fileName}_${dt}.${file_ext}`
	mv $fileLoc/$fullFileName $outFileLoc/$archFileName
	RESULT=$?
	if [ $RESULT -ne 0 ]; then
		exit 1
	fi
done 

echo "DEBUG : DSV Files moved to archive location" | tee -ai ${logFileName}

##=====================================================================================##
echo "Move DSV Files to Archive Location Process Ended" | tee -ai ${logFileName}
echo "########################################################################################" | tee -ai ${logFileName}
exit 0