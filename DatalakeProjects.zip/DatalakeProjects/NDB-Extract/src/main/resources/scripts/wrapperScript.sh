#########################################################################################################################
# Script Name                   : wrapperScript.sh
# Author Name                   : Vandana Shrestha
# Program                       : DPO NDB Extracts
# Last Updated         		    : 20/04/2018
# Last Updated by       	    : Shefali Jain
# Last Updated                  : 08/02/2018
# Last Updated by               : Pankaj Kumar Vashistha
# Execution        		        : wrapperScript.sh <FeedName> <ExtractName> <RootDirectory> <appndLastWrdFlag> <spclCharFile> <logFileName>
##########################################################################################################################
# sh wrapperScript.sh UHN_Reporting F5938P_PROD_PRVCNTC_ZIP /mapr/datalake/uhclake/tst/developer/pankaj/scripts/ndb_extract YES /mapr/datalake/uhclake/dataplatform/ndb/t_conf/SpecialCharFile /mapr/datalake/uhclake/dataplatform/ndb/t_logs/UHN_Reporting-F5938P_PROD_LANTYP_ZIP_0000246-180730073548993-oozie-mapr-W.log
#!/bin/bash

echo "########################################################################################" | tee -ai $6
echo "Wrapper Script Process Started" | tee -ai $6
echo "DEBUG : Inputs to the wrapperScript.sh "$1" :: "$2" :: "$3" :: "$4" :: "$5" :: "$6 | tee -ai $6

if [ $# !=  6 ] ; then
    echo "ERROR : Please provide <FeedName> <ExtractName> <RootDirectory> <appndLastWrdFlag> <spclCharFile> <logFileName> as input parameters " | tee -ai $6
    exit 1
else
START_TMD=$(date +"%Y-%m-%d %H:%M:%S")
START_TM=$(date +"%s")
echo "INFO : Start time of Wrapper Script : "$START_TMD | tee -ai $6
        echo "DEBUG : Inputs to the paramGen.sh "$1" :: "$2" :: "$3" :: "$4" :: "$5" :: "$6 | tee -ai $6
        fdNm=$1
        exNm=$2
        rootDir=$3
        appndLastWrdFlag=$4
        spclCharFile=$5
        logFileName=$6
fi


#if [ -n "$logFileName" ]; then
#       completeLoc=`cat "${logFileName}" | grep -w "extractFilePath" | head -1 | cut -d ":" -f5 | tr -d '[:space:]'`
#        	tempLoc=`echo $completeLoc | rev | cut -d '/' -f1 | rev`
#        	if [ ! ${completeLoc:0:5} = "/mapr" ]; then
#  				completeLoc="/mapr"${completeLoc}
#			fi
#        	Ts=`echo $completeLoc | cut -d_ -f2`
#        	export metaFile=$completeLoc"/extractmeta.txt"
#       	echo "Meta File with path in if condition: "$metaFile >> ${logFileName}
#  else
#       	tempLoc=`ls $rootDir/$fdNm/$exNm -t1|head -n 1`
#       	Ts=`echo $tempLoc | cut -d_ -f2`
#       	export metaFile=$rootDir/$fdNm/$exNm/$tempLoc"/extractmeta.txt"
#		echo "Meta File with path in else condition: "$metaFile >> ${logFileName}
#fi

if [ -n "$logFileName" ]; then

      # completeLoc=`cat "${logFileName}" | grep -w "extractFilePath" | head -1 | cut -d ":" -f5 | tr -d '[:space:]'`
      completeLoc=` grep -w "extractFilePath=" $logFileName  | cut -d "=" -f2 | awk '{print}' ORS='|'`
      echo "DEBUG : List of Log(s)Location : "$completeLoc | tee -ai ${logFileName}
      IFS="|" read -ra ADDR <<< "$completeLoc"
      for i in "${ADDR[@]}";
           do
            echo "DEBUG : Inside For loop :  Log Location : "$i | tee -ai ${logFileName}

                completeLoc=$i
        	tempLoc=`echo $i | rev | cut -d '/' -f1 | rev`
        	if [ ! ${completeLoc:0:5} = "/mapr" ]; then

  				completeLoc="/mapr"${completeLoc}
			fi

        	Ts=`echo $tempLoc | cut -d_ -f2`
echo "INFO : Extract Timestamp::  "$Ts | tee -ai ${logFileName}
        	export metaFile=$completeLoc"/extractmeta.txt"
       	echo "DEBUG : Meta File with path in if condition: "$metaFile >> ${logFileName}

       	echo "################################### Reading the Meta File #############################################" | tee -ai ${logFileName}

if [ -f "$metaFile" ];
then
	if grep -q "=" $metaFile
	then
		pitTabName=`cat $metaFile | grep -w "pitTabName" |  cut -d "=" -f2`
        pitRowKey=`cat $metaFile | grep -w "pitRowKey" |  cut -d "=" -f2`
        extractFilePath=`cat $metaFile | grep -w "extractFilePath" |  cut -d "=" -f2`
        extractFileName=`cat $metaFile | grep -w "extractFileName" |  cut -d "=" -f2`
        outFileLoc=`cat $metaFile | grep -w "outFileLoc" |  cut -d "=" -f2`
        outFileName=`cat $metaFile | grep -w "outFileName" |  cut -d "=" -f2`
        outFileExt=`cat $metaFile | grep -w "outFileExt" |  cut -d "=" -f2`
        archLoc=`cat $metaFile | grep -w "archLoc" |  cut -d "=" -f2`
        peiTab=`cat $metaFile | grep -w "peiTab" |  cut -d "=" -f2`
        securityfileLoc=`cat $metaFile | grep -w "securityfileLoc" |  cut -d "=" -f2`
		zipFileName=`cat $metaFile | grep -w "zipFileName" |  cut -d "=" -f2`
	else
		#	pitTabName=`cat $metaFile |  cut -d ";" -f1`
		pitRowKey=`cat $metaFile |  cut -d ";" -f2`
		extractFilePath=`cat $metaFile |  cut -d ";" -f3`
		extractFileName=`cat $metaFile |  cut -d ";" -f4 | cut -d "." -f3`
		outFileLoc=`cat $metaFile |  cut -d ";" -f5`
		outFileName=`cat $metaFile |  cut -d ";" -f6 | cut -d "|" -f2`
		outFileExt=`cat $metaFile |  cut -d ";" -f7`
		archLoc=`cat $metaFile |  cut -d ";" -f8`
		peiHbasePath=`cat $metaFile |  cut -d ";" -f9`
		secPropFile=`cat $metaFile |  cut -d ";" -f10`
	fi
else
	echo "ERROR : Meta File not found " | tee -ai ${logFileName}
	exit 1
fi

########################### Removing of special characters ######################################

echo "DEBUG : Checking Special Character Code Start" | tee -ai ${logFileName}
echo $spclCharFile | tee -ai ${logFileName}
if [ -f "$spclCharFile" ];
then
        lineDetails=`cat $spclCharFile | grep ${exNm}`
        echo "$lineDetails" | tee -ai ${logFileName}
        if [ ! -z "$lineDetails" ]; then
                removeCharFlag=`echo $lineDetails | cut -d "|" -f2`
                spclChar==`echo $lineDetails | cut -d "|" -f3`
                removeSpclCharFlag=`echo "$removeCharFlag"|tr [[:lower:]] [[:upper:]]`
                if [ ${removeSpclCharFlag} = "YES" ]; then
                        echo ${spclChar} | tee -ai ${logFileName}
                        echo "DEBUG : Running special char removal for ${exNm}" | tee -ai ${logFileName}
                        for wrd in ${spclChar//;/ }; do
                                echo "DEBUG : Removing $wrd special char for ${exNm}" | tee -ai ${logFileName}
                                #sed -i 's/\xc2//g' "/mapr"$extractFilePath/$extractFileName
                                sed -i 's/'${wrd}'//g' "/mapr"$extractFilePath/$extractFileName
                        done
                        echo "DEBUG : Special Character Removed Successfully" | tee -ai ${logFileName}
                fi
        fi
fi

####################### End of Removing of special characters ######################################

echo "pitRowKey-------> "$pitRowKey | tee -ai ${logFileName}
echo "zipFileName-----> "$zipFileName | tee -ai ${logFileName}
echo "outFileLoc------> "$outFileLoc | tee -ai ${logFileName}
echo "extractFilePath-> "$extractFilePath | tee -ai ${logFileName}
echo "File Path-------> ""/mapr"$extractFilePath/$extractFileName | tee -ai ${logFileName}

########################### Appending EOF character ######################################
START_TM_Z=$(date +"%s")
START_TM_ZD=$(date +"%Y-%m-%d %H:%M:%S")
echo "INFO : Start time of appending EOF character : "$START_TM_ZD | tee -ai ${logFileName}
echo "DEBUG : Appending EOF character Code Start" | tee -ai ${logFileName}
appndLastWrd=`echo "$appndLastWrdFlag"|tr [[:lower:]] [[:upper:]]`
if [ ${appndLastWrd} = "YES" ]; then
        lastLine=`tail -1 "/mapr"$extractFilePath/$extractFileName | cut -f1`
        #spclCharToAppend=""
        if [ $lastLine != "" ] ; then
                        echo "DEBUG : Apending EOF char" | tee -ai ${logFileName}
                        echo "" >> "/mapr"$extractFilePath/$extractFileName | tee -ai ${logFileName}
        fi
fi
echo "DEBUG : Appending EOF character Code Complete" | tee -ai ${logFileName}

TC_END_TM_Z=$(date +"%s")
TC_END_TM_ZD=$(date +"%Y-%m-%d %H:%M:%S")
echo "INFO : End time of appending EOF character : "$TC_END_TM_ZD | tee -ai ${logFileName}
diff_Z=$(($TC_END_TM_Z - $START_TM_Z))

echo "INFO : Execution Time: " $(($diff_Z/3600)) " Hours "$(($diff_Z/60))" Min " $(($diff_Z%60))" Sec" | tee -ai ${logFileName}

###################### End of Appending EOF character ######################################

if [ -z "${extractFilePath}" ]
then
    echo "ERROR : extractFilePath value not found in "$metaFile | tee -ai ${logFileName}
	exit 1
else
    echo "DEBUG : extractFilePath value : "$extractFilePath | tee -ai ${logFileName}
fi

if [ -z "${extractFileName}" ]
then
    echo "ERROR : extractFileName value not found in "$metaFile | tee -ai ${logFileName}
	exit 1
else
    echo "DEBUG : extractFileName value : "$extractFileName | tee -ai ${logFileName}
fi

########################### log file creation ######################################

########################### log file creation ends ##################################

outFileExt=`echo "$outFileExt" | tr [[:lower:]] [[:upper:]]`
#outFileName=` echo "${exNm}" | tr "_" "." `
#outFileName=` echo "$outFileName" | tr -d "[:space:]" `
echo "outFileExt---"$outFileExt | tee -ai ${logFileName}

if [ ! -z $outFileExt ]
then
	outFileName1=$zipFileName"."$outFileExt
	archOutFileNm=$outFileName"_"$Ts"."$outFileExt
#	mkdir -p ${outFileLoc}"/zipFiles"
#	chmod 777 ${outFileLoc}"/zipFiles"
#	zipOutFileLoc=${outFileLoc}"/zipFiles"
else
	outFileName1=$outFileName
	archOutFileNm=$outFileName"_"$Ts
fi
echo "Final outFileName---->"$outFileLoc/$outFileName1 | tee -ai ${logFileName}

srcFileLoc=$rootDir/$fdNm/$exNm/$tempLoc
echo "DEBUG srcFileLoc---->"$srcFileLoc | tee -ai ${logFileName}

srcFileLoc="/mapr"$extractFilePath
echo "Final srcFileLoc---->"$srcFileLoc | tee -ai ${logFileName}
#srcFileLoc="$rootDir/$fdNm/$exNm/temp"

echo "################################### converting the source files to desired format starts #############################################" | tee -ai ${logFileName}
if [ $outFileExt == "ZIP" ]
then
	echo "DEBUG :the desired format configured is "$outFileExt | tee -ai ${logFileName}
	#echo `cd $srcFileLoc && zip -r $outFileName1 *`
	echo `cd $srcFileLoc && zip ${outFileLoc}/${outFileName1} * -x *.txt`
	if [ $? -eq 0 ] ; then
		echo "Extract available for ECG --" ${outFileLoc}/$outFileName1 | tee -ai ${logFileName}
		#Removing the file from temp data location
		echo "Removing the file from temp data location after zipping " | tee -ai ${logFileName}
		rm "/mapr"$extractFilePath/$extractFileName
	fi

fi
echo "################################### converting the source files to desired format completes #############################################" | tee -ai ${logFileName}

echo "################################### Creating a file updating the final status starts #############################################" | tee -ai ${logFileName}

touch ${outFileLoc}/${fdNm}"_AllExtractsPitRowKeys"
chmod 777 ${outFileLoc}/${fdNm}"_AllExtractsPitRowKeys"
echo ${exNm}"|"${outFileName1}"|"${pitRowKey} >> ${outFileLoc}/${fdNm}"_AllExtractsPitRowKeys" | tee -ai ${logFileName}

echo "################################### Creating a file updating the final status completes #############################################" | tee -ai ${logFileName}

echo "INFO : Wrapper Script Process Completed" | tee -ai ${logFileName}
echo "########################################################################################" | tee -ai ${logFileName}
 done

  else
echo "INFO : inside ELSE Condition" | tee -ai ${logFileName}
       	tempLoc=`ls $rootDir/$fdNm/$exNm -t1|head -n 1`
       	Ts=`echo $tempLoc | cut -d_ -f2`
       	export metaFile=$rootDir/$fdNm/$exNm/$tempLoc"/extractmeta.txt"
		echo "INFO : Meta File with path in else condition: "$metaFile >> ${logFileName}
		echo "################################### Reading the Meta File #############################################" | tee -ai ${logFileName}

if [ -f "$metaFile" ];
then
	if grep -q "=" $metaFile
	then
		pitTabName=`cat $metaFile | grep -w "pitTabName" |  cut -d "=" -f2`
        pitRowKey=`cat $metaFile | grep -w "pitRowKey" |  cut -d "=" -f2`
        extractFilePath=`cat $metaFile | grep -w "extractFilePath" |  cut -d "=" -f2`
        extractFileName=`cat $metaFile | grep -w "extractFileName" |  cut -d "=" -f2`
        outFileLoc=`cat $metaFile | grep -w "outFileLoc" |  cut -d "=" -f2`
        outFileName=`cat $metaFile | grep -w "outFileName" |  cut -d "=" -f2`
        outFileExt=`cat $metaFile | grep -w "outFileExt" |  cut -d "=" -f2`
        archLoc=`cat $metaFile | grep -w "archLoc" |  cut -d "=" -f2`
        peiTab=`cat $metaFile | grep -w "peiTab" |  cut -d "=" -f2`
        securityfileLoc=`cat $metaFile | grep -w "securityfileLoc" |  cut -d "=" -f2`
		zipFileName=`cat $metaFile | grep -w "zipFileName" |  cut -d "=" -f2`
	else
		#	pitTabName=`cat $metaFile |  cut -d ";" -f1`
		pitRowKey=`cat $metaFile |  cut -d ";" -f2`
		extractFilePath=`cat $metaFile |  cut -d ";" -f3`
		extractFileName=`cat $metaFile |  cut -d ";" -f4 | cut -d "." -f3`
		outFileLoc=`cat $metaFile |  cut -d ";" -f5`
		outFileName=`cat $metaFile |  cut -d ";" -f6 | cut -d "|" -f2`
		outFileExt=`cat $metaFile |  cut -d ";" -f7`
		archLoc=`cat $metaFile |  cut -d ";" -f8`
		peiHbasePath=`cat $metaFile |  cut -d ";" -f9`
		secPropFile=`cat $metaFile |  cut -d ";" -f10`
	fi
else
	echo "ERROR : Meta File not found " | tee -ai ${logFileName}
	exit 1
fi

########################### Removing of special characters ######################################

echo "DEBUG : Checking Special Character Code Start" | tee -ai ${logFileName}
echo $spclCharFile | tee -ai ${logFileName}
if [ -f "$spclCharFile" ];
then
        lineDetails=`cat $spclCharFile | grep ${exNm}`
        echo "$lineDetails" | tee -ai ${logFileName}
        if [ ! -z "$lineDetails" ]; then
                removeCharFlag=`echo $lineDetails | cut -d "|" -f2`
                spclChar==`echo $lineDetails | cut -d "|" -f3`
                removeSpclCharFlag=`echo "$removeCharFlag"|tr [[:lower:]] [[:upper:]]`
                if [ ${removeSpclCharFlag} = "YES" ]; then
                        echo ${spclChar} | tee -ai ${logFileName}
                        echo "DEBUG : Running special char removal for ${exNm}" | tee -ai ${logFileName}
                        for wrd in ${spclChar//;/ }; do
                                echo "DEBUG : Removing $wrd special char for ${exNm}" | tee -ai ${logFileName}
                                #sed -i 's/\xc2//g' "/mapr"$extractFilePath/$extractFileName
                                sed -i 's/'${wrd}'//g' "/mapr"$extractFilePath/$extractFileName
                        done
                        echo "DEBUG : Special Character Removed Successfully" | tee -ai ${logFileName}
                fi
        fi
fi

####################### End of Removing of special characters ######################################

echo "pitRowKey-------> "$pitRowKey | tee -ai ${logFileName}
echo "zipFileName-----> "$zipFileName | tee -ai ${logFileName}
echo "outFileLoc------> "$outFileLoc | tee -ai ${logFileName}
echo "extractFilePath-> "$extractFilePath | tee -ai ${logFileName}
echo "File Path-------> ""/mapr"$extractFilePath/$extractFileName | tee -ai ${logFileName}

########################### Appending EOF character ######################################
START_TM_Z=$(date +"%s")
START_TM_ZD=$(date +"%Y-%m-%d %H:%M:%S")
echo "INFO : Start time of appending EOF character : "$START_TM_ZD | tee -ai ${logFileName}
echo "DEBUG : Appending EOF character Code Start" | tee -ai ${logFileName}
appndLastWrd=`echo "$appndLastWrdFlag"|tr [[:lower:]] [[:upper:]]`
if [ ${appndLastWrd} = "YES" ]; then
        lastLine=`tail -1 "/mapr"$extractFilePath/$extractFileName | cut -f1`
        #spclCharToAppend=""
        if [ $lastLine != "" ] ; then
                        echo "Apending EOF char" | tee -ai ${logFileName}
                        echo "" >> "/mapr"$extractFilePath/$extractFileName | tee -ai ${logFileName}
        fi
fi
echo "DEBUG : Appending EOF character Code Complete" | tee -ai ${logFileName}
TC_END_TM_Z=$(date +"%s")
TC_END_TM_ZD=$(date +"%Y-%m-%d %H:%M:%S")
echo "INFO : End time of appending EOF character : "$TC_END_TM_Z | tee -ai ${logFileName}
diff_Z=$(($TC_END_TM_Z - $START_TM_Z))

echo "INFO : Execution Time: " $(($diff_Z/3600)) " Hours "$(($diff_Z/60))" Min " $(($diff_Z%60))" Sec" | tee -ai ${logFileName}

###################### End of Appending EOF character ######################################

if [ -z "${extractFilePath}" ]
then
    echo "ERROR : extractFilePath value not found in "$metaFile | tee -ai ${logFileName}
	exit 1
else
    echo "DEBUG : extractFilePath value : "$extractFilePath | tee -ai ${logFileName}
fi

if [ -z "${extractFileName}" ]
then
    echo "ERROR : extractFileName value not found in "$metaFile | tee -ai ${logFileName}
	exit 1
else
    echo "DEBUG : extractFileName value : "$extractFileName | tee -ai ${logFileName}
fi

########################### log file creation ######################################

########################### log file creation ends ##################################

outFileExt=`echo "$outFileExt" | tr [[:lower:]] [[:upper:]]`
#outFileName=` echo "${exNm}" | tr "_" "." `
#outFileName=` echo "$outFileName" | tr -d "[:space:]" `
echo "outFileExt---"$outFileExt | tee -ai ${logFileName}

if [ ! -z $outFileExt ]
then
	outFileName1=$zipFileName"."$outFileExt
	archOutFileNm=$outFileName"_"$Ts"."$outFileExt
#	mkdir -p ${outFileLoc}"/zipFiles"
#	chmod 777 ${outFileLoc}"/zipFiles"
#	zipOutFileLoc=${outFileLoc}"/zipFiles"
else
	outFileName1=$outFileName
	archOutFileNm=$outFileName"_"$Ts
fi
echo "Final outFileName---->"$outFileLoc/$outFileName1 | tee -ai ${logFileName}

srcFileLoc=$rootDir/$fdNm/$exNm/$tempLoc
echo "DEBUG srcFileLoc---->"$srcFileLoc | tee -ai ${logFileName}
srcFileLoc="/mapr"$extractFilePath
echo "FINAL srcFileLoc---->"$srcFileLoc | tee -ai ${logFileName}
#srcFileLoc="$rootDir/$fdNm/$exNm/temp"

echo "################################### converting the source files to desired format starts #############################################" | tee -ai ${logFileName}
if [ $outFileExt == "ZIP" ]
then
	echo "DEBUG :the desired format configured is "$outFileExt | tee -ai ${logFileName}
	#echo `cd $srcFileLoc && zip -r $outFileName1 *`
	echo `cd $srcFileLoc && zip ${outFileLoc}/${outFileName1} * -x *.txt`
	if [ $? -eq 0 ] ; then
		echo "Extract available for ECG --" ${outFileLoc}/$outFileName1 | tee -ai ${logFileName}
		#Removing the file from temp data location
		echo "Removing the file from temp data location after zipping " | tee -ai ${logFileName}
		rm "/mapr"$extractFilePath/$extractFileName
	fi

fi
echo "################################### converting the source files to desired format completes #############################################" | tee -ai ${logFileName}

echo "################################### Creating a file updating the final status starts #############################################" | tee -ai ${logFileName}

touch ${outFileLoc}/${fdNm}"_AllExtractsPitRowKeys"
chmod 777 ${outFileLoc}/${fdNm}"_AllExtractsPitRowKeys"
echo ${exNm}"|"${outFileName1}"|"${pitRowKey} >> ${outFileLoc}/${fdNm}"_AllExtractsPitRowKeys" | tee -ai ${logFileName}

echo "################################### Creating a file updating the final status completes #############################################" | tee -ai ${logFileName}

echo "INFO : Wrapper Script Process Completed" | tee -ai ${logFileName}
echo "########################################################################################" | tee -ai ${logFileName}
fi
TC_END_TM=$(date +"%s")
TC_END_TMD=$(date +"%Y-%m-%d %H:%M:%S")
echo "INFO : End time of Wrapper Script : "$TC_END_TMD | tee -ai ${logFileName}
diff=$(($TC_END_TM - $START_TM))
echo "INFO : Execution Time for wrapper script : " $(($diff/3600)) " Hours "$(($diff/60))" Min " $(($diff%60))" Sec" | tee -ai ${logFileName}

exit 0
