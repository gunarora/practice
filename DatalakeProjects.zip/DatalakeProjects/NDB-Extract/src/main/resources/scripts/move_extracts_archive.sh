#########################################################################################################################
# Script Name                   : move_extracts_archive.sh
# Author Name                   : Pankaj Kumar Vashistha
# Execution        		        : move_extracts_archive.sh <extractLoc> <extractArchiveLoc> <file_type> <ctl_file_name> <touch_file_name> <touch_file_sftp_name> <configArchiveLoc> <logFileName>
##########################################################################################################################
# sh move_extracts_archive.sh /mapr/datalake/uhclake/tst/developer/pankaj/scripts/ndb_extract/oozie/final /mapr/datalake/uhclake/tst/developer/pankaj/scripts/ndb_extract/oozie/final/test ZIP /mapr/datalake/uhclake/dataplatform/ndb/t_logs/UHN_Reporting-F5938P_PROD_LANTYP_ZIP_0000246-180730073548993-oozie-mapr-W.log
#!/bin/bash

echo "########################################################################################" | tee -ai $8
echo "Move Extracts to Archive Location Process Started" | tee -ai $8
echo "DEBUG : Move Extracts to Archive extractLoc "$1 "  extractArchiveLoc:: "$2 "  file_type:: "$3 "  ctl_file_name:: "$4 " touch_file_name:: "$5 " touch_file_sftp_name:: "$6 "  configArchiveLoc:: "$7 "  logFileName:: "$8 "allRowKeyFileNm:: " $9 | tee -ai $8

##===========================Assign Constant Val=======================================##
extractLoc=$1
extractArchiveLoc=$2
file_type=$3
ctl_file_name=$4
touch_file_name=$5
touch_file_sftp_name=$6
configArchiveLoc=$7
logFileName=$8
allRowKeyFileNm=$9
dt1=$(date +'%Y-%m-%d %H:%M:%S.%3N')
Tm="T";
dt=${dt1:0:4}${dt1:5:2}${dt1:8:2}$Tm${dt1:11:2}${dt1:14:2}${dt1:17:2};

echo "DEBUG : Adding timestamp in zip before moving to archive location" | tee -ai ${logFileName}

##=====================================================================================##
##========================== Logic applied Below ======================================##

for input_property_file in `ls -1 ${extractLoc}/*.$file_type`
do
        fullFileName=`basename $input_property_file`
	    # echo "F5938P.PROD.LANTYP.ZIP" | sed -e "s/\(.*\)\(\..*$\)/\1\.$DATE\2/g"
	    archFileName=`echo $fullFileName | sed -e "s/\(.*\)\(\..*$\)/\1\.$dt\2/g"`
	    echo "archFileName ::"$archFileName  | tee -ai ${logFileName}
        mv $extractLoc/$fullFileName $extractArchiveLoc/$archFileName
        RESULT=$?
        if [ $RESULT -ne 0 ]; then
                exit 1
        fi
done
echo "DEBUG : ZIP Files moved to archive location" | tee -ai ${logFileName}
echo "DEBUG : Moving ctl files to config location" | tee -ai ${logFileName}

    confCtlFileName=`echo ${ctl_file_name}_${dt}`
    confTouchFileName=`echo ${touch_file_name}_${dt}`
    confTouchFileSftpName=`echo ${touch_file_sftp_name}_${dt}`
    confAllRowKeyFileNm=`echo ${allRowKeyFileNm}_${dt}`
	mv $extractLoc/$ctl_file_name $configArchiveLoc/$confCtlFileName
	mv $extractLoc/$touch_file_name $configArchiveLoc/$confTouchFileName
	mv $extractLoc/$touch_file_sftp_name $configArchiveLoc/$confTouchFileSftpName
	mv $extractLoc/$allRowKeyFileNm $configArchiveLoc/$confAllRowKeyFileNm

echo "DEBUG : ctl file to config location Completed" | tee -ai ${logFileName}

##=====================================================================================##
echo "Move Extracts to Archive Location Process Ended" | tee -ai ${logFileName}
echo "########################################################################################" | tee -ai ${logFileName}
exit 0