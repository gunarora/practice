package com.uhg.optum.provider

import org.scalatest.FlatSpec
import com.uhg.optum.common.CustomFunctions

import scala.io.Source

class TestCompareExtract extends FlatSpec {

  "Test main positive Mismatch" should "compare arg1 and arg2 then store arg3" in {
    val f1Path=this.getClass.getResource("/File1.csv").getPath
      //.substring(1).replace(s"/",s"\\").replace(s"%20",s" ")
    println(f1Path)
    val f2Path=this.getClass.getResource("/File2.csv").getPath
    //.substring(1).replace(s"/",s"\\").replace(s"%20",s" ")
    val outPath=this.getClass.getResource("/output").getPath
      //.substring(1).replace(s"/",s"\\").replace(s"%20",s" ")
    CompareExtract.main(Array[String](f1Path,f2Path,outPath))
    val fileName=CustomFunctions.getSavedFileName(outPath+"/Mismatched_Records")
    val misMatchFile= outPath+"/Mismatched_Records/"+fileName
    val mismatchData = Source.fromFile(misMatchFile).getLines.toString
    val misMatchExpected=this.getClass.getResource("/expactedOP/mismatched.csv").getPath
      //.substring(1).replace(s"/",s"\\").replace(s"%20",s" ")
    val mismatchDataExpected = Source.fromFile(misMatchExpected).getLines.toString
    assert(mismatchData == mismatchDataExpected)
  }
  "Test main positive Missed" should "compare arg1 and arg2 then store arg3" in {
    val missedPath=this.getClass.getResource("/output").getPath
      //.substring(1).replace(s"/",s"\\").replace(s"%20",s" ")
    val fileName=CustomFunctions.getSavedFileName(missedPath+"/Missed_Records")
    val missedFile= missedPath+"/Missed_Records/"+fileName
    val missedData = Source.fromFile(missedFile).getLines.toString
    val missedExpected=this.getClass.getResource("/expactedOP/missed.csv").getPath
      //.substring(1).replace(s"/",s"\\").replace(s"%20",s" ")
    val missedDataExpected = Source.fromFile(missedExpected).getLines.toString
    assert(missedData == missedDataExpected)
  }
}