package com.uhg.optum.provider

import org.scalatest.FlatSpec
import com.uhg.optum.common.Logger

class TestLogger extends FlatSpec {
  "A logger class info" should "info logs" in {
    val info= Logger.log.info(s" ")
    assert( info.toString == "()")
  }
  "A logger class error" should "error logs" in {
    val error= Logger.log.error(s" ")
    assert( error.toString == "()")
  }
  "A logger class debug" should "debug logs" in {
    val debug= Logger.log.debug(s" ")
    assert( debug.toString == "()")
  }
}