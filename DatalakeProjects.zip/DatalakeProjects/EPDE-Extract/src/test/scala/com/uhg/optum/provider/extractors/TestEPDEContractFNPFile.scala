package com.uhg.optum.provider.extractors

import com.uhg.optum.JobRunner.{PEI, PEIInstanceEmpty}
import com.uhg.optum.dao.{LocalRepositoryManager}
import com.uhg.optum.executors.GlobalContext

import com.uhg.optum.tests.base.UnitSpec
import org.apache.spark.sql.DataFrame

import scala.util.{Failure, Success}

class TestEPDEContractFNPFile extends UnitSpec with EPDEContractFNPFile{
  var globalContext: GlobalContext = _
  implicit var pei: PEI = _

  override def beforeAll(): Unit = {
    super.beforeAll()
    globalContext = new GlobalContext("EPDE-OPTUM", "local") with LocalRepositoryManager
    import com.uhg.optum.protocols.PEIProtocol._
    globalContext.peTable.get("EPDE-OPTUM", "pei") match {
      case Success(instance) =>
        this.pei = instance
        Success()
      case Failure(ex) =>
        Failure(new PEIInstanceEmpty("Exception while getting the columns info from PEI Table", ex))
    }

  }
    test("common4000ExportProcess method should return dataframe for fullFileInd as 'P' with only include logic") {
      val queryMap = Map(("df5_query", "SELECT CRIT_TXT_VAL_1 FROM XYZ WHERE DATA_VEND_CD= '$vendor_cd'"),("df5_query_tables", ""))
      val df6= mock[DataFrame]
      val df7= mock[DataFrame]
      val df19=mock[DataFrame]
      val prevRunDt=""
      val fullFileInd="P"
      val contQuery =Map(("df_20_query","SELECT *  FROM  F5938DBE_PROV_NTWK_CONTR PNC"),("df_20_query_tables",""),("df_all_inc","SELECT * FROM df_20_query"),("df_all_inc_tables",""))
      println("in the test case")
      val sparkSession = globalContext.sparkSession
      import sparkSession.implicits._
      //val df = Seq("OPTUM","OPTUM").toDF()
      val df = Seq(
        ("P", "OPTUM"),
        ("W", "OPTUM"),
        ("L", "ABC")
      ).toDF("CRIT_TXT_VAL_1", "DATA_VEND_CD")
      df.createOrReplaceTempView("df_20_query")
      df.createOrReplaceTempView("F5938DBE_PROV_NTWK_CONTR")
      //when(df6.createOrReplaceTempView(df6_query))
      val vendor_cd="OPTUM"
      assert(common4000ExportProcess(df6,df7,df19,prevRunDt,fullFileInd,contQuery,vendor_cd)(globalContext,pei).except(df).count===0)
    }
  test("common4000ExportProcess method should return dataframe for fullFileInd as 'F' with both include and exclude logic") {
    val queryMap = Map(("df5_query", "SELECT CRIT_TXT_VAL_1 FROM XYZ WHERE DATA_VEND_CD= '$vendor_cd'"),("df5_query_tables", ""))
    val df6= mock[DataFrame]
    val df7= mock[DataFrame]
    val df19=mock[DataFrame]
    val prevRunDt=""
    val fullFileInd="F"
    val contQuery =Map(("df_20Full_query","SELECT *  FROM  F5938DBE_PROV_NTWK_CONTR PNC"),("df_20Full_query_tables",""),("df_all_inc","SELECT * FROM df_20Full_query"),("df_all_inc_tables",""),("df_all_inc_exc","SELECT * FROM df_20Full_query"),("df_all_inc_exc_tables",""))
    println("in the test case")
    val sparkSession = globalContext.sparkSession
    import sparkSession.implicits._
    //val df = Seq("OPTUM","OPTUM").toDF()
    val df = Seq(
      ("P", "OPTUM"),
      ("W", "OPTUM"),
      ("L", "ABC")
    ).toDF("CRIT_TXT_VAL_1", "DATA_VEND_CD")
    df.createOrReplaceTempView("df_20Full_query")
    df.createOrReplaceTempView("F5938DBE_PROV_NTWK_CONTR")
    //when(df6.createOrReplaceTempView(df6_query))
    val vendor_cd="OPTUM"
    assert(common4000ExportProcess(df6,df7,df19,prevRunDt,fullFileInd,contQuery,vendor_cd)(globalContext,pei).except(df).count===0)
  }

  /*test("common2250ExportProcess should be return dataframe on the successfull execution"){
    val dfin= mock[DataFrame]
    val contQuery=Map(("df_20_newContracts","SELECT *  FROM  F5938DBE_PROV_NTWK_CONTR PNC"),("df_20_newContracts_tables",""),("df_20_ActContracts","SELECT * FROM df_20Full_query"),("df_20_ActContracts_tables",""),("df_20_VendorChg","SELECT * FROM df_20Full_query"),("df_20_VendorChg_tables",""),("df20_skip1","SELECT * FROM df_20Full_query"),("df20_skip1_tables",""),("contract_df","SELECT * FROM df_20Full_query"),("contract_df_tables",""))

    val vendor_cd="OPTUM"
    val sparkSession = globalContext.sparkSession
    import sparkSession.implicits._
    //val df = Seq("OPTUM","OPTUM").toDF()
    val df = Seq(
      ("P", "OPTUM"),
      ("W", "OPTUM"),
      ("L", "ABC")
    ).toDF("CRIT_TXT_VAL_1", "DATA_VEND_CD")
    df.createOrReplaceTempView("df_20Full_query")
    df.createOrReplaceTempView("F5938DBE_PROV_NTWK_CONTR")

    assert(common2250ExportProcess(dfin,contQuery,vendor_cd," ")(globalContext,pei).isSuccess)
  }*/


  /*test("common2250ExportProcess should be failure for the wrong contract queries"){
    val dfin= mock[DataFrame]
    val contQuery=Map(("df_20_newContracts","SELECT *  FROM  F5938DBE_PROV_NTWK_CONTR PNC"),("df_20_newContracts_tables",""),("df_20_ActContracts1","SELECT * FROM df_20Full_query"),("df_20_ActContracts_tables",""),("df_20_VendorChg","SELECT * FROM df_20Full_query"),("df_20_VendorChg_tables",""),("df20_skip1","SELECT * FROM df_20Full_query"),("df20_skip1_tables",""),("contract_df","SELECT * FROM df_20Full_query"),("contract_df_tables",""))

    val vendor_cd="OPTUM"
    val sparkSession = globalContext.sparkSession
    import sparkSession.implicits._
    //val df = Seq("OPTUM","OPTUM").toDF()
    val df = Seq(
      ("P", "OPTUM"),
      ("W", "OPTUM"),
      ("L", "ABC")
    ).toDF("CRIT_TXT_VAL_1", "DATA_VEND_CD")
    df.createOrReplaceTempView("df_20Full_query")
    df.createOrReplaceTempView("F5938DBE_PROV_NTWK_CONTR")

    assert(common2250ExportProcess(dfin,contQuery,vendor_cd," ")(globalContext,pei).isFailure)
  }*/

  override def afterAll(): Unit = {

    super.afterAll()
    globalContext.sparkContext.stop()
  }
}
