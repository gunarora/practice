package com.uhg.optum.provider

import java.util.regex.Matcher

import com.uhg.optum.JobRunner.{PEI, PEIInstanceEmpty}
import com.uhg.optum.conf.ApplicationConfig.workingDir
import com.uhg.optum.dao.{HbaseRepositoryManager, LocalRepositoryManager}
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.provider.RawExtractProvider
import com.uhg.optum.provider.snapshot.CommonSnapshotProvider
import com.uhg.optum.provider.validators.PreExtractValidator
import com.uhg.optum.util.EPDECommonUtil
import com.uhg.optum.tests.base.UnitSpec
import org.apache.spark.sql.{DataFrame, DataFrameReader, SQLContext}
import org.mockito.Mockito.when

import scala.util.{Failure, Success}

class TestCommonSnapShotUtil  extends UnitSpec with CommonSnapshotProvider{
  var globalContext: GlobalContext = _
  implicit var pei: PEI = _

  override def beforeAll(): Unit = {
    super.beforeAll()

    //val peiRowKey = "MCAD_Reporting-TOPS"
    globalContext = new GlobalContext("EPDE-OPTUM","local") with LocalRepositoryManager

    import com.uhg.optum.protocols.PEIProtocol._

    globalContext.peTable.get("EPDE-OPTUM", "pei") match {
      case Success(instance) =>
        this.pei = instance
        Success()
      case Failure(ex) =>
        Failure(new PEIInstanceEmpty("Exception while getting the columns info from PEI Table", ex))
    }

  }


  test("getLstRunDtFlag method should return false for the empty value of lstrundate") {
    val lstrundate=""
    val fullLoadFlg=""
    val entity="XYZ"
    assert(getLstRunDtFlag(lstrundate: String, fullLoadFlg: String, entity: String) == false)
  }

  test("getLstRunDtFlag method should return true for the empty value of lstrundate") {
    val lstrundate="1995-09-04"
    val fullLoadFlg=""
    val entity="XYZ"
    assert(getLstRunDtFlag(lstrundate: String, fullLoadFlg: String, entity: String) == true)
  }
  test("getLstRunDtFlag method should return false for the 'Y' value of fullLoadFlg") {
    val lstrundate="1995-09-04"
    val fullLoadFlg="Y"
    val entity="XYZ"
    assert(getLstRunDtFlag(lstrundate: String, fullLoadFlg: String, entity: String) == false)
  }
/*
  test("getOrCreateSnapShots should call getCommonSnapshotPerEntity as snapshot already exists")
  {
    val rawExtractProvider = mock[RawExtractProvider]
    val pitRowKey="EPDE-OPTUM-XYZ1111"
    val tables="XYZ"
    val checkComm      onSnapshot=""
    val dataframe=mock[DataFrame]
    val dataframeReader=mock[DataFrameReader]
    val context=mock[GlobalContext]
    val sqlContext=mock[SQLContext]
    val entity=tables
    when(rawExtractProvider.getCommonSnapshotPerEntity(entity)(context)).thenReturn("Y")
    when(context.sqlContext).thenReturn(sqlContext)
    when(sqlContext.read).thenReturn(dataframeReader)
    when(dataframeReader.parquet(workingDir + "/snapshot/" + "XYZ")).thenReturn(dataframe)

    assert(EPDECommonUtil.getOrCreateSnapShots(pitRowKey ,tables ,checkCommonSnapshot)(context,pei,rawExtractProvider)=="Y")
  }
  test("getOrCreateSnapShots should call getSnapshotExtractPerEntity as checkCommonSnapshot is 'N'")
  {
    val rawExtractProvider = mock[RawExtractProvider]
    val pitRowKey="EPDE-OPTUM-XYZ1111"
    val tables="XYZ"
    val checkCommonSnapshot="N"
    val entity=tables
    val dataframe=mock[DataFrame]
    val dataframeReader=mock[DataFrameReader]
    val context=mock[GlobalContext]
    val sqlContext=mock[SQLContext]
    /*when(context.sqlContext).thenReturn(sqlContext)
    when(sqlContext.read).thenReturn(dataframeReader)
    when(dataframeReader.parquet(workingDir + "/snapshot/" + "XYZ")).thenReturn(dataframe)*/
    when(rawExtractProvider.getSnapshotExtractPerEntity("EPDE-XYZ", entity, pei, pitRowKey)(globalContext)).thenReturn("Y")
    assert(EPDECommonUtil.getOrCreateSnapShots(pitRowKey ,tables ,checkCommonSnapshot)(globalContext,pei,rawExtractProvider)=="Y")
  }
  test("getOrCreateSnapShots should call getSnapshotExtractPerEntity as common snapshot does not exist")
  {
    val rawExtractProvider = mock[RawExtractProvider]
    val pitRowKey="EPDE-OPTUM-XYZ1111"
    val tables="ABC"
    val checkCommonSnapshot=""
    val entity=tables
    val dataframe=mock[DataFrame]
    val dataframeReader=mock[DataFrameReader]
    val context=mock[GlobalContext]
    val sqlContext=mock[SQLContext]
    /*when(context.sqlContext).thenReturn(sqlContext)
    when(sqlContext.read).thenReturn(dataframeReader)
    when(dataframeReader.parquet(workingDir + "/snapshot/" + "XYZ")).thenReturn(dataframe)*/
    when(rawExtractProvider.getSnapshotExtractPerEntity("EPDE-ABC", entity, pei, pitRowKey)(globalContext)).thenReturn("Y")
    assert(EPDECommonUtil.getOrCreateSnapShots(pitRowKey ,tables ,checkCommonSnapshot)(globalContext,pei,rawExtractProvider)=="Y")
  }
*/
  override def afterAll(): Unit = {

    super.afterAll()
    globalContext.sparkContext.stop()
  }

}
