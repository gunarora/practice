package com.uhg.optum.provider.extractors



import com.uhg.optum.JobRunner.{PEI, PEIInstanceEmpty}
import com.uhg.optum.dao.{HbaseRepositoryManager, LocalRepositoryManager}
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDERK4InputJsonSchema.{ExtractFileEntity, Query, SegmentDetails}
import com.uhg.optum.provider.extractors.EPDERK4_HAS_SegExt
import com.uhg.optum.util.CommonUtil
import com.uhg.optum.tests.base.UnitSpec

import scala.util.{Failure, Success}

class TestHASSegmentUtil extends UnitSpec with EPDERK4_HAS_SegExt {
  var globalContext: GlobalContext = _
  implicit var pei: PEI = _
  var glblVarLst = collection.mutable.Map[String, String]()

  override def beforeAll(): Unit = {
    super.beforeAll()

    globalContext = new GlobalContext("EPDE_OPTUM","local") with LocalRepositoryManager
    import com.uhg.optum.protocols.PEIProtocol._
    globalContext.peTable.get("EPDE_OPTUM", "pei") match{
      case Success(instance) =>
        this.pei = instance
        Success()
      case Failure(ex) =>
        Failure(new PEIInstanceEmpty("Exception while getting the columns info from PEI Table", ex))
    }
    val WS_CANC_DT_1 = "01/01/0001" // used in PSP ; genrated in
    val WS_CANC_DT_2 = "12/31/9999" // used in PSP ; genrated in
    val WS_UPDT_DT_1 = "03/01/2019" // used in PSP
    val WS_UPDT_DT_2 = "12/31/9999" // used in PSP
    val WS_ACTV_CD_1 = "A" // used in ADD
    val WS_ACTV_CD_2 = "I" // used in ADD
    CommonUtil.add2Map(glblVarLst, "${WS_CANC_DT_1}", WS_CANC_DT_1)
    CommonUtil.add2Map(glblVarLst, "${WS_CANC_DT_2}", WS_CANC_DT_2)
    CommonUtil.add2Map(glblVarLst, "${WS_UPDT_DT_1}", WS_UPDT_DT_1)
    CommonUtil.add2Map(glblVarLst, "${WS_UPDT_DT_2}", WS_UPDT_DT_2)

    CommonUtil.add2Map(glblVarLst, "${WS_ACTV_CD_1}", WS_ACTV_CD_1)
    CommonUtil.add2Map(glblVarLst, "${WS_ACTV_CD_2}", WS_ACTV_CD_2)

  }
 /* test("hasSegGen method should throw exception if the PRV final view  does not exist") {
    val query = new Query("HAS_FINAL_FETCH", "SELECT DISTINCT 'HAS' AS OUT_HAS_REC_TYP,PAT.PROV_ID AS OUT_HAS_PROV_ID,TEL.TEL_NBR OUT_HAS_TEL_NBR,TEL.AREA_CD AS OUT_HAS_AREA_CD,CASE 	WHEN PAT.TEL_USE_TYP_CD='C' AND PRV_FNL_VIEW.OUT_ADD_TYP_CD='BILL' THEN  'B' WHEN PAT.TEL_USE_TYP_CD='C' AND PRV_FNL_VIEW.OUT_ADD_TYP_CD!='BILL' THEN 'P' ELSE PAT.TEL_USE_TYP_CD END AS OUT_HAS_TYP_CD,PAT.DIR_IND AS OUT_HAS_DIR_IND,WHEN from_unixtime(CHAR(TEL.LST_UPDT_DT,USA),'yyyyMMdd') > from_unixtime(WS_PREV_RUN_DT,'yyyyMMdd')  OR  from_unixtime(CHAR(PAT.LST_UPDT_DT,USA),'yyyyMMdd') > from_unixtime(WS_PREV_RUN_DT,'yyyyMMdd') THEN 'Y'  ELSE 'N' END AS OUT_HAS_CHG_IND,PAT.EXT_NBR AS OUT_HAS_EXT_NBR,PAT.PRI_CD AS OUT_HAS_PRI_CD,PAT.ACTV_CD AS OUT_HAS_ACTV_CD,' ' AS OUT_HAS_TEL_TYP_CD FROM PROV_ADR_TEL_CMNCT PAT, TEL_CMNCT TEL,PRV_FNL_VIEW WHERE PAT.PROV_ID =PRV_FNL_VIEW.OUT_ADD_PROV_ID AND PAT.TAX_ID_NBR=PRV_FNL_VIEW.PTA_TAX_ID_NBR AND  PAT.TAX_ID_TYP_CD = PRV_FNL_VIEW.PTA_TAX_ID_TYP_CD AND  PAT.ADR_ID = PRV_FNL_VIEW.OUT_ADD_ADR_ID AND PAT.TEL_CMNCT_ID  = TEL.TEL_CMNCT_ID AND TEL.CANC_DT = '12/31/9999' AND PAT.ADR_TYP_CD IN (SELECT CASE WHEN PRV_FNL_VIEW.PTA_ADR_TYP_CD='L' ELSE 'H' END AS WS_ADR_TYP_CD_1 FROM PRV_FNL_VIEW,'D') AND ((PAT.ACTV_CD  = 'A') OR (PAT.ACTV_CD IN ('A','I') AND  PAT.LST_UPDT_DT  BETWEEN '12/31/9999' AND WS_PREV_RUN_DT )) ORDER BY PAT.ACTV_CD DESC", null, null)
    val queries = Seq(query)
    val segDtls = new SegmentDetails("HAS",
      "6",
      "OUT_HAS_REC_TYP;OUT_HAS_PROV_ID;OUT_HAS_TEL_NBR;OUT_HAS_AREA_CD;OUT_HAS_TYP_CD;OUT_HAS_DIR_IND;OUT_HAS_CHG_IND;OUT_HAS_EXT_NBR;OUT_HAS_PRI_CD;OUT_HAS_ACTV_CD;OUT_HAS_TEL_TYP_CD",
      "3;9;7;3;1;1;1;10;1;1;1",
      "400","",
      queries
    )
    val segDtlsSeq = Seq(segDtls)
    val prevRunDate = ""
    val outputFilePath = ""
    val spark = globalContext.sparkSession
    import spark.implicits._
    val s = Seq(1, 2, 3)
    val df = s.toDF
    //df.createOrReplaceTempView("PRV_FNL_VIEW")
    println("=======================" + spark.catalog.tableExists("PRV_FNL_VIEW") + "========")
    val thrownExcep = intercept[Exception] {
      hasSegGen(segDtlsSeq,outputFilePath,glblVarLst)(globalContext)
    }
    assert(thrownExcep.getMessage == "The temporary view PRV_FNL_VIEW from PRV segment is required for HAS segment")
  }*/


  /*test("hasSegGen method should return 'N' if HAS segment details are not present") {
    val query = new Query("HAS_FETCH_HASN", "SELECT DISTINCT 'HAS' AS OUT_HAS_REC_TYP,PAT.PROV_ID AS OUT_HAS_PROV_ID,TEL.TEL_NBR OUT_HAS_TEL_NBR,TEL.AREA_CD AS OUT_HAS_AREA_CD,CASE 	WHEN PAT.TEL_USE_TYP_CD='C' AND PRV_FNL_VIEW.OUT_ADD_TYP_CD='BILL' THEN  'B' WHEN PAT.TEL_USE_TYP_CD='C' AND PRV_FNL_VIEW.OUT_ADD_TYP_CD!='BILL' THEN 'P' ELSE PAT.TEL_USE_TYP_CD END AS OUT_HAS_TYP_CD,PAT.DIR_IND AS OUT_HAS_DIR_IND,WHEN from_unixtime(CHAR(TEL.LST_UPDT_DT,USA),'yyyyMMdd') > from_unixtime(WS_PREV_RUN_DT,'yyyyMMdd')  OR  from_unixtime(CHAR(PAT.LST_UPDT_DT,USA),'yyyyMMdd') > from_unixtime(WS_PREV_RUN_DT,'yyyyMMdd') THEN 'Y'  ELSE 'N' END AS OUT_HAS_CHG_IND,PAT.EXT_NBR AS OUT_HAS_EXT_NBR,PAT.PRI_CD AS OUT_HAS_PRI_CD,PAT.ACTV_CD AS OUT_HAS_ACTV_CD,' ' AS OUT_HAS_TEL_TYP_CD FROM PROV_ADR_TEL_CMNCT PAT, TEL_CMNCT TEL,PRV_FNL_VIEW WHERE PAT.PROV_ID =PRV_FNL_VIEW.OUT_ADD_PROV_ID AND PAT.TAX_ID_NBR=PRV_FNL_VIEW.PTA_TAX_ID_NBR AND  PAT.TAX_ID_TYP_CD = PRV_FNL_VIEW.PTA_TAX_ID_TYP_CD AND  PAT.ADR_ID = PRV_FNL_VIEW.OUT_ADD_ADR_ID AND PAT.TEL_CMNCT_ID  = TEL.TEL_CMNCT_ID AND TEL.CANC_DT = '12/31/9999' AND PAT.ADR_TYP_CD IN (SELECT CASE WHEN PRV_FNL_VIEW.PTA_ADR_TYP_CD='L' ELSE 'H' END AS WS_ADR_TYP_CD_1 FROM PRV_FNL_VIEW,'D') AND ((PAT.ACTV_CD  = 'A') OR (PAT.ACTV_CD IN ('A','I') AND  PAT.LST_UPDT_DT  BETWEEN '12/31/9999' AND WS_PREV_RUN_DT )) ORDER BY PAT.ACTV_CD DESC", null, null)
    val queries = Seq(query)
    val segDtls = new SegmentDetails("HASOO",
      "14",
      "OUT_HAS_REC_TYP;OUT_HAS_PROV_ID;OUT_HAS_TEL_NBR;OUT_HAS_AREA_CD;OUT_HAS_TYP_CD;OUT_HAS_DIR_IND;OUT_HAS_CHG_IND;OUT_HAS_EXT_NBR;OUT_HAS_PRI_CD;OUT_HAS_ACTV_CD;OUT_HAS_TEL_TYP_CD",
      "3;9;7;3;1;1;1;10;1;1;1",
      "400","",
      queries
    )
    val segDtlsSeq = Seq(segDtls)
    val prevRunDate = ""
    val outputFilePath = ""
    val spark = globalContext.sparkSession
    import spark.implicits._
    val s = Seq(1, 2, 3)
    val df = s.toDF
    df.createOrReplaceTempView("PRV_FNL_VIEW")
    //println("======================="+spark.catalog.tableExists("PRV_FNL_VIEW")+"========")
    /* val thrownExcep = intercept[Exception] {
       hasSegGen(segDtlsSeq, prevRunDate, outputFilePath,glblVarLst)(globalContext)
     }*/
    assert(hasSegGen(segDtlsSeq, outputFilePath,glblVarLst)(globalContext)=="N")

  }*/
  /*test("hasSegGen method should return 'N' if there is no data for HAS segment") {
    val query = new Query("HAS_FINAL_FETCH", "SELECT DISTINCT 'HAS' AS OUT_HAS_REC_TYP,OUT_HAS_PROV_ID,OUT_HAS_TEL_NBR FROM PRV_FNL_VIEW WHERE OUT_HAS_PROV_ID=11", null, null)
    val queries = Seq(query)
    val segDtls = new SegmentDetails("HAS",
      "21",
      "OUT_HAS_REC_TYP;OUT_HAS_PROV_ID;OUT_HAS_TEL_NBR;OUT_HAS_AREA_CD;OUT_HAS_TYP_CD;OUT_HAS_DIR_IND;OUT_HAS_CHG_IND;OUT_HAS_EXT_NBR;OUT_HAS_PRI_CD;OUT_HAS_ACTV_CD;OUT_HAS_TEL_TYP_CD",
      "3;9;7;3;1;1;1;10;1;1;1",
      "400",
      "",
      queries
    )

    val segDtlsSeq = Seq(segDtls)
    val prevRunDate = ""
    val outputFilePath = ""
    val spark = globalContext.sparkSession

    import spark.implicits._
    val s = Seq((1233, 176),
      (234, 2323),
      (30000, 29898))
    val df = s.toDF("OUT_HAS_PROV_ID", "OUT_HAS_TEL_NBR")
    df.createOrReplaceTempView("PRV_FNL_VIEW")

    println("=======================" + spark.catalog.tableExists("PRV_FNL_VIEW") + "========")

    assert(hasSegGen(segDtls, outputFilePath,glblVarLst)(globalContext) == "N")
  }*/
 /* test("hasSegGen method should return 'N' if there is no HAS_AFFIL_21  query for HAS segment") {
    val query = new Query("HAS_SRC_EXCL_6", "SELECT DISTINCT 'HAS' AS OUT_HAS_REC_TYP,OUT_HAS_PROV_ID,OUT_HAS_TEL_NBR FROM PRV_FNL_VIEW WHERE OUT_HAS_PROV_ID=11", null, null)
    val queries = Seq(query)
    val segDtls = new SegmentDetails("HAS",
      "21",
      "OUT_HAS_REC_TYP;OUT_HAS_PROV_ID;OUT_HAS_TEL_NBR;OUT_HAS_AREA_CD;OUT_HAS_TYP_CD;OUT_HAS_DIR_IND;OUT_HAS_CHG_IND;OUT_HAS_EXT_NBR;OUT_HAS_PRI_CD;OUT_HAS_ACTV_CD;OUT_HAS_TEL_TYP_CD",
      "3;9;7;3;1;1;1;10;1;1;1",
      "400",
      "",
      queries
    )
    val segDtlsSeq = Seq(segDtls)
    val prevRunDate = ""
    val outputFilePath = ""
    val spark = globalContext.sparkSession

    import spark.implicits._
    val s = Seq((1233, 176),
      (234, 2323),
      (30000, 29898))
    val df = s.toDF("OUT_HAS_PROV_ID", "OUT_HAS_TEL_NBR")
    df.createOrReplaceTempView("PRV_FNL_VIEW")

    println("=======================" + spark.catalog.tableExists("PRV_FNL_VIEW") + "========")

    assert(hasSegGen(segDtls, outputFilePath,glblVarLst)(globalContext) == "N")
  }*/
  test("hasSegGen method should return 'N' if there is no HAS_SRC_EXCL_6  query for HAS segment") {
    val query = new Query("HAS_AFFIL_21", "SELECT DISTINCT 'HAS' AS OUT_HAS_REC_TYP,OUT_HAS_PROV_ID,OUT_HAS_TEL_NBR FROM PRV_FNL_VIEW WHERE OUT_HAS_PROV_ID=11", null, null)
    val query1 = new Query("HAS_EXCL", "SELECT DISTINCT 'HAS' AS OUT_HAS_REC_TYP,OUT_HAS_PROV_ID,OUT_HAS_TEL_NBR FROM PRV_FNL_VIEW WHERE OUT_HAS_PROV_ID=11", null, null)
    val queries = Seq(query,query1)
    val segDtls = new SegmentDetails("HAS",
      "21",
      "OUT_HAS_REC_TYP;OUT_HAS_PROV_ID;OUT_HAS_TEL_NBR;OUT_HAS_AREA_CD;OUT_HAS_TYP_CD;OUT_HAS_DIR_IND;OUT_HAS_CHG_IND;OUT_HAS_EXT_NBR;OUT_HAS_PRI_CD;OUT_HAS_ACTV_CD;OUT_HAS_TEL_TYP_CD",
      "3;9;7;3;1;1;1;10;1;1;1",
      "400",
      "",
      queries
    )
    val segDtlsSeq = Seq(segDtls)
    val prevRunDate = ""
    val outputFilePath = ""
    val spark = globalContext.sparkSession

    import spark.implicits._
    val s = Seq((1233, 176),
      (234, 2323),
      (30000, 29898))
    val df = s.toDF("OUT_HAS_PROV_ID", "OUT_HAS_TEL_NBR")
    df.createOrReplaceTempView("PRV_FNL_VIEW")

    println("=======================" + spark.catalog.tableExists("PRV_FNL_VIEW") + "========")

    assert(hasSegGen(segDtls, outputFilePath,glblVarLst)(globalContext) == "N")
  }

 /* test("hasSegGen method should return 'N' if there is no HAS_EXCL  query for HAS segment") {
    val query = new Query("HAS_AFFIL_21", "SELECT DISTINCT 'HAS' AS OUT_HAS_REC_TYP,OUT_HAS_PROV_ID,OUT_HAS_TEL_NBR FROM PRV_FNL_VIEW WHERE OUT_HAS_PROV_ID=11", null, null)
    val query1 = new Query("HAS_SRC_EXCL_6", "SELECT DISTINCT 'HAS' AS OUT_HAS_REC_TYP,OUT_HAS_PROV_ID,OUT_HAS_TEL_NBR FROM PRV_FNL_VIEW WHERE OUT_HAS_PROV_ID=11", null, null)
    val query2 = new Query("HAS_FINAL_FETCH", "SELECT DISTINCT 'HAS' AS OUT_HAS_REC_TYP,OUT_HAS_PROV_ID,OUT_HAS_TEL_NBR FROM PRV_FNL_VIEW WHERE OUT_HAS_PROV_ID=11", null, null)
    val queries = Seq(query,query1,query2)
    val segDtls = new SegmentDetails("HAS",
      "21",
      "OUT_HAS_REC_TYP;OUT_HAS_PROV_ID;OUT_HAS_TEL_NBR;OUT_HAS_AREA_CD;OUT_HAS_TYP_CD;OUT_HAS_DIR_IND;OUT_HAS_CHG_IND;OUT_HAS_EXT_NBR;OUT_HAS_PRI_CD;OUT_HAS_ACTV_CD;OUT_HAS_TEL_TYP_CD",
      "3;9;7;3;1;1;1;10;1;1;1",
      "400",
      "",
      queries
    )
    val segDtlsSeq = Seq(segDtls)
    val prevRunDate = ""
    val outputFilePath = ""
    val spark = globalContext.sparkSession

    import spark.implicits._
    val s = Seq((1233, 176),
      (234, 2323),
      (30000, 29898))
    val df = s.toDF("OUT_HAS_PROV_ID", "OUT_HAS_TEL_NBR")
    df.createOrReplaceTempView("PRV_FNL_VIEW")

    println("=======================" + spark.catalog.tableExists("PRV_FNL_VIEW") + "========")

    assert(hasSegGen(segDtls, outputFilePath,glblVarLst)(globalContext) == "N")
  }*/
 /* test("hasSegGen method should return 'N' if there is no proper sequence of queries for HAS segment") {
    val query = new Query("HAS_SRC_EXCL_6", "SELECT DISTINCT 'HAS' AS OUT_HAS_REC_TYP,OUT_HAS_PROV_ID,OUT_HAS_TEL_NBR FROM ADR_TYP_VIEW WHERE OUT_HAS_PROV_ID=11", null, null)
    val query1 = new Query("HAS_FINAL_FETCH", "SELECT DISTINCT 'HAS' AS OUT_HAS_REC_TYP,OUT_HAS_PROV_ID,OUT_HAS_TEL_NBR FROM PRV_FNL_VIEW WHERE OUT_HAS_PROV_ID=11", null, null)
    val query2 = new Query("HAS_AFFIL_21", "SELECT DISTINCT 'HAS' AS OUT_HAS_REC_TYP,OUT_HAS_PROV_ID,OUT_HAS_TEL_NBR FROM PRV_FNL_VIEW WHERE OUT_HAS_PROV_ID=11", null, null)
    val queries = Seq(query,query1,query2)
    val segDtls = new SegmentDetails("HAS",
      "21",
      "OUT_HAS_REC_TYP;OUT_HAS_PROV_ID;OUT_HAS_TEL_NBR;OUT_HAS_AREA_CD;OUT_HAS_TYP_CD;OUT_HAS_DIR_IND;OUT_HAS_CHG_IND;OUT_HAS_EXT_NBR;OUT_HAS_PRI_CD;OUT_HAS_ACTV_CD;OUT_HAS_TEL_TYP_CD",
      "3;9;7;3;1;1;1;10;1;1;1",
      "400",
      "",
      queries
    )
    val segDtlsSeq = Seq(segDtls)
    val prevRunDate = ""
    val outputFilePath = ""
    val spark = globalContext.sparkSession

    import spark.implicits._
    val s = Seq((1233, 176),
      (234, 2323),
      (30000, 29898))
    val df = s.toDF("OUT_HAS_PROV_ID", "OUT_HAS_TEL_NBR")
    df.createOrReplaceTempView("PRV_FNL_VIEW")

    println("=======================" + spark.catalog.tableExists("PRV_FNL_VIEW") + "========")

    assert(hasSegGen(segDtls, outputFilePath,glblVarLst)(globalContext) == "N")
  }

*/








  override def afterAll(): Unit = {
    super.afterAll()
    globalContext.sparkContext.stop()
  }
}
