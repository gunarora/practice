package com.uhg.optum.provider.extractors


import com.uhg.optum.JobRunner.{PEI, PEIInstanceEmpty}
import com.uhg.optum.dao.{HbaseRepositoryManager, LocalRepositoryManager}
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDERK4InputJsonSchema.{ExtractFileEntity, Queries, Query, SegmentDetails}
import com.uhg.optum.provider.validators.PreExtractValidator
import com.uhg.optum.util.{CommonUtil, EPDECommonUtil, Logger}
import com.uhg.optum.tests.base.UnitSpec
import org.apache.spark.sql.{DataFrame, Row, SQLContext}
import org.mockito.Mockito.when
import com.uhg.optum.provider.extractors.EPDERK4JsonSourceExtractor

import scala.util.{Failure, Success}
import com.uhg.optum.EPDERK4JobRunner


class TestALTSegmentUtil  extends UnitSpec with EPDERK4JsonSourceExtractor {
  var globalContext: GlobalContext = _
  implicit var pei: PEI = _
  var glblVarLst = collection.mutable.Map[String, String]()
  var varLst = collection.mutable.Map[String, String]()
  override def beforeAll(): Unit = {
    super.beforeAll()

    globalContext = new GlobalContext("EPDE_OPTUM", "local") with LocalRepositoryManager
    import com.uhg.optum.protocols.PEIProtocol._
    globalContext.peTable.get("EPDE_OPTUM", "pei") match {
      case Success(instance) =>
        this.pei = instance
        Success()
      case Failure(ex) =>
        Failure(new PEIInstanceEmpty("Exception while getting the columns info from PEI Table", ex))
    }

    val WS_CANC_DT_1 = "01/01/0001" // used in PSP ; genrated in
    val WS_CANC_DT_2 = "12/31/9999" // used in PSP ; genrated in
    val WS_UPDT_DT_1 = "03/01/2019" // used in PSP
    val WS_UPDT_DT_2 = "12/31/9999" // used in PSP
    val WS_ACTV_CD_1 = "A" // used in ADD
    val WS_ACTV_CD_2 = "I" // used in ADD
    CommonUtil.add2Map(glblVarLst, "${WS_CANC_DT_1}", WS_CANC_DT_1)
    CommonUtil.add2Map(glblVarLst, "${WS_CANC_DT_2}", WS_CANC_DT_2)
    CommonUtil.add2Map(glblVarLst, "${WS_UPDT_DT_1}", WS_UPDT_DT_1)
    CommonUtil.add2Map(glblVarLst, "${WS_UPDT_DT_2}", WS_UPDT_DT_2)

    CommonUtil.add2Map(glblVarLst, "${WS_ACTV_CD_1}", WS_ACTV_CD_1)
    CommonUtil.add2Map(glblVarLst, "${WS_ACTV_CD_2}", WS_ACTV_CD_2)

  }

  test(" method should be failure if the PRV does not final view  exist") {
    val SchemaNm = "F5938DBE"
    val inputEntity = mock[ExtractFileEntity]
    //val query = new Query("ALT_15_ALTNM", "SELECT A.PROV_ID AS PROV_ID,A.ALT_NM_TYP_CD AS PAN_ALT_NM_TYP_CD ,A.LST_UPDT_DT AS PAN_LST_UPDT_DT,CASE WHEN  (unix_timestamp(A.LST_UPDT_DT,'yyyy-MM-dd')> unix_timestamp('${WS_PREV_RUN_DT_YMD}','yyyyMMdd')) THEN 'Y' ELSE 'N' END AS OUT_ALT_CHNG_CD ,A.ACTV_CD AS PAN_ACTV_CD,A.LST_NM AS PAN_LST_NM,A.FST_NM AS PAN_FST_NM,A.MDL_NM AS PAN_MDL_NM,A.NM_SUFX_CD AS PAN_NM_SUFX_CD,A.LST_UPDT_TYP_CD AS PAN_LST_UPDT_TYP_CD,A.USER_OFC_CD AS PAN_USER_OFC_CD,A.USER_ID AS PAN_USER_ID FROM ${SchemaNm}_PROV_ALT_NM  A INNER JOIN PRV_FNL_VIEW  PST ON A.PROV_ID = PST.LNK_PROV_ID WHERE ((A.ACTV_CD      = 'A') OR (A.ACTV_CD     IN ('${WS_ACTV_CD_1}' ,'${WS_ACTV_CD_2}') AND unix_timestamp(A.LST_UPDT_DT,'yyyy-MM-dd') BETWEEN unix_timestamp('${WS_UPDT_DT_1}','MM/dd/yyyy') AND unix_timestamp('${WS_UPDT_DT_2}','MM/dd/yyyy')))", null, null)
    val query = new Query("ALT_FNL_VIEW","SELECT * FROM PRV_FNL_VIEW",null,null)
    val queries = Seq(query)
    var segDtls = new SegmentDetails("ALT",
      "2",
      "OUT_ALT_REC_TYP;OUT_ALT_MPIN;OUT_ALT_LST_NM;OUT_ALT_NM_SUFX_CD;OUT_ALT_FST_NM;OUT_ALT_MDL_NM;OUT_ALT_NM_TYP_CD;OUT_ALT_ACTV_CD;OUT_ALT_CHNG_CD",
      "3;9;60;7;20;20;1;1;1",
      "7", "",
      queries
    )
    val segDetailsSeq = Seq(segDtls)

    // val inputEntity = new ExtractFileEntity("F5938RK4","PRV;ALT;PSP;SCO;PQI;HAS;PLI;PFA;TIN;PTI;TCO;NCE;ADD;PHO;ACT;LGS;LNG;HRS;HCA;ACO;AD1;CON;CDK;CSP;COS;CUL;NPI;COE","F5938DBE",segDetailsSeq)
    val prevRunDate =""
    val outputFilePath ="maprfs:///datalake/uhclake/tst/developer/EPDE/TestFiles/"
    val spark=globalContext.sparkSession
    //val SchemaNm = "F5938DBE"
    import spark.implicits._
    val s=Seq((1233, 176),
      (234, 2323),
      (30000, 29898))
    val df=s.toDF("OUT_PRV_PROV_ID","OUT_PRV_TEL_NBR")
    df.createOrReplaceTempView("PRV_FNL_VIEW1")
    println("======================="+spark.catalog.tableExists("PRV_FNL_VIEW1")+"========")

    /*  val thrownExcep = intercept[Exception] {
        acoSegGen(inputEntity,SW_SKIP_ACO, WS_PREV_RUN_DT_YMD, outputFilePath)(globalContext)
      }*/
    assertThrows[org.apache.spark.sql.AnalysisException]
      {
        assert(genALTSeg(segDtls,varLst,glblVarLst,outputFilePath)(globalContext)=='N')
      }
  }

  test("SegDtls Object for ALT Segment should be not null") {
    val SchemaNm = "F5938DBE"
    val inputEntity = mock[ExtractFileEntity]
    val query = new Query("ALT_15_ALTNM", "SELECT A.PROV_ID AS PROV_ID,A.ALT_NM_TYP_CD AS PAN_ALT_NM_TYP_CD ,A.LST_UPDT_DT AS PAN_LST_UPDT_DT,CASE WHEN  (unix_timestamp(A.LST_UPDT_DT,'yyyy-MM-dd')> unix_timestamp('${WS_PREV_RUN_DT_YMD}','yyyyMMdd')) THEN 'Y' ELSE 'N' END AS OUT_ALT_CHNG_CD ,A.ACTV_CD AS PAN_ACTV_CD,A.LST_NM AS PAN_LST_NM,A.FST_NM AS PAN_FST_NM,A.MDL_NM AS PAN_MDL_NM,A.NM_SUFX_CD AS PAN_NM_SUFX_CD,A.LST_UPDT_TYP_CD AS PAN_LST_UPDT_TYP_CD,A.USER_OFC_CD AS PAN_USER_OFC_CD,A.USER_ID AS PAN_USER_ID FROM ${SchemaNm}_PROV_ALT_NM  A INNER JOIN PRV_FNL_VIEW  PST ON A.PROV_ID = PST.LNK_PROV_ID WHERE ((A.ACTV_CD      = 'A') OR (A.ACTV_CD     IN ('${WS_ACTV_CD_1}' ,'${WS_ACTV_CD_2}') AND unix_timestamp(A.LST_UPDT_DT,'yyyy-MM-dd') BETWEEN unix_timestamp('${WS_UPDT_DT_1}','MM/dd/yyyy') AND unix_timestamp('${WS_UPDT_DT_2}','MM/dd/yyyy')))", null, null)
    val queries = Seq(query)
    var segDtls = new SegmentDetails("ALT",
      "2",
      "OUT_ALT_REC_TYP;OUT_ALT_MPIN;OUT_ALT_LST_NM;OUT_ALT_NM_SUFX_CD;OUT_ALT_FST_NM;OUT_ALT_MDL_NM;OUT_ALT_NM_TYP_CD;OUT_ALT_ACTV_CD;OUT_ALT_CHNG_CD",
      "3;9;60;7;20;20;1;1;1",
      "7", "",
      queries
    )
    segDtls = null

    val segDetailsSeq = Seq(segDtls)
    when(inputEntity.segmentDetails).thenReturn(segDetailsSeq)
    var outputFilePath = ""
    assertThrows[NullPointerException]
      {
        genALTSeg(segDtls,varLst,glblVarLst,outputFilePath)(globalContext)
      }
  }

  test(" method should be success if the PRV final view  exist") {
    val SchemaNm = "F5938DBE"
    val inputEntity = mock[ExtractFileEntity]
    //val query = new Query("ALT_15_ALTNM", "SELECT A.PROV_ID AS PROV_ID,A.ALT_NM_TYP_CD AS PAN_ALT_NM_TYP_CD ,A.LST_UPDT_DT AS PAN_LST_UPDT_DT,CASE WHEN  (unix_timestamp(A.LST_UPDT_DT,'yyyy-MM-dd')> unix_timestamp('${WS_PREV_RUN_DT_YMD}','yyyyMMdd')) THEN 'Y' ELSE 'N' END AS OUT_ALT_CHNG_CD ,A.ACTV_CD AS PAN_ACTV_CD,A.LST_NM AS PAN_LST_NM,A.FST_NM AS PAN_FST_NM,A.MDL_NM AS PAN_MDL_NM,A.NM_SUFX_CD AS PAN_NM_SUFX_CD,A.LST_UPDT_TYP_CD AS PAN_LST_UPDT_TYP_CD,A.USER_OFC_CD AS PAN_USER_OFC_CD,A.USER_ID AS PAN_USER_ID FROM ${SchemaNm}_PROV_ALT_NM  A INNER JOIN PRV_FNL_VIEW  PST ON A.PROV_ID = PST.LNK_PROV_ID WHERE ((A.ACTV_CD      = 'A') OR (A.ACTV_CD     IN ('${WS_ACTV_CD_1}' ,'${WS_ACTV_CD_2}') AND unix_timestamp(A.LST_UPDT_DT,'yyyy-MM-dd') BETWEEN unix_timestamp('${WS_UPDT_DT_1}','MM/dd/yyyy') AND unix_timestamp('${WS_UPDT_DT_2}','MM/dd/yyyy')))", null, null)
    val query = new Query("ALT_FNL_VIEW1","SELECT * FROM PRV_FNL_VIEW",null,null)
    val queries = Seq(query)
    var segDtls = new SegmentDetails("ALT",
      "2",
      "OUT_ALT_REC_TYP;OUT_ALT_MPIN;OUT_ALT_LST_NM;OUT_ALT_NM_SUFX_CD;OUT_ALT_FST_NM;OUT_ALT_MDL_NM;OUT_ALT_NM_TYP_CD;OUT_ALT_ACTV_CD;OUT_ALT_CHNG_CD",
      "3;9;60;7;20;20;1;1;1",
      "7", "",
      queries
    )
    val segDetailsSeq = Seq(segDtls)

    // val inputEntity = new ExtractFileEntity("F5938RK4","PRV;ALT;PSP;SCO;PQI;HAS;PLI;PFA;TIN;PTI;TCO;NCE;ADD;PHO;ACT;LGS;LNG;HRS;HCA;ACO;AD1;CON;CDK;CSP;COS;CUL;NPI;COE","F5938DBE",segDetailsSeq)
    val prevRunDate =""
    val outputFilePath ="maprfs:///datalake/uhclake/tst/developer/EPDE/TestFiles/"
    val spark=globalContext.sparkSession
    //val SchemaNm = "F5938DBE"
    import spark.implicits._
    val s=Seq((1233, 176),
      (234, 2323),
      (30000, 29898))
    val df=s.toDF("OUT_PRV_PROV_ID","OUT_PRV_TEL_NBR")
    df.createOrReplaceTempView("PRV_FNL_VIEW")
    println("======================="+spark.catalog.tableExists("PRV_FNL_VIEW")+"========")

    /*  val thrownExcep = intercept[Exception] {
        acoSegGen(inputEntity,SW_SKIP_ACO, WS_PREV_RUN_DT_YMD, outputFilePath)(globalContext)
      }*/
    assert(genALTSeg(segDtls,varLst,glblVarLst, outputFilePath)(globalContext)=="N")
  }

  test("Getting the dataframe from empty sql query should not be success") {

    val dataFrame = mock[DataFrame]
    var query = mock[Query]
    query = new Query("ALT_FNL_VIEW","",null,null)
    val queries = Seq(query)
    var segDtls = new SegmentDetails("ALT",
      "2",
      "OUT_ALT_REC_TYP;OUT_ALT_MPIN;OUT_ALT_LST_NM;OUT_ALT_NM_SUFX_CD;OUT_ALT_FST_NM;OUT_ALT_MDL_NM;OUT_ALT_NM_TYP_CD;OUT_ALT_ACTV_CD;OUT_ALT_CHNG_CD",
      "3;9;60;7;20;20;1;1;1",
      "7", "",
      queries
    )
    val segDetailsSeq = Seq(segDtls)

    // val inputEntity = new ExtractFileEntity("F5938RK4","PRV;ALT;PSP;SCO;PQI;HAS;PLI;PFA;TIN;PTI;TCO;NCE;ADD;PHO;ACT;LGS;LNG;HRS;HCA;ACO;AD1;CON;CDK;CSP;COS;CUL;NPI;COE","F5938DBE",segDetailsSeq)
    val prevRunDate =""
    val outputFilePath ="maprfs:///datalake/uhclake/tst/developer/EPDE/TestFiles/"
    val spark=globalContext.sparkSession
    //val SchemaNm = "F5938DBE"
    import spark.implicits._
    val s=Seq((1233, 176),
      (234, 2323),
      (30000, 29898))
    val df=s.toDF("OUT_PRV_PROV_ID","OUT_PRV_TEL_NBR")
    df.createOrReplaceTempView("PRV_FNL_VIEW")
    val thrownExcep = intercept[Exception] {
      genALTSeg(segDtls,varLst,glblVarLst,outputFilePath)(globalContext)
    }
    assert(thrownExcep.getMessage == "ERROR : Cannot make DF as Query is empty or NULL or does not start with select ALT_FNL_VIEW")

  }


  override def afterAll(): Unit = {
    super.afterAll()
    globalContext.sparkContext.stop()
  }

}

