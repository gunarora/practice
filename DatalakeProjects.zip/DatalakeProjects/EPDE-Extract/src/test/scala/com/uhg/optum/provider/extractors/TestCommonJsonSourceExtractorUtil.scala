package com.uhg.optum.provider.extractors

import com.uhg.optum.JobRunner.{PEI, PEIInstanceEmpty}
import com.uhg.optum.dao.LocalRepositoryManager
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDECommonInputJsonSchema.{ExtractFileEntity, Query, SegmentDetails}
import com.uhg.optum.tests.base.UnitSpec
import org.apache.spark.sql.DataFrame
import com.uhg.optum.util.CommonUtil


import scala.util.{Failure, Success}


class TestCommonJsonSourceExtractorUtil extends UnitSpec with EPDECommonJsonSourceExtractor  {
  var globalContext : GlobalContext = _
  implicit var pei: PEI = _


  override def beforeAll(): Unit = {
    super.beforeAll()

    globalContext = new GlobalContext("EPDE_OPTUM", "local") with LocalRepositoryManager
    import com.uhg.optum.protocols.PEIProtocol._
    globalContext.peTable.get("EPDE_OPTUM", "pei") match {
      case Success(instance) =>
        this.pei = instance
        Success()
      case Failure(ex) =>
        Failure(new PEIInstanceEmpty("Exception while getting the columns info from PEI Table", ex))
    }
  }



  test("Input entity object for Common when null should be failure") {
    val WS_PREV_RUN_DT_YMD = "9999-12-31"
    var inputEntity = mock[ExtractFileEntity]

    val outputFilePath= ""
    val query1 = new Query("FAC","SELECT 'Y' as fac_temp FROM F5938DBE_DATA_VEND_CRIT_DTL WHERE DATA_VEND_CD = '$vendor_cd' AND trim(DATA_VEND_FUNC_CD) = 'E' AND CRIT_ID = 2 AND trim(CRIT_TXT_VAL_1) = 'N' AND trim(ACTV_CD) = 'A' AND trim(CRIT_COND_CD) = 'I'")
    val query2 = new Query("UNIQUE_PROV","SELECT a.* FROM (SELECT *, ROW_NUMBER() OVER (PARTITION BY PROV_OUT_VENDR_CD,PROV_OUT_PROV_ID ORDER BY PROV_OUT_VENDR_CD,PROV_OUT_PROV_ID ASC) AS RNUM  FROM PROV_df) a WHERE a.RNUM=1")
    val queries = Seq(query1,query2)
    val segDtls = new SegmentDetails("PROVIDER",
      "0",
      "PROV_OUT_VENDR_CD;PROV_OUT_PROV_TYP_CD;PROV_OUT_UPDT_TYP_CD;PROV_OUT_PROV_ID;PROV_OUT_VEND_KEY;PROV_PQD_OR_FQD_CNT;PROV_OUT_ORG_TYP_CD",
      "3;9;9;3;9;4;4;1;1;10;10;2;1",
      "400",
      null,
      queries
    )
    val segDetailsSeq =Seq(segDtls)
    inputEntity = new ExtractFileEntity("EPDE_Common","","F5938DBE",segDetailsSeq)

    var peiRowKey = ""
    var inputParqFile = ""
    var vendorCd = "OHPH"
    assert(generateExtractFromJson(null,peiRowKey,inputParqFile,outputFilePath,vendorCd,vendorCd)(globalContext).isFailure)

  }


  test("Segment details for Input entity object if null should be failure") {
    var inputEntity = mock[ExtractFileEntity]

    val outputFilePath= "/epde"
    val query1 = new Query("FAC","SELECT 'Y' as fac_temp FROM F5938DBE_DATA_VEND_CRIT_DTL WHERE DATA_VEND_CD = '$vendor_cd' AND trim(DATA_VEND_FUNC_CD) = 'E' AND CRIT_ID = 2 AND trim(CRIT_TXT_VAL_1) = 'N' AND trim(ACTV_CD) = 'A' AND trim(CRIT_COND_CD) = 'I'")
    val query2 = new Query("UNIQUE_PROV","SELECT a.* FROM (SELECT *, ROW_NUMBER() OVER (PARTITION BY PROV_OUT_VENDR_CD,PROV_OUT_PROV_ID ORDER BY PROV_OUT_VENDR_CD,PROV_OUT_PROV_ID ASC) AS RNUM  FROM PROV_df) a WHERE a.RNUM=1")
    val queries = Seq(query1,query2)
    val segDtls = new SegmentDetails("PROVIDER",
      "0",
      "PROV_OUT_VENDR_CD;PROV_OUT_PROV_TYP_CD;PROV_OUT_UPDT_TYP_CD;PROV_OUT_PROV_ID;PROV_OUT_VEND_KEY;PROV_PQD_OR_FQD_CNT;PROV_OUT_ORG_TYP_CD",
      "3;9;9;3;9;4;4;1;1;10;10;2;1",
      "400",
      null,
      queries
    )
    val segDetailsSeq =Seq(segDtls)
    inputEntity = new ExtractFileEntity("EPDE_Common","","F5938DBE",null)

    var peiRowKey = ""
    var inputParqFile = "abc.parquet"
    var vendorCd = "OHPH"
    assert(generateExtractFromJson(inputEntity,peiRowKey,inputParqFile,outputFilePath,vendorCd,vendorCd)(globalContext).isFailure)

  }



  test("Parquet input file path for Common when empty should be failure") {
    val WS_PREV_RUN_DT_YMD = "9999-12-31"
    var inputEntity = mock[ExtractFileEntity]

    val outputFilePath= ""
    val query1 = new Query("FAC","SELECT 'Y' as fac_temp FROM F5938DBE_DATA_VEND_CRIT_DTL WHERE DATA_VEND_CD = '$vendor_cd' AND trim(DATA_VEND_FUNC_CD) = 'E' AND CRIT_ID = 2 AND trim(CRIT_TXT_VAL_1) = 'N' AND trim(ACTV_CD) = 'A' AND trim(CRIT_COND_CD) = 'I'")
    val query2 = new Query("UNIQUE_PROV","SELECT a.* FROM (SELECT *, ROW_NUMBER() OVER (PARTITION BY PROV_OUT_VENDR_CD,PROV_OUT_PROV_ID ORDER BY PROV_OUT_VENDR_CD,PROV_OUT_PROV_ID ASC) AS RNUM  FROM PROV_df) a WHERE a.RNUM=1")
    val queries = Seq(query1,query2)
    val segDtls = new SegmentDetails("PROVIDER",
      "0",
      "PROV_OUT_VENDR_CD;PROV_OUT_PROV_TYP_CD;PROV_OUT_UPDT_TYP_CD;PROV_OUT_PROV_ID;PROV_OUT_VEND_KEY;PROV_PQD_OR_FQD_CNT;PROV_OUT_ORG_TYP_CD",
      "3;9;9;3;9;4;4;1;1;10;10;2;1",
      "400",
      null,
      queries
    )
    val segDetailsSeq =Seq(segDtls)
    inputEntity = new ExtractFileEntity("EPDE_Common","","F5938DBE",segDetailsSeq)

    var peiRowKey = ""
    var inputParqFile = ""
    var vendorCd = "OHPH"
    assert(generateExtractFromJson(inputEntity,peiRowKey,inputParqFile,outputFilePath,vendorCd,vendorCd)(globalContext).isFailure)

  }

  test("Parquet input file path for Common when null should be failure") {
    val WS_PREV_RUN_DT_YMD = "9999-12-31"
    var inputEntity = mock[ExtractFileEntity]

    val outputFilePath= ""
    val query1 = new Query("FAC","SELECT 'Y' as fac_temp FROM F5938DBE_DATA_VEND_CRIT_DTL WHERE DATA_VEND_CD = '$vendor_cd' AND trim(DATA_VEND_FUNC_CD) = 'E' AND CRIT_ID = 2 AND trim(CRIT_TXT_VAL_1) = 'N' AND trim(ACTV_CD) = 'A' AND trim(CRIT_COND_CD) = 'I'")
    val query2 = new Query("UNIQUE_PROV","SELECT a.* FROM (SELECT *, ROW_NUMBER() OVER (PARTITION BY PROV_OUT_VENDR_CD,PROV_OUT_PROV_ID ORDER BY PROV_OUT_VENDR_CD,PROV_OUT_PROV_ID ASC) AS RNUM  FROM PROV_df) a WHERE a.RNUM=1")
    val queries = Seq(query1,query2)
    val segDtls = new SegmentDetails("PROVIDER",
      "0",
      "PROV_OUT_VENDR_CD;PROV_OUT_PROV_TYP_CD;PROV_OUT_UPDT_TYP_CD;PROV_OUT_PROV_ID;PROV_OUT_VEND_KEY;PROV_PQD_OR_FQD_CNT;PROV_OUT_ORG_TYP_CD",
      "3;9;9;3;9;4;4;1;1;10;10;2;1",
      "400",
      null,
      queries
    )
    val segDetailsSeq =Seq(segDtls)
    inputEntity = new ExtractFileEntity("EPDE_Common","","F5938DBE",segDetailsSeq)

    var peiRowKey = ""
    var inputParqFile = null
    var vendorCd = "OHPH"
    assert(generateExtractFromJson(inputEntity,peiRowKey,inputParqFile,outputFilePath,vendorCd,vendorCd)(globalContext).isFailure)

  }


  test("Vendor code for Common when null should be failure") {
    val WS_PREV_RUN_DT_YMD = "9999-12-31"
    var inputEntity = mock[ExtractFileEntity]

    val outputFilePath= ""
    val query1 = new Query("FAC","SELECT 'Y' as fac_temp FROM F5938DBE_DATA_VEND_CRIT_DTL WHERE DATA_VEND_CD = '$vendor_cd' AND trim(DATA_VEND_FUNC_CD) = 'E' AND CRIT_ID = 2 AND trim(CRIT_TXT_VAL_1) = 'N' AND trim(ACTV_CD) = 'A' AND trim(CRIT_COND_CD) = 'I'")
    val query2 = new Query("UNIQUE_PROV","SELECT a.* FROM (SELECT *, ROW_NUMBER() OVER (PARTITION BY PROV_OUT_VENDR_CD,PROV_OUT_PROV_ID ORDER BY PROV_OUT_VENDR_CD,PROV_OUT_PROV_ID ASC) AS RNUM  FROM PROV_df) a WHERE a.RNUM=1")
    val queries = Seq(query1,query2)
    val segDtls = new SegmentDetails("PROVIDER",
      "0",
      "PROV_OUT_VENDR_CD;PROV_OUT_PROV_TYP_CD;PROV_OUT_UPDT_TYP_CD;PROV_OUT_PROV_ID;PROV_OUT_VEND_KEY;PROV_PQD_OR_FQD_CNT;PROV_OUT_ORG_TYP_CD",
      "3;9;9;3;9;4;4;1;1;10;10;2;1",
      "400",
      null,
      queries
    )
    val segDetailsSeq =Seq(segDtls)
    inputEntity = new ExtractFileEntity("EPDE_Common","","F5938DBE",segDetailsSeq)

    var peiRowKey = ""
    var inputParqFile = "abc.parquet"
    var vendorCd = null
    assert(generateExtractFromJson(inputEntity,peiRowKey,inputParqFile,outputFilePath,vendorCd,vendorCd)(globalContext).isFailure)

  }


  test("Vendor code for Common when empty should be failure") {
    val WS_PREV_RUN_DT_YMD = "9999-12-31"
    var inputEntity = mock[ExtractFileEntity]

    val outputFilePath= ""
    val query1 = new Query("FAC","SELECT 'Y' as fac_temp FROM F5938DBE_DATA_VEND_CRIT_DTL WHERE DATA_VEND_CD = '$vendor_cd' AND trim(DATA_VEND_FUNC_CD) = 'E' AND CRIT_ID = 2 AND trim(CRIT_TXT_VAL_1) = 'N' AND trim(ACTV_CD) = 'A' AND trim(CRIT_COND_CD) = 'I'")
    val query2 = new Query("UNIQUE_PROV","SELECT a.* FROM (SELECT *, ROW_NUMBER() OVER (PARTITION BY PROV_OUT_VENDR_CD,PROV_OUT_PROV_ID ORDER BY PROV_OUT_VENDR_CD,PROV_OUT_PROV_ID ASC) AS RNUM  FROM PROV_df) a WHERE a.RNUM=1")
    val queries = Seq(query1,query2)
    val segDtls = new SegmentDetails("PROVIDER",
      "0",
      "PROV_OUT_VENDR_CD;PROV_OUT_PROV_TYP_CD;PROV_OUT_UPDT_TYP_CD;PROV_OUT_PROV_ID;PROV_OUT_VEND_KEY;PROV_PQD_OR_FQD_CNT;PROV_OUT_ORG_TYP_CD",
      "3;9;9;3;9;4;4;1;1;10;10;2;1",
      "400",
      null,
      queries
    )
    val segDetailsSeq =Seq(segDtls)
    inputEntity = new ExtractFileEntity("EPDE_Common","","F5938DBE",segDetailsSeq)

    var peiRowKey = ""
    var inputParqFile = "abc.parquet"
    var vendorCd = ""
    assert(generateExtractFromJson(inputEntity,peiRowKey,inputParqFile,outputFilePath,vendorCd,vendorCd)(globalContext).isFailure)

  }

  test("generateExtractFromJson method should be success if the Provider DF final view exists") {
    val WS_PREV_RUN_DT_YMD = "9999-12-31"
    var inputEntity = mock[ExtractFileEntity]

    val outputFilePath= ""
    val query1 = new Query("FAC","SELECT 'Y' as fac_temp FROM F5938DBE_DATA_VEND_CRIT_DTL WHERE DATA_VEND_CD = '$vendor_cd' AND trim(DATA_VEND_FUNC_CD) = 'E' AND CRIT_ID = 2 AND trim(CRIT_TXT_VAL_1) = 'N' AND trim(ACTV_CD) = 'A' AND trim(CRIT_COND_CD) = 'I'")
    val query2 = new Query("UNIQUE_PROV","SELECT a.* FROM (SELECT *, ROW_NUMBER() OVER (PARTITION BY PROV_OUT_VENDR_CD,PROV_OUT_PROV_ID ORDER BY PROV_OUT_VENDR_CD,PROV_OUT_PROV_ID ASC) AS RNUM  FROM PROV_df) a WHERE a.RNUM=1")
    val queries = Seq(query1,query2)
    val segDtls = new SegmentDetails("PROVIDER",
      "0",
      "PROV_OUT_VENDR_CD;PROV_OUT_PROV_TYP_CD;PROV_OUT_UPDT_TYP_CD;PROV_OUT_PROV_ID;PROV_OUT_VEND_KEY;PROV_PQD_OR_FQD_CNT;PROV_OUT_ORG_TYP_CD",
      "3;9;9;3;9;4;4;1;1;10;10;2;1",
      "400",
      null,
      queries
    )
    val segDetailsSeq =Seq(segDtls)
    inputEntity = new ExtractFileEntity("EPDE_Common","","F5938DBE",segDetailsSeq)

    var peiRowKey = ""
    var inputParqFile = "abc.parquet"
    var vendorCd = "OHPH"
    assert(generateExtractFromJson(inputEntity,peiRowKey,inputParqFile,outputFilePath,vendorCd,vendorCd)(globalContext).isFailure)

  }

  test("generateExtractFromJson method should be success if the Contract DF final view exists") {
    val WS_PREV_RUN_DT_YMD = "9999-12-31"
    var inputEntity = mock[ExtractFileEntity]

    val outputFilePath= ""
    val query1 = new Query("FAC","SELECT 'Y' as fac_temp FROM F5938DBE_DATA_VEND_CRIT_DTL WHERE DATA_VEND_CD = '$vendor_cd' AND trim(DATA_VEND_FUNC_CD) = 'E' AND CRIT_ID = 2 AND trim(CRIT_TXT_VAL_1) = 'N' AND trim(ACTV_CD) = 'A' AND trim(CRIT_COND_CD) = 'I'")
    val query2 = new Query("UNIQUE_PROV","SELECT a.* FROM (SELECT *, ROW_NUMBER() OVER (PARTITION BY PROV_OUT_VENDR_CD,PROV_OUT_PROV_ID ORDER BY PROV_OUT_VENDR_CD,PROV_OUT_PROV_ID ASC) AS RNUM  FROM PROV_df) a WHERE a.RNUM=1")
    val queries = Seq(query1,query2)
    val segDtls = new SegmentDetails("PROVIDER",
      "0",
      "PROV_OUT_VENDR_CD;PROV_OUT_PROV_TYP_CD;PROV_OUT_UPDT_TYP_CD;PROV_OUT_PROV_ID;PROV_OUT_VEND_KEY;PROV_PQD_OR_FQD_CNT;PROV_OUT_ORG_TYP_CD",
      "3;9;9;3;9;4;4;1;1;10;10;2;1",
      "400",
      null,
      queries
    )
    val segDetailsSeq =Seq(segDtls)
    inputEntity = new ExtractFileEntity("EPDE_Common","","F5938DBE",segDetailsSeq)

    var peiRowKey = ""
    var inputParqFile = "abc.parquet"
    var vendorCd = "OHPH"
    assert(generateExtractFromJson(inputEntity,peiRowKey,inputParqFile,outputFilePath,vendorCd,vendorCd)(globalContext).isFailure)

  }

 test("generateExtractFromJson method return failure if no key matches") {
    val WS_PREV_RUN_DT_YMD = "9999-12-31"
    var inputEntity = mock[ExtractFileEntity]

    val outputFilePath = ""
    val query1 = new Query("FAC1", "SELECT 'Y' as fac_temp FROM F5938DBE_DATA_VEND_CRIT_DTL WHERE DATA_VEND_CD = '$vendor_cd' AND trim(DATA_VEND_FUNC_CD) = 'E' AND CRIT_ID = 2 AND trim(CRIT_TXT_VAL_1) = 'N' AND trim(ACTV_CD) = 'A' AND trim(CRIT_COND_CD) = 'I'")
    val query2 = new Query("UNIQUE_PROV1", "SELECT a.* FROM (SELECT *, ROW_NUMBER() OVER (PARTITION BY PROV_OUT_VENDR_CD,PROV_OUT_PROV_ID ORDER BY PROV_OUT_VENDR_CD,PROV_OUT_PROV_ID ASC) AS RNUM  FROM PROV_df) a WHERE a.RNUM=1")
    val queries = Seq(query1, query2)
    val segDtls = new SegmentDetails("PROVIDER",
      "0",
      "PROV_OUT_VENDR_CD;PROV_OUT_PROV_TYP_CD;PROV_OUT_UPDT_TYP_CD;PROV_OUT_PROV_ID;PROV_OUT_VEND_KEY;PROV_PQD_OR_FQD_CNT;PROV_OUT_ORG_TYP_CD",
      "3;9;9;3;9;4;4;1;1;10;10;2;1",
      "400",
      "ABC",
      queries
    )
    val segDetailsSeq = Seq(segDtls)
    inputEntity = new ExtractFileEntity("EPDE_Common", "", "F5938DBE", segDetailsSeq)

    var peiRowKey = ""
    var inputParqFile = "/datalake/uhclake/tst/t_inbound/uhg/ndb/inbound/VS/Shivani_1/OHPH"
    var vendorCd = "OHPH"
    assert(generateExtractFromJson(inputEntity, peiRowKey, inputParqFile, outputFilePath, vendorCd,vendorCd)(globalContext).isFailure)
  }



  test("createParquetFromMap method should be failure if the df Map is null") {
    var outLoc = "/epde"
    var dfsMap = collection.mutable.Map[String, DataFrame]()
    var df1 = globalContext.sparkSession.emptyDataFrame
    var df2 = globalContext.sparkSession.emptyDataFrame
    dfsMap.put("a.parquet",df1)
    dfsMap.put("b.parquet",df2)
    assert(CommonUtil.createParquetFromMap(dfsMap,outLoc)(globalContext).isFailure)
  }



  test("createParquetFromMap method should be failure if the outLoc is null") {
    var outLoc = null
    var dfsMap = collection.mutable.Map[String, DataFrame]()
    var df1 = globalContext.sparkSession.emptyDataFrame
    var df2 = globalContext.sparkSession.emptyDataFrame
    dfsMap.put("a.parquet",df1)
    dfsMap.put("b.parquet",df2)
    assert(CommonUtil.createParquetFromMap(dfsMap,outLoc)(globalContext).isFailure)
  }


  test("createParquetFromMap method should be failure if the outLoc is empty") {
    var outLoc = ""
    var dfsMap = collection.mutable.Map[String, DataFrame]()
    var df1 = globalContext.sparkSession.emptyDataFrame
    var df2 = globalContext.sparkSession.emptyDataFrame
    dfsMap.put("a.parquet",df1)
    dfsMap.put("b.parquet",df2)
    assert(CommonUtil.createParquetFromMap(dfsMap,outLoc)(globalContext).isFailure)
  }


/*  test("generateExtractFromJson method should be failure if no details for segment PROVIDER is present") {
    var inputEntity = mock[ExtractFileEntity]

    val outputFilePath= "/epde"
    val query1 = new Query("FAC","SELECT 'Y' as fac_temp FROM F5938DBE_DATA_VEND_CRIT_DTL WHERE DATA_VEND_CD = '$vendor_cd' AND trim(DATA_VEND_FUNC_CD) = 'E' AND CRIT_ID = 2 AND trim(CRIT_TXT_VAL_1) = 'N' AND trim(ACTV_CD) = 'A' AND trim(CRIT_COND_CD) = 'I'")
    val query2 = new Query("UNIQUE_PROV","SELECT a.* FROM (SELECT *, ROW_NUMBER() OVER (PARTITION BY PROV_OUT_VENDR_CD,PROV_OUT_PROV_ID ORDER BY PROV_OUT_VENDR_CD,PROV_OUT_PROV_ID ASC) AS RNUM  FROM PROV_df) a WHERE a.RNUM=1")
    val queries = Seq(query1,query2)
    val segDtls = new SegmentDetails("PROV",
      "0",
      "PROV_OUT_VENDR_CD;PROV_OUT_PROV_TYP_CD;PROV_OUT_UPDT_TYP_CD;PROV_OUT_PROV_ID;PROV_OUT_VEND_KEY;PROV_PQD_OR_FQD_CNT;PROV_OUT_ORG_TYP_CD",
      "3;9;9;3;9;4;4;1;1;10;10;2;1",
      "400",
      "",
      queries
    )
    val segDetailsSeq =Seq(segDtls)
    inputEntity = new ExtractFileEntity("EPDE_Common","","F5938DBE",segDetailsSeq)

    var peiRowKey = ""
    var inputParqFile = "/datalake/uhclake/tst/t_inbound/uhg/ndb/inbound/VS/Shivani_1/OHPH"
    var vendorCd = "OHPH"
    assert(generateExtractFromJson(inputEntity,peiRowKey,inputParqFile,outputFilePath,vendorCd)(globalContext).isSuccess)
  }*/

  /*test("generateExtractFromJson method should be failure if no details for segment CONTRACT is present") {
    var inputEntity = mock[ExtractFileEntity]

    val outputFilePath= "/epde"
    val query1 = new Query("FAC","SELECT 'Y' as fac_temp FROM F5938DBE_DATA_VEND_CRIT_DTL WHERE DATA_VEND_CD = '$vendor_cd' AND trim(DATA_VEND_FUNC_CD) = 'E' AND CRIT_ID = 2 AND trim(CRIT_TXT_VAL_1) = 'N' AND trim(ACTV_CD) = 'A' AND trim(CRIT_COND_CD) = 'I'")
    val query2 = new Query("UNIQUE_PROV","SELECT a.* FROM (SELECT *, ROW_NUMBER() OVER (PARTITION BY PROV_OUT_VENDR_CD,PROV_OUT_PROV_ID ORDER BY PROV_OUT_VENDR_CD,PROV_OUT_PROV_ID ASC) AS RNUM  FROM PROV_df) a WHERE a.RNUM=1")
    val queries = Seq(query1,query2)
    val segDtls = new SegmentDetails("CONT",
      "0",
      "PROV_OUT_VENDR_CD;PROV_OUT_PROV_TYP_CD;PROV_OUT_UPDT_TYP_CD;PROV_OUT_PROV_ID;PROV_OUT_VEND_KEY;PROV_PQD_OR_FQD_CNT;PROV_OUT_ORG_TYP_CD",
      "3;9;9;3;9;4;4;1;1;10;10;2;1",
      "400",
      "",
      queries
    )
    val segDetailsSeq =Seq(segDtls)
    inputEntity = new ExtractFileEntity("EPDE_Common","","F5938DBE",segDetailsSeq)

    var peiRowKey = ""
    var inputParqFile = "/datalake/uhclake/tst/t_inbound/uhg/ndb/inbound/VS/Shivani_1/OHPH"
    var vendorCd = "OHPH"
    assert(generateExtractFromJson(inputEntity,peiRowKey,inputParqFile,outputFilePath,vendorCd)(globalContext).isSuccess)
  }
*/
  test("generateExtractFromJson method should be failure if no prov_df is registered") {
    var inputEntity = mock[ExtractFileEntity]

    val outputFilePath= "/epde"
    val query1 = new Query("FAC","SELECT 'Y' as fac_temp FROM F5938DBE_DATA_VEND_CRIT_DTL WHERE DATA_VEND_CD = '$vendor_cd' AND trim(DATA_VEND_FUNC_CD) = 'E' AND CRIT_ID = 2 AND trim(CRIT_TXT_VAL_1) = 'N' AND trim(ACTV_CD) = 'A' AND trim(CRIT_COND_CD) = 'I'")
    val query2 = new Query("UNIQUE_PROV","SELECT a.* FROM (SELECT *, ROW_NUMBER() OVER (PARTITION BY PROV_OUT_VENDR_CD,PROV_OUT_PROV_ID ORDER BY PROV_OUT_VENDR_CD,PROV_OUT_PROV_ID ASC) AS RNUM  FROM PROV_df) a WHERE a.RNUM=1")
    val queries = Seq(query1,query2)
    val segDtls1 = new SegmentDetails("PROV",
      "0",
      "PROV_OUT_VENDR_CD;PROV_OUT_PROV_TYP_CD;PROV_OUT_UPDT_TYP_CD;PROV_OUT_PROV_ID;PROV_OUT_VEND_KEY;PROV_PQD_OR_FQD_CNT;PROV_OUT_ORG_TYP_CD",
      "3;9;9;3;9;4;4;1;1;10;10;2;1",
      "400",
      "ABC",
      queries
    )

    val segDtls2 = new SegmentDetails("CONT",
      "0",
      "PROV_OUT_VENDR_CD;PROV_OUT_PROV_TYP_CD;PROV_OUT_UPDT_TYP_CD;PROV_OUT_PROV_ID;PROV_OUT_VEND_KEY;PROV_PQD_OR_FQD_CNT;PROV_OUT_ORG_TYP_CD",
      "3;9;9;3;9;4;4;1;1;10;10;2;1",
      "400",
      "ABC",
      queries
    )
    val segDetailsSeq =Seq(segDtls1,segDtls2)
    inputEntity = new ExtractFileEntity("EPDE_Common","","F5938DBE",segDetailsSeq)

    var peiRowKey = ""
   // var inputParqFile = "abc.parquet"
    var vendorCd = "OHPH"
    var inputParqFile = "/datalake/uhclake/tst/t_inbound/uhg/ndb/inbound/VS/Shivani_1/OHPH"
    assert(generateExtractFromJson(inputEntity,peiRowKey,inputParqFile,outputFilePath,vendorCd,vendorCd)(globalContext).isFailure)
  }

  /*test("generateExtractFromJson method should be failure if no con_df is registered") {
    var inputEntity = mock[ExtractFileEntity]

    val outputFilePath= "/epde"
    val query1 = new Query("FAC1","SELECT 'Y' as fac_temp FROM F5938DBE_DATA_VEND_CRIT_DTL WHERE DATA_VEND_CD = '$vendor_cd' AND trim(DATA_VEND_FUNC_CD) = 'E' AND CRIT_ID = 2 AND trim(CRIT_TXT_VAL_1) = 'N' AND trim(ACTV_CD) = 'A' AND trim(CRIT_COND_CD) = 'I'")
    val query2 = new Query("UNIQUE_PROV1","SELECT a.* FROM (SELECT *, ROW_NUMBER() OVER (PARTITION BY PROV_OUT_VENDR_CD,PROV_OUT_PROV_ID ORDER BY PROV_OUT_VENDR_CD,PROV_OUT_PROV_ID ASC) AS RNUM  FROM PROV_df) a WHERE a.RNUM=1")
    val query3 = new Query("PHYSICIAN1","SELECT PROV_OUT_VENDR_CD,PROV_OUT_PROV_TYP_CD,PROV_OUT_UPDT_TYP_CD,PROV_OUT_PROV_ID,PROV_OUT_VEND_KEY,PROV_PQD_OR_FQD_CNT,PROV_OUT_ORG_TYP_CD FROM UNIQUE_PROV WHERE PROV_OUT_PROV_TYP_CD != 'O'")
    val query4 = new Query("GROUP1","SELECT PROV_OUT_VENDR_CD,PROV_OUT_PROV_TYP_CD,PROV_OUT_UPDT_TYP_CD,PROV_OUT_PROV_ID,PROV_OUT_VEND_KEY,PROV_PQD_OR_FQD_CNT,PROV_OUT_ORG_TYP_CD FROM UNIQUE_PROV WHERE PROV_OUT_PROV_TYP_CD = 'O' AND (PROV_OUT_ORG_TYP_CD = '033' OR PROV_OUT_ORG_TYP_CD = '050')")
    val query5 = new Query("FACILITY1","SELECT PROV_OUT_VENDR_CD,PROV_OUT_PROV_TYP_CD,PROV_OUT_UPDT_TYP_CD,PROV_OUT_PROV_ID,PROV_OUT_VEND_KEY,PROV_PQD_OR_FQD_CNT,PROV_OUT_ORG_TYP_CD FROM UNIQUE_PROV WHERE PROV_OUT_PROV_TYP_CD = 'O' AND PROV_OUT_ORG_TYP_CD != '033' AND PROV_OUT_ORG_TYP_CD != '050'")
    val queries1 = Seq(query1,query2,query3,query4,query5)
    val segDtl1 = new SegmentDetails("PROVIDER",
      "0",
      "PROV_OUT_VENDR_CD;PROV_OUT_PROV_TYP_CD;PROV_OUT_UPDT_TYP_CD;PROV_OUT_PROV_ID;PROV_OUT_VEND_KEY;PROV_PQD_OR_FQD_CNT;PROV_OUT_ORG_TYP_CD",
      "3;9;9;3;9;4;4;1;1;10;10;2;1",
      "400",
      "",
      queries1
    )
    val query6 = new Query("UNIQUE_CON1","SELECT CON.* FROM (SELECT *, ROW_NUMBER() OVER (PARTITION BY CONTR_OUT_VENDR_CD, CONTR_OUT_PROV_ID, CONTR_OUT_TAX_ID_NBR, CONTR_OUT_CONTR_ID ORDER BY CONTR_OUT_VENDR_CD, CONTR_OUT_PROV_ID, CONTR_OUT_TAX_ID_NBR, CONTR_OUT_CONTR_ID ASC) AS RNUM  FROM CON_df) con WHERE con.RNUM=1")
    val query7 = new Query("PHYSICIAN1","SELECT CONTR_OUT_VENDR_CD,CONTR_OUT_PROV_TYP_CD,CONTR_OUT_PROV_ID,CONTR_OUT_CONTR_ID,CONTR_OUT_TAX_ID_NBR,CONTR_OUT_ORG_TYP_CD FROM UNIQUE_CON WHERE CONTR_OUT_PROV_TYP_CD != 'O'")
    val query8 = new Query("GROUP1","SELECT CONTR_OUT_VENDR_CD,CONTR_OUT_PROV_TYP_CD,CONTR_OUT_PROV_ID,CONTR_OUT_CONTR_ID,CONTR_OUT_TAX_ID_NBR,CONTR_OUT_ORG_TYP_CD FROM UNIQUE_CON WHERE CONTR_OUT_PROV_TYP_CD = 'O' AND (CONTR_OUT_ORG_TYP_CD = '033' OR CONTR_OUT_ORG_TYP_CD = '050')")
    val query9 = new Query("FACILITY1","SELECT CONTR_OUT_VENDR_CD,CONTR_OUT_PROV_TYP_CD,CONTR_OUT_PROV_ID,CONTR_OUT_CONTR_ID,CONTR_OUT_TAX_ID_NBR,CONTR_OUT_ORG_TYP_CD FROM UNIQUE_CON WHERE CONTR_OUT_PROV_TYP_CD = 'O' AND (CONTR_OUT_ORG_TYP_CD != '033' AND CONTR_OUT_ORG_TYP_CD != '050')")
    val queries2 = Seq(query6,query7,query8,query9)
    val segDt2 = new SegmentDetails("CONTRACT",
      "0",
      "PROV_OUT_VENDR_CD;PROV_OUT_PROV_TYP_CD;PROV_OUT_UPDT_TYP_CD;PROV_OUT_PROV_ID;PROV_OUT_VEND_KEY;PROV_PQD_OR_FQD_CNT;PROV_OUT_ORG_TYP_CD",
      "3;9;9;3;9;4;4;1;1;10;10;2;1",
      "400",
      "",
      queries2
    )

    val segDetailsSeq =Seq(segDtl1,segDt2)
    inputEntity = new ExtractFileEntity("EPDE_Common","","F5938DBE",segDetailsSeq)

    var peiRowKey = ""
    // var inputParqFile = "abc.parquet"
    var vendorCd = "OHPH"
    var inputParqFile = "/datalake/uhclake/tst/t_inbound/uhg/ndb/inbound/VS/Shivani_1/OHPH"
    assert(generateExtractFromJson(inputEntity,peiRowKey,inputParqFile,outputFilePath,vendorCd)(globalContext).isSuccess)
  }*/

/*  test("generateExtractFromJson method should return N if no key matches for Provider") {
    var inputEntity = mock[ExtractFileEntity]

    val outputFilePath= "/epde"
    val query1 = new Query("FAC111","SELECT 'Y' as fac_temp FROM F5938DBE_DATA_VEND_CRIT_DTL WHERE DATA_VEND_CD = '$vendor_cd' AND trim(DATA_VEND_FUNC_CD) = 'E' AND CRIT_ID = 2 AND trim(CRIT_TXT_VAL_1) = 'N' AND trim(ACTV_CD) = 'A' AND trim(CRIT_COND_CD) = 'I'")
    val query2 = new Query("UNIQUE_PROV111","SELECT a.* FROM (SELECT *, ROW_NUMBER() OVER (PARTITION BY PROV_OUT_VENDR_CD,PROV_OUT_PROV_ID ORDER BY PROV_OUT_VENDR_CD,PROV_OUT_PROV_ID ASC) AS RNUM  FROM PROV_df) a WHERE a.RNUM=1")
    val queries = Seq(query1,query2)
    val segDtls = new SegmentDetails("PROVIDER",
      "0",
      "PROV_OUT_VENDR_CD;PROV_OUT_PROV_TYP_CD;PROV_OUT_UPDT_TYP_CD;PROV_OUT_PROV_ID;PROV_OUT_VEND_KEY;PROV_PQD_OR_FQD_CNT;PROV_OUT_ORG_TYP_CD",
      "3;9;9;3;9;4;4;1;1;10;10;2;1",
      "400",
      "",
      queries
    )
    val segDetailsSeq =Seq(segDtls)
    inputEntity = new ExtractFileEntity("EPDE_Common","","F5938DBE",segDetailsSeq)

    var peiRowKey = ""
    // var inputParqFile = "abc.parquet"
    var vendorCd = "OHPH"
    var inputParqFile = "/datalake/uhclake/tst/t_inbound/uhg/ndb/inbound/VS/Shivani_1/OHPH"
    assert(generateExtractFromJson(inputEntity,peiRowKey,inputParqFile,outputFilePath,vendorCd)(globalContext).get.equals("N"))
  }*/

/*
  test("generateExtractFromJson method should return N if no key matches for contract") {
    var inputEntity = mock[ExtractFileEntity]

    val outputFilePath= "/epde"
    val query1 = new Query("FAC111","SELECT 'Y' as fac_temp FROM F5938DBE_DATA_VEND_CRIT_DTL WHERE DATA_VEND_CD = '$vendor_cd' AND trim(DATA_VEND_FUNC_CD) = 'E' AND CRIT_ID = 2 AND trim(CRIT_TXT_VAL_1) = 'N' AND trim(ACTV_CD) = 'A' AND trim(CRIT_COND_CD) = 'I'")
    val query2 = new Query("UNIQUE_PROV111","SELECT a.* FROM (SELECT *, ROW_NUMBER() OVER (PARTITION BY PROV_OUT_VENDR_CD,PROV_OUT_PROV_ID ORDER BY PROV_OUT_VENDR_CD,PROV_OUT_PROV_ID ASC) AS RNUM  FROM PROV_df) a WHERE a.RNUM=1")
    val queries = Seq(query1,query2)
    val segDtl1 = new SegmentDetails("PROVIDER",
      "0",
      "PROV_OUT_VENDR_CD;PROV_OUT_PROV_TYP_CD;PROV_OUT_UPDT_TYP_CD;PROV_OUT_PROV_ID;PROV_OUT_VEND_KEY;PROV_PQD_OR_FQD_CNT;PROV_OUT_ORG_TYP_CD",
      "3;9;9;3;9;4;4;1;1;10;10;2;1",
      "400",
      "",
      queries
    )

    val segDt2 = new SegmentDetails("CONTRACT",
      "0",
      "PROV_OUT_VENDR_CD;PROV_OUT_PROV_TYP_CD;PROV_OUT_UPDT_TYP_CD;PROV_OUT_PROV_ID;PROV_OUT_VEND_KEY;PROV_PQD_OR_FQD_CNT;PROV_OUT_ORG_TYP_CD",
      "3;9;9;3;9;4;4;1;1;10;10;2;1",
      "400",
      "",
      queries
    )

    val segDetailsSeq =Seq(segDtl1,segDt2)
    inputEntity = new ExtractFileEntity("EPDE_Common","","F5938DBE",segDetailsSeq)

    var peiRowKey = ""
    // var inputParqFile = "abc.parquet"
    var vendorCd = "OHPH"
    var inputParqFile = "/datalake/uhclake/tst/t_inbound/uhg/ndb/inbound/VS/Shivani_1/OHPH"
    assert(generateExtractFromJson(inputEntity,peiRowKey,inputParqFile,outputFilePath,vendorCd)(globalContext).get.equals("N"))
  }
*/



/*
  test("generateExtractFromJson method should return N if no keys matches for contract and provider") {
    var inputEntity = mock[ExtractFileEntity]

    val outputFilePath= "/epde"
    val query1 = new Query("FAC1","SELECT 'Y' as fac_temp FROM F5938DBE_DATA_VEND_CRIT_DTL WHERE DATA_VEND_CD = '$vendor_cd' AND trim(DATA_VEND_FUNC_CD) = 'E' AND CRIT_ID = 2 AND trim(CRIT_TXT_VAL_1) = 'N' AND trim(ACTV_CD) = 'A' AND trim(CRIT_COND_CD) = 'I'")
    val query2 = new Query("UNIQUE_PROV1","SELECT a.* FROM (SELECT *, ROW_NUMBER() OVER (PARTITION BY PROV_OUT_VENDR_CD,PROV_OUT_PROV_ID ORDER BY PROV_OUT_VENDR_CD,PROV_OUT_PROV_ID ASC) AS RNUM  FROM PROV_df) a WHERE a.RNUM=1")
    val query3 = new Query("PHYSICIAN1","SELECT PROV_OUT_VENDR_CD,PROV_OUT_PROV_TYP_CD,PROV_OUT_UPDT_TYP_CD,PROV_OUT_PROV_ID,PROV_OUT_VEND_KEY,PROV_PQD_OR_FQD_CNT,PROV_OUT_ORG_TYP_CD FROM UNIQUE_PROV WHERE PROV_OUT_PROV_TYP_CD != 'O'")
    val query4 = new Query("GROUP1","SELECT PROV_OUT_VENDR_CD,PROV_OUT_PROV_TYP_CD,PROV_OUT_UPDT_TYP_CD,PROV_OUT_PROV_ID,PROV_OUT_VEND_KEY,PROV_PQD_OR_FQD_CNT,PROV_OUT_ORG_TYP_CD FROM UNIQUE_PROV WHERE PROV_OUT_PROV_TYP_CD = 'O' AND (PROV_OUT_ORG_TYP_CD = '033' OR PROV_OUT_ORG_TYP_CD = '050')")
    val query5 = new Query("FACILITY1","SELECT PROV_OUT_VENDR_CD,PROV_OUT_PROV_TYP_CD,PROV_OUT_UPDT_TYP_CD,PROV_OUT_PROV_ID,PROV_OUT_VEND_KEY,PROV_PQD_OR_FQD_CNT,PROV_OUT_ORG_TYP_CD FROM UNIQUE_PROV WHERE PROV_OUT_PROV_TYP_CD = 'O' AND PROV_OUT_ORG_TYP_CD != '033' AND PROV_OUT_ORG_TYP_CD != '050'")
    val queries1 = Seq(query1,query2,query3,query4,query5)
    val segDtl1 = new SegmentDetails("PROVIDER",
      "0",
      "PROV_OUT_VENDR_CD;PROV_OUT_PROV_TYP_CD;PROV_OUT_UPDT_TYP_CD;PROV_OUT_PROV_ID;PROV_OUT_VEND_KEY;PROV_PQD_OR_FQD_CNT;PROV_OUT_ORG_TYP_CD",
      "3;9;9;3;9;4;4;1;1;10;10;2;1",
      "400",
      "",
      queries1
    )
    val query6 = new Query("UNIQUE_CON1","SELECT CON.* FROM (SELECT *, ROW_NUMBER() OVER (PARTITION BY CONTR_OUT_VENDR_CD, CONTR_OUT_PROV_ID, CONTR_OUT_TAX_ID_NBR, CONTR_OUT_CONTR_ID ORDER BY CONTR_OUT_VENDR_CD, CONTR_OUT_PROV_ID, CONTR_OUT_TAX_ID_NBR, CONTR_OUT_CONTR_ID ASC) AS RNUM  FROM CON_df) con WHERE con.RNUM=1")
    val query7 = new Query("PHYSICIAN1","SELECT CONTR_OUT_VENDR_CD,CONTR_OUT_PROV_TYP_CD,CONTR_OUT_PROV_ID,CONTR_OUT_CONTR_ID,CONTR_OUT_TAX_ID_NBR,CONTR_OUT_ORG_TYP_CD FROM UNIQUE_CON WHERE CONTR_OUT_PROV_TYP_CD != 'O'")
    val query8 = new Query("GROUP1","SELECT CONTR_OUT_VENDR_CD,CONTR_OUT_PROV_TYP_CD,CONTR_OUT_PROV_ID,CONTR_OUT_CONTR_ID,CONTR_OUT_TAX_ID_NBR,CONTR_OUT_ORG_TYP_CD FROM UNIQUE_CON WHERE CONTR_OUT_PROV_TYP_CD = 'O' AND (CONTR_OUT_ORG_TYP_CD = '033' OR CONTR_OUT_ORG_TYP_CD = '050')")
    val query9 = new Query("FACILITY1","SELECT CONTR_OUT_VENDR_CD,CONTR_OUT_PROV_TYP_CD,CONTR_OUT_PROV_ID,CONTR_OUT_CONTR_ID,CONTR_OUT_TAX_ID_NBR,CONTR_OUT_ORG_TYP_CD FROM UNIQUE_CON WHERE CONTR_OUT_PROV_TYP_CD = 'O' AND (CONTR_OUT_ORG_TYP_CD != '033' AND CONTR_OUT_ORG_TYP_CD != '050')")
    val queries2 = Seq(query6,query7,query8,query9)
    val segDt2 = new SegmentDetails("CONTRACT",
      "0",
      "PROV_OUT_VENDR_CD;PROV_OUT_PROV_TYP_CD;PROV_OUT_UPDT_TYP_CD;PROV_OUT_PROV_ID;PROV_OUT_VEND_KEY;PROV_PQD_OR_FQD_CNT;PROV_OUT_ORG_TYP_CD",
      "3;9;9;3;9;4;4;1;1;10;10;2;1",
      "400",
      "",
      queries2
    )

    val segDetailsSeq =Seq(segDtl1,segDt2)
    inputEntity = new ExtractFileEntity("EPDE_Common","","F5938DBE",segDetailsSeq)

    var peiRowKey = ""
    // var inputParqFile = "abc.parquet"
    var vendorCd = "OHPH"
    var inputParqFile = "/datalake/uhclake/tst/t_inbound/uhg/ndb/inbound/VS/Shivani_1/OHPH"
    assert(generateExtractFromJson(inputEntity,peiRowKey,inputParqFile,outputFilePath,vendorCd)(globalContext).get.equals("N"))
  }


*/






  override def afterAll(): Unit = {
    super.afterAll()
    globalContext.sparkContext.stop()
  }

}




