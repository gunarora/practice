package com.uhg.optum.provider.extractors

import com.uhg.optum.JobRunner.{PEI, PEIInstanceEmpty}
import com.uhg.optum.dao.{HbaseRepositoryManager, LocalRepositoryManager}
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDERK4InputJsonSchema.{ExtractFileEntity, Queries, Query, SegmentDetails}
import com.uhg.optum.provider.validators.PreExtractValidator
import com.uhg.optum.util.{CommonUtil, EPDECommonUtil, Logger}
import com.uhg.optum.tests.base.UnitSpec
import org.apache.spark.sql.{DataFrame, Row, SQLContext}
import org.mockito.Mockito.when
import com.uhg.optum.provider.extractors.EPDERK4JsonSourceExtractor

import scala.util.{Failure, Success}
import com.uhg.optum.EPDERK4JobRunner



class TestSCOSegmentUtil extends UnitSpec with EPDERK4JsonSourceExtractor {
  var globalContext : GlobalContext = _
  implicit var pei: PEI = _
  var glblVarLst  = collection.mutable.Map[String, String]()

  override def beforeAll(): Unit = {
    super.beforeAll()

    globalContext = new GlobalContext("EPDE_OPTUM","local") with LocalRepositoryManager
    import com.uhg.optum.protocols.PEIProtocol._
    globalContext.peTable.get("EPDE_OPTUM", "pei") match {
      case Success(instance) =>
        this.pei = instance
        Success()
      case Failure(ex) =>
        Failure(new PEIInstanceEmpty("Exception while getting the columns info from PEI Table", ex))
    }

    val WS_CANC_DT_1="01/01/0001"  // used in PSP ; genrated in
    val WS_CANC_DT_2="12/31/9999"  // used in PSP ; genrated in
    val WS_UPDT_DT_1= "03/01/2019"  // used in PSP
    val WS_UPDT_DT_2="12/31/9999"   // used in PSP
    val WS_ACTV_CD_1="A"  // used in ADD
    val WS_ACTV_CD_2="I"   // used in ADD
    CommonUtil.add2Map(glblVarLst,"${WS_CANC_DT_1}",WS_CANC_DT_1)
    CommonUtil.add2Map(glblVarLst,"${WS_CANC_DT_2}",WS_CANC_DT_2)
    CommonUtil.add2Map(glblVarLst,"${WS_UPDT_DT_1}",WS_UPDT_DT_1)
    CommonUtil.add2Map(glblVarLst,"${WS_UPDT_DT_2}",WS_UPDT_DT_2)

    CommonUtil.add2Map(glblVarLst,"${WS_ACTV_CD_1}",WS_ACTV_CD_1)
    CommonUtil.add2Map(glblVarLst,"${WS_ACTV_CD_2}",WS_ACTV_CD_2)

  }


  test("SegDtls Object for SCO Segment should be not null") {
    val SW_SKIP_SCO = "N"
    val SchemaNm = "F5938DBE"
    val inputEntity = mock[ExtractFileEntity]
    val query = new Query("SCO_PROV_AFFIL","SELECT 'SCO' AS OUT_SCO_REC_TYP_CD, PSO.PROV_ID AS OUT_SCO_PROV_ID,PSO.CONTR_ORG_CD AS OUT_SCO_CONT_ORG,PSO.PRI_CD AS OUT_SCO_PRI_SEC_CD,PSO.SPCL_TYP_CD AS OUT_SCO_CODE, ,SPT.SPCL_TYP_SHRT_DESC  AS OUT_SCO_CODE_DESC,PSO.CRED_VERF_ORG_IND AS OUT_SCO_BOARD,PSO.PRAC_SPCL_IND AS OUT_SCO_PRACT_IND ,PSO.SPCL_SRC_CD AS OUT_SCO_VER_SOURCE ,PSO.SPCL_BD_CERT_CD  AS OUT_SCO_BC,PSO.SPCL_BD_CERT_DT AS OUT_SCO_CERT_DATE,PSO.RCERT_EFF_DT AS OUT_SCO_RE_CERT_DATE ,PSO.SPCL_BD_EXPIR_DT AS OUT_SCO_EXP_DATE,PSO.SPCL_BD_EXAM_DT AS OUT_SCO_BOARD_DATE,PSO.EFF_DT  AS OUT_SCO_EFF_DATE ,PSO.CANC_DT AS OUT_SCO_CAN_DATE ,PSO.RES_IND AS OUT_SCO_RESIDENT ,PSO.PCP_SPCL_OVRD_IND AS OUT_SCO_PCP_OVR, PSO.LST_UPDT_DT AS PSO_LST_UPDT_DT from ${SchemaNm}_PROV_SPCL_CONTR_ORG PSO,${SchemaNm}_SPCL_TYP  SPT ,${SchemaNm}_SPCL_TYP_CATGY STC ,${SchemaNm}_PROV_SPCL  PSP WHERE  PSO.PROV_ID  = ${WS_SQL_PROV_ID}  AND  PSO.SPCL_TYP_CD = ${WS_PSO_SPCL_TYP_CD} AND  PSO.PROV_ID =  PSP.PROV_ID AND  PSO.SPCL_TYP_CD   =  SPT.SPCL_TYP_CD AND  SPT.SPCL_TYP_CD  =  STC.SPCL_TYP_CD ANDSTC.SPCL_TYP_CD = PSP.SPCL_TYP_CD AND  PSO.CONTR_ORG_CD  <> 'UHN'",null,null)
    val queries = Seq(query)
    var segDtls = new SegmentDetails("SCO",
      "4",
      "OUT_SCO_REC_TYP_CD;OUT_SCO_PROV_ID;OUT_SCO_CONT_ORG;OUT_SCO_PRI_SEC_CD;OUT_SCO_CODE;OUT_SCO_CODE_DESC;OUT_SCO_CATGY;OUT_SCO_BOARD;OUT_SCO_PRACT_IND;OUT_SCO_VER_SOURCE;OUT_SCO_BC;OUT_SCO_CERT_DATE;OUT_SCO_RE_CERT_DATE;OUT_SCO_EXP_DATE;OUT_SCO_BOARD_DATE;OUT_SCO_EFF_DATE;OUT_SCO_CAN_DATE;OUT_SCO_RESIDENT;OUT_SCO_PCP_OVR;OUT_SCO_CHG_IND",
      "3;9;4;1;3;25;4;9;1;3;1;10;10;10;10;10;10;1;1;1",
      "7","",
      queries
    )
    segDtls=null

    val segDetailsSeq =Seq(segDtls)
    when(inputEntity.segmentDetails).thenReturn(segDetailsSeq)
    var outputFilePath = ""
    /*    inputEntity.segmentDetails.map{
          s => s.segQueries.map{
            m => var key = m.name
              println("key:: " + key)
              var value = m.query
              println("value:: " +value)
          }
        }*/

    assertThrows[NullPointerException]
      {
        genSCOSeg(segDtls,glblVarLst,SW_SKIP_SCO,outputFilePath)(globalContext)
      }
    //assert(caught.getMessage.indexOf("-1"))
    //assert(genSCOSeg(segDtls,glblVarLst,SW_SKIP_SCO,outputFilePath)(globalContext).isFailure)

  }
  test("genSCOSeg method should be failure if the PSP final view doesnt exist") {
    val SW_SKIP_SCO = "N"
    val SchemaNm = "F5938DBE"
    val inputEntity = mock[ExtractFileEntity]
    //val query = new Query("SCO_PROV_AFFIL","SELECT 'SCO' AS OUT_SCO_REC_TYP_CD, PSO.PROV_ID AS OUT_SCO_PROV_ID,PSO.CONTR_ORG_CD AS OUT_SCO_CONT_ORG,PSO.PRI_CD AS OUT_SCO_PRI_SEC_CD,PSO.SPCL_TYP_CD AS OUT_SCO_CODE, ,SPT.SPCL_TYP_SHRT_DESC  AS OUT_SCO_CODE_DESC,PSO.CRED_VERF_ORG_IND AS OUT_SCO_BOARD,PSO.PRAC_SPCL_IND AS OUT_SCO_PRACT_IND ,PSO.SPCL_SRC_CD AS OUT_SCO_VER_SOURCE ,PSO.SPCL_BD_CERT_CD  AS OUT_SCO_BC,PSO.SPCL_BD_CERT_DT AS OUT_SCO_CERT_DATE,PSO.RCERT_EFF_DT AS OUT_SCO_RE_CERT_DATE ,PSO.SPCL_BD_EXPIR_DT AS OUT_SCO_EXP_DATE,PSO.SPCL_BD_EXAM_DT AS OUT_SCO_BOARD_DATE,PSO.EFF_DT  AS OUT_SCO_EFF_DATE ,PSO.CANC_DT AS OUT_SCO_CAN_DATE ,PSO.RES_IND AS OUT_SCO_RESIDENT ,PSO.PCP_SPCL_OVRD_IND AS OUT_SCO_PCP_OVR, PSO.LST_UPDT_DT AS PSO_LST_UPDT_DT from ${SchemaNm}_PROV_SPCL_CONTR_ORG PSO,${SchemaNm}_SPCL_TYP  SPT ,${SchemaNm}_SPCL_TYP_CATGY STC ,${SchemaNm}_PROV_SPCL  PSP WHERE  PSO.PROV_ID  = ${WS_SQL_PROV_ID}  AND  PSO.SPCL_TYP_CD = ${WS_PSO_SPCL_TYP_CD} AND  PSO.PROV_ID =  PSP.PROV_ID AND  PSO.SPCL_TYP_CD   =  SPT.SPCL_TYP_CD AND  SPT.SPCL_TYP_CD  =  STC.SPCL_TYP_CD ANDSTC.SPCL_TYP_CD = PSP.SPCL_TYP_CD AND  PSO.CONTR_ORG_CD  <> 'UHN'",null,null)
    val query = new Query("SCO_FNL_VIEW","SELECT * FROM PSP_FINAL_VIEW",null,null)
    val queries = Seq(query)
    val segDtls = new SegmentDetails("SCO",
      "4",
      "OUT_SCO_REC_TYP_CD;OUT_SCO_PROV_ID;OUT_SCO_CONT_ORG;OUT_SCO_PRI_SEC_CD;OUT_SCO_CODE;OUT_SCO_CODE_DESC;OUT_SCO_CATGY;OUT_SCO_BOARD;OUT_SCO_PRACT_IND;OUT_SCO_VER_SOURCE;OUT_SCO_BC;OUT_SCO_CERT_DATE;OUT_SCO_RE_CERT_DATE;OUT_SCO_EXP_DATE;OUT_SCO_BOARD_DATE;OUT_SCO_EFF_DATE;OUT_SCO_CAN_DATE;OUT_SCO_RESIDENT;OUT_SCO_PCP_OVR;OUT_SCO_CHG_IND",
      "3;9;4;1;3;25;4;9;1;3;1;10;10;10;10;10;10;1;1;1",
      "7","",
      queries
    )
    val segDetailsSeq =Seq(segDtls)
    // val inputEntity = new ExtractFileEntity("F5938RK4","PRV;ALT;PSP;SCO;PQI;HAS;PLI;PFA;TIN;PTI;TCO;NCE;ADD;PHO;ACT;LGS;LNG;HRS;HCA;ACO;AD1;CON;CDK;CSP;COS;CUL;NPI;COE","F5938DBE",segDetailsSeq)
    val prevRunDate =""
    val outputFilePath ="maprfs:///datalake/uhclake/tst/developer/EPDE/TestFiles/"
    val spark=globalContext.sparkSession
    //val SchemaNm = "F5938DBE"
    import spark.implicits._
    val s=Seq((1233, 176),
      (234, 2323),
      (30000, 29898))
    val df=s.toDF("OUT_PHO_PROV_ID","OUT_PHO_TEL_NBR")
    df.createOrReplaceTempView("PSP_FINAL_VIEW1")
    println("======================="+spark.catalog.tableExists("PSP_FINAL_VIEW1")+"========")

    /*  val thrownExcep = intercept[Exception] {
        acoSegGen(inputEntity,SW_SKIP_ACO, WS_PREV_RUN_DT_YMD, outputFilePath)(globalContext)
      }*/
    assertThrows[org.apache.spark.sql.AnalysisException]
      {
        assert(genSCOSeg(segDtls,glblVarLst,SW_SKIP_SCO, outputFilePath)(globalContext).isFailure)
      }

  }

  test("genSCOSeg method should be success if the PSP final view  exist") {
    val SW_SKIP_SCO = "N"
    val SchemaNm = "F5938DBE"
    val inputEntity = mock[ExtractFileEntity]
    //val query = new Query("SCO_PROV_AFFIL","SELECT 'SCO' AS OUT_SCO_REC_TYP_CD, PSO.PROV_ID AS OUT_SCO_PROV_ID,PSO.CONTR_ORG_CD AS OUT_SCO_CONT_ORG,PSO.PRI_CD AS OUT_SCO_PRI_SEC_CD,PSO.SPCL_TYP_CD AS OUT_SCO_CODE, ,SPT.SPCL_TYP_SHRT_DESC  AS OUT_SCO_CODE_DESC,PSO.CRED_VERF_ORG_IND AS OUT_SCO_BOARD,PSO.PRAC_SPCL_IND AS OUT_SCO_PRACT_IND ,PSO.SPCL_SRC_CD AS OUT_SCO_VER_SOURCE ,PSO.SPCL_BD_CERT_CD  AS OUT_SCO_BC,PSO.SPCL_BD_CERT_DT AS OUT_SCO_CERT_DATE,PSO.RCERT_EFF_DT AS OUT_SCO_RE_CERT_DATE ,PSO.SPCL_BD_EXPIR_DT AS OUT_SCO_EXP_DATE,PSO.SPCL_BD_EXAM_DT AS OUT_SCO_BOARD_DATE,PSO.EFF_DT  AS OUT_SCO_EFF_DATE ,PSO.CANC_DT AS OUT_SCO_CAN_DATE ,PSO.RES_IND AS OUT_SCO_RESIDENT ,PSO.PCP_SPCL_OVRD_IND AS OUT_SCO_PCP_OVR, PSO.LST_UPDT_DT AS PSO_LST_UPDT_DT from ${SchemaNm}_PROV_SPCL_CONTR_ORG PSO,${SchemaNm}_SPCL_TYP  SPT ,${SchemaNm}_SPCL_TYP_CATGY STC ,${SchemaNm}_PROV_SPCL  PSP WHERE  PSO.PROV_ID  = ${WS_SQL_PROV_ID}  AND  PSO.SPCL_TYP_CD = ${WS_PSO_SPCL_TYP_CD} AND  PSO.PROV_ID =  PSP.PROV_ID AND  PSO.SPCL_TYP_CD   =  SPT.SPCL_TYP_CD AND  SPT.SPCL_TYP_CD  =  STC.SPCL_TYP_CD ANDSTC.SPCL_TYP_CD = PSP.SPCL_TYP_CD AND  PSO.CONTR_ORG_CD  <> 'UHN'",null,null)
    val query = new Query("SCO_FNL_VIE","SELECT * FROM PSP_FINAL_VIEW",null,null)
    val queries = Seq(query)
    val segDtls = new SegmentDetails("SCO",
      "4",
      "OUT_SCO_REC_TYP_CD;OUT_SCO_PROV_ID;OUT_SCO_CONT_ORG;OUT_SCO_PRI_SEC_CD;OUT_SCO_CODE;OUT_SCO_CODE_DESC;OUT_SCO_CATGY;OUT_SCO_BOARD;OUT_SCO_PRACT_IND;OUT_SCO_VER_SOURCE;OUT_SCO_BC;OUT_SCO_CERT_DATE;OUT_SCO_RE_CERT_DATE;OUT_SCO_EXP_DATE;OUT_SCO_BOARD_DATE;OUT_SCO_EFF_DATE;OUT_SCO_CAN_DATE;OUT_SCO_RESIDENT;OUT_SCO_PCP_OVR;OUT_SCO_CHG_IND",
      "3;9;4;1;3;25;4;9;1;3;1;10;10;10;10;10;10;1;1;1",
      "7","",
      queries
    )
    val segDetailsSeq =Seq(segDtls)
    // val inputEntity = new ExtractFileEntity("F5938RK4","PRV;ALT;PSP;SCO;PQI;HAS;PLI;PFA;TIN;PTI;TCO;NCE;ADD;PHO;ACT;LGS;LNG;HRS;HCA;ACO;AD1;CON;CDK;CSP;COS;CUL;NPI;COE","F5938DBE",segDetailsSeq)
    val prevRunDate =""
    val outputFilePath ="maprfs:///datalake/uhclake/tst/developer/EPDE/TestFiles/"
    val spark=globalContext.sparkSession
    //val SchemaNm = "F5938DBE"
    import spark.implicits._
    val s=Seq((1233, 176),
      (234, 2323),
      (30000, 29898))
    val df=s.toDF("OUT_PHO_PROV_ID","OUT_PHO_TEL_NBR")
    df.createOrReplaceTempView("PSP_FINAL_VIEW")
    println("======================="+spark.catalog.tableExists("PSP_FINAL_VIEW")+"========")

    /*  val thrownExcep = intercept[Exception] {
        acoSegGen(inputEntity,SW_SKIP_ACO, WS_PREV_RUN_DT_YMD, outputFilePath)(globalContext)
      }*/
    assert(genSCOSeg(segDtls,glblVarLst,SW_SKIP_SCO, outputFilePath)(globalContext).isSuccess)
  }
  /*
    test("genSCOSeg method should be  success if the PSP final view exists") {
      val SW_SKIP_SCO = "N"
      val SchemaNm = "F5938DBE"
      val inputEntity = mock[ExtractFileEntity]
      val query = new Query("SCO_PROV_AFFIL","SELECT 'SCO' AS OUT_SCO_REC_TYP_CD, PSO.PROV_ID AS OUT_SCO_PROV_ID,PSO.CONTR_ORG_CD AS OUT_SCO_CONT_ORG,PSO.PRI_CD AS OUT_SCO_PRI_SEC_CD,PSO.SPCL_TYP_CD AS OUT_SCO_CODE, ,SPT.SPCL_TYP_SHRT_DESC  AS OUT_SCO_CODE_DESC,PSO.CRED_VERF_ORG_IND AS OUT_SCO_BOARD,PSO.PRAC_SPCL_IND AS OUT_SCO_PRACT_IND ,PSO.SPCL_SRC_CD AS OUT_SCO_VER_SOURCE ,PSO.SPCL_BD_CERT_CD  AS OUT_SCO_BC,PSO.SPCL_BD_CERT_DT AS OUT_SCO_CERT_DATE,PSO.RCERT_EFF_DT AS OUT_SCO_RE_CERT_DATE ,PSO.SPCL_BD_EXPIR_DT AS OUT_SCO_EXP_DATE,PSO.SPCL_BD_EXAM_DT AS OUT_SCO_BOARD_DATE,PSO.EFF_DT  AS OUT_SCO_EFF_DATE ,PSO.CANC_DT AS OUT_SCO_CAN_DATE ,PSO.RES_IND AS OUT_SCO_RESIDENT ,PSO.PCP_SPCL_OVRD_IND AS OUT_SCO_PCP_OVR, PSO.LST_UPDT_DT AS PSO_LST_UPDT_DT from ${SchemaNm}_PROV_SPCL_CONTR_ORG PSO,${SchemaNm}_SPCL_TYP  SPT ,${SchemaNm}_SPCL_TYP_CATGY STC ,${SchemaNm}_PROV_SPCL  PSP WHERE  PSO.PROV_ID  = ${WS_SQL_PROV_ID}  AND  PSO.SPCL_TYP_CD = ${WS_PSO_SPCL_TYP_CD} AND  PSO.PROV_ID =  PSP.PROV_ID AND  PSO.SPCL_TYP_CD   =  SPT.SPCL_TYP_CD AND  SPT.SPCL_TYP_CD  =  STC.SPCL_TYP_CD ANDSTC.SPCL_TYP_CD = PSP.SPCL_TYP_CD AND  PSO.CONTR_ORG_CD  <> 'UHN'",null,null)
      val queries = Seq(query)
      val segDtls = new SegmentDetails("SCO",
        "4",
        "OUT_SCO_REC_TYP_CD;OUT_SCO_PROV_ID;OUT_SCO_CONT_ORG;OUT_SCO_PRI_SEC_CD;OUT_SCO_CODE;OUT_SCO_CODE_DESC;OUT_SCO_CATGY;OUT_SCO_BOARD;OUT_SCO_PRACT_IND;OUT_SCO_VER_SOURCE;OUT_SCO_BC;OUT_SCO_CERT_DATE;OUT_SCO_RE_CERT_DATE;OUT_SCO_EXP_DATE;OUT_SCO_BOARD_DATE;OUT_SCO_EFF_DATE;OUT_SCO_CAN_DATE;OUT_SCO_RESIDENT;OUT_SCO_PCP_OVR;OUT_SCO_CHG_IND",
        "3;9;4;1;3;25;4;9;1;3;1;10;10;10;10;10;10;1;1;1",
        "7","",
        queries
      )
      val segDetailsSeq =Seq(segDtls)
      // val inputEntity = new ExtractFileEntity("F5938RK4","PRV;ALT;PSP;SCO;PQI;HAS;PLI;PFA;TIN;PTI;TCO;NCE;ADD;PHO;ACT;LGS;LNG;HRS;HCA;ACO;AD1;CON;CDK;CSP;COS;CUL;NPI;COE","F5938DBE",segDetailsSeq)
      val prevRunDate =""
      val outputFilePath ="maprfs:///user/sgoyal34"
      val spark=globalContext.sparkSession
      var varLst = collection.mutable.Map[String, String]()
      assert(genSCOSeg(segDtls,glblVarLst,SW_SKIP_SCO,outputFilePath)(globalContext).isSuccess)
    }
    */

  /*  test("genSCOSeg method should return 'Y' if skip flag is 'N'") {
    val SW_SKIP_SCO = "N"
    val SchemaNm = "F5938DBE"
    val inputEntity = mock[ExtractFileEntity]
    val query = new Query("SCO_PROV_AFFIL","SELECT 'SCO' AS OUT_SCO_REC_TYP_CD, PSO.PROV_ID AS OUT_SCO_PROV_ID,PSO.CONTR_ORG_CD AS OUT_SCO_CONT_ORG,PSO.PRI_CD AS OUT_SCO_PRI_SEC_CD,PSO.SPCL_TYP_CD AS OUT_SCO_CODE, ,SPT.SPCL_TYP_SHRT_DESC  AS OUT_SCO_CODE_DESC,PSO.CRED_VERF_ORG_IND AS OUT_SCO_BOARD,PSO.PRAC_SPCL_IND AS OUT_SCO_PRACT_IND ,PSO.SPCL_SRC_CD AS OUT_SCO_VER_SOURCE ,PSO.SPCL_BD_CERT_CD  AS OUT_SCO_BC,PSO.SPCL_BD_CERT_DT AS OUT_SCO_CERT_DATE,PSO.RCERT_EFF_DT AS OUT_SCO_RE_CERT_DATE ,PSO.SPCL_BD_EXPIR_DT AS OUT_SCO_EXP_DATE,PSO.SPCL_BD_EXAM_DT AS OUT_SCO_BOARD_DATE,PSO.EFF_DT  AS OUT_SCO_EFF_DATE ,PSO.CANC_DT AS OUT_SCO_CAN_DATE ,PSO.RES_IND AS OUT_SCO_RESIDENT ,PSO.PCP_SPCL_OVRD_IND AS OUT_SCO_PCP_OVR, PSO.LST_UPDT_DT AS PSO_LST_UPDT_DT from ${SchemaNm}_PROV_SPCL_CONTR_ORG PSO,${SchemaNm}_SPCL_TYP  SPT ,${SchemaNm}_SPCL_TYP_CATGY STC ,${SchemaNm}_PROV_SPCL  PSP WHERE  PSO.PROV_ID  = ${WS_SQL_PROV_ID}  AND  PSO.SPCL_TYP_CD = ${WS_PSO_SPCL_TYP_CD} AND  PSO.PROV_ID =  PSP.PROV_ID AND  PSO.SPCL_TYP_CD   =  SPT.SPCL_TYP_CD AND  SPT.SPCL_TYP_CD  =  STC.SPCL_TYP_CD ANDSTC.SPCL_TYP_CD = PSP.SPCL_TYP_CD AND  PSO.CONTR_ORG_CD  <> 'UHN'",null,null)
    val queries = Seq(query)
    val segDtls = new SegmentDetails("SCO",
      "4",
      "OUT_SCO_REC_TYP_CD;OUT_SCO_PROV_ID;OUT_SCO_CONT_ORG;OUT_SCO_PRI_SEC_CD;OUT_SCO_CODE;OUT_SCO_CODE_DESC;OUT_SCO_CATGY;OUT_SCO_BOARD;OUT_SCO_PRACT_IND;OUT_SCO_VER_SOURCE;OUT_SCO_BC;OUT_SCO_CERT_DATE;OUT_SCO_RE_CERT_DATE;OUT_SCO_EXP_DATE;OUT_SCO_BOARD_DATE;OUT_SCO_EFF_DATE;OUT_SCO_CAN_DATE;OUT_SCO_RESIDENT;OUT_SCO_PCP_OVR;OUT_SCO_CHG_IND",
      "3;9;4;1;3;25;4;9;1;3;1;10;10;10;10;10;10;1;1;1",
      "7",
      queries
    )
    val segDetailsSeq =Seq(segDtls)
    //  val inputEntity = new ExtractFileEntity("F5938RK4","PRV;ALT;PSP;SCO;PQI;HAS;PLI;PFA;TIN;PTI;TCO;NCE;ADD;PHO;ACT;LGS;LNG;HRS;HCA;ACO;AD1;CON;CDK;CSP;COS;CUL;NPI;COE","F5938DBE",segDetailsSeq)
      val prevRunDate =""
      val outputFilePath ="maprfs:///user/sgoyal34"
      val spark=globalContext.sparkSession
      //val SchemaNm = "F5938DBE"
      import spark.implicits._
      val s=Seq((1233, 176),
        (234, 2323),
        (30000, 29898))
      val df=s.toDF("OUT_PHO_PROV_ID","OUT_PHO_TEL_NBR")
      df.createOrReplaceTempView("ADD_FINAL_QRY")

      println("=======================" + spark.catalog.tableExists("ADD_FINAL_QRY") + "========")
      var varLst = collection.mutable.Map[String, String]()

      assert(acoSegGen(segDtls,glblVarLst,SW_SKIP_ACO, WS_PREV_RUN_DT_YMD, outputFilePath)(globalContext).get.equals("Y"))
    }*/


  test("genSCOSeg method should return 'N' if the skip flag is 'Y'") {
    val SW_SKIP_SCO = "Y"
    val SchemaNm = "F5938DBE"
    val inputEntity = mock[ExtractFileEntity]
    val query = new Query("SCO_PROV_AFFIL","SELECT 'SCO' AS OUT_SCO_REC_TYP_CD, PSO.PROV_ID AS OUT_SCO_PROV_ID,PSO.CONTR_ORG_CD AS OUT_SCO_CONT_ORG,PSO.PRI_CD AS OUT_SCO_PRI_SEC_CD,PSO.SPCL_TYP_CD AS OUT_SCO_CODE, ,SPT.SPCL_TYP_SHRT_DESC  AS OUT_SCO_CODE_DESC,PSO.CRED_VERF_ORG_IND AS OUT_SCO_BOARD,PSO.PRAC_SPCL_IND AS OUT_SCO_PRACT_IND ,PSO.SPCL_SRC_CD AS OUT_SCO_VER_SOURCE ,PSO.SPCL_BD_CERT_CD  AS OUT_SCO_BC,PSO.SPCL_BD_CERT_DT AS OUT_SCO_CERT_DATE,PSO.RCERT_EFF_DT AS OUT_SCO_RE_CERT_DATE ,PSO.SPCL_BD_EXPIR_DT AS OUT_SCO_EXP_DATE,PSO.SPCL_BD_EXAM_DT AS OUT_SCO_BOARD_DATE,PSO.EFF_DT  AS OUT_SCO_EFF_DATE ,PSO.CANC_DT AS OUT_SCO_CAN_DATE ,PSO.RES_IND AS OUT_SCO_RESIDENT ,PSO.PCP_SPCL_OVRD_IND AS OUT_SCO_PCP_OVR, PSO.LST_UPDT_DT AS PSO_LST_UPDT_DT from ${SchemaNm}_PROV_SPCL_CONTR_ORG PSO,${SchemaNm}_SPCL_TYP  SPT ,${SchemaNm}_SPCL_TYP_CATGY STC ,${SchemaNm}_PROV_SPCL  PSP WHERE  PSO.PROV_ID  = ${WS_SQL_PROV_ID}  AND  PSO.SPCL_TYP_CD = ${WS_PSO_SPCL_TYP_CD} AND  PSO.PROV_ID =  PSP.PROV_ID AND  PSO.SPCL_TYP_CD   =  SPT.SPCL_TYP_CD AND  SPT.SPCL_TYP_CD  =  STC.SPCL_TYP_CD ANDSTC.SPCL_TYP_CD = PSP.SPCL_TYP_CD AND  PSO.CONTR_ORG_CD  <> 'UHN'",null,null)
    val queries = Seq(query)
    val segDtls = new SegmentDetails("SCO",
      "4",
      "OUT_SCO_REC_TYP_CD;OUT_SCO_PROV_ID;OUT_SCO_CONT_ORG;OUT_SCO_PRI_SEC_CD;OUT_SCO_CODE;OUT_SCO_CODE_DESC;OUT_SCO_CATGY;OUT_SCO_BOARD;OUT_SCO_PRACT_IND;OUT_SCO_VER_SOURCE;OUT_SCO_BC;OUT_SCO_CERT_DATE;OUT_SCO_RE_CERT_DATE;OUT_SCO_EXP_DATE;OUT_SCO_BOARD_DATE;OUT_SCO_EFF_DATE;OUT_SCO_CAN_DATE;OUT_SCO_RESIDENT;OUT_SCO_PCP_OVR;OUT_SCO_CHG_IND",
      "3;9;4;1;3;25;4;9;1;3;1;10;10;10;10;10;10;1;1;1",
      "7","",
      queries
    )
    val segDetailsSeq =Seq(segDtls)
    // val inputEntity = new ExtractFileEntity("F5938RK4","PRV;ALT;PSP;SCO;PQI;HAS;PLI;PFA;TIN;PTI;TCO;NCE;ADD;PHO;ACT;LGS;LNG;HRS;HCA;ACO;AD1;CON;CDK;CSP;COS;CUL;NPI;COE","F5938DBE",segDetailsSeq)
    val prevRunDate =""
    val outputFilePath ="maprfs:///user/sgoyal34"
    val spark=globalContext.sparkSession
    //val SchemaNm = "F5938DBE"
    import spark.implicits._
    val s=Seq((1233, 176),
      (234, 2323),
      (30000, 29898))
    val df=s.toDF("OUT_PHO_PROV_ID","OUT_PHO_TEL_NBR")
    df.createOrReplaceTempView("PSP_FINAL_QRY_2")

    println("=======================" + spark.catalog.tableExists("PSP_FINAL_QRY_2") + "========")
    assert(genSCOSeg(segDtls,glblVarLst,SW_SKIP_SCO, outputFilePath)(globalContext).get.equals("N"))
  }


  test("genSCOSeg method should return 'N' if no valid values for SCO present in segDtls") {
    val SW_SKIP_SCO = "N"
    val SchemaNm = "F5938DBE"
    val inputEntity = mock[ExtractFileEntity]
    val query = new Query("SCO_PROV_AFFIL","SELECT 'SCO' AS OUT_SCO_REC_TYP_CD, PSO.PROV_ID AS OUT_SCO_PROV_ID,PSO.CONTR_ORG_CD AS OUT_SCO_CONT_ORG,PSO.PRI_CD AS OUT_SCO_PRI_SEC_CD,PSO.SPCL_TYP_CD AS OUT_SCO_CODE, ,SPT.SPCL_TYP_SHRT_DESC  AS OUT_SCO_CODE_DESC,PSO.CRED_VERF_ORG_IND AS OUT_SCO_BOARD,PSO.PRAC_SPCL_IND AS OUT_SCO_PRACT_IND ,PSO.SPCL_SRC_CD AS OUT_SCO_VER_SOURCE ,PSO.SPCL_BD_CERT_CD  AS OUT_SCO_BC,PSO.SPCL_BD_CERT_DT AS OUT_SCO_CERT_DATE,PSO.RCERT_EFF_DT AS OUT_SCO_RE_CERT_DATE ,PSO.SPCL_BD_EXPIR_DT AS OUT_SCO_EXP_DATE,PSO.SPCL_BD_EXAM_DT AS OUT_SCO_BOARD_DATE,PSO.EFF_DT  AS OUT_SCO_EFF_DATE ,PSO.CANC_DT AS OUT_SCO_CAN_DATE ,PSO.RES_IND AS OUT_SCO_RESIDENT ,PSO.PCP_SPCL_OVRD_IND AS OUT_SCO_PCP_OVR, PSO.LST_UPDT_DT AS PSO_LST_UPDT_DT from ${SchemaNm}_PROV_SPCL_CONTR_ORG PSO,${SchemaNm}_SPCL_TYP  SPT ,${SchemaNm}_SPCL_TYP_CATGY STC ,${SchemaNm}_PROV_SPCL  PSP WHERE  PSO.PROV_ID  = ${WS_SQL_PROV_ID}  AND  PSO.SPCL_TYP_CD = ${WS_PSO_SPCL_TYP_CD} AND  PSO.PROV_ID =  PSP.PROV_ID AND  PSO.SPCL_TYP_CD   =  SPT.SPCL_TYP_CD AND  SPT.SPCL_TYP_CD  =  STC.SPCL_TYP_CD ANDSTC.SPCL_TYP_CD = PSP.SPCL_TYP_CD AND  PSO.CONTR_ORG_CD  <> 'UHN'",null,null)
    val queries = Seq(query)
    val segDtls = new SegmentDetails("SCOOO",
      "4",
      "OUT_SCO_REC_TYP_CD;OUT_SCO_PROV_ID;OUT_SCO_CONT_ORG;OUT_SCO_PRI_SEC_CD;OUT_SCO_CODE;OUT_SCO_CODE_DESC;OUT_SCO_CATGY;OUT_SCO_BOARD;OUT_SCO_PRACT_IND;OUT_SCO_VER_SOURCE;OUT_SCO_BC;OUT_SCO_CERT_DATE;OUT_SCO_RE_CERT_DATE;OUT_SCO_EXP_DATE;OUT_SCO_BOARD_DATE;OUT_SCO_EFF_DATE;OUT_SCO_CAN_DATE;OUT_SCO_RESIDENT;OUT_SCO_PCP_OVR;OUT_SCO_CHG_IND",
      "3;9;4;1;3;25;4;9;1;3;1;10;10;10;10;10;10;1;1;1",
      "7","",
      queries
    )
    val segDetailsSeq =Seq(segDtls)
    val prevRunDate =""
    val outputFilePath ="maprfs:///user/sgoyal34"
    val spark=globalContext.sparkSession
    //val SchemaNm = "F5938DBE"
    /*    import spark.implicits._
        val s=Seq((1233, 176),
          (234, 2323),
          (30000, 29898))
        val df=s.toDF("OUT_PHO_PROV_ID","OUT_PHO_TEL_NBR")
        df.createOrReplaceTempView("PSP_FINAL_QRY_2")*/

    println("=======================" + spark.catalog.tableExists("PSP_FINAL_QRY_2") + "========")
    assert(genSCOSeg(segDtls,glblVarLst,SW_SKIP_SCO,outputFilePath)(globalContext).get.equals("N"))
  }



  override def afterAll(): Unit = {
    super.afterAll()
    globalContext.sparkContext.stop()
  }

}




