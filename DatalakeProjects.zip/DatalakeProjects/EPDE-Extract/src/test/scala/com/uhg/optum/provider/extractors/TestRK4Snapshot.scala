package com.uhg.optum.provider.extractors

import com.uhg.optum.JobRunner.{PEI, PEIInstanceEmpty}
import com.uhg.optum.dao.LocalRepositoryManager
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.provider.RawExtractProvider
import com.uhg.optum.provider.snapshot.CommonSnapshotProvider
import com.uhg.optum.tests.base.UnitSpec
import com.uhg.optum.util.EPDECommonUtil
import org.apache.spark.sql.{DataFrame, DataFrameReader, SQLContext}
import org.apache.spark.sql.{DataFrame, DataFrameReader, SQLContext}
import org.mockito.Matchers
import org.mockito.Mockito.when

import scala.util.{Failure, Success}

class TestRK4Snapshot extends UnitSpec with CommonSnapshotProvider{
  var globalContext: GlobalContext = _
  implicit var pei: PEI = _

  override def beforeAll(): Unit = {
    super.beforeAll()

    //val peiRowKey = "MCAD_Reporting-TOPS"
    globalContext = new GlobalContext("EPDE-OPTUM","local") with LocalRepositoryManager

    import com.uhg.optum.protocols.PEIProtocol._

    globalContext.peTable.get("EPDE-OPTUM", "pei") match {
      case Success(instance) =>
        this.pei = instance
        Success()
      case Failure(ex) =>
        Failure(new PEIInstanceEmpty("Exception while getting the columns info from PEI Table", ex))
    }

  }





/*
  test("getSnapShotParquetFiles should call getSnapshotExtractPerEntity as refresh flag is Y")
  {
    val rawExtractProvider = mock[RawExtractProvider]
    val pitRowKey="EPDE-OPTUM-1111"
    val tables=List("ABC")
    val refreshFlag="Y"
    val eitFlag="Y"
    val context=mock[GlobalContext]
    val pei=mock[PEI]
    /*when(context.sqlContext).thenReturn(sqlContext)
    when(sqlContext.read).thenReturn(dataframeReader)
    when(dataframeReader.parquet(workingDir + "/snapshot/" + "XYZ")).thenReturn(dataframe)*/
    when(rawExtractProvider.getSnapshotExtractPerEntity("EPDE-OPTUM-F5938DBE_ABC","F5938DBE_ABC", pei,pitRowKey,eitFlag)(context)).thenReturn("Y")
    assert(EPDECommonUtil.getSnapShotParquetFiles(pitRowKey,tables,refreshFlag,eitFlag)(context,pei,rawExtractProvider)=="Y")
  }

  test("getSnapShotParquetFiles should call getSnapshotExtractPerEntity as the entity is not present in snapshot folder ")
  {
    val rawExtractProvider = mock[RawExtractProvider]
    val pitRowKey="EPDE-OPTUM-1111"
    val tables=List("ABC")
    val refreshFlag="N"
    val eitFlag="Y"
    val checkCommonSnapshot=""
    val entity=tables.apply(0)
    val dataframe=mock[DataFrame]
    val dataframeReader=mock[DataFrameReader]
    val context=mock[GlobalContext]
    val sqlContext=mock[SQLContext]
    val pei=mock[PEI]
    /*when(context.sqlContext).thenReturn(sqlContext)
    when(sqlContext.read).thenReturn(dataframeReader)
    when(dataframeReader.parquet(workingDir + "/snapshot/" + "XYZ")).thenReturn(dataframe)*/
    when(rawExtractProvider.getSnapshotExtractPerEntity("EPDE-OPTUM-F5938DBE_ABC","F5938DBE_ABC", pei,pitRowKey,eitFlag)(context)).thenReturn("Y")
    assert(EPDECommonUtil.getSnapShotParquetFiles(pitRowKey,tables,refreshFlag,eitFlag)(context,pei,rawExtractProvider)=="Y")
  }




  test("getSnapShotParquetFiles should call getSnapshotExtractPerEntity as the entity is not present in snapshot folder and refresh flag is Y")
  {
    val rawExtractProvider = mock[RawExtractProvider]
    val pitRowKey="EPDE-OPTUM-1111"
    val tables=List("ABC")
    val refreshFlag="Y"
    val eitFlag="Y"
    val checkCommonSnapshot=""
    val entity=tables.apply(0)
    val dataframe=mock[DataFrame]
    val dataframeReader=mock[DataFrameReader]
    val context=mock[GlobalContext]
    val sqlContext=mock[SQLContext]
    val pei=mock[PEI]
    /*when(context.sqlContext).thenReturn(sqlContext)
    when(sqlContext.read).thenReturn(dataframeReader)
    when(dataframeReader.parquet(workingDir + "/snapshot/" + "XYZ")).thenReturn(dataframe)*/
    when(rawExtractProvider.getSnapshotExtractPerEntity("EPDE-OPTUM-F5938DBE_ABC","F5938DBE_ABC", pei,pitRowKey,eitFlag)(context)).thenReturn("Y")
    assert(EPDECommonUtil.getSnapShotParquetFiles(pitRowKey,tables,refreshFlag,eitFlag)(context,pei,rawExtractProvider)=="Y")
  }*/


  /*test("getSnapShotParquetFiles should call getSnapshotExtractPerEntity as snapshot already exists")
  {
    val rawExtractProvider = mock[RawExtractProvider]
    val pitRowKey="EPDE-OPTUM-XYZ1111"
    val tables="XYZ"
    val refreshFlag=""
    val eitFlag=""
    val dataframe=mock[DataFrame]
    val dataframeReader=mock[DataFrameReader]
    val context=mock[GlobalContext]
    val sqlContext=mock[SQLContext]
    val entity=tables
    when(rawExtractProvider.getCommonSnapshotPerEntity(entity)(context)).thenReturn("Y")
    when(context.sqlContext).thenReturn(sqlContext)
    when(sqlContext.read).thenReturn(dataframeReader)
    when(dataframeReader.parquet(workingDir + "/snapshot/" + "XYZ")).thenReturn(dataframe)

    assert(EPDECommonUtil.getSnapShotParquetFiles(pitRowKey,tables,refreshFlag,eitFlag)(context,pei,rawExtractProvider)=="Y")
  }*/
  override def afterAll(): Unit = {

    super.afterAll()
    globalContext.sparkContext.stop()
  }
}
