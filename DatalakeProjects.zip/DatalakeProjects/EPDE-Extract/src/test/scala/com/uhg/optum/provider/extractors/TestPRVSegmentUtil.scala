package com.uhg.optum.provider.extractors

import com.uhg.optum.JobRunner.{PEI, PEIInstanceEmpty}
import com.uhg.optum.dao.LocalRepositoryManager
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDERK4InputJsonSchema.{ExtractFileEntity, Query, SegmentDetails}
import com.uhg.optum.tests.base.UnitSpec
import com.uhg.optum.util.CommonUtil
import org.apache.spark.sql.DataFrame

import scala.util.{Failure, Success}

class TestPRVSegmentUtil  extends UnitSpec with EPDERK4_PRV_SegExt {
  var globalContext: GlobalContext = _
  implicit var pei: PEI = _
  var glblVarLst = collection.mutable.Map[String, String]()

  override def beforeAll(): Unit = {
    super.beforeAll()

    globalContext = new GlobalContext("EPDE_OPTUM","local") with LocalRepositoryManager
    import com.uhg.optum.protocols.PEIProtocol._
    globalContext.peTable.get("EPDE-OPTUM", "pei") match {
      case Success(instance) =>
        this.pei = instance
        Success()
      case Failure(ex) =>
        Failure(new PEIInstanceEmpty("Exception while getting the columns info from PEI Table", ex))
    }
    val WS_CANC_DT_1 = "01/01/0001" // used in PSP ; genrated in
    val WS_CANC_DT_2 = "12/31/9999" // used in PSP ; genrated in
    val WS_UPDT_DT_1 = "03/01/2019" // used in PSP
    val WS_UPDT_DT_2 = "12/31/9999" // used in PSP
    val WS_ACTV_CD_1 = "A" // used in ADD
    val WS_ACTV_CD_2 = "I" // used in ADD
    CommonUtil.add2Map(glblVarLst, "${WS_CANC_DT_1}", WS_CANC_DT_1)
    CommonUtil.add2Map(glblVarLst, "${WS_CANC_DT_2}", WS_CANC_DT_2)
    CommonUtil.add2Map(glblVarLst, "${WS_UPDT_DT_1}", WS_UPDT_DT_1)
    CommonUtil.add2Map(glblVarLst, "${WS_UPDT_DT_2}", WS_UPDT_DT_2)
    CommonUtil.add2Map(glblVarLst, "${WS_ACTV_CD_1}", WS_ACTV_CD_1)
    CommonUtil.add2Map(glblVarLst, "${WS_ACTV_CD_2}", WS_ACTV_CD_2)
  }
/*
  test("PRV method should return N for successful intermediate Query Execution") {
    val query = new Query("PRV_SEL_RKP_Prov", "SELECT PROV_OUT_PROV_ID,PROV_OUT_VEND_KEY ,PROV_OUT_UPDT_TYP_CD, ROW_NUMBER() OVER (PARTITION BY PROV_OUT_PROV_ID ORDER BY  PROV_OUT_VEND_KEY,PROV_OUT_UPDT_TYP_CD ) AS RNUM  FROM SELPROV", null, null)
    val queries = Seq(query)
    val segDtls = new SegmentDetails("PRV",
      "1",
      "PROV_OUT_VENDR_CD;PROV_OUT_PROV_TYP_CD;PROV_OUT_UPDT_TYP_CD;PROV_OUT_PROV_ID;PROV_OUT_VEND_KEY;PROV_PQD_OR_FQD_CNT;PROV_OUT_ORG_TYP_CD",
      "10;10;10;10;10",
      "400","",
      queries
    )
    val spark = globalContext.sparkSession
    import spark.implicits._

    var SELPROV= Seq(
      ("OHPH","P","C","528719","","",""),
      ("OHPH","P","C","530799","","",""),
      ("OHPH","P","C","2022991","","",""),
      ("OHPH","O","C","2426556","","","050"),
      ("OHPH","O","C","2450934","","","050")
    ).toDF("PROV_OUT_VENDR_CD","PROV_OUT_PROV_TYP_CD","PROV_OUT_UPDT_TYP_CD","PROV_OUT_PROV_ID","PROV_OUT_VEND_KEY","PROV_PQD_OR_FQD_CNT","PROV_OUT_ORG_TYP_CD")
    SELPROV.createOrReplaceTempView("SELPROV")
    val prevRunDate = ""
    val outputFilePath = ""
    println("=======================" + spark.catalog.tableExists("SELPROV") + "========")

    assert(genPRVSeg(segDtls,glblVarLst,glblVarLst,outputFilePath)(globalContext)=="N")
  }*/

  /*test("PRV method should return Y for successful final Query Execution") {
    val query = new Query("PRV_FNL_VIEW", "SELECT 'PRV' AS OUT_PRV_REC_TYP_CD,PROV_OUT_UPDT_TYP_CD AS OUT_PRV_UPDT_TYP_CD ,lpad(PRO_PROV_ID,9,0) AS OUT_PRV_PROV_ID from PRV_2100_LBL", null, null)
    val queries = Seq(query)
    val segDtls = new SegmentDetails("PRV",
      "1",
      "OUT_PRV_REC_TYP_CD;OUT_PRV_UPDT_TYP_CD;OUT_PRV_PROV_ID",
      "03;01;09",
      "400","",
      queries
    )
    val spark = globalContext.sparkSession
    import spark.implicits._

    var PRV_2100_LBL= Seq(
      ("C","528719"),
      ("C","530799"),
      ("C","2022991"),
      ("C","2426556"),
      ("C","2450934")
    ).toDF("PROV_OUT_UPDT_TYP_CD","PRO_PROV_ID")
    PRV_2100_LBL.createOrReplaceTempView("PRV_2100_LBL")
    val prevRunDate = ""
    val outputFilePath = ""
    println("=======================" + spark.catalog.tableExists("PRV_2100_LBL") + "========")

    assert(genPRVSeg(segDtls,glblVarLst,glblVarLst,outputFilePath)(globalContext)=="Y")
  }


  test("PRV method should return N for unsuccessful final Query Execution") {
    val query = new Query("PRV_FNL_VIEW", "SELECT 'PRV' AS OUT_PRV_REC_TYP_CD,PROV_OUT_UPDT_TYP_CD AS OUT_PRV_UPDT_TYP_CD ,lpad(PRO_PROV_ID,9,0) AS OUT_PRV_PROV_ID from PRV_2100_LBL", null, null)
    val queries = Seq(query)
    val segDtls = new SegmentDetails("PRV",
      "1",
      "OUT_PRV_REC_TYP_CD;OUT_PRV_UPDT_TYP_CD;OUT_PRV_PROV_ID",
      "03;01;09",
      "400","",
      queries
    )
    val spark = globalContext.sparkSession
    val prevRunDate = ""
    val outputFilePath = ""


    val PRV_2100_LBL = globalContext.sqlContext.emptyDataFrame
    PRV_2100_LBL.createOrReplaceTempView("PRV_2100_LBL")
    println("=======================" + spark.catalog.tableExists("PRV_2100_LBL") + "==unsuccesful======")
    assert(genPRVSeg(segDtls,glblVarLst,glblVarLst,outputFilePath)(globalContext)=="N")
  }*/

  test("Getting the dataframe from empty sql query should not be success") {

    val dataFrame = mock[DataFrame]
    var query1 = mock[Query]
    query1 = new Query("PRV_DEG_CD_RCRDS","",null,null)

    val thrownExcep = intercept[Exception] {
      CommonUtil.executeQry(glblVarLst,query1)(globalContext)
    }
    println("======================= select statement ==unsuccesful======")
    assert(thrownExcep.getMessage == "ERROR : Cannot make DF as Query is empty or NULL or does not start with select "+query1.name)

  }
  test("PRV method should return N for succesful PRV_DEG_CD_RCRDS Query Execution") {
    val query = new Query("PRV_DEG_CD_RCRDS", "SELECT DEG.PROV_ID AS PROV_ID,DEG.DEG_CD AS DEG_CD,DEG.PRI_CD AS PRI_CD,DEG.ACTV_CD AS ACTV_CD,DEG.LST_UPDT_DT AS LST_UPDT_DT FROM F5938DBE_PROV_DEG DEG", null, null)
    val queries = Seq(query)
    val segDtls = new SegmentDetails("PRV",
      "1",
      "OUT_PRV_REC_TYP_CD;OUT_PRV_UPDT_TYP_CD;OUT_PRV_PROV_ID",
      "03;01;09",
      "400","",
      queries
    )
    val spark = globalContext.sparkSession
    import spark.implicits._
    var F5938DBE_PROV_DEG= Seq(
      ("1624048","MS","P","A","2009-12-14"),
      ("1624048","MSW","S","A","2009-12-14")
     ).toDF("PROV_ID","DEG_CD","PRI_CD","ACTV_CD","LST_UPDT_DT")
    F5938DBE_PROV_DEG.createOrReplaceTempView("F5938DBE_PROV_DEG")
    val prevRunDate = ""
    val outputFilePath = ""
    //val F5938DBE_PROV_DEG = globalContext.sqlContext.emptyDataFrame
    //F5938DBE_PROV_DEG.createOrReplaceTempView("F5938DBE_PROV_DEG")
    println("=======================" + spark.catalog.tableExists("F5938DBE_PROV_DEG") + "==unsuccesful======")
    assert(genPRVSeg(segDtls,glblVarLst,glblVarLst,outputFilePath)(globalContext)=="N")
  }
  test("PRV method should return N for succesful PRV_DEG_CD_NORCRDS Query Execution") {

    val query1 = new Query("PRV_DEG_CD_RCRDS", "SELECT DEG.PROV_ID AS PROV_ID,DEG.DEG_CD AS DEG_CD,DEG.PRI_CD AS PRI_CD,DEG.ACTV_CD AS ACTV_CD,DEG.LST_UPDT_DT AS LST_UPDT_DT FROM F5938DBE_PROV_DEG DEG", null, null)
    val query2 = new Query("PRV_DEG_CD_NORCRDS", "SELECT PRV.PRO_PROV_ID AS PDG_PROV_ID,'' AS PDG_DEG_CD_1,'' AS PDG_PRI_CD_1,'' AS PDG_ACTV_CD_1, '01/01/0001' AS PDG_LST_UPDT_DT_2 FROM PRV_2100_LBL PRV LEFT OUTER JOIN PRV_DEG_CD_RCRDS DEG ON PRV.PRO_PROV_ID=DEG.PROV_ID WHERE DEG.PROV_ID IS NULL", null, null)
    val queries = Seq(query1,query2)
    val segDtls = new SegmentDetails("PRV",
      "1",
      "OUT_PRV_REC_TYP_CD;OUT_PRV_UPDT_TYP_CD;OUT_PRV_PROV_ID",
      "03;01;09",
      "400","",
      queries
    )

    val spark = globalContext.sparkSession
    import spark.implicits._

    var F5938DBE_PROV_DEG= Seq(
      ("1624048","MS","P","A","2009-12-14"),
      ("528719","MSW","S","A","2009-12-14")
    ).toDF("PROV_ID","DEG_CD","PRI_CD","ACTV_CD","LST_UPDT_DT")
    F5938DBE_PROV_DEG.createOrReplaceTempView("F5938DBE_PROV_DEG")
    var PRV_DEG_CD_RCRDS= Seq(
      ("1624048","MS","P","A","2009-12-14"),
      ("528719","MSW","S","A","2009-12-14")
    ).toDF("PROV_ID","DEG_CD","PRI_CD","ACTV_CD","LST_UPDT_DT")
    PRV_DEG_CD_RCRDS.createOrReplaceTempView("PRV_DEG_CD_RCRDS")
    var PRV_2100_LBL= Seq(
      ("C","528719"),
      ("C","530799"),
      ("C","2022991"),
      ("C","2426556"),
      ("C","2450934")
    ).toDF("PROV_OUT_UPDT_TYP_CD","PRO_PROV_ID")
    PRV_2100_LBL.createOrReplaceTempView("PRV_2100_LBL")

    val prevRunDate = ""
    val outputFilePath = ""
    println("=======================" + spark.catalog.tableExists("F5938DBE_PROV_DEG") + "==unsuccesful======")
    println("=======================" + spark.catalog.tableExists("PRV_DEG_CD_RCRDS") + "==unsuccesful======")
    println("=======================" + spark.catalog.tableExists("PRV_2100_LBL") + "==unsuccesful======")
    assert(genPRVSeg(segDtls,glblVarLst,glblVarLst,outputFilePath)(globalContext)=="N")
  }

  test("PRV method should return N for succesful PRV_DEG_CNT Query Execution") {
    val SchemaNm = "F5938DBE"
    val query1 = new Query("PRV_DEG_CD_RCRDS", "SELECT DEG.PROV_ID AS PROV_ID,DEG.DEG_CD AS DEG_CD,DEG.PRI_CD AS PRI_CD,DEG.ACTV_CD AS ACTV_CD,DEG.LST_UPDT_DT AS LST_UPDT_DT FROM F5938DBE_PROV_DEG DEG", null, null)
    val query2 = new Query("PRV_DEG_CNT", "SELECT PROV_ID AS PROV_ID,CAST(COUNT(*) AS STRING) AS CNT FROM PRV_DEG_CD_RCRDS GROUP BY PROV_ID", null, null)
    val queries = Seq(query1,query2)
    val segDtls = new SegmentDetails("PRV",
      "1",
      "OUT_PRV_REC_TYP_CD;OUT_PRV_UPDT_TYP_CD;OUT_PRV_PROV_ID",
      "03;01;09",
      "400","",
      queries
    )

    val spark = globalContext.sparkSession
    import spark.implicits._

    var F5938DBE_PROV_DEG= Seq(
      ("1624048","MS","P","A","2009-12-14"),
      ("528719","MSW","S","A","2009-12-14")
    ).toDF("PROV_ID","DEG_CD","PRI_CD","ACTV_CD","LST_UPDT_DT")
    F5938DBE_PROV_DEG.createOrReplaceTempView("F5938DBE_PROV_DEG")
    var PRV_DEG_CD_RCRDS= Seq(
      ("1624048","MS","P","A","2009-12-14"),
      ("528719","MSW","S","A","2009-12-14")
    ).toDF("PROV_ID","DEG_CD","PRI_CD","ACTV_CD","LST_UPDT_DT")
    PRV_DEG_CD_RCRDS.createOrReplaceTempView("PRV_DEG_CD_RCRDS")

    val prevRunDate = ""
    val outputFilePath = ""
    println("=======================" + spark.catalog.tableExists("F5938DBE_PROV_DEG") + "==succesful======")
    println("=======================" + spark.catalog.tableExists("PRV_DEG_CD_RCRDS") + "==succesful======")

    assert(genPRVSeg(segDtls,glblVarLst,glblVarLst,outputFilePath)(globalContext)=="N")
  }

  test("PRV method should return N for succesful PRV_DEG_CD_OCCURS Query Execution") {
    val SchemaNm = "F5938DBE"
    val query1 = new Query("PRV_DEG_CD_RCRDS", "SELECT DEG.PROV_ID AS PROV_ID,DEG.DEG_CD AS DEG_CD,DEG.PRI_CD AS PRI_CD,DEG.ACTV_CD AS ACTV_CD,DEG.LST_UPDT_DT AS LST_UPDT_DT FROM F5938DBE_PROV_DEG DEG", null, null)
    val query2 = new Query("PRV_DEG_CD_NORCRDS", "SELECT CAST(PROV_ID AS STRING) AS PROV_ID,CAST(COUNT(*) AS STRING) AS CNT FROM PRV_DEG_CD_RCRDS GROUP BY PROV_ID", null, null)
    val queries = Seq(query1,query2)
    val segDtls = new SegmentDetails("PRV",
      "1",
      "OUT_PRV_REC_TYP_CD;OUT_PRV_UPDT_TYP_CD;OUT_PRV_PROV_ID",
      "03;01;09",
      "400","",
      queries
    )

    val spark = globalContext.sparkSession
    import spark.implicits._

    var F5938DBE_PROV_DEG= Seq(
      ("1624048","MS","P","A","2009-12-14"),
      ("528719","MSW","S","A","2009-12-14")
    ).toDF("PROV_ID","DEG_CD","PRI_CD","ACTV_CD","LST_UPDT_DT")
    F5938DBE_PROV_DEG.createOrReplaceTempView("F5938DBE_PROV_DEG")
    var PRV_DEG_CD_RCRDS= Seq(
      ("1624048","MS","P","A","2009-12-14"),
      ("528719","MSW","S","A","2009-12-14")
    ).toDF("PROV_ID","DEG_CD","PRI_CD","ACTV_CD","LST_UPDT_DT")
    PRV_DEG_CD_RCRDS.createOrReplaceTempView("PRV_DEG_CD_RCRDS")

    val prevRunDate = ""
    val outputFilePath = ""
    println("=======================" + spark.catalog.tableExists("F5938DBE_PROV_DEG") + "==succesful======")
    println("=======================" + spark.catalog.tableExists("PRV_DEG_CD_RCRDS") + "==succesful======")

    assert(genPRVSeg(segDtls,glblVarLst,glblVarLst,outputFilePath)(globalContext)=="N")
  }

}
