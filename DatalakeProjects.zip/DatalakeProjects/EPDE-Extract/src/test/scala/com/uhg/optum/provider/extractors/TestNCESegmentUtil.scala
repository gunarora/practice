package com.uhg.optum.provider.extractors

import com.uhg.optum.JobRunner.{PEI, PEIInstanceEmpty}
import com.uhg.optum.dao.LocalRepositoryManager
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDERK4InputJsonSchema.{ExtractFileEntity, Query, SegmentDetails}
import com.uhg.optum.tests.base.UnitSpec
import com.uhg.optum.util.{CommonUtil, Logger}
import org.apache.spark.sql.DataFrame

import scala.util.{Failure, Success}


class TestNCESegmentUtil extends UnitSpec with EPDERK4JsonSourceExtractor with EPDERK4_NCE_SegExt {
  var globalContext : GlobalContext = _
  implicit var pei: PEI = _
  var glblVarLst  = collection.mutable.Map[String, String]()

  override def beforeAll(): Unit = {
    super.beforeAll()

    globalContext = new GlobalContext("EPDE_OPTUM","local") with LocalRepositoryManager
    import com.uhg.optum.protocols.PEIProtocol._
    globalContext.peTable.get("EPDE_OPTUM", "pei") match {
      case Success(instance) =>
        this.pei = instance
        Success()
      case Failure(ex) =>
        Failure(new PEIInstanceEmpty("Exception while getting the columns info from PEI Table", ex))
    }

    val WS_CANC_DT_1="01/01/0001"  // used in PSP ; genrated in
    val WS_CANC_DT_2="12/31/9999"  // used in PSP ; genrated in
    val WS_UPDT_DT_1= "03/01/2019"  // used in PSP
    val WS_UPDT_DT_2="12/31/9999"   // used in PSP
    val WS_ACTV_CD_1="A"  // used in ADD
    val WS_ACTV_CD_2="I"   // used in ADD
    val SchemaNm = "F5938DBE"
    val WS_PREV_RUN_DT_YMD = "99991231"
    CommonUtil.add2Map(glblVarLst,"${WS_CANC_DT_1}",WS_CANC_DT_1)
    CommonUtil.add2Map(glblVarLst,"${WS_CANC_DT_2}",WS_CANC_DT_2)
    CommonUtil.add2Map(glblVarLst,"${WS_UPDT_DT_1}",WS_UPDT_DT_1)
    CommonUtil.add2Map(glblVarLst,"${WS_UPDT_DT_2}",WS_UPDT_DT_2)

    CommonUtil.add2Map(glblVarLst,"${WS_ACTV_CD_1}",WS_ACTV_CD_1)
    CommonUtil.add2Map(glblVarLst,"${WS_ACTV_CD_2}",WS_ACTV_CD_2)
    CommonUtil.add2Map(glblVarLst,"${SchemaNm}",SchemaNm)
    CommonUtil.add2Map(glblVarLst,"${WS_PREV_RUN_DT_YMD}",WS_PREV_RUN_DT_YMD)


  }


/*  test("SegDtls Object for NCE Segment when null should be failure") {
    val SW_SKIP_NCE = "N"

    var inputEntity = mock[ExtractFileEntity]

    val outputFilePath= ""
    val query1 = new Query("NCE_56_CUR","SELECT ADD.OUT_ADD_PROV_ID AS OUT_ADD_PROV_ID,ADD.OUT_ADD_ADR_ID_9 AS OUT_ADD_ADR_ID_9,ADD.TAX_ID_NBR AS TAX_ID_NBR,ADD.OUT_ADD_TYP_CD AS OUT_ADD_TYP_CD, COUNT(*) FROM ${SchemaNm}_PROV_TIN_ADR_CONTR_ORG PAO INNER JOIN ADD_FINAL_QRY ADD ON (PAO.PROV_ID = ADD.OUT_ADD_PROV_ID AND PAO.ADR_ID = ADD.OUT_ADD_ADR_ID_9) INNER JOIN ${SchemaNm}_PROV_TIN_PAY_AFFIL PTP ON (PTP.PROV_ID = ADD.OUT_ADD_PROV_ID AND PAO.TAX_ID_NBR = PTP.TAX_ID_NBR AND PTP.TAX_ID_NBR = ADD.TAX_ID_NBR ) INNER JOIN ${SchemaNm}_PROV_TIN_ADR PTA ON (PTA.PROV_ID = ADD.OUT_ADD_PROV_ID AND PTP.TAX_ID_NBR = PTA.TAX_ID_NBR AND PTA.TAX_ID_TYP_CD = PTP.TAX_ID_TYP_CD AND PAO.ADR_ID = PTA.ADR_ID AND PTA.ADR_TYP_CD = ADD.OUT_ADD_TYP_CD) GROUP BY ADD.OUT_ADD_PROV_ID ,ADD.OUT_ADD_ADR_ID_9 ,ADD.TAX_ID_NBR ,ADD.OUT_ADD_TYP_CD  HAVING COUNT(*)=1",null,null)
    val query2 = new Query("NCE_FNL_VIEW","SELECT 'ACO' AS OUT_ACO_REC_TYP_CD, PAO.PROV_ID AS OUT_ACO_PROV_ID, PAO.TAX_ID_NBR AS OUT_ACO_TIN, '000' AS OUT_ACO_MAID_3, PAO.ADR_ID AS OUT_ACO_MAID_9, CASE WHEN '${PTA_ADR_TYP_CD}' = 'L' THEN 'PR' WHEN '${PTA_ADR_TYP_CD}' = 'T' THEN 'MAIL' ELSE 'BILL' END AS OUT_ACO_MAID_TYP_CD, PAO.CONTR_ORG_CD AS OUT_ACO_CONT_ORG, PAO.PRI_CD AS OUT_ACO_PRI_CD, PAO.CORSP_ADR_IND AS OUT_ACO_CORR_CD, PAO.EFF_DT AS OUT_ACO_EFF_DATE, PAO.CANC_DT AS OUT_ACO_CAN_DATE, PAO.TMLN_RSN_TYP_CD AS OUT_ACO_CAN_REASON,PAO.LST_UPDT_DT AS PAO_LST_UPDT_DT, case when unix_timestamp(PAO.LST_UPDT_DT,'yyyy-MM-dd')  > unix_timestamp(${WS_PREV_RUN_DT_YMD},'yyyy-MM-dd') then (case when unix_timestamp(PAO.CANC_DT,'yyyy-MM-dd') < unix_timestamp('9999-12-31','yyyy-MM-dd') then 'C' else 'Y' end) else (case when unix_timestamp(PAO.CANC_DT,'yyyy-MM-dd') = unix_timestamp('9999-12-31','yyyy-MM-dd') then 'N' else '' end) end as OUT_ACO_CHG_IND FROM ${SchemaNm}_PROV_TIN_ADR_CONTR_ORG PAO INNER JOIN ACO_SEL_65_CUR SEL ON (PAO.PROV_ID = SEL.OUT_ADD_PROV_ID AND PAO.ADR_ID = SEL.OUT_ADD_ADR_ID_9) INNER JOIN ${SchemaNm}_PROV_TIN_PAY_AFFIL PTP ON (PTP.PROV_ID = SEL.OUT_ADD_PROV_ID AND PAO.TAX_ID_NBR = PTP.TAX_ID_NBR AND PTP.TAX_ID_NBR = SEL.TAX_ID_NBR ) INNER JOIN ${SchemaNm}_PROV_TIN_ADR PTA ON (PTA.PROV_ID = SEL.OUT_ADD_PROV_ID AND PTP.TAX_ID_NBR = PTA.TAX_ID_NBR AND PTA.TAX_ID_TYP_CD = PTP.TAX_ID_TYP_CD AND PAO.ADR_ID = PTA.ADR_ID AND PTA.ADR_TYP_CD = SEL.OUT_ADD_TYP_CD)",null,null)
    val queries = Seq(query1,query2)
    val segDtls = new SegmentDetails("NCE",
      "20",
      "OUT_ACO_REC_TYP_CD;OUT_ACO_PROV_ID;OUT_ACO_TIN;OUT_ACO_MAID_3;OUT_ACO_MAID_9;OUT_ACO_MAID_TYP_CD;OUT_ACO_CONT_ORG;OUT_ACO_PRI_CD;OUT_ACO_CORR_CD;OUT_ACO_EFF_DATE;OUT_ACO_CAN_DATE;OUT_ACO_CAN_REASON;OUT_ACO_CHG_IND",
      "3;9;9;3;9;4;4;1;1;10;10;2;1",
      "400",
      "",
      queries
    )
    val segDetailsSeq =Seq(segDtls)

    assert(genNCESeg(null,glblVarLst,SW_SKIP_NCE,outputFilePath)(globalContext).isFailure)

  }*/
/*
  test("SegDtls Object for NCE Segment when not null should be success") {
    val SW_SKIP_NCE= "N"
/*    val SchemaNm = "F5938DBE"
    val WS_PREV_RUN_DT_YMD = "9999-12-31"*/
    var inputEntity = mock[ExtractFileEntity]

    val outputFilePath= ""
    val query1 = new Query("NCE_56_CUR","SELECT ADD.OUT_ADD_PROV_ID AS OUT_ADD_PROV_ID,ADD.OUT_ADD_ADR_ID_9 AS OUT_ADD_ADR_ID_9,ADD.TAX_ID_NBR AS TAX_ID_NBR,ADD.OUT_ADD_TYP_CD AS OUT_ADD_TYP_CD, COUNT(*) FROM ${SchemaNm}_PROV_TIN_ADR_CONTR_ORG PAO INNER JOIN ADD_FINAL_QRY ADD ON (PAO.PROV_ID = ADD.OUT_ADD_PROV_ID AND PAO.ADR_ID = ADD.OUT_ADD_ADR_ID_9) INNER JOIN ${SchemaNm}_PROV_TIN_PAY_AFFIL PTP ON (PTP.PROV_ID = ADD.OUT_ADD_PROV_ID AND PAO.TAX_ID_NBR = PTP.TAX_ID_NBR AND PTP.TAX_ID_NBR = ADD.TAX_ID_NBR ) INNER JOIN ${SchemaNm}_PROV_TIN_ADR PTA ON (PTA.PROV_ID = ADD.OUT_ADD_PROV_ID AND PTP.TAX_ID_NBR = PTA.TAX_ID_NBR AND PTA.TAX_ID_TYP_CD = PTP.TAX_ID_TYP_CD AND PAO.ADR_ID = PTA.ADR_ID AND PTA.ADR_TYP_CD = ADD.OUT_ADD_TYP_CD) GROUP BY ADD.OUT_ADD_PROV_ID ,ADD.OUT_ADD_ADR_ID_9 ,ADD.TAX_ID_NBR ,ADD.OUT_ADD_TYP_CD  HAVING COUNT(*)=1",null,null)
    val query2 = new Query("NCE_FNL_VIEW","SELECT 'ACO' AS OUT_ACO_REC_TYP_CD, PAO.PROV_ID AS OUT_ACO_PROV_ID, PAO.TAX_ID_NBR AS OUT_ACO_TIN, '000' AS OUT_ACO_MAID_3, PAO.ADR_ID AS OUT_ACO_MAID_9, CASE WHEN '${PTA_ADR_TYP_CD}' = 'L' THEN 'PR' WHEN '${PTA_ADR_TYP_CD}' = 'T' THEN 'MAIL' ELSE 'BILL' END AS OUT_ACO_MAID_TYP_CD, PAO.CONTR_ORG_CD AS OUT_ACO_CONT_ORG, PAO.PRI_CD AS OUT_ACO_PRI_CD, PAO.CORSP_ADR_IND AS OUT_ACO_CORR_CD, PAO.EFF_DT AS OUT_ACO_EFF_DATE, PAO.CANC_DT AS OUT_ACO_CAN_DATE, PAO.TMLN_RSN_TYP_CD AS OUT_ACO_CAN_REASON,PAO.LST_UPDT_DT AS PAO_LST_UPDT_DT, case when unix_timestamp(PAO.LST_UPDT_DT,'yyyy-MM-dd')  > unix_timestamp(${WS_PREV_RUN_DT_YMD},'yyyy-MM-dd') then (case when unix_timestamp(PAO.CANC_DT,'yyyy-MM-dd') < unix_timestamp('9999-12-31','yyyy-MM-dd') then 'C' else 'Y' end) else (case when unix_timestamp(PAO.CANC_DT,'yyyy-MM-dd') = unix_timestamp('9999-12-31','yyyy-MM-dd') then 'N' else '' end) end as OUT_ACO_CHG_IND FROM ${SchemaNm}_PROV_TIN_ADR_CONTR_ORG PAO INNER JOIN ACO_SEL_65_CUR SEL ON (PAO.PROV_ID = SEL.OUT_ADD_PROV_ID AND PAO.ADR_ID = SEL.OUT_ADD_ADR_ID_9) INNER JOIN ${SchemaNm}_PROV_TIN_PAY_AFFIL PTP ON (PTP.PROV_ID = SEL.OUT_ADD_PROV_ID AND PAO.TAX_ID_NBR = PTP.TAX_ID_NBR AND PTP.TAX_ID_NBR = SEL.TAX_ID_NBR ) INNER JOIN ${SchemaNm}_PROV_TIN_ADR PTA ON (PTA.PROV_ID = SEL.OUT_ADD_PROV_ID AND PTP.TAX_ID_NBR = PTA.TAX_ID_NBR AND PTA.TAX_ID_TYP_CD = PTP.TAX_ID_TYP_CD AND PAO.ADR_ID = PTA.ADR_ID AND PTA.ADR_TYP_CD = SEL.OUT_ADD_TYP_CD)",null,null)
    val queries = Seq(query1,query2)
    val segDtls = new SegmentDetails("NCE",
      "20",
      "OUT_ACO_REC_TYP_CD;OUT_ACO_PROV_ID;OUT_ACO_TIN;OUT_ACO_MAID_3;OUT_ACO_MAID_9;OUT_ACO_MAID_TYP_CD;OUT_ACO_CONT_ORG;OUT_ACO_PRI_CD;OUT_ACO_CORR_CD;OUT_ACO_EFF_DATE;OUT_ACO_CAN_DATE;OUT_ACO_CAN_REASON;OUT_ACO_CHG_IND",
      "3;9;9;3;9;4;4;1;1;10;10;2;1",
      "400","",
      queries
    )
    val segDetailsSeq =Seq(segDtls)
    // inputEntity = new ExtractFileEntity("F5938RK4","PRV;ALT;PSP;SCO;PQI;HAS;PLI;PFA;TIN;PTI;TCO;NCE;ADD;PHO;ACT;LGS;LNG;HRS;HCA;ACO;AD1;CON;CDK;CSP;COS;CUL;NPI;COE","F5938DBE",segDetailsSeq)
    // when(inputEntity.segmentDetails).thenReturn(segDetailsSeq)
    /*   inputEntity.segmentDetails.map{
         s => s.segQueries.map{
           m => var key = m.name
             println("key:: " + key)
             var value = m.query
             println("value:: " +value)
         }
       }*/
    assert(genNCESeg(segDtls,glblVarLst,SW_SKIP_NCE,outputFilePath)(globalContext).isFailure)

  }

*/



/*  test("genNCESeg method should be failure if the TIN final view doesnt exist") {
    val query1 = new Query("NCE_56_CUR","SELECT ADD.OUT_ADD_PROV_ID AS OUT_ADD_PROV_ID,ADD.OUT_ADD_ADR_ID_9 AS OUT_ADD_ADR_ID_9,ADD.TAX_ID_NBR AS TAX_ID_NBR,ADD.OUT_ADD_TYP_CD AS OUT_ADD_TYP_CD, COUNT(*) FROM ${SchemaNm}_PROV_TIN_ADR_CONTR_ORG PAO INNER JOIN ADD_FINAL_QRY ADD ON (PAO.PROV_ID = ADD.OUT_ADD_PROV_ID AND PAO.ADR_ID = ADD.OUT_ADD_ADR_ID_9) INNER JOIN ${SchemaNm}_PROV_TIN_PAY_AFFIL PTP ON (PTP.PROV_ID = ADD.OUT_ADD_PROV_ID AND PAO.TAX_ID_NBR = PTP.TAX_ID_NBR AND PTP.TAX_ID_NBR = ADD.TAX_ID_NBR ) INNER JOIN ${SchemaNm}_PROV_TIN_ADR PTA ON (PTA.PROV_ID = ADD.OUT_ADD_PROV_ID AND PTP.TAX_ID_NBR = PTA.TAX_ID_NBR AND PTA.TAX_ID_TYP_CD = PTP.TAX_ID_TYP_CD AND PAO.ADR_ID = PTA.ADR_ID AND PTA.ADR_TYP_CD = ADD.OUT_ADD_TYP_CD) GROUP BY ADD.OUT_ADD_PROV_ID ,ADD.OUT_ADD_ADR_ID_9 ,ADD.TAX_ID_NBR ,ADD.OUT_ADD_TYP_CD  HAVING COUNT(*)=1",null,null)
    val query2 = new Query("NCE_FNL_VIEW","SELECT 'ACO' AS OUT_ACO_REC_TYP_CD, PAO.PROV_ID AS OUT_ACO_PROV_ID, PAO.TAX_ID_NBR AS OUT_ACO_TIN, '000' AS OUT_ACO_MAID_3, PAO.ADR_ID AS OUT_ACO_MAID_9, CASE WHEN '${PTA_ADR_TYP_CD}' = 'L' THEN 'PR' WHEN '${PTA_ADR_TYP_CD}' = 'T' THEN 'MAIL' ELSE 'BILL' END AS OUT_ACO_MAID_TYP_CD, PAO.CONTR_ORG_CD AS OUT_ACO_CONT_ORG, PAO.PRI_CD AS OUT_ACO_PRI_CD, PAO.CORSP_ADR_IND AS OUT_ACO_CORR_CD, PAO.EFF_DT AS OUT_ACO_EFF_DATE, PAO.CANC_DT AS OUT_ACO_CAN_DATE, PAO.TMLN_RSN_TYP_CD AS OUT_ACO_CAN_REASON,PAO.LST_UPDT_DT AS PAO_LST_UPDT_DT, case when unix_timestamp(PAO.LST_UPDT_DT,'yyyy-MM-dd')  > unix_timestamp(${WS_PREV_RUN_DT_YMD},'yyyy-MM-dd') then (case when unix_timestamp(PAO.CANC_DT,'yyyy-MM-dd') < unix_timestamp('9999-12-31','yyyy-MM-dd') then 'C' else 'Y' end) else (case when unix_timestamp(PAO.CANC_DT,'yyyy-MM-dd') = unix_timestamp('9999-12-31','yyyy-MM-dd') then 'N' else '' end) end as OUT_ACO_CHG_IND FROM ${SchemaNm}_PROV_TIN_ADR_CONTR_ORG PAO INNER JOIN ACO_SEL_65_CUR SEL ON (PAO.PROV_ID = SEL.OUT_ADD_PROV_ID AND PAO.ADR_ID = SEL.OUT_ADD_ADR_ID_9) INNER JOIN ${SchemaNm}_PROV_TIN_PAY_AFFIL PTP ON (PTP.PROV_ID = SEL.OUT_ADD_PROV_ID AND PAO.TAX_ID_NBR = PTP.TAX_ID_NBR AND PTP.TAX_ID_NBR = SEL.TAX_ID_NBR ) INNER JOIN ${SchemaNm}_PROV_TIN_ADR PTA ON (PTA.PROV_ID = SEL.OUT_ADD_PROV_ID AND PTP.TAX_ID_NBR = PTA.TAX_ID_NBR AND PTA.TAX_ID_TYP_CD = PTP.TAX_ID_TYP_CD AND PAO.ADR_ID = PTA.ADR_ID AND PTA.ADR_TYP_CD = SEL.OUT_ADD_TYP_CD)",null,null)
    val queries = Seq(query1,query2)
    val segDtls = new SegmentDetails("NCE",
      "20",
      "OUT_ACO_REC_TYP_CD;OUT_ACO_PROV_ID;OUT_ACO_TIN;OUT_ACO_MAID_3;OUT_ACO_MAID_9;OUT_ACO_MAID_TYP_CD;OUT_ACO_CONT_ORG;OUT_ACO_PRI_CD;OUT_ACO_CORR_CD;OUT_ACO_EFF_DATE;OUT_ACO_CAN_DATE;OUT_ACO_CAN_REASON;OUT_ACO_CHG_IND",
      "3;9;9;3;9;4;4;1;1;10;10;2;1",
      "400","",
      queries
    )
    val SW_SKIP_NCE = "N"
/*    val WS_PREV_RUN_DT_YMD = "9999-12-31"*/
    val segDetailsSeq =Seq(segDtls)
    val inputEntity = new ExtractFileEntity("F5938RK4","PRV;ALT;PSP;SCO;PQI;HAS;PLI;PFA;TIN;PTI;TCO;NCE;ADD;PHO;ACT;LGS;LNG;HRS;HCA;ACO;AD1;CON;CDK;CSP;COS;CUL;NPI;COE","F5938DBE","NA","NA","NA",segDetailsSeq)
    val prevRunDate =""
    val outputFilePath ="maprfs:///user/sgoyal34"
    val spark=globalContext.sparkSession
    //val SchemaNm = "F5938DBE"
    import spark.implicits._
    val s=Seq((1233, 176),
      (234, 2323),
      (30000, 29898))
    val df=s.toDF("OUT_PHO_PROV_ID","OUT_PHO_TEL_NBR")
   // df.createOrReplaceTempView("TIN_FNL_VIEW")
    println("======================="+spark.catalog.tableExists("TIN_FNL_VIEW")+"========")

    ///*  val thrownExcep = intercept[Exception] {
   //     acoSegGen(inputEntity,SW_SKIP_ACO, WS_PREV_RUN_DT_YMD, outputFilePath)(globalContext)
      //}*/
    assert(genNCESeg(segDtls,glblVarLst,SW_SKIP_NCE, outputFilePath)(globalContext).isFailure)
  }*/


/*

  test("genNCESeg method should be  success if the TIN final view exists") {
    val query1 = new Query("NCE_56_CUR","SELECT ADD.OUT_ADD_PROV_ID AS OUT_ADD_PROV_ID,ADD.OUT_ADD_ADR_ID_9 AS OUT_ADD_ADR_ID_9,ADD.TAX_ID_NBR AS TAX_ID_NBR,ADD.OUT_ADD_TYP_CD AS OUT_ADD_TYP_CD, COUNT(*) FROM ${SchemaNm}_PROV_TIN_ADR_CONTR_ORG PAO INNER JOIN ADD_FINAL_QRY ADD ON (PAO.PROV_ID = ADD.OUT_ADD_PROV_ID AND PAO.ADR_ID = ADD.OUT_ADD_ADR_ID_9) INNER JOIN ${SchemaNm}_PROV_TIN_PAY_AFFIL PTP ON (PTP.PROV_ID = ADD.OUT_ADD_PROV_ID AND PAO.TAX_ID_NBR = PTP.TAX_ID_NBR AND PTP.TAX_ID_NBR = ADD.TAX_ID_NBR ) INNER JOIN ${SchemaNm}_PROV_TIN_ADR PTA ON (PTA.PROV_ID = ADD.OUT_ADD_PROV_ID AND PTP.TAX_ID_NBR = PTA.TAX_ID_NBR AND PTA.TAX_ID_TYP_CD = PTP.TAX_ID_TYP_CD AND PAO.ADR_ID = PTA.ADR_ID AND PTA.ADR_TYP_CD = ADD.OUT_ADD_TYP_CD) GROUP BY ADD.OUT_ADD_PROV_ID ,ADD.OUT_ADD_ADR_ID_9 ,ADD.TAX_ID_NBR ,ADD.OUT_ADD_TYP_CD  HAVING COUNT(*)=1",null,null)
    val query2 = new Query("NCE_FNL_VIEW","SELECT 'ACO' AS OUT_ACO_REC_TYP_CD, PAO.PROV_ID AS OUT_ACO_PROV_ID, PAO.TAX_ID_NBR AS OUT_ACO_TIN, '000' AS OUT_ACO_MAID_3, PAO.ADR_ID AS OUT_ACO_MAID_9, CASE WHEN '${PTA_ADR_TYP_CD}' = 'L' THEN 'PR' WHEN '${PTA_ADR_TYP_CD}' = 'T' THEN 'MAIL' ELSE 'BILL' END AS OUT_ACO_MAID_TYP_CD, PAO.CONTR_ORG_CD AS OUT_ACO_CONT_ORG, PAO.PRI_CD AS OUT_ACO_PRI_CD, PAO.CORSP_ADR_IND AS OUT_ACO_CORR_CD, PAO.EFF_DT AS OUT_ACO_EFF_DATE, PAO.CANC_DT AS OUT_ACO_CAN_DATE, PAO.TMLN_RSN_TYP_CD AS OUT_ACO_CAN_REASON,PAO.LST_UPDT_DT AS PAO_LST_UPDT_DT, case when unix_timestamp(PAO.LST_UPDT_DT,'yyyy-MM-dd')  > unix_timestamp(${WS_PREV_RUN_DT_YMD},'yyyy-MM-dd') then (case when unix_timestamp(PAO.CANC_DT,'yyyy-MM-dd') < unix_timestamp('9999-12-31','yyyy-MM-dd') then 'C' else 'Y' end) else (case when unix_timestamp(PAO.CANC_DT,'yyyy-MM-dd') = unix_timestamp('9999-12-31','yyyy-MM-dd') then 'N' else '' end) end as OUT_ACO_CHG_IND FROM ${SchemaNm}_PROV_TIN_ADR_CONTR_ORG PAO INNER JOIN ACO_SEL_65_CUR SEL ON (PAO.PROV_ID = SEL.OUT_ADD_PROV_ID AND PAO.ADR_ID = SEL.OUT_ADD_ADR_ID_9) INNER JOIN ${SchemaNm}_PROV_TIN_PAY_AFFIL PTP ON (PTP.PROV_ID = SEL.OUT_ADD_PROV_ID AND PAO.TAX_ID_NBR = PTP.TAX_ID_NBR AND PTP.TAX_ID_NBR = SEL.TAX_ID_NBR ) INNER JOIN ${SchemaNm}_PROV_TIN_ADR PTA ON (PTA.PROV_ID = SEL.OUT_ADD_PROV_ID AND PTP.TAX_ID_NBR = PTA.TAX_ID_NBR AND PTA.TAX_ID_TYP_CD = PTP.TAX_ID_TYP_CD AND PAO.ADR_ID = PTA.ADR_ID AND PTA.ADR_TYP_CD = SEL.OUT_ADD_TYP_CD)",null,null)
    val queries = Seq(query1,query2)
    val segDtls = new SegmentDetails("NCE",
      "20",
      "OUT_ACO_REC_TYP_CD;OUT_ACO_PROV_ID;OUT_ACO_TIN;OUT_ACO_MAID_3;OUT_ACO_MAID_9;OUT_ACO_MAID_TYP_CD;OUT_ACO_CONT_ORG;OUT_ACO_PRI_CD;OUT_ACO_CORR_CD;OUT_ACO_EFF_DATE;OUT_ACO_CAN_DATE;OUT_ACO_CAN_REASON;OUT_ACO_CHG_IND",
      "3;9;9;3;9;4;4;1;1;10;10;2;1",
      "400",
      "",
      queries
    )
    val SW_SKIP_NCE = "N"
/*    val WS_PREV_RUN_DT_YMD = "9999-12-31"*/
    val segDetailsSeq =Seq(segDtls)
    val inputEntity = new ExtractFileEntity("F5938RK4","PRV;ALT;PSP;SCO;PQI;HAS;PLI;PFA;TIN;PTI;TCO;NCE;ADD;PHO;ACT;LGS;LNG;HRS;HCA;ACO;AD1;CON;CDK;CSP;COS;CUL;NPI;COE","F5938DBE","NA","NA","NA",segDetailsSeq)
    val prevRunDate =""
    val outputFilePath ="maprfs:///user/sgoyal34"
    val spark=globalContext.sparkSession
    var varLst = collection.mutable.Map[String, String]()
    import spark.implicits._
    val s=Seq((1233, 176),
      (234, 2323),
      (30000, 29898))
    val df=s.toDF("OUT_PHO_PROV_ID","OUT_PHO_TEL_NBR")
    df.createOrReplaceTempView("TIN_FNL_VIEW")
    assert(genNCESeg(segDtls,glblVarLst,SW_SKIP_NCE,outputFilePath)(globalContext).isFailure)
  }
*/



  /*   test("genNCESeg method should return 'Y' if skip flag is 'N'") {
        val query1 = new Query("NCE_56_CUR","SELECT ADD.OUT_ADD_PROV_ID AS OUT_ADD_PROV_ID,ADD.OUT_ADD_ADR_ID_9 AS OUT_ADD_ADR_ID_9,ADD.TAX_ID_NBR AS TAX_ID_NBR,ADD.OUT_ADD_TYP_CD AS OUT_ADD_TYP_CD, COUNT(*) FROM ${SchemaNm}_PROV_TIN_ADR_CONTR_ORG PAO INNER JOIN ADD_FINAL_QRY ADD ON (PAO.PROV_ID = ADD.OUT_ADD_PROV_ID AND PAO.ADR_ID = ADD.OUT_ADD_ADR_ID_9) INNER JOIN ${SchemaNm}_PROV_TIN_PAY_AFFIL PTP ON (PTP.PROV_ID = ADD.OUT_ADD_PROV_ID AND PAO.TAX_ID_NBR = PTP.TAX_ID_NBR AND PTP.TAX_ID_NBR = ADD.TAX_ID_NBR ) INNER JOIN ${SchemaNm}_PROV_TIN_ADR PTA ON (PTA.PROV_ID = ADD.OUT_ADD_PROV_ID AND PTP.TAX_ID_NBR = PTA.TAX_ID_NBR AND PTA.TAX_ID_TYP_CD = PTP.TAX_ID_TYP_CD AND PAO.ADR_ID = PTA.ADR_ID AND PTA.ADR_TYP_CD = ADD.OUT_ADD_TYP_CD) GROUP BY ADD.OUT_ADD_PROV_ID ,ADD.OUT_ADD_ADR_ID_9 ,ADD.TAX_ID_NBR ,ADD.OUT_ADD_TYP_CD  HAVING COUNT(*)=1",null,null)
        val query2 = new Query("NCE_FNL_VIEW","SELECT 'ACO' AS OUT_ACO_REC_TYP_CD, PAO.PROV_ID AS OUT_ACO_PROV_ID, PAO.TAX_ID_NBR AS OUT_ACO_TIN, '000' AS OUT_ACO_MAID_3, PAO.ADR_ID AS OUT_ACO_MAID_9, CASE WHEN '${PTA_ADR_TYP_CD}' = 'L' THEN 'PR' WHEN '${PTA_ADR_TYP_CD}' = 'T' THEN 'MAIL' ELSE 'BILL' END AS OUT_ACO_MAID_TYP_CD, PAO.CONTR_ORG_CD AS OUT_ACO_CONT_ORG, PAO.PRI_CD AS OUT_ACO_PRI_CD, PAO.CORSP_ADR_IND AS OUT_ACO_CORR_CD, PAO.EFF_DT AS OUT_ACO_EFF_DATE, PAO.CANC_DT AS OUT_ACO_CAN_DATE, PAO.TMLN_RSN_TYP_CD AS OUT_ACO_CAN_REASON,PAO.LST_UPDT_DT AS PAO_LST_UPDT_DT, case when unix_timestamp(PAO.LST_UPDT_DT,'yyyy-MM-dd')  > unix_timestamp(${WS_PREV_RUN_DT_YMD},'yyyy-MM-dd') then (case when unix_timestamp(PAO.CANC_DT,'yyyy-MM-dd') < unix_timestamp('9999-12-31','yyyy-MM-dd') then 'C' else 'Y' end) else (case when unix_timestamp(PAO.CANC_DT,'yyyy-MM-dd') = unix_timestamp('9999-12-31','yyyy-MM-dd') then 'N' else '' end) end as OUT_ACO_CHG_IND FROM ${SchemaNm}_PROV_TIN_ADR_CONTR_ORG PAO INNER JOIN ACO_SEL_65_CUR SEL ON (PAO.PROV_ID = SEL.OUT_ADD_PROV_ID AND PAO.ADR_ID = SEL.OUT_ADD_ADR_ID_9) INNER JOIN ${SchemaNm}_PROV_TIN_PAY_AFFIL PTP ON (PTP.PROV_ID = SEL.OUT_ADD_PROV_ID AND PAO.TAX_ID_NBR = PTP.TAX_ID_NBR AND PTP.TAX_ID_NBR = SEL.TAX_ID_NBR ) INNER JOIN ${SchemaNm}_PROV_TIN_ADR PTA ON (PTA.PROV_ID = SEL.OUT_ADD_PROV_ID AND PTP.TAX_ID_NBR = PTA.TAX_ID_NBR AND PTA.TAX_ID_TYP_CD = PTP.TAX_ID_TYP_CD AND PAO.ADR_ID = PTA.ADR_ID AND PTA.ADR_TYP_CD = SEL.OUT_ADD_TYP_CD)",null,null)
        val queries = Seq(query1,query2)
       val segDtls = new SegmentDetails("NCE",
         "20",
         "OUT_ACO_REC_TYP_CD;OUT_ACO_PROV_ID;OUT_ACO_TIN;OUT_ACO_MAID_3;OUT_ACO_MAID_9;OUT_ACO_MAID_TYP_CD;OUT_ACO_CONT_ORG;OUT_ACO_PRI_CD;OUT_ACO_CORR_CD;OUT_ACO_EFF_DATE;OUT_ACO_CAN_DATE;OUT_ACO_CAN_REASON;OUT_ACO_CHG_IND",
         "3;9;9;3;9;4;4;1;1;10;10;2;1",
         "400",
         "",
         queries
       )
        val SW_SKIP_NCE = "N"
        val WS_PREV_RUN_DT_YMD = "9999-12-31"
        val segDetailsSeq =Seq(segDtls)
        val inputEntity = new ExtractFileEntity("F5938RK4","PRV;ALT;PSP;SCO;PQI;HAS;PLI;PFA;TIN;PTI;TCO;NCE;ADD;PHO;ACT;LGS;LNG;HRS;HCA;ACO;AD1;CON;CDK;CSP;COS;CUL;NPI;COE","F5938DBE",segDetailsSeq)
        val prevRunDate =""
        val outputFilePath ="maprfs:///user/sgoyal34"
        val spark=globalContext.sparkSession
        //val SchemaNm = "F5938DBE"
        import spark.implicits._
        val s=Seq((1233, 176),
          (234, 2323),
          (30000, 29898))
        val df=s.toDF("OUT_PHO_PROV_ID","OUT_PHO_TEL_NBR")
        df.createOrReplaceTempView("TIN_FNL_VIEW")

        println("=======================" + spark.catalog.tableExists("ADD_FINAL_QRY") + "========")
        var varLst = collection.mutable.Map[String, String]()

        assert(genNCESeg(segDtls,glblVarLst,SW_SKIP_NCE,outputFilePath)(globalContext).get.equals("Y"))
      }*/


  test("genNCESeg method should return 'N' if the skip flag is 'Y'") {
    val query1 = new Query("NCE_56_CUR","SELECT ADD.OUT_ADD_PROV_ID AS OUT_ADD_PROV_ID,ADD.OUT_ADD_ADR_ID_9 AS OUT_ADD_ADR_ID_9,ADD.TAX_ID_NBR AS TAX_ID_NBR,ADD.OUT_ADD_TYP_CD AS OUT_ADD_TYP_CD, COUNT(*) FROM ${SchemaNm}_PROV_TIN_ADR_CONTR_ORG PAO INNER JOIN ADD_FINAL_QRY ADD ON (PAO.PROV_ID = ADD.OUT_ADD_PROV_ID AND PAO.ADR_ID = ADD.OUT_ADD_ADR_ID_9) INNER JOIN ${SchemaNm}_PROV_TIN_PAY_AFFIL PTP ON (PTP.PROV_ID = ADD.OUT_ADD_PROV_ID AND PAO.TAX_ID_NBR = PTP.TAX_ID_NBR AND PTP.TAX_ID_NBR = ADD.TAX_ID_NBR ) INNER JOIN ${SchemaNm}_PROV_TIN_ADR PTA ON (PTA.PROV_ID = ADD.OUT_ADD_PROV_ID AND PTP.TAX_ID_NBR = PTA.TAX_ID_NBR AND PTA.TAX_ID_TYP_CD = PTP.TAX_ID_TYP_CD AND PAO.ADR_ID = PTA.ADR_ID AND PTA.ADR_TYP_CD = ADD.OUT_ADD_TYP_CD) GROUP BY ADD.OUT_ADD_PROV_ID ,ADD.OUT_ADD_ADR_ID_9 ,ADD.TAX_ID_NBR ,ADD.OUT_ADD_TYP_CD  HAVING COUNT(*)=1",null,null)
    val query2 = new Query("NCE_FNL_VIEW","SELECT 'ACO' AS OUT_ACO_REC_TYP_CD, PAO.PROV_ID AS OUT_ACO_PROV_ID, PAO.TAX_ID_NBR AS OUT_ACO_TIN, '000' AS OUT_ACO_MAID_3, PAO.ADR_ID AS OUT_ACO_MAID_9, CASE WHEN '${PTA_ADR_TYP_CD}' = 'L' THEN 'PR' WHEN '${PTA_ADR_TYP_CD}' = 'T' THEN 'MAIL' ELSE 'BILL' END AS OUT_ACO_MAID_TYP_CD, PAO.CONTR_ORG_CD AS OUT_ACO_CONT_ORG, PAO.PRI_CD AS OUT_ACO_PRI_CD, PAO.CORSP_ADR_IND AS OUT_ACO_CORR_CD, PAO.EFF_DT AS OUT_ACO_EFF_DATE, PAO.CANC_DT AS OUT_ACO_CAN_DATE, PAO.TMLN_RSN_TYP_CD AS OUT_ACO_CAN_REASON,PAO.LST_UPDT_DT AS PAO_LST_UPDT_DT, case when unix_timestamp(PAO.LST_UPDT_DT,'yyyy-MM-dd')  > unix_timestamp(${WS_PREV_RUN_DT_YMD},'yyyy-MM-dd') then (case when unix_timestamp(PAO.CANC_DT,'yyyy-MM-dd') < unix_timestamp('9999-12-31','yyyy-MM-dd') then 'C' else 'Y' end) else (case when unix_timestamp(PAO.CANC_DT,'yyyy-MM-dd') = unix_timestamp('9999-12-31','yyyy-MM-dd') then 'N' else '' end) end as OUT_ACO_CHG_IND FROM ${SchemaNm}_PROV_TIN_ADR_CONTR_ORG PAO INNER JOIN ACO_SEL_65_CUR SEL ON (PAO.PROV_ID = SEL.OUT_ADD_PROV_ID AND PAO.ADR_ID = SEL.OUT_ADD_ADR_ID_9) INNER JOIN ${SchemaNm}_PROV_TIN_PAY_AFFIL PTP ON (PTP.PROV_ID = SEL.OUT_ADD_PROV_ID AND PAO.TAX_ID_NBR = PTP.TAX_ID_NBR AND PTP.TAX_ID_NBR = SEL.TAX_ID_NBR ) INNER JOIN ${SchemaNm}_PROV_TIN_ADR PTA ON (PTA.PROV_ID = SEL.OUT_ADD_PROV_ID AND PTP.TAX_ID_NBR = PTA.TAX_ID_NBR AND PTA.TAX_ID_TYP_CD = PTP.TAX_ID_TYP_CD AND PAO.ADR_ID = PTA.ADR_ID AND PTA.ADR_TYP_CD = SEL.OUT_ADD_TYP_CD)",null,null)
    val queries = Seq(query1,query2)
    val segDtls = new SegmentDetails("NCE",
      "20",
      "OUT_ACO_REC_TYP_CD;OUT_ACO_PROV_ID;OUT_ACO_TIN;OUT_ACO_MAID_3;OUT_ACO_MAID_9;OUT_ACO_MAID_TYP_CD;OUT_ACO_CONT_ORG;OUT_ACO_PRI_CD;OUT_ACO_CORR_CD;OUT_ACO_EFF_DATE;OUT_ACO_CAN_DATE;OUT_ACO_CAN_REASON;OUT_ACO_CHG_IND",
      "3;9;9;3;9;4;4;1;1;10;10;2;1",
      "400",
      "",
      queries
    )
    val SW_SKIP_NCE = "Y"
/*    val WS_PREV_RUN_DT_YMD = "9999-12-31"*/
    val segDetailsSeq =Seq(segDtls)
    val inputEntity = new ExtractFileEntity("F5938RK4","PRV;ALT;PSP;SCO;PQI;HAS;PLI;PFA;TIN;PTI;TCO;NCE;ADD;PHO;ACT;LGS;LNG;HRS;HCA;ACO;AD1;CON;CDK;CSP;COS;CUL;NPI;COE","F5938DBE","NA","NA","NA",segDetailsSeq)
    val prevRunDate =""
    val outputFilePath ="maprfs:///user/sgoyal34"
    val spark=globalContext.sparkSession
    //val SchemaNm = "F5938DBE"
    import spark.implicits._
    val s=Seq((1233, 176),
      (234, 2323),
      (30000, 29898))
    val df=s.toDF("OUT_PHO_PROV_ID","OUT_PHO_TEL_NBR")
    df.createOrReplaceTempView("TIN_FNL_VIEW")

    println("=======================" + spark.catalog.tableExists("ADD_FINAL_QRY") + "========")
    assert(genNCESeg(segDtls,glblVarLst,SW_SKIP_NCE, outputFilePath)(globalContext).get.equals("N"))
  }


  test("genNCESeg method should return 'N' if no valid values for NCE present in segDtls") {
    val query1 = new Query("NCE_SEL_65_CUR","SELECT ADD.OUT_ADD_PROV_ID AS OUT_ADD_PROV_ID,ADD.OUT_ADD_ADR_ID_9 AS OUT_ADD_ADR_ID_9,ADD.TAX_ID_NBR AS TAX_ID_NBR,ADD.OUT_ADD_TYP_CD AS OUT_ADD_TYP_CD, COUNT(*) FROM ${SchemaNm}_PROV_TIN_ADR_CONTR_ORG PAO INNER JOIN ADD_FINAL_QRY ADD ON (PAO.PROV_ID = ADD.OUT_ADD_PROV_ID AND PAO.ADR_ID = ADD.OUT_ADD_ADR_ID_9) INNER JOIN ${SchemaNm}_PROV_TIN_PAY_AFFIL PTP ON (PTP.PROV_ID = ADD.OUT_ADD_PROV_ID AND PAO.TAX_ID_NBR = PTP.TAX_ID_NBR AND PTP.TAX_ID_NBR = ADD.TAX_ID_NBR ) INNER JOIN ${SchemaNm}_PROV_TIN_ADR PTA ON (PTA.PROV_ID = ADD.OUT_ADD_PROV_ID AND PTP.TAX_ID_NBR = PTA.TAX_ID_NBR AND PTA.TAX_ID_TYP_CD = PTP.TAX_ID_TYP_CD AND PAO.ADR_ID = PTA.ADR_ID AND PTA.ADR_TYP_CD = ADD.OUT_ADD_TYP_CD) GROUP BY ADD.OUT_ADD_PROV_ID ,ADD.OUT_ADD_ADR_ID_9 ,ADD.TAX_ID_NBR ,ADD.OUT_ADD_TYP_CD  HAVING COUNT(*)=1",null,null)
    val query2 = new Query("NCE_65_CUR","SELECT 'ACO' AS OUT_ACO_REC_TYP_CD, PAO.PROV_ID AS OUT_ACO_PROV_ID, PAO.TAX_ID_NBR AS OUT_ACO_TIN, '000' AS OUT_ACO_MAID_3, PAO.ADR_ID AS OUT_ACO_MAID_9, CASE WHEN '${PTA_ADR_TYP_CD}' = 'L' THEN 'PR' WHEN '${PTA_ADR_TYP_CD}' = 'T' THEN 'MAIL' ELSE 'BILL' END AS OUT_ACO_MAID_TYP_CD, PAO.CONTR_ORG_CD AS OUT_ACO_CONT_ORG, PAO.PRI_CD AS OUT_ACO_PRI_CD, PAO.CORSP_ADR_IND AS OUT_ACO_CORR_CD, PAO.EFF_DT AS OUT_ACO_EFF_DATE, PAO.CANC_DT AS OUT_ACO_CAN_DATE, PAO.TMLN_RSN_TYP_CD AS OUT_ACO_CAN_REASON,PAO.LST_UPDT_DT AS PAO_LST_UPDT_DT, case when unix_timestamp(PAO.LST_UPDT_DT,'yyyy-MM-dd')  > unix_timestamp(${WS_PREV_RUN_DT_YMD},'yyyy-MM-dd') then (case when unix_timestamp(PAO.CANC_DT,'yyyy-MM-dd') < unix_timestamp('9999-12-31','yyyy-MM-dd') then 'C' else 'Y' end) else (case when unix_timestamp(PAO.CANC_DT,'yyyy-MM-dd') = unix_timestamp('9999-12-31','yyyy-MM-dd') then 'N' else '' end) end as OUT_ACO_CHG_IND FROM ${SchemaNm}_PROV_TIN_ADR_CONTR_ORG PAO INNER JOIN ACO_SEL_65_CUR SEL ON (PAO.PROV_ID = SEL.OUT_ADD_PROV_ID AND PAO.ADR_ID = SEL.OUT_ADD_ADR_ID_9) INNER JOIN ${SchemaNm}_PROV_TIN_PAY_AFFIL PTP ON (PTP.PROV_ID = SEL.OUT_ADD_PROV_ID AND PAO.TAX_ID_NBR = PTP.TAX_ID_NBR AND PTP.TAX_ID_NBR = SEL.TAX_ID_NBR ) INNER JOIN ${SchemaNm}_PROV_TIN_ADR PTA ON (PTA.PROV_ID = SEL.OUT_ADD_PROV_ID AND PTP.TAX_ID_NBR = PTA.TAX_ID_NBR AND PTA.TAX_ID_TYP_CD = PTP.TAX_ID_TYP_CD AND PAO.ADR_ID = PTA.ADR_ID AND PTA.ADR_TYP_CD = SEL.OUT_ADD_TYP_CD)",null,null)
    val queries = Seq(query1,query2)
    val segDtls = new SegmentDetails("NCE1",
      "20",
      "OUT_ACO_REC_TYP_CD;OUT_ACO_PROV_ID;OUT_ACO_TIN;OUT_ACO_MAID_3;OUT_ACO_MAID_9;OUT_ACO_MAID_TYP_CD;OUT_ACO_CONT_ORG;OUT_ACO_PRI_CD;OUT_ACO_CORR_CD;OUT_ACO_EFF_DATE;OUT_ACO_CAN_DATE;OUT_ACO_CAN_REASON;OUT_ACO_CHG_IND",
      "3;9;9;3;9;4;4;1;1;10;10;2;1",
      "400",
      "",
      queries
    )
    val SW_SKIP_NCE = "N"
/*    val WS_PREV_RUN_DT_YMD = "9999-12-31"*/
    val segDetailsSeq =Seq(segDtls)
    val inputEntity = new ExtractFileEntity("F5938RK4","PRV;ALT;PSP;SCO;PQI;HAS;PLI;PFA;TIN;PTI;TCO;NCE;ADD;PHO;ACT;LGS;LNG;HRS;HCA;ACO;AD1;CON;CDK;CSP;COS;CUL;NPI;COE","F5938DBE","NA","NA","NA",segDetailsSeq)
    val prevRunDate =""
    val outputFilePath ="maprfs:///user/sgoyal34"
    val spark=globalContext.sparkSession
    //val SchemaNm = "F5938DBE"
    import spark.implicits._
    val s=Seq((1233, 176),
      (234, 2323),
      (30000, 29898))
    val df=s.toDF("OUT_PHO_PROV_ID","OUT_PHO_TEL_NBR")
    df.createOrReplaceTempView("TIN_FNL_VIEW")
    Logger.log.info("")
    println("=======================" + spark.catalog.tableExists("TIN_FNL_VIEW") + "========")
    assert(genNCESeg(segDtls,glblVarLst,SW_SKIP_NCE,outputFilePath)(globalContext).get.equals("N"))
  }


  test("genNCESeg method should return 'N' if no valid key for NCE present in segDtls") {
    val query1 = new Query("NCE1_SEL_65_CUR","SELECT ADD.OUT_ADD_PROV_ID AS OUT_ADD_PROV_ID,ADD.OUT_ADD_ADR_ID_9 AS OUT_ADD_ADR_ID_9,ADD.TAX_ID_NBR AS TAX_ID_NBR,ADD.OUT_ADD_TYP_CD AS OUT_ADD_TYP_CD, COUNT(*) FROM ${SchemaNm}_PROV_TIN_ADR_CONTR_ORG PAO INNER JOIN ADD_FINAL_QRY ADD ON (PAO.PROV_ID = ADD.OUT_ADD_PROV_ID AND PAO.ADR_ID = ADD.OUT_ADD_ADR_ID_9) INNER JOIN ${SchemaNm}_PROV_TIN_PAY_AFFIL PTP ON (PTP.PROV_ID = ADD.OUT_ADD_PROV_ID AND PAO.TAX_ID_NBR = PTP.TAX_ID_NBR AND PTP.TAX_ID_NBR = ADD.TAX_ID_NBR ) INNER JOIN ${SchemaNm}_PROV_TIN_ADR PTA ON (PTA.PROV_ID = ADD.OUT_ADD_PROV_ID AND PTP.TAX_ID_NBR = PTA.TAX_ID_NBR AND PTA.TAX_ID_TYP_CD = PTP.TAX_ID_TYP_CD AND PAO.ADR_ID = PTA.ADR_ID AND PTA.ADR_TYP_CD = ADD.OUT_ADD_TYP_CD) GROUP BY ADD.OUT_ADD_PROV_ID ,ADD.OUT_ADD_ADR_ID_9 ,ADD.TAX_ID_NBR ,ADD.OUT_ADD_TYP_CD  HAVING COUNT(*)=1",null,null)
    val query2 = new Query("NCE1_65_CUR","SELECT 'ACO' AS OUT_ACO_REC_TYP_CD, PAO.PROV_ID AS OUT_ACO_PROV_ID, PAO.TAX_ID_NBR AS OUT_ACO_TIN, '000' AS OUT_ACO_MAID_3, PAO.ADR_ID AS OUT_ACO_MAID_9, CASE WHEN '${PTA_ADR_TYP_CD}' = 'L' THEN 'PR' WHEN '${PTA_ADR_TYP_CD}' = 'T' THEN 'MAIL' ELSE 'BILL' END AS OUT_ACO_MAID_TYP_CD, PAO.CONTR_ORG_CD AS OUT_ACO_CONT_ORG, PAO.PRI_CD AS OUT_ACO_PRI_CD, PAO.CORSP_ADR_IND AS OUT_ACO_CORR_CD, PAO.EFF_DT AS OUT_ACO_EFF_DATE, PAO.CANC_DT AS OUT_ACO_CAN_DATE, PAO.TMLN_RSN_TYP_CD AS OUT_ACO_CAN_REASON,PAO.LST_UPDT_DT AS PAO_LST_UPDT_DT, case when unix_timestamp(PAO.LST_UPDT_DT,'yyyy-MM-dd')  > unix_timestamp(${WS_PREV_RUN_DT_YMD},'yyyy-MM-dd') then (case when unix_timestamp(PAO.CANC_DT,'yyyy-MM-dd') < unix_timestamp('9999-12-31','yyyy-MM-dd') then 'C' else 'Y' end) else (case when unix_timestamp(PAO.CANC_DT,'yyyy-MM-dd') = unix_timestamp('9999-12-31','yyyy-MM-dd') then 'N' else '' end) end as OUT_ACO_CHG_IND FROM ${SchemaNm}_PROV_TIN_ADR_CONTR_ORG PAO INNER JOIN ACO_SEL_65_CUR SEL ON (PAO.PROV_ID = SEL.OUT_ADD_PROV_ID AND PAO.ADR_ID = SEL.OUT_ADD_ADR_ID_9) INNER JOIN ${SchemaNm}_PROV_TIN_PAY_AFFIL PTP ON (PTP.PROV_ID = SEL.OUT_ADD_PROV_ID AND PAO.TAX_ID_NBR = PTP.TAX_ID_NBR AND PTP.TAX_ID_NBR = SEL.TAX_ID_NBR ) INNER JOIN ${SchemaNm}_PROV_TIN_ADR PTA ON (PTA.PROV_ID = SEL.OUT_ADD_PROV_ID AND PTP.TAX_ID_NBR = PTA.TAX_ID_NBR AND PTA.TAX_ID_TYP_CD = PTP.TAX_ID_TYP_CD AND PAO.ADR_ID = PTA.ADR_ID AND PTA.ADR_TYP_CD = SEL.OUT_ADD_TYP_CD)",null,null)
    val queries = Seq(query1,query2)
    val segDtls = new SegmentDetails("NCE",
      "20",
      "OUT_ACO_REC_TYP_CD;OUT_ACO_PROV_ID;OUT_ACO_TIN;OUT_ACO_MAID_3;OUT_ACO_MAID_9;OUT_ACO_MAID_TYP_CD;OUT_ACO_CONT_ORG;OUT_ACO_PRI_CD;OUT_ACO_CORR_CD;OUT_ACO_EFF_DATE;OUT_ACO_CAN_DATE;OUT_ACO_CAN_REASON;OUT_ACO_CHG_IND",
      "3;9;9;3;9;4;4;1;1;10;10;2;1",
      "400",
      "",
      queries
    )
    val SW_SKIP_NCE = "N"
    val WS_PREV_RUN_DT_YMD = "9999-12-31"
    val segDetailsSeq =Seq(segDtls)
    val inputEntity = new ExtractFileEntity("F5938RK4","PRV;ALT;PSP;SCO;PQI;HAS;PLI;PFA;TIN;PTI;TCO;NCE;ADD;PHO;ACT;LGS;LNG;HRS;HCA;ACO;AD1;CON;CDK;CSP;COS;CUL;NPI;COE","F5938DBE","NA","NA","NA",segDetailsSeq)
    val prevRunDate =""
    val outputFilePath ="maprfs:///user/sgoyal34"
    val spark=globalContext.sparkSession
    //val SchemaNm = "F5938DBE"
    import spark.implicits._
    val s=Seq((1233, 176),
      (234, 2323),
      (30000, 29898))
    val df=s.toDF("OUT_PHO_PROV_ID","OUT_PHO_TEL_NBR")
    df.createOrReplaceTempView("TIN_FNL_VIEW")
    Logger.log.info("")
    println("=======================" + spark.catalog.tableExists("TIN_FNL_VIEW") + "========")
    assert(genNCESeg(segDtls,glblVarLst,SW_SKIP_NCE,outputFilePath)(globalContext).get.equals("N"))
  }



  override def afterAll(): Unit = {
    super.afterAll()
    globalContext.sparkContext.stop()
  }

}




