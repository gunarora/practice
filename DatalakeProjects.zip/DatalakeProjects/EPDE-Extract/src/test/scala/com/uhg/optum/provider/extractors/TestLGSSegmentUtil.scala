package com.uhg.optum.provider.extractors

import com.uhg.optum.JobRunner.{PEI, PEIInstanceEmpty}
import com.uhg.optum.dao.{HbaseRepositoryManager, LocalRepositoryManager}
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDERK4InputJsonSchema.{ExtractFileEntity, Query, SegmentDetails}
import com.uhg.optum.provider.extractors.{EPDERK4JsonSourceExtractor, EPDERK4_PHO_SegExt}
import com.uhg.optum.util.CommonUtil
import com.uhg.optum.tests.base.UnitSpec
import com.uhg.optum.util.CommonUtil.add2Map
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}
import org.mockito.Mockito.when

import scala.util.{Failure, Success}

class TestLGSSegmentUtil extends UnitSpec with EPDERK4_LGS_SegExt {
  var globalContext: GlobalContext = _
  implicit var pei: PEI = _
  var glblVarLst = collection.mutable.Map[String, String]()

  override def beforeAll(): Unit = {
    super.beforeAll()

    globalContext = new GlobalContext("EPDE-OPTUM", "local") with LocalRepositoryManager
    import com.uhg.optum.protocols.PEIProtocol._
    globalContext.peTable.get("EPDE-OPTUM", "pei") match {
      case Success(instance) =>
        this.pei = instance
        Success()
      case Failure(ex) =>
        Failure(new PEIInstanceEmpty("Exception while getting the columns info from PEI Table", ex))
    }
    val WS_CANC_DT_1 = "01/01/0001" // used in PSP ; genrated in
    val WS_CANC_DT_2 = "12/31/9999" // used in PSP ; genrated in
    val WS_UPDT_DT_1 = "03/01/2019" // used in PSP
    val WS_UPDT_DT_2 = "12/31/9999" // used in PSP
    val WS_ACTV_CD_1 = "A" // used in ADD
    val WS_ACTV_CD_2 = "I" // used in ADD
    val vndrCd="OHPH"
    val provTypCd="GROUP"
    CommonUtil.add2Map(glblVarLst, "${WS_CANC_DT_1}", WS_CANC_DT_1)
    CommonUtil.add2Map(glblVarLst, "${WS_CANC_DT_2}", WS_CANC_DT_2)
    CommonUtil.add2Map(glblVarLst, "${WS_UPDT_DT_1}", WS_UPDT_DT_1)
    CommonUtil.add2Map(glblVarLst, "${WS_UPDT_DT_2}", WS_UPDT_DT_2)

    CommonUtil.add2Map(glblVarLst, "${WS_ACTV_CD_1}", WS_ACTV_CD_1)
    CommonUtil.add2Map(glblVarLst, "${WS_ACTV_CD_2}", WS_ACTV_CD_2)
    add2Map(glblVarLst,"${WS_VENDR_CD}",vndrCd)
    add2Map(glblVarLst,"provTypCd",provTypCd)
    //datafilesDir+"/"+glblVarLst("${WS_VENDR_CD}")+"/"+glblVarLst("provTypCd")+"/"

  }



  test("lgsSegGen method should return 'N' if  any of the dependent view is not present for making LGS_FNL_VIEW") {
    val query1 = new Query("LGS_SEL_COLS", "SELECT DISTINCT 'LGS' AS OUT_LGS_REC_TYP, * from PRV_FNL_VIEW ", null, null)
    val query2 = new Query("LGS_1075_CHECK_SRC_EXCL", "SELECT DISTINCT 'LGS' AS OUT_LGS_REC_TYP, * from PRV_FNL_VIEW ", null, null)
    val query3 = new Query("LGS_PRE_FETCH", "SELECT DISTINCT 'LGS' AS OUT_LGS_REC_TYP, * from PRV_FNL_VIEW ", null, null)
    val query4 = new Query("LGS_FNL", "SELECT DISTINCT 'LGS' AS OUT_LGS_REC_TYP, * from PRV_FNL_VIEW ", null, null)
    val queries = Seq(query1,query2, query3, query4)
    val segDtls = new SegmentDetails("LGS",
      "16",
      "OUT_LGS_REC_TYP;OUT_LGS_PROV_ID;OUT_LGS_LANG_CD;OUT_LGS_CHG_IND;OUT_LGS_LANG1_SPKN_BY_CD;OUT_LGS_LANG2_SPKN_BY_CD;OUT_LGS_LANG3_SPKN_BY_CD;OUT_LGS_LANG4_SPKN_BY_CD",
      "3;9;3;1;1;1;1;1",
      "400","",
      queries
    )


    val outputFilePath = ""
    val spark = globalContext.sparkSession
    import spark.implicits._
    val s = Seq(1, 2, 3)
    val df = s.toDF
    //df.createOrReplaceTempView("PRV_FNL_VIEW")
    println("======================="+spark.catalog.tableExists("PRV_FNL_VIEW")+"========")
//    assert(lgsSegGen(segDtls, outputFilePath,glblVarLst)(globalContext)=="N")
    assertThrows[org.apache.spark.sql.AnalysisException] {
      assert(lgsSegGen(segDtls, outputFilePath,glblVarLst)(globalContext).equals(Failure))
    }

  }


  test("lgsSegGen method should return 'N' if  no valid query is present") {
    val query1 = new Query("LGS_SEL_COLS_1", "SELECT DISTINCT 'LGS' AS OUT_LGS_REC_TYP, * from PRV_FNL_VIEW ", null, null)
    val query2 = new Query("LGS_1075_CHECK_SRC_EXCL_2", "SELECT DISTINCT 'LGS' AS OUT_LGS_REC_TYP, * from PRV_FNL_VIEW ", null, null)
    val query3 = new Query("LGS_PRE_FETCH_3", "SELECT DISTINCT 'LGS' AS OUT_LGS_REC_TYP, * from PRV_FNL_VIEW ", null, null)
    val query4 = new Query("LGS_FNL_4", "SELECT DISTINCT 'LGS' AS OUT_LGS_REC_TYP, * from PRV_FNL_VIEW ", null, null)
    val queries = Seq(query1,query2, query3, query4)
    val segDtls = new SegmentDetails("LGS",
      "16",
      "OUT_LGS_REC_TYP;OUT_LGS_PROV_ID;OUT_LGS_LANG_CD;OUT_LGS_CHG_IND",
      "3;9;3;1",
      "400","",
      queries
    )


    val outputFilePath = ""
    val spark = globalContext.sparkSession
    //  import spark.implicits._
    /*val s = Seq()
    val df = s.toDF
    */
    var df=globalContext.sqlContext.emptyDataFrame
    df.createOrReplaceTempView("LGS_SRC_EXCL_6")
    println("======================="+spark.catalog.tableExists("LGS_SRC_EXCL_6")+"========")
    assertThrows[org.apache.spark.sql.AnalysisException] {
      assert(lgsSegGen(segDtls, outputFilePath,glblVarLst)(globalContext).equals(Failure))
    }



  }

  test("lgsSegGen method should return 'N' if  key LGS_FNL_VIEW is  not present in segment details") {
    val query = new Query("LGS_FNL_VIEW11", "SELECT  'LGS' AS OUT_LGS_REC_TYP, * from LGS_SRC_EXCL_6 ", null, null)
    val queries = Seq(query)
    val segDtls = new SegmentDetails("LGS",
      "16",
      "OUT_LGS_REC_TYP;OUT_LGS_PROV_ID;OUT_LGS_LANG_CD;OUT_LGS_CHG_IND",
      "3;9;3;1",
      "400","",
      queries
    )


    val outputFilePath = ""
    val spark = globalContext.sparkSession


    val df=globalContext.sqlContext.emptyDataFrame
    df.createOrReplaceTempView("LGS_SRC_EXCL_6")
    println("======================="+spark.catalog.tableExists("LGS_SRC_EXCL_6")+"========")
    assert(lgsSegGen(segDtls, outputFilePath,glblVarLst)(globalContext)=="N")

  }



 /* test("lgsSegGen method should return 'N' if  some of the dependent views are not present for making LGS_FNL_VIEW") {
    val query1 = new Query("LGS_SEL_COLS", "SELECT DISTINCT 'LGS' AS OUT_LGS_REC_TYP, * from LGS_EXCL ", null, null)
    val query = new Query("LGS_FNL_VIEW", "SELECT * from LGS_SEL_COLS ", null, null)
    val queries = Seq(query1,query)
    val segDtls = new SegmentDetails("LGS",
      "16",
      "OUT_LGS_REC_TYP;OUT_LGS_PROV_ID;OUT_LGS_LANG_CD;OUT_LGS_CHG_IND",
      "3;9;3;1",
      "400","",
      queries
    )


    val outputFilePath = ""
    val spark = globalContext.sparkSession
    import spark.implicits._
    val s = Seq(1, 2, 3)
    val df = s.toDF
    df.createOrReplaceTempView("LGS_EXCL")
    println("======================="+spark.catalog.tableExists("LGS_SRC_EXCL_6")+"========")

    assertThrows[org.apache.spark.sql.AnalysisException] {
      assert(lgsSegGen(segDtls, outputFilePath,glblVarLst)(globalContext).equals(Failure))
    }

    // assert(lgsSegGen(segDtls, outputFilePath,glblVarLst)(globalContext)=="N")

  }*/
  test("lgsSegGen method should return 'Y' if  all the dependent views are present for making LGS_FNL_VIEW") {
    // val query = new Query("LGS_FNL_VIEW", "SELECT * from LGS_SRC_EXCL_6 ", null, null)
    val query1 = new Query("LGS_SRC_EXCL_6", "SELECT DISTINCT 'LGS' AS OUT_LGS_REC_TYP, * from LGS_EXCL ", null, null)
    val queries = Seq(query1)
    val segDtls = new SegmentDetails("LGS",
      "16",
      "OUT_LGS_REC_TYP;OUT_LGS_PROV_ID;OUT_LGS_LANG_CD;OUT_LGS_CHG_IND",
      "3;9;3;1",
      "400","",
      queries
    )


    val outputFilePath = ""
    val spark = globalContext.sparkSession
    import spark.implicits._
    val s = Seq(1, 2, 3)
    val df = s.toDF
    df.createOrReplaceTempView("LGS_EXCL")
    println("======================="+spark.catalog.tableExists("LGS_SRC_EXCL_6")+"========")
    assert(lgsSegGen(segDtls, outputFilePath,glblVarLst)(globalContext)=="N")

  }




  override def afterAll(): Unit = {
    super.afterAll()
    globalContext.sparkContext.stop()
  }
}



