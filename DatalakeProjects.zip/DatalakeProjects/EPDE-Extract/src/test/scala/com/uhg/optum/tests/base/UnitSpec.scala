package com.uhg.optum.tests.base

import org.scalatest.{BeforeAndAfterEach, FunSuite, Inspectors, BeforeAndAfterAll, Inside, OptionValues, Matchers}
import org.scalatest.mockito.MockitoSugar

abstract class UnitSpec extends FunSuite with Matchers with
  OptionValues with Inside with Inspectors with BeforeAndAfterEach with MockitoSugar with BeforeAndAfterAll
