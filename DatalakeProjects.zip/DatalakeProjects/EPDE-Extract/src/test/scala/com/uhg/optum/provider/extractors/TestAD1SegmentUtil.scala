package com.uhg.optum.provider.extractors
import com.uhg.optum.JobRunner.{PEI, PEIInstanceEmpty}
import com.uhg.optum.dao.{HbaseRepositoryManager, LocalRepositoryManager}
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDERK4InputJsonSchema.{ExtractFileEntity, Query, SegmentDetails}
import com.uhg.optum.provider.extractors.EPDERK4_AD1_SegExt
import com.uhg.optum.util.CommonUtil
import com.uhg.optum.tests.base.UnitSpec

import scala.util.{Failure, Success}

class TestAD1SegmentUtil extends UnitSpec with EPDERK4_AD1_SegExt {
  var globalContext: GlobalContext = _
  implicit var pei: PEI = _
  var glblVarLst = collection.mutable.Map[String, String]()

  override def beforeAll(): Unit = {
    super.beforeAll()

    globalContext = new GlobalContext("EPDE_OPTUM","local") with LocalRepositoryManager
    import com.uhg.optum.protocols.PEIProtocol._
    globalContext.peTable.get("EPDE_OPTUM", "pei") match{
      case Success(instance) =>
        this.pei = instance
        Success()
      case Failure(ex) =>
        Failure(new PEIInstanceEmpty("Exception while getting the columns info from PEI Table", ex))
    }
    val WS_CANC_DT_1 = "01/01/0001" // used in PSP ; genrated in
    val WS_CANC_DT_2 = "12/31/9999" // used in PSP ; genrated in
    val WS_UPDT_DT_1 = "03/01/2019" // used in PSP
    val WS_UPDT_DT_2 = "12/31/9999" // used in PSP
    val WS_ACTV_CD_1 = "A" // used in ADD
    val WS_ACTV_CD_2 = "I" // used in ADD
    CommonUtil.add2Map(glblVarLst, "${WS_CANC_DT_1}", WS_CANC_DT_1)
    CommonUtil.add2Map(glblVarLst, "${WS_CANC_DT_2}", WS_CANC_DT_2)
    CommonUtil.add2Map(glblVarLst, "${WS_UPDT_DT_1}", WS_UPDT_DT_1)
    CommonUtil.add2Map(glblVarLst, "${WS_UPDT_DT_2}", WS_UPDT_DT_2)

    CommonUtil.add2Map(glblVarLst, "${WS_ACTV_CD_1}", WS_ACTV_CD_1)
    CommonUtil.add2Map(glblVarLst, "${WS_ACTV_CD_2}", WS_ACTV_CD_2)

  }
  /*test("ad1SegGen method should throw exception if the ADD final view  does not exist") {
    val query = new Query("AD1_FETCH2", "SELECT DISTINCT 'AD1' AS OUT_AD1_REC_TYP,PAT.PROV_ID AS OUT_AD1_PROV_ID,TEL.TEL_NBR OUT_AD1_TEL_NBR,TEL.AREA_CD AS OUT_AD1_AREA_CD,CASE 	WHEN PAT.TEL_USE_TYP_CD='C' AND ADD_FNL_VIEW.OUT_ADD_TYP_CD='BILL' THEN  'B' WHEN PAT.TEL_USE_TYP_CD='C' AND ADD_FNL_VIEW.OUT_ADD_TYP_CD!='BILL' THEN 'P' ELSE PAT.TEL_USE_TYP_CD END AS OUT_AD1_TYP_CD,PAT.DIR_IND AS OUT_AD1_DIR_IND,WHEN from_unixtime(CHAR(TEL.LST_UPDT_DT,USA),'yyyyMMdd') > from_unixtime(WS_PREV_RUN_DT,'yyyyMMdd')  OR  from_unixtime(CHAR(PAT.LST_UPDT_DT,USA),'yyyyMMdd') > from_unixtime(WS_PREV_RUN_DT,'yyyyMMdd') THEN 'Y'  ELSE 'N' END AS OUT_AD1_CHG_IND,PAT.EXT_NBR AS OUT_AD1_EXT_NBR,PAT.PRI_CD AS OUT_AD1_PRI_CD,PAT.ACTV_CD AS OUT_AD1_ACTV_CD,' ' AS OUT_AD1_TEL_TYP_CD FROM PROV_ADR_TEL_CMNCT PAT, TEL_CMNCT TEL,ADD_FNL_VIEW WHERE PAT.PROV_ID =ADD_FNL_VIEW.OUT_ADD_PROV_ID AND PAT.TAX_ID_NBR=ADD_FNL_VIEW.PTA_TAX_ID_NBR AND  PAT.TAX_ID_TYP_CD = ADD_FNL_VIEW.PTA_TAX_ID_TYP_CD AND  PAT.ADR_ID = ADD_FNL_VIEW.OUT_ADD_ADR_ID AND PAT.TEL_CMNCT_ID  = TEL.TEL_CMNCT_ID AND TEL.CANC_DT = '12/31/9999' AND PAT.ADR_TYP_CD IN (SELECT CASE WHEN ADD_FNL_VIEW.PTA_ADR_TYP_CD='L' ELSE 'H' END AS WS_ADR_TYP_CD_1 FROM ADD_FNL_VIEW,'D') AND ((PAT.ACTV_CD  = 'A') OR (PAT.ACTV_CD IN ('A','I') AND  PAT.LST_UPDT_DT  BETWEEN '12/31/9999' AND WS_PREV_RUN_DT )) ORDER BY PAT.ACTV_CD DESC", null, null)
    val queries = Seq(query)
    val segDtls = new SegmentDetails("AD1",
      "21",
      "OUT_AD1_REC_TYP;OUT_AD1_PROV_ID;OUT_AD1_TEL_NBR;OUT_AD1_AREA_CD;OUT_AD1_TYP_CD;OUT_AD1_DIR_IND;OUT_AD1_CHG_IND;OUT_AD1_EXT_NBR;OUT_AD1_PRI_CD;OUT_AD1_ACTV_CD;OUT_AD1_TEL_TYP_CD",
      "3;9;7;3;1;1;1;10;1;1;1",
      "400",
      "",
      queries
    )
    val segDtlsSeq = Seq(segDtls)
    val prevRunDate = ""
    val outputFilePath = ""
    val spark = globalContext.sparkSession
    import spark.implicits._
    val s = Seq(1, 2, 3)
    val df = s.toDF
    //df.createOrReplaceTempView("ADD_FNL_VIEW")
    println("=======================" + spark.catalog.tableExists("ADD_FNL_VIEW") + "========")
    val thrownExcep = intercept[Exception] {
      ad1SegGen(segDtlsSeq, prevRunDate, outputFilePath,glblVarLst)(globalContext)
    }
    assert(thrownExcep.getMessage == "The temporary view ADD_FNL_VIEW from ADD segment is required for AD1 segment")
  }*/


  /*test("ad1SegGen method should return 'N' if AD1 segment details are not present") {
    val query = new Query("AD1_FETCH_AD1N", "SELECT DISTINCT 'AD1' AS OUT_AD1_REC_TYP,PAT.PROV_ID AS OUT_AD1_PROV_ID,TEL.TEL_NBR OUT_AD1_TEL_NBR,TEL.AREA_CD AS OUT_AD1_AREA_CD,CASE 	WHEN PAT.TEL_USE_TYP_CD='C' AND ADD_FNL_VIEW.OUT_ADD_TYP_CD='BILL' THEN  'B' WHEN PAT.TEL_USE_TYP_CD='C' AND ADD_FNL_VIEW.OUT_ADD_TYP_CD!='BILL' THEN 'P' ELSE PAT.TEL_USE_TYP_CD END AS OUT_AD1_TYP_CD,PAT.DIR_IND AS OUT_AD1_DIR_IND,WHEN from_unixtime(CHAR(TEL.LST_UPDT_DT,USA),'yyyyMMdd') > from_unixtime(WS_PREV_RUN_DT,'yyyyMMdd')  OR  from_unixtime(CHAR(PAT.LST_UPDT_DT,USA),'yyyyMMdd') > from_unixtime(WS_PREV_RUN_DT,'yyyyMMdd') THEN 'Y'  ELSE 'N' END AS OUT_AD1_CHG_IND,PAT.EXT_NBR AS OUT_AD1_EXT_NBR,PAT.PRI_CD AS OUT_AD1_PRI_CD,PAT.ACTV_CD AS OUT_AD1_ACTV_CD,' ' AS OUT_AD1_TEL_TYP_CD FROM PROV_ADR_TEL_CMNCT PAT, TEL_CMNCT TEL,ADD_FNL_VIEW WHERE PAT.PROV_ID =ADD_FNL_VIEW.OUT_ADD_PROV_ID AND PAT.TAX_ID_NBR=ADD_FNL_VIEW.PTA_TAX_ID_NBR AND  PAT.TAX_ID_TYP_CD = ADD_FNL_VIEW.PTA_TAX_ID_TYP_CD AND  PAT.ADR_ID = ADD_FNL_VIEW.OUT_ADD_ADR_ID AND PAT.TEL_CMNCT_ID  = TEL.TEL_CMNCT_ID AND TEL.CANC_DT = '12/31/9999' AND PAT.ADR_TYP_CD IN (SELECT CASE WHEN ADD_FNL_VIEW.PTA_ADR_TYP_CD='L' ELSE 'H' END AS WS_ADR_TYP_CD_1 FROM ADD_FNL_VIEW,'D') AND ((PAT.ACTV_CD  = 'A') OR (PAT.ACTV_CD IN ('A','I') AND  PAT.LST_UPDT_DT  BETWEEN '12/31/9999' AND WS_PREV_RUN_DT )) ORDER BY PAT.ACTV_CD DESC", null, null)
    val queries = Seq(query)
    val segDtls = new SegmentDetails("AD1OO",
      "14",
      "OUT_AD1_REC_TYP;OUT_AD1_PROV_ID;OUT_AD1_TEL_NBR;OUT_AD1_AREA_CD;OUT_AD1_TYP_CD;OUT_AD1_DIR_IND;OUT_AD1_CHG_IND;OUT_AD1_EXT_NBR;OUT_AD1_PRI_CD;OUT_AD1_ACTV_CD;OUT_AD1_TEL_TYP_CD",
      "3;9;7;3;1;1;1;10;1;1;1",
      "400",
      "",
      queries
    )
    val segDtlsSeq = Seq(segDtls)
    val prevRunDate = ""
    val outputFilePath = ""
    val spark = globalContext.sparkSession
    import spark.implicits._
    val s = Seq(1, 2, 3)
    val df = s.toDF
    df.createOrReplaceTempView("ADD_FNL_VIEW")
    //println("======================="+spark.catalog.tableExists("ADD_FNL_VIEW")+"========")
    /* val thrownExcep = intercept[Exception] {
       ad1SegGen(segDtlsSeq, prevRunDate, outputFilePath,glblVarLst)(globalContext)
     }*/
    assert(ad1SegGen(segDtls, prevRunDate, outputFilePath,glblVarLst)(globalContext)=="N")

  }*/
  /*test("ad1SegGen method should return 'N' if there is no data for AD1 segment") {
    val query = new Query("AD1_FETCH2", "SELECT DISTINCT 'AD1' AS OUT_AD1_REC_TYP,OUT_AD1_PROV_ID,OUT_AD1_TEL_NBR FROM ADD_FNL_VIEW WHERE OUT_AD1_PROV_ID=11", null, null)
    val queries = Seq(query)
    val segDtls = new SegmentDetails("AD1",
      "21",
      "OUT_AD1_REC_TYP;OUT_AD1_PROV_ID;OUT_AD1_TEL_NBR;OUT_AD1_AREA_CD;OUT_AD1_TYP_CD;OUT_AD1_DIR_IND;OUT_AD1_CHG_IND;OUT_AD1_EXT_NBR;OUT_AD1_PRI_CD;OUT_AD1_ACTV_CD;OUT_AD1_TEL_TYP_CD",
      "3;9;7;3;1;1;1;10;1;1;1",
      "400",
      "",
      queries
    )
    val segDtlsSeq = Seq(segDtls)
    val prevRunDate = ""
    val outputFilePath = ""
    val spark = globalContext.sparkSession

    import spark.implicits._
    val s = Seq((1233, 176),
      (234, 2323),
      (30000, 29898))
    val df = s.toDF("OUT_AD1_PROV_ID", "OUT_AD1_TEL_NBR")
    df.createOrReplaceTempView("ADD_FNL_VIEW")

    println("=======================" + spark.catalog.tableExists("ADD_FNL_VIEW") + "========")

    assert(ad1SegGen(segDtls,  outputFilePath,glblVarLst)(globalContext) == "N")
  }*/
  test("ad1SegGen method should return 'N' if there is no ADD_UNI_FNL_VIEW  query for AD1 segment") {
    val query = new Query("ADR_TYP_VIEW1", "SELECT DISTINCT 'AD1' AS OUT_AD1_REC_TYP,OUT_AD1_PROV_ID,OUT_AD1_TEL_NBR FROM ADD_FNL_VIEW WHERE OUT_AD1_PROV_ID=11", null, null)
    val queries = Seq(query)
    val segDtls = new SegmentDetails("AD1",
      "21",
      "OUT_AD1_REC_TYP;OUT_AD1_PROV_ID;OUT_AD1_TEL_NBR;OUT_AD1_AREA_CD;OUT_AD1_TYP_CD;OUT_AD1_DIR_IND;OUT_AD1_CHG_IND;OUT_AD1_EXT_NBR;OUT_AD1_PRI_CD;OUT_AD1_ACTV_CD;OUT_AD1_TEL_TYP_CD",
      "3;9;7;3;1;1;1;10;1;1;1",
      "400",
      "",
      queries
    )
    val segDtlsSeq = Seq(segDtls)
    val prevRunDate = ""
    val outputFilePath = ""
    val spark = globalContext.sparkSession

    import spark.implicits._
    val s = Seq((1233, 176),
      (234, 2323),
      (30000, 29898))
    val df = s.toDF("OUT_AD1_PROV_ID", "OUT_AD1_TEL_NBR")
    df.createOrReplaceTempView("ADD_FNL_VIEW")

    println("=======================" + spark.catalog.tableExists("ADD_FNL_VIEW") + "========")

    assert(ad1SegGen(segDtls, outputFilePath,glblVarLst)(globalContext) == "N")
  }
  test("ad1SegGen method should return 'N' if there is no AD1_FETCH1  query for AD1 segment") {
    val query = new Query("ADD_UNI_FNL_VIEW", "SELECT DISTINCT 'AD1' AS OUT_AD1_REC_TYP,OUT_AD1_PROV_ID,OUT_AD1_TEL_NBR FROM ADD_FNL_VIEW WHERE OUT_AD1_PROV_ID=11", null, null)
    val query1 = new Query("AD1_FETCH11", "SELECT DISTINCT 'AD1' AS OUT_AD1_REC_TYP,OUT_AD1_PROV_ID,OUT_AD1_TEL_NBR FROM ADD_FNL_VIEW WHERE OUT_AD1_PROV_ID=11", null, null)
    val queries = Seq(query,query1)
    val segDtls = new SegmentDetails("AD1",
      "21",
      "OUT_AD1_REC_TYP;OUT_AD1_PROV_ID;OUT_AD1_TEL_NBR;OUT_AD1_AREA_CD;OUT_AD1_TYP_CD;OUT_AD1_DIR_IND;OUT_AD1_CHG_IND;OUT_AD1_EXT_NBR;OUT_AD1_PRI_CD;OUT_AD1_ACTV_CD;OUT_AD1_TEL_TYP_CD",
      "3;9;7;3;1;1;1;10;1;1;1",
      "400",
      "",
      queries
    )
    val segDtlsSeq = Seq(segDtls)
    val prevRunDate = ""
    val outputFilePath = ""
    val spark = globalContext.sparkSession

    import spark.implicits._
    val s = Seq((1233, 176),
      (234, 2323),
      (30000, 29898))
    val df = s.toDF("OUT_AD1_PROV_ID", "OUT_AD1_TEL_NBR")
    df.createOrReplaceTempView("ADD_FNL_VIEW")

    println("=======================" + spark.catalog.tableExists("ADD_FNL_VIEW") + "========")

    assert(ad1SegGen(segDtls,  outputFilePath,glblVarLst)(globalContext) == "N")
  }

  test("ad1SegGen method should return 'N' if there is no AD1_FETCH2  query for AD1 segment") {
    val query = new Query("ADD_UNI_FNL_VIEW", "SELECT DISTINCT 'AD1' AS OUT_AD1_REC_TYP,OUT_AD1_PROV_ID,OUT_AD1_TEL_NBR FROM ADD_FNL_VIEW WHERE OUT_AD1_PROV_ID=11", null, null)
    val query1 = new Query("AD1_FETCH1", "SELECT DISTINCT 'AD1' AS OUT_AD1_REC_TYP,OUT_AD1_PROV_ID,OUT_AD1_TEL_NBR FROM ADD_FNL_VIEW WHERE OUT_AD1_PROV_ID=11", null, null)
    val query2 = new Query("AD1_FETCH14", "SELECT DISTINCT 'AD1' AS OUT_AD1_REC_TYP,OUT_AD1_PROV_ID,OUT_AD1_TEL_NBR FROM ADD_FNL_VIEW WHERE OUT_AD1_PROV_ID=11", null, null)
    val queries = Seq(query,query1,query2)
    val segDtls = new SegmentDetails("AD1",
      "21",
      "OUT_AD1_REC_TYP;OUT_AD1_PROV_ID;OUT_AD1_TEL_NBR;OUT_AD1_AREA_CD;OUT_AD1_TYP_CD;OUT_AD1_DIR_IND;OUT_AD1_CHG_IND;OUT_AD1_EXT_NBR;OUT_AD1_PRI_CD;OUT_AD1_ACTV_CD;OUT_AD1_TEL_TYP_CD",
      "3;9;7;3;1;1;1;10;1;1;1",
      "400",
      "",
      queries
    )
    val segDtlsSeq = Seq(segDtls)
    val prevRunDate = ""
    val outputFilePath = ""
    val spark = globalContext.sparkSession

    import spark.implicits._
    val s = Seq((1233, 176),
      (234, 2323),
      (30000, 29898))
    val df = s.toDF("OUT_AD1_PROV_ID", "OUT_AD1_TEL_NBR")
    df.createOrReplaceTempView("ADD_FNL_VIEW")

    println("=======================" + spark.catalog.tableExists("ADD_FNL_VIEW") + "========")

    assert(ad1SegGen(segDtls,  outputFilePath,glblVarLst)(globalContext) == "N")
  }
  /*test("ad1SegGen method should return 'N' if there is no proper sequence of queries for AD1 segment") {
    val query = new Query("AD1_FETCH2", "SELECT DISTINCT 'AD1' AS OUT_AD1_REC_TYP,OUT_AD1_PROV_ID,OUT_AD1_TEL_NBR FROM ADR_TYP_VIEW WHERE OUT_AD1_PROV_ID=11", null, null)
    val query1 = new Query("AD1_FETCH1", "SELECT DISTINCT 'AD1' AS OUT_AD1_REC_TYP,OUT_AD1_PROV_ID,OUT_AD1_TEL_NBR FROM ADD_FNL_VIEW WHERE OUT_AD1_PROV_ID=11", null, null)
    val query2 = new Query("ADD_UNI_FNL_VIEW", "SELECT DISTINCT 'AD1' AS OUT_AD1_REC_TYP,OUT_AD1_PROV_ID,OUT_AD1_TEL_NBR FROM ADD_FNL_VIEW WHERE OUT_AD1_PROV_ID=11", null, null)
    val queries = Seq(query,query1,query2)
    val segDtls = new SegmentDetails("AD1",
      "21",
      "OUT_AD1_REC_TYP;OUT_AD1_PROV_ID;OUT_AD1_TEL_NBR;OUT_AD1_AREA_CD;OUT_AD1_TYP_CD;OUT_AD1_DIR_IND;OUT_AD1_CHG_IND;OUT_AD1_EXT_NBR;OUT_AD1_PRI_CD;OUT_AD1_ACTV_CD;OUT_AD1_TEL_TYP_CD",
      "3;9;7;3;1;1;1;10;1;1;1",
      "400",
      "",
      queries
    )
    val segDtlsSeq = Seq(segDtls)
    val prevRunDate = ""
    val outputFilePath = ""
    val spark = globalContext.sparkSession

    import spark.implicits._
    val s = Seq((1233, 176),
      (234, 2323),
      (30000, 29898))
    val df = s.toDF("OUT_AD1_PROV_ID", "OUT_AD1_TEL_NBR")
    df.createOrReplaceTempView("ADD_FNL_VIEW")

    println("=======================" + spark.catalog.tableExists("ADD_FNL_VIEW") + "========")

    assert(ad1SegGen(segDtls,  outputFilePath,glblVarLst)(globalContext) == "N")
  }*/


  test("ad1SegGen method should be  success if the ADD final view exists") {
    val query3 = new Query(name = "AD1_FETCH1", "select * from ADD_FINAL_VIEW", null, null)
    //   val query4 = new Query(name = "AD1_FETCH1", "select OUT_ACO_TEL_NBR from ADD_FINAL_VIEW", null, null)
    // val query5 = new Query(name = "AD1_FNL_VIEW", "select OUT_ACO_TEL_NBR from ADD_FINAL_VIEW", null, null)

    //val query3 = new Query("ACO_FNL_VIEW","SELECT 'ACO' AS OUT_ACO_REC_TYP_CD, PAO.PROV_ID AS OUT_ACO_PROV_ID, PAO.TAX_ID_NBR AS OUT_ACO_TIN, '000' AS OUT_ACO_MAID_3, PAO.ADR_ID AS OUT_ACO_MAID_9, CASE WHEN '${PTA_ADR_TYP_CD}' = 'L' THEN 'PR' WHEN '${PTA_ADR_TYP_CD}' = 'T' THEN 'MAIL' ELSE 'BILL' END AS OUT_ACO_MAID_TYP_CD, PAO.CONTR_ORG_CD AS OUT_ACO_CONT_ORG, PAO.PRI_CD AS OUT_ACO_PRI_CD, PAO.CORSP_ADR_IND AS OUT_ACO_CORR_CD, PAO.EFF_DT AS OUT_ACO_EFF_DATE, PAO.CANC_DT AS OUT_ACO_CAN_DATE, PAO.TMLN_RSN_TYP_CD AS OUT_ACO_CAN_REASON,PAO.LST_UPDT_DT AS PAO_LST_UPDT_DT, case when unix_timestamp(PAO.LST_UPDT_DT,'yyyy-MM-dd')  > unix_timestamp(${WS_PREV_RUN_DT_YMD},'yyyy-MM-dd') then (case when unix_timestamp(PAO.CANC_DT,'yyyy-MM-dd') < unix_timestamp('9999-12-31','yyyy-MM-dd') then 'C' else 'Y' end) else (case when unix_timestamp(PAO.CANC_DT,'yyyy-MM-dd') = unix_timestamp('9999-12-31','yyyy-MM-dd') then 'N' else '' end) end as OUT_ACO_CHG_IND FROM ${SchemaNm}_PROV_TIN_ADR_CONTR_ORG PAO INNER JOIN ACO_SEL_65_CUR SEL ON (PAO.PROV_ID = SEL.OUT_ADD_PROV_ID AND PAO.ADR_ID = SEL.OUT_ADD_ADR_ID_9) INNER JOIN ${SchemaNm}_PROV_TIN_PAY_AFFIL PTP ON (PTP.PROV_ID = SEL.OUT_ADD_PROV_ID AND PAO.TAX_ID_NBR = PTP.TAX_ID_NBR AND PTP.TAX_ID_NBR = SEL.TAX_ID_NBR ) INNER JOIN ${SchemaNm}_PROV_TIN_ADR PTA ON (PTA.PROV_ID = SEL.OUT_ADD_PROV_ID AND PTP.TAX_ID_NBR = PTA.TAX_ID_NBR AND PTA.TAX_ID_TYP_CD = PTP.TAX_ID_TYP_CD AND PAO.ADR_ID = PTA.ADR_ID AND PTA.ADR_TYP_CD = SEL.OUT_ADD_TYP_CD)",null,null)
    val queries = Seq(query3)

    val segDtls = new SegmentDetails("AD1",
      "20",
      "OUT_ACO_REC_TYP_CD;OUT_ACO_PROV_ID;OUT_ACO_TIN;OUT_ACO_MAID_3;OUT_ACO_MAID_9;OUT_ACO_MAID_TYP_CD;OUT_ACO_CONT_ORG;OUT_ACO_PRI_CD;OUT_ACO_CORR_CD;OUT_ACO_EFF_DATE;OUT_ACO_CAN_DATE;OUT_ACO_CAN_REASON;OUT_ACO_CHG_IND",
      "3;9;9;3;9;4;4;1;1;10;10;2;1",
      "400",
      "",
      queries
    )
    val SW_SKIP_AD1 = "N"
    val WS_PREV_RUN_DT_YMD = "9999-12-31"
    val segDetailsSeq =Seq(segDtls)
    val inputEntity = new ExtractFileEntity("F5938RK4","PRV;ALT;PSP;SCO;PQI;HAS;PLI;PFA;TIN;PTI;TCO;NCE;ADD;PHO;ACT;LGS;LNG;HRS;HCA;ACO;AD1;CON;CDK;CSP;COS;CUL;NPI;COE","F5938DBE","NA","NA","NA",segDetailsSeq)
    val prevRunDate =""
    val outputFilePath = "maprfs:///datalake/uhclake/tst/developer/EPDE/TestFiles/"
    val spark = globalContext.sparkSession
    //val SchemaNm = "F5938DBE"
    import spark.implicits._
    val s = Seq((1233, 176),
      (234, 2323),
      (30000, 29898))
    val df = s.toDF("OUT_ACO_PROV_ID", "OUT_ACO_TEL_NBR")
    df.createOrReplaceTempView("ADD_FINAL_VIEW")
    println("=======================" + spark.catalog.tableExists("ADD_FINAL_VIEW") + "========")
    //  var varLst = collection.mutable.Map[String, String]()
    assert(ad1SegGen(segDtls, outputFilePath,glblVarLst)(globalContext)=="N")

  }



  test("ad1SegGen method should be failure if the ADD final view doesnt exist") {
    // val query1 = new Query("ACO_SEL_65_CUR", "SELECT ADD.OUT_ADD_PROV_ID AS OUT_ADD_PROV_ID,ADD.OUT_ADD_ADR_ID_9 AS OUT_ADD_ADR_ID_9,ADD.TAX_ID_NBR AS TAX_ID_NBR,ADD.OUT_ADD_TYP_CD AS OUT_ADD_TYP_CD, COUNT(*) FROM ${SchemaNm}_PROV_TIN_ADR_CONTR_ORG PAO INNER JOIN ADD_FINAL_QRY ADD ON (PAO.PROV_ID = ADD.OUT_ADD_PROV_ID AND PAO.ADR_ID = ADD.OUT_ADD_ADR_ID_9) INNER JOIN ${SchemaNm}_PROV_TIN_PAY_AFFIL PTP ON (PTP.PROV_ID = ADD.OUT_ADD_PROV_ID AND PAO.TAX_ID_NBR = PTP.TAX_ID_NBR AND PTP.TAX_ID_NBR = ADD.TAX_ID_NBR ) INNER JOIN ${SchemaNm}_PROV_TIN_ADR PTA ON (PTA.PROV_ID = ADD.OUT_ADD_PROV_ID AND PTP.TAX_ID_NBR = PTA.TAX_ID_NBR AND PTA.TAX_ID_TYP_CD = PTP.TAX_ID_TYP_CD AND PAO.ADR_ID = PTA.ADR_ID AND PTA.ADR_TYP_CD = ADD.OUT_ADD_TYP_CD) GROUP BY ADD.OUT_ADD_PROV_ID ,ADD.OUT_ADD_ADR_ID_9 ,ADD.TAX_ID_NBR ,ADD.OUT_ADD_TYP_CD  HAVING COUNT(*)=1", null, null)
    // val query2 = new Query("ACO_65_CUR", "SELECT 'ACO' AS OUT_ACO_REC_TYP_CD, PAO.PROV_ID AS OUT_ACO_PROV_ID, PAO.TAX_ID_NBR AS OUT_ACO_TIN, '000' AS OUT_ACO_MAID_3, PAO.ADR_ID AS OUT_ACO_MAID_9, CASE WHEN '${PTA_ADR_TYP_CD}' = 'L' THEN 'PR' WHEN '${PTA_ADR_TYP_CD}' = 'T' THEN 'MAIL' ELSE 'BILL' END AS OUT_ACO_MAID_TYP_CD, PAO.CONTR_ORG_CD AS OUT_ACO_CONT_ORG, PAO.PRI_CD AS OUT_ACO_PRI_CD, PAO.CORSP_ADR_IND AS OUT_ACO_CORR_CD, PAO.EFF_DT AS OUT_ACO_EFF_DATE, PAO.CANC_DT AS OUT_ACO_CAN_DATE, PAO.TMLN_RSN_TYP_CD AS OUT_ACO_CAN_REASON,PAO.LST_UPDT_DT AS PAO_LST_UPDT_DT, case when unix_timestamp(PAO.LST_UPDT_DT,'yyyy-MM-dd')  > unix_timestamp(${WS_PREV_RUN_DT_YMD},'yyyy-MM-dd') then (case when unix_timestamp(PAO.CANC_DT,'yyyy-MM-dd') < unix_timestamp('9999-12-31','yyyy-MM-dd') then 'C' else 'Y' end) else (case when unix_timestamp(PAO.CANC_DT,'yyyy-MM-dd') = unix_timestamp('9999-12-31','yyyy-MM-dd') then 'N' else '' end) end as OUT_ACO_CHG_IND FROM ${SchemaNm}_PROV_TIN_ADR_CONTR_ORG PAO INNER JOIN ACO_SEL_65_CUR SEL ON (PAO.PROV_ID = SEL.OUT_ADD_PROV_ID AND PAO.ADR_ID = SEL.OUT_ADD_ADR_ID_9) INNER JOIN ${SchemaNm}_PROV_TIN_PAY_AFFIL PTP ON (PTP.PROV_ID = SEL.OUT_ADD_PROV_ID AND PAO.TAX_ID_NBR = PTP.TAX_ID_NBR AND PTP.TAX_ID_NBR = SEL.TAX_ID_NBR ) INNER JOIN ${SchemaNm}_PROV_TIN_ADR PTA ON (PTA.PROV_ID = SEL.OUT_ADD_PROV_ID AND PTP.TAX_ID_NBR = PTA.TAX_ID_NBR AND PTA.TAX_ID_TYP_CD = PTP.TAX_ID_TYP_CD AND PAO.ADR_ID = PTA.ADR_ID AND PTA.ADR_TYP_CD = SEL.OUT_ADD_TYP_CD)", null, null)
    //val queries = Seq(query1, query2)
    val query3 = new Query(name = "AD1_FETCH1", "select * from ADD_FNL_VIEW1", null, null)
    val query4 = new Query(name = "AD1_FNL_VIEW", "select OUT_ACO_TEL_NBR from ADD_FNL_VIEW1", null, null)
    val queries = Seq(query3, query4)
    val segDtls = new SegmentDetails("AD1",
      "20",
      "OUT_ACO_REC_TYP_CD;OUT_ACO_PROV_ID;OUT_ACO_TIN;OUT_ACO_MAID_3;OUT_ACO_MAID_9;OUT_ACO_MAID_TYP_CD;OUT_ACO_CONT_ORG;OUT_ACO_PRI_CD;OUT_ACO_CORR_CD;OUT_ACO_EFF_DATE;OUT_ACO_CAN_DATE;OUT_ACO_CAN_REASON;OUT_ACO_CHG_IND",
      "3;9;9;3;9;4;4;1;1;10;10;2;1",
      "400", "",
      queries
    )
    val SW_SKIP_ACO = "N"
    val WS_PREV_RUN_DT_YMD = "9999-12-31"
    val segDetailsSeq = Seq(segDtls)
    val inputEntity = new ExtractFileEntity("F5938RK4", "PRV;ALT;PSP;SCO;PQI;HAS;PLI;PFA;TIN;PTI;TCO;NCE;ADD;PHO;ACT;LGS;LNG;HRS;HCA;ACO;AD1;CON;CDK;CSP;COS;CUL;NPI;COE", "F5938DBE", "NA", "NA", "NA", segDetailsSeq)
    val prevRunDate = ""
    val outputFilePath = "maprfs:///datalake/uhclake/tst/developer/EPDE/TestFiles/"
    val spark = globalContext.sparkSession
    //val SchemaNm = "F5938DBE"
    import spark.implicits._
    val s = Seq((1233, 176),
      (234, 2323),
      (30000, 29898))
    val df = s.toDF("OUT_ACO_PROV_ID", "OUT_ACO_TEL_NBR")
    // df.createOrReplaceTempView("ADD_FINAL_VIEW1")
    // println("=======================" + spark.catalog.tableExists("ADD_FINAL_VIEW1") + "========")

    /*  val thrownExcep = intercept[Exception] {
        acoSegGen(inputEntity,SW_SKIP_ACO, WS_PREV_RUN_DT_YMD, outputFilePath)(globalContext)
      }*/
    assertThrows[org.apache.spark.sql.AnalysisException] {
      assert(ad1SegGen(segDtls,outputFilePath,glblVarLst)(globalContext).equals(Failure))
    }  }

  test("ad1SegGen method should return 'N' if no valid values for AD1 present in segDtls") {
    val query1 = new Query("AD1","SELECT ADD.OUT_ADD_PROV_ID AS OUT_ADD_PROV_ID,ADD.OUT_ADD_ADR_ID_9 AS OUT_ADD_ADR_ID_9,ADD.TAX_ID_NBR AS TAX_ID_NBR,ADD.OUT_ADD_TYP_CD AS OUT_ADD_TYP_CD, COUNT(*) FROM ${SchemaNm}_PROV_TIN_ADR_CONTR_ORG PAO INNER JOIN ADD_FINAL_QRY ADD ON (PAO.PROV_ID = ADD.OUT_ADD_PROV_ID AND PAO.ADR_ID = ADD.OUT_ADD_ADR_ID_9) INNER JOIN ${SchemaNm}_PROV_TIN_PAY_AFFIL PTP ON (PTP.PROV_ID = ADD.OUT_ADD_PROV_ID AND PAO.TAX_ID_NBR = PTP.TAX_ID_NBR AND PTP.TAX_ID_NBR = ADD.TAX_ID_NBR ) INNER JOIN ${SchemaNm}_PROV_TIN_ADR PTA ON (PTA.PROV_ID = ADD.OUT_ADD_PROV_ID AND PTP.TAX_ID_NBR = PTA.TAX_ID_NBR AND PTA.TAX_ID_TYP_CD = PTP.TAX_ID_TYP_CD AND PAO.ADR_ID = PTA.ADR_ID AND PTA.ADR_TYP_CD = ADD.OUT_ADD_TYP_CD) GROUP BY ADD.OUT_ADD_PROV_ID ,ADD.OUT_ADD_ADR_ID_9 ,ADD.TAX_ID_NBR ,ADD.OUT_ADD_TYP_CD  HAVING COUNT(*)=1",null,null)
    val query2 = new Query("AD2","SELECT 'ACO' AS OUT_ACO_REC_TYP_CD, PAO.PROV_ID AS OUT_ACO_PROV_ID, PAO.TAX_ID_NBR AS OUT_ACO_TIN, '000' AS OUT_ACO_MAID_3, PAO.ADR_ID AS OUT_ACO_MAID_9, CASE WHEN '${PTA_ADR_TYP_CD}' = 'L' THEN 'PR' WHEN '${PTA_ADR_TYP_CD}' = 'T' THEN 'MAIL' ELSE 'BILL' END AS OUT_ACO_MAID_TYP_CD, PAO.CONTR_ORG_CD AS OUT_ACO_CONT_ORG, PAO.PRI_CD AS OUT_ACO_PRI_CD, PAO.CORSP_ADR_IND AS OUT_ACO_CORR_CD, PAO.EFF_DT AS OUT_ACO_EFF_DATE, PAO.CANC_DT AS OUT_ACO_CAN_DATE, PAO.TMLN_RSN_TYP_CD AS OUT_ACO_CAN_REASON,PAO.LST_UPDT_DT AS PAO_LST_UPDT_DT, case when unix_timestamp(PAO.LST_UPDT_DT,'yyyy-MM-dd')  > unix_timestamp(${WS_PREV_RUN_DT_YMD},'yyyy-MM-dd') then (case when unix_timestamp(PAO.CANC_DT,'yyyy-MM-dd') < unix_timestamp('9999-12-31','yyyy-MM-dd') then 'C' else 'Y' end) else (case when unix_timestamp(PAO.CANC_DT,'yyyy-MM-dd') = unix_timestamp('9999-12-31','yyyy-MM-dd') then 'N' else '' end) end as OUT_ACO_CHG_IND FROM ${SchemaNm}_PROV_TIN_ADR_CONTR_ORG PAO INNER JOIN ACO_SEL_65_CUR SEL ON (PAO.PROV_ID = SEL.OUT_ADD_PROV_ID AND PAO.ADR_ID = SEL.OUT_ADD_ADR_ID_9) INNER JOIN ${SchemaNm}_PROV_TIN_PAY_AFFIL PTP ON (PTP.PROV_ID = SEL.OUT_ADD_PROV_ID AND PAO.TAX_ID_NBR = PTP.TAX_ID_NBR AND PTP.TAX_ID_NBR = SEL.TAX_ID_NBR ) INNER JOIN ${SchemaNm}_PROV_TIN_ADR PTA ON (PTA.PROV_ID = SEL.OUT_ADD_PROV_ID AND PTP.TAX_ID_NBR = PTA.TAX_ID_NBR AND PTA.TAX_ID_TYP_CD = PTP.TAX_ID_TYP_CD AND PAO.ADR_ID = PTA.ADR_ID AND PTA.ADR_TYP_CD = SEL.OUT_ADD_TYP_CD)",null,null)
    val queries = Seq(query1,query2)
    val segDtls = new SegmentDetails("AD1",
      "20",
      "OUT_ACO_REC_TYP_CD;OUT_ACO_PROV_ID;OUT_ACO_TIN;OUT_ACO_MAID_3;OUT_ACO_MAID_9;OUT_ACO_MAID_TYP_CD;OUT_ACO_CONT_ORG;OUT_ACO_PRI_CD;OUT_ACO_CORR_CD;OUT_ACO_EFF_DATE;OUT_ACO_CAN_DATE;OUT_ACO_CAN_REASON;OUT_ACO_CHG_IND",
      "3;9;9;3;9;4;4;1;1;10;10;2;1",
      "400",
      "",
      queries
    )
    val SW_SKIP_ACO = "N"
    val WS_PREV_RUN_DT_YMD = "9999-12-31"
    val segDetailsSeq =Seq(segDtls)
    val inputEntity = new ExtractFileEntity("F5938RK4","PRV;ALT;PSP;SCO;PQI;HAS;PLI;PFA;TIN;PTI;TCO;NCE;ADD;PHO;ACT;LGS;LNG;HRS;HCA;ACO;AD1;CON;CDK;CSP;COS;CUL;NPI;COE","F5938DBE","NA","NA","NA",segDetailsSeq)
    val prevRunDate =""
    val outputFilePath ="maprfs:///user/sgoyal34"
    val spark=globalContext.sparkSession
    //val SchemaNm = "F5938DBE"
    /*    import spark.implicits._
        val s=Seq((1233, 176),
          (234, 2323),
          (30000, 29898))
        val df=s.toDF("OUT_PHO_PROV_ID","OUT_PHO_TEL_NBR")
        df.createOrReplaceTempView("ADD_FINAL_QRY")*/

    println("=======================" + spark.catalog.tableExists("ADD_FINAL_QRY") + "========")
    assert(ad1SegGen(segDtls,outputFilePath,glblVarLst)(globalContext).equals("N"))
  }


  override def afterAll(): Unit = {
    super.afterAll()
    globalContext.sparkContext.stop()
  }
}


