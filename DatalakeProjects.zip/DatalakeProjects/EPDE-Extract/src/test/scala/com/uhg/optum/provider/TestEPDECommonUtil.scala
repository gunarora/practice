package com.uhg.optum.provider

import com.uhg.optum.JobRunner.{PEI, PEIInstanceEmpty}
import com.uhg.optum.dao.{HbaseRepositoryManager, LocalRepositoryManager}
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDEInputJsonSchema.{EPDEInputExtractInfo, ExtractDetail, ExtractFileEntity, QueryDetail}
import com.uhg.optum.provider.validators.PreExtractValidator
import com.uhg.optum.util.{EPDECommonUtil, Logger}
import com.uhg.optum.tests.base.UnitSpec
import org.apache.spark.sql.{DataFrame, Row, SQLContext}
import org.mockito.Mockito.when
import com.uhg.optum.util.CommonUtil
import com.uhg.optum.util.exceptions.QueryFailureException
import spray.json.JsObject

import scala.util.{Failure, Success, Try}

class TestEPDECommonUtil extends UnitSpec {
  implicit var globalContext: GlobalContext = _
  implicit var pei: PEI = _

  override def beforeAll(): Unit = {
    super.beforeAll()

    //val peiRowKey = "MCAD_Reporting-TOPS"
 globalContext = new GlobalContext("EPDE-OPTUM","local") with LocalRepositoryManager

    import com.uhg.optum.protocols.PEIProtocol._
    globalContext.peTable.get("EPDE-OPTUM", "pei") match {
      case Success(instance) =>
        this.pei = instance
        Success()
      case Failure(ex) =>
        Failure(new PEIInstanceEmpty("Exception while getting the columns info from PEI Table", ex))
    }
    // globalContext = mock[GlobalContext with LocalRepositoryManager]
  }


 /* test("Getting the dataframe from empty sql query should be failure test1") {
    val sqlContext = mock[SQLContext]
    // when(globalContext.sqlContext).thenReturn(sqlContext)
    val dataFrame = mock[DataFrame]
    val query = ""
    when(sqlContext.sql(query)).thenReturn(dataFrame)
    assert(EPDECommonUtil.getDataframeFromQuery(query)(globalContext).isFailure)
  }
  test("Getting the dataframe from null sql query should be failure test2") {
    val sqlContext = mock[SQLContext]
    // when(globalContext.sqlContext).thenReturn(sqlContext)
    val dataFrame = mock[DataFrame]
    val query = null
    when(sqlContext.sql(query)).thenReturn(dataFrame)
    assert(EPDECommonUtil.getDataframeFromQuery(query)(globalContext).isFailure)
  }*/
  /*test("Getting the dataframe from non Select  sql query should be failure test3") {
    val sqlContext = mock[SQLContext]
    // when(globalContext.sqlContext).thenReturn(sqlContext)
    val dataFrame = mock[DataFrame]
    val query = "c Select "
    when(sqlContext.sql(query)).thenReturn(dataFrame)
    assert(EPDECommonUtil.getDataframeFromQuery(query)(globalContext).isFailure)
  }*/

  test("Getting the dataframe from sql query should be success") {
    val sqlcontext = mock[SQLContext]
    //when(globalContext.sqlContext).thenReturn(sqlcontext)
    val dataFrame = mock[DataFrame]
    val query = "Select * "
    when(sqlcontext.sql(query)).thenReturn(dataFrame)
    assert(EPDECommonUtil.getDataframeFromQuery(query)(globalContext).isSuccess)
  }
  test("Sql query should be optimised with new values") {
    var query = "select * from XYZ where vendor_code='$vendor_code'"
    val expectedResult = "select * from XYZ where vendor_code='OPTUM'"
    var result = EPDECommonUtil.optimiseQuery(query, "OPTUM", "$vendor_code")
    assert(expectedResult == result)
  }
  test("Getting the Common queries details should be success") {
    val extractFileEntity = mock[ExtractFileEntity]
    val extractDetailsSeq = mock[Seq[ExtractDetail]]
    val extractDetails = mock[ExtractDetail]
    val queryDetails = mock[Seq[QueryDetail]]
    when(extractFileEntity.extractDetails).thenReturn(extractDetailsSeq)
    when(extractDetailsSeq.head).thenReturn(extractDetails)
    when(extractDetails.commonQueries).thenReturn(queryDetails)

    assert(EPDECommonUtil.getCommonQueriesDetails(extractFileEntity).isSuccess)
  }
  test("Getting the Contract queries details should be success") {
    val extractFileEntity = mock[ExtractFileEntity]
    val extractDetailsSeq = mock[Seq[ExtractDetail]]
    val extractDetails = mock[ExtractDetail]
    val queryDetails = mock[Seq[QueryDetail]]
    when(extractFileEntity.extractDetails).thenReturn(extractDetailsSeq)
    when(extractDetailsSeq.head).thenReturn(extractDetails)
    when(extractDetails.commonQueries).thenReturn(queryDetails)
    assert(EPDECommonUtil.getContractQueriesDetails(extractFileEntity).isSuccess)
  }


  test("Validate method should return true for dataframe having count more than zero") {
    val queryMap = Map(("df_query1", "select * from XYZ where value='$vendor_code'"),("df_query1_tables", ""))
    val sqlcontext = mock[SQLContext]
    val key = "df_query1"
    val valueToBeChecked = "$vendor_code"
    val vendorCode = "OPTUM"
    val dataFrame = mock[DataFrame]
    val query = "Select * "
    val sparkSession = globalContext.sparkSession

    import sparkSession.implicits._
    val df = Seq("OPTUM", "OPC").toDF()
    df.createOrReplaceTempView("XYZ")
    val lastRunPlc=""
    //when(sqlcontext.sql("select * from XYZ where value='OPTUM'")).thenReturn(dataFrame)
    //when(EPDECommonUtil.getDataframeFromQuery("select * from XYZ where value='OPTUM'")(globalContext).get).thenReturn(dataFrame)
    // when(dataFrame.count()).thenReturn(1)
    //when(EPDECommonUtil.getDataframeFromQuery("select * from XYZ where vendor_code='OPTUM'")(globalContext)).thenReturn(Try(dataFrame))
    assert(PreExtractValidator.validate(queryMap, key, valueToBeChecked, vendorCode,lastRunPlc).get == true)

  }


  // val queryMap = Map(("df_query1", "select * from XYZ where vendor_code='$vendor_code'"))
  // val key = "df_query1"
  //  val valueToBeChecked = "$vendor_code"
  // val vendorCode = "OPTUM"
  ///val inputEntity = mock[ExtractFileEntity]
  // val df = mock[DataFrame]
  //val sqlContext = mock[SQLContext]
  // when(sqlContext.sql("select * from XYZ where vendor_code='OPTUM'")).thenReturn(df)
  //when(sqlcontext.sql()).thenReturn(df)
  // when(EPDECommonUtil.getDataframeFromQuery("select * from XYZ where vendor_code='OPTUM'")(globalContext)).thenReturn(Try(df))
  //when(df.count()).thenReturn(1)
  // assert(PreExtractValidator.validate(queryMap, key, valueToBeChecked, vendorCode)(globalContext).get == true)
  test("Validate method should return false for dataframe having count equal to zero") {
    val queryMap = Map(("df_query1", "select * from XYZ where value='$vendor_code'"),("df_query1_tables", ""))
    val key = "df_query1"
    val valueToBeChecked = "$vendor_code"
    val vendorCode = "OPTUM"
    val sparkSession = globalContext.sparkSession

    import sparkSession.implicits._
    val df = Seq("UHG", "OPC").toDF()
    df.createOrReplaceTempView("XYZ")
    val lastRunPlc=""
    assert(PreExtractValidator.validate(queryMap, key, valueToBeChecked, vendorCode,lastRunPlc).get == false)

  }
  /*test("Validate method should return false for dataframe having count equal to zero") {
    val queryMap = Map(("df_query1", "select * from XYZ where vendor_code='$vendor_code'"))
    val key = "df_query1"
    val valueToBeChecked = "$vendor_code"
    val vendorCode = "OPTUM"
    val df = mock[DataFrame]
    val sqlcontext = mock[SQLContext]
   // when(globalContext.sqlContext).thenReturn(sqlcontext)
    when(sqlcontext.sql(queryMap.get(key).head.toString)).thenReturn(df)
    when(EPDECommonUtil.getDataframeFromQuery("select * from XYZ where vendor_code='OPTUM'")(globalContext).get).thenReturn(df)
    when(df.count()).thenReturn(0)
    assert(PreExtractValidator.validate(queryMap, key, valueToBeChecked, vendorCode)(globalContext).get == false)
  }*/
  test("getCriteriaIndicator method should return 'Y' for dataframe having count equal to one") {
    // implicit val globalContext = new GlobalContext("Test","EPDE_OPTUM") with LocalRepositoryManager
    val queryMap = Map(("df_query1", "select * from XYZ where value='$vendor_code'"),("df_query1_tables", ""))
    val key = "df_query1"
    val valueToBeChecked = "$vendor_code"
    val vendorCode = "OPTUM"
    val sparkSession = globalContext.sparkSession
    import sparkSession.implicits._
    val df = Seq("OPTUM", "OPC").toDF()
    df.createOrReplaceTempView("XYZ")
    val lastRunPlc=""
    assert(PreExtractValidator.getCriteriaIndicator(queryMap, key, valueToBeChecked, vendorCode,lastRunPlc) == "Y")

  }
  test("getCriteriaIndicator method should return 'N'  for dataframe having count other than  one") {
    val queryMap = Map(("df_query1", "select * from XYZ where value='$vendor_code'"),("df_query1_tables", ""))
    val key = "df_query1"
    val valueToBeChecked = "$vendor_code"
    val vendorCode = "OPTUM"
    val sparkSession = globalContext.sparkSession
    import sparkSession.implicits._
    val df = Seq("OPTUM1", "OPTUM1").toDF()
    df.createOrReplaceTempView("XYZ")
    val lastRunPlc=""
    assert(PreExtractValidator.getCriteriaIndicator(queryMap, key, valueToBeChecked, vendorCode,lastRunPlc) == "N")

  }

  test("checkFullFileIndicator method should return 'F' for fullFileInd having value 'W' and currDay>5") {
    val queryMap = Map(("df5_query", "SELECT CRIT_TXT_VAL_1 FROM XYZ WHERE DATA_VEND_CD= '$vendor_cd'"),("df5_query_tables", ""))
    val currDay = 6
    //  val row = Row("W")
    val currWeekOfMon = 1
    val key = "df5_query"
    val vendorCode = "OPTUM"
    val sparkSession = globalContext.sparkSession
    import sparkSession.implicits._
    //val df = Seq("OPTUM","OPTUM").toDF()
    val df = Seq(
      ("W", "OPTUM"),
      ("W", "OPC"),
      ("L", "ABC")
    ).toDF("CRIT_TXT_VAL_1", "DATA_VEND_CD")
    df.createOrReplaceTempView("XYZ")
    val lastRunPlc=""
    assert(PreExtractValidator.checkFullFileIndicator(queryMap, vendorCode, currDay, currWeekOfMon,lastRunPlc).get == "F")
  }
  /*test("checkFullFileIndicator method should return 'F' for fullFileInd having value 'W' and currDay>5") {
    val queryMap = Map(("df5_query", "select * from XYZ where vendor_code='$vendor_cd'"))
    val currDay = 6
    val row = Row("W")
    val currWeekOfMon = 1
    val key = "df5_query"
    val vendorCode = "OPTUM"
    val df5 = mock[DataFrame]
    val sqlcontext = mock[SQLContext]
    when(globalContext.sqlContext).thenReturn(sqlcontext)
    when(EPDECommonUtil.getDataframeFromQuery("select * from XYZ where vendor_code='OPTUM'")(globalContext).get).thenReturn(df5)
    when(df5.count()).thenReturn(1)
    when(df5.head).thenReturn(row)
    assert(PreExtractValidator.checkFullFileIndicator(queryMap, vendorCode, currDay, currWeekOfMon)(globalContext).get == "F")
  }*/
  test("checkFullFileIndicator method should return 'F' for fullFileInd = 'M',cur_weekOfMonth=1 and currDay>5") {
    //val queryMap = Map(("df5_query", "select * from XYZ where vendor_code='$vendor_cd'"))
    val queryMap = Map(("df5_query", "SELECT CRIT_TXT_VAL_1 FROM XYZ WHERE DATA_VEND_CD= '$vendor_cd'"),("df5_query_tables", ""))
    //val query="SELECT CRIT_TXT_VAL_1 FROM XYZ WHERE DATA_VEND_CD= '$vendor_cd'"
    val currDay = 6
    //val row = Row("M")
    val currWeekOfMon = 1
    val key = "df5_query"
    val vendorCode = "OPTUM"
    val sparkSession = globalContext.sparkSession
    import sparkSession.implicits._
    //val df = Seq("OPTUM","OPTUM").toDF()
    val df = Seq(
      ("M", "OPTUM"),
      ("W", "OPC"),
      ("L", "ABC")
    ).toDF("CRIT_TXT_VAL_1", "DATA_VEND_CD")
    df.createOrReplaceTempView("XYZ")
    /*val df5 = mock[DataFrame]
    val sqlcontext = mock[SQLContext]
    when(globalContext.sqlContext).thenReturn(sqlcontext)
    when(EPDECommonUtil.getDataframeFromQuery("select * from XYZ where vendor_code='OPTUM'")(globalContext).get).thenReturn(df5)
    when(df5.count()).thenReturn(1)
    when(df5.head).thenReturn(row)*/
    val lastRunPlc=""
    assert(PreExtractValidator.checkFullFileIndicator(queryMap, vendorCode, currDay, currWeekOfMon,lastRunPlc).get == "F")
  }
  test("checkFullFileIndicator method should return 'F' for fullFileInd = 'O'") {
    val queryMap = Map(("df5_query", "SELECT CRIT_TXT_VAL_1 FROM XYZ WHERE DATA_VEND_CD= '$vendor_cd'"),("df5_query_tables", ""))
    val currDay = 6
    //val row = Row("O")
    val currWeekOfMon = 1
    val vendorCode = "OPTUM"
    val sparkSession = globalContext.sparkSession
    import sparkSession.implicits._
    //val df = Seq("OPTUM","OPTUM").toDF()
    val df = Seq(
      ("O", "OPTUM"),
      ("W", "OPC"),
      ("L", "ABC")
    ).toDF("CRIT_TXT_VAL_1", "DATA_VEND_CD")
    df.createOrReplaceTempView("XYZ")
    val lastRunPlc=""
    assert(PreExtractValidator.checkFullFileIndicator(queryMap, vendorCode, currDay, currWeekOfMon,lastRunPlc).get == "F")
  }
  test("checkFullFileIndicator method should return 'P' for fullFileInd = 'P'") {
    val queryMap = Map(("df5_query", "SELECT CRIT_TXT_VAL_1 FROM XYZ WHERE DATA_VEND_CD= '$vendor_cd'"),("df5_query_tables", ""))
    val currDay = 6
    //val row = Row("P")
    val currWeekOfMon = 1
    val key = "df5_query"
    val vendorCode = "OPTUM"
    val sparkSession = globalContext.sparkSession
    import sparkSession.implicits._
    //val df = Seq("OPTUM","OPTUM").toDF()
    val df = Seq(
      ("P", "OPTUM"),
      ("W", "OPC"),
      ("L", "ABC")
    ).toDF("CRIT_TXT_VAL_1", "DATA_VEND_CD")
    df.createOrReplaceTempView("XYZ")
    val lastRunPlc=""
    assert(PreExtractValidator.checkFullFileIndicator(queryMap, vendorCode, currDay, currWeekOfMon,lastRunPlc).get == "P")
  }
  test("checkFullFileIndicator method should return 'N' for output dataframe having count less than 1 ") {
    val queryMap = Map(("df5_query", "SELECT CRIT_TXT_VAL_1 FROM XYZ WHERE DATA_VEND_CD= '$vendor_cd'"),("df5_query_tables", ""))
    val currDay = 6
    val row = Row("F")
    val currWeekOfMon = 1
    val key = "df5_query"
    val vendorCode = "OPTUM"
    val sparkSession = globalContext.sparkSession
    import sparkSession.implicits._
    //val df = Seq("OPTUM","OPTUM").toDF()
    val df = Seq(
      ("P", "OPTUM1"),
      ("W", "OPC"),
      ("L", "ABC")
    ).toDF("CRIT_TXT_VAL_1", "DATA_VEND_CD")
    df.createOrReplaceTempView("XYZ")
    val lastRunPlc=""
    assert(PreExtractValidator.checkFullFileIndicator(queryMap, vendorCode, currDay, currWeekOfMon,lastRunPlc).get == "N")
  }
  /*test("checkFullFileIndicator method should throw exception  for output dataframe having count more than 1 ") {
    val queryMap = Map(("df5_query", "SELECT CRIT_TXT_VAL_1 FROM XYZ WHERE DATA_VEND_CD= '$vendor_cd'"),("df5_query_tables", ""))
    val currDay = 6
    val row = Row("F")
    val currWeekOfMon = 1
    val key = "df5_query"
    val vendorCode = "OPTUM"
    val sparkSession = globalContext.sparkSession
    import sparkSession.implicits._
    //val df = Seq("OPTUM","OPTUM").toDF()
    val df = Seq(
      ("P", "OPTUM"),
      ("W", "OPTUM"),
      ("L", "ABC")
    ).toDF("CRIT_TXT_VAL_1", "DATA_VEND_CD")
    df.createOrReplaceTempView("XYZ")
    val lastRunPlc=""
    assert(PreExtractValidator.checkFullFileIndicator(queryMap, vendorCode, currDay, currWeekOfMon,lastRunPlc).isFailure)
  }*/

  override def afterAll(): Unit = {

    super.afterAll()
    globalContext.sparkContext.stop()
  }

  /* val extractFileEntity=mock[ExtractFileEntity]
   val extractDetailsSeq=mock[Seq[ExtractDetail]]
   val extractDetails=mock[ExtractDetail]
   val queryDetails=mock[Seq[QueryDetail]]
   when(extractFileEntity.extractDetails).thenReturn(extractDetailsSeq)
   when(extractDetailsSeq.head).thenReturn(extractDetails)
   when(extractDetails.commonQueries).thenReturn(queryDetails)
   assert(EPDECommonUtil.getContractQueriesDetails(extractFileEntity).isSuccess)*/
  /*override def afterAll() {
  }*/
  /*var sparkSession : SparkSession = _
  override def beforeAll(): Unit = {
    sparkSession = SparkSession.builder().appName("udf testings")
      .master("local")
      .config("", "")
      .getOrCreate()
  }*/
  //var globalContext: GlobalContext = _
  /* var sparkSession : SparkSession = _
   override def beforeEach() {
     sparkSession = SparkSession.builder().appName("udf testings")
       .master("local")
       .config("", "")
       .getOrCreate()
   }*/
  /*test ("getting the dataframe should throw exception") {
   intercept[Exception] {
      EPDECommonUtil.getDataframeFromQuery("select * from XYZ")(globalContext)
    }*/
  /*test("get dataframe from the query"){
    val dataframe = mock[DataFrame]
  }*/
  /* override def afterEach() {
     sparkSession.stop()
   }*/
  /*test("Test1 PITUpdateUtil should succeed") {
    val pITUpdate = mock[EPDECommonUtil]
    //val logFileName = "file:///src/main/resources/PITUpdate.log"
    val logRDD = mock[RDD[String]]
    when(pITUpdate.getRDD(Matchers.any(),Matchers.contains(logFileName))).thenReturn(logRDD)
    when(pITUpdate.getTempExtractPath(logRDD)).thenReturn(Try(extractPath))
    val testMockRDD = globalContext.sparkContext.parallelize(List(pitRowKeyRdd))
    when(pITUpdate.getRDD(Matchers.any(),Matchers.contains(extractMeta))).thenReturn(testMockRDD)
    when(pITUpdate.extractRowWithFilter(Matchers.contains(pitRowKeyCF),Matchers.any())).thenReturn(Try{peiRowKey})
    when(pITUpdate.extractRowWithFilter(Matchers.contains(extractFilePathCF),Matchers.any())).thenReturn(Try{extractPath})
    when(pITUpdate.updateHBaseField(globalContext,peiRowKey,status)).thenReturn(Try{true})
    when(pITUpdate.rmFileOrPath(extractPath)).thenReturn(Try{true})
    when(pITUpdate.updatePIT(status,logFileName,globalContext)).thenCallRealMethod()
    assert(pITUpdate.updatePIT(status,logFileName,globalContext).isSuccess)
  }*/
}