package com.uhg.optum.provider.extractors

import com.uhg.optum.JobRunner.{PEI, PEIInstanceEmpty}
import com.uhg.optum.dao.{HbaseRepositoryManager, LocalRepositoryManager}
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDERK4InputJsonSchema.{ExtractFileEntity, Query, SegmentDetails}
import com.uhg.optum.provider.extractors.{EPDERK4JsonSourceExtractor, EPDERK4_PHO_SegExt}
import com.uhg.optum.util.CommonUtil
import com.uhg.optum.tests.base.UnitSpec
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.sql.DataFrame
import org.mockito.Mockito.when

import scala.util.{Failure, Success}


class TestPHOSegmentUtil extends UnitSpec with EPDERK4_PHO_SegExt {
  var globalContext: GlobalContext = _
  implicit var pei: PEI = _
  var glblVarLst = collection.mutable.Map[String, String]()
  var varLst = collection.mutable.Map[String, String]()
  override def beforeAll(): Unit = {
    super.beforeAll()

    globalContext = new GlobalContext("EPDE-OPTUM","local") with LocalRepositoryManager
    import com.uhg.optum.protocols.PEIProtocol._
    globalContext.peTable.get("EPDE-OPTUM", "pei") match {
      case Success(instance) =>
        this.pei = instance
        Success()
      case Failure(ex) =>
        Failure(new PEIInstanceEmpty("Exception while getting the columns info from PEI Table", ex))
    }
    val WS_CANC_DT_1="01/01/0001"  // used in PSP ; genrated in
    val WS_CANC_DT_2="12/31/9999"  // used in PSP ; genrated in
    val WS_UPDT_DT_1= "03/01/2019"  // used in PSP
    val WS_UPDT_DT_2="12/31/9999"   // used in PSP
    val WS_ACTV_CD_1="A"  // used in ADD
    val WS_ACTV_CD_2="I"   // used in ADD




    CommonUtil.add2Map(glblVarLst,"${WS_CANC_DT_1}",WS_CANC_DT_1)
    CommonUtil.add2Map(glblVarLst,"${WS_CANC_DT_2}",WS_CANC_DT_2)
    CommonUtil.add2Map(glblVarLst,"${WS_UPDT_DT_1}",WS_UPDT_DT_1)
    CommonUtil.add2Map(glblVarLst,"${WS_UPDT_DT_2}",WS_UPDT_DT_2)

    CommonUtil.add2Map(glblVarLst,"${WS_ACTV_CD_1}",WS_ACTV_CD_1)
    CommonUtil.add2Map(glblVarLst,"${WS_ACTV_CD_2}",WS_ACTV_CD_2)

  }


  test("phoSegGen method should return 'N' if there is no ADR_TYP_VIEW  query for PHO segment") {
    val query = new Query("ADR_TYP_VIEW1", "SELECT DISTINCT 'PHO' AS OUT_PHO_REC_TYP,OUT_PHO_PROV_ID,OUT_PHO_TEL_NBR FROM ADD_FNL_VIEW WHERE OUT_PHO_PROV_ID=11", null, null)
    val queries = Seq(query)
    val segDtls = new SegmentDetails("PHO",
      "14",
      "OUT_PHO_REC_TYP;OUT_PHO_PROV_ID;OUT_PHO_TEL_NBR;OUT_PHO_AREA_CD;OUT_PHO_TYP_CD;OUT_PHO_DIR_IND;OUT_PHO_CHG_IND;OUT_PHO_EXT_NBR;OUT_PHO_PRI_CD;OUT_PHO_ACTV_CD;OUT_PHO_TEL_TYP_CD",
      "3;9;7;3;1;1;1;10;1;1;1",
      "400","",
      queries
    )
    val segDtlsSeq = Seq(segDtls)
    val prevRunDate = ""
    val outputFilePath = ""
    val spark = globalContext.sparkSession

    import spark.implicits._
    val s = Seq((1233, 176),
      (234, 2323),
      (30000, 29898))
    val df = s.toDF("OUT_PHO_PROV_ID", "OUT_PHO_TEL_NBR")
    df.createOrReplaceTempView("ADD_FNL_VIEW")

    println("=======================" + spark.catalog.tableExists("ADD_FNL_VIEW") + "========")

    assert(phoSegGen(segDtls, outputFilePath,glblVarLst)(globalContext) == "N")
  }

  test("SegDtls Object for PHO Segment should be not null") {
    val SchemaNm = "F5938DBE"
    val inputEntity = mock[ExtractFileEntity]
    val query = new Query("ADR_TYP_VIEW1", "SELECT DISTINCT 'PHO' AS OUT_PHO_REC_TYP,OUT_PHO_PROV_ID,OUT_PHO_TEL_NBR FROM ADD_FNL_VIEW WHERE OUT_PHO_PROV_ID=11", null, null)
    val queries = Seq(query)
    var segDtls = new SegmentDetails("PHO",
      "14",
      "OUT_PHO_REC_TYP;OUT_PHO_PROV_ID;OUT_PHO_TEL_NBR;OUT_PHO_AREA_CD;OUT_PHO_TYP_CD;OUT_PHO_DIR_IND;OUT_PHO_CHG_IND;OUT_PHO_EXT_NBR;OUT_PHO_PRI_CD;OUT_PHO_ACTV_CD;OUT_PHO_TEL_TYP_CD",
      "3;9;7;3;1;1;1;10;1;1;1",
      "400","",
      queries
    )
    segDtls=null

    val segDetailsSeq =Seq(segDtls)
    when(inputEntity.segmentDetails).thenReturn(segDetailsSeq)
    var outputFilePath = ""
    /*    inputEntity.segmentDetails.map{
          s => s.segQueries.map{
            m => var key = m.name
              println("key:: " + key)
              var value = m.query
              println("value:: " +value)
          }
        }*/

    assertThrows[NullPointerException]
      {
        phoSegGen(segDtls,outputFilePath,glblVarLst)(globalContext)
      }
    //assert(caught.getMessage.indexOf("-1"))
    //assert(genSCOSeg(segDtls,glblVarLst,SW_SKIP_SCO,outputFilePath)(globalContext).isFailure)

  }

  test("Getting the dataframe from empty sql query should not be success") {

    val dataFrame = mock[DataFrame]
    var query = mock[Query]
    query = new Query("PHO_FNL_VIEW","",null,null)
    val queries = Seq(query)
    var segDtls = new SegmentDetails("PHO",
      "14",
      "OUT_PHO_REC_TYP;OUT_PHO_PROV_ID;OUT_PHO_TEL_NBR;OUT_PHO_AREA_CD;OUT_PHO_TYP_CD;OUT_PHO_DIR_IND;OUT_PHO_CHG_IND;OUT_PHO_EXT_NBR;OUT_PHO_PRI_CD;OUT_PHO_ACTV_CD;OUT_PHO_TEL_TYP_CD",
      "3;9;7;3;1;1;1;10;1;1;1",
      "400","",
      queries
    )
    val segDetailsSeq = Seq(segDtls)

    // val inputEntity = new ExtractFileEntity("F5938RK4","PRV;ALT;PSP;SCO;PQI;HAS;PLI;PFA;TIN;PTI;TCO;NCE;ADD;PHO;ACT;LGS;LNG;HRS;HCA;ACO;AD1;CON;CDK;CSP;COS;CUL;NPI;COE","F5938DBE",segDetailsSeq)
    val prevRunDate =""
    val outputFilePath ="maprfs:///datalake/uhclake/tst/developer/EPDE/TestFiles/"
    val spark=globalContext.sparkSession
    //val SchemaNm = "F5938DBE"
    import spark.implicits._
    val s=Seq((1233, 176),
      (234, 2323),
      (30000, 29898))
    val df=s.toDF("OUT_PRV_PROV_ID","OUT_PRV_TEL_NBR")
    df.createOrReplaceTempView("PRV_FNL_VIEW")
    val thrownExcep = intercept[Exception] {
      phoSegGen(segDtls,outputFilePath,glblVarLst)(globalContext)
    }
    assert(thrownExcep.getMessage == "ERROR : Cannot make DF as Query is empty or NULL or does not start with select PHO_FNL_VIEW")

  }

  test("phoSegGen method should be success if the ADD_FNL_VIEW  exist") {
    val SW_SKIP_SCO = "N"
    val SchemaNm = "F5938DBE"
    val inputEntity = mock[ExtractFileEntity]
    //val query = new Query("SCO_PROV_AFFIL","SELECT 'SCO' AS OUT_SCO_REC_TYP_CD, PSO.PROV_ID AS OUT_SCO_PROV_ID,PSO.CONTR_ORG_CD AS OUT_SCO_CONT_ORG,PSO.PRI_CD AS OUT_SCO_PRI_SEC_CD,PSO.SPCL_TYP_CD AS OUT_SCO_CODE, ,SPT.SPCL_TYP_SHRT_DESC  AS OUT_SCO_CODE_DESC,PSO.CRED_VERF_ORG_IND AS OUT_SCO_BOARD,PSO.PRAC_SPCL_IND AS OUT_SCO_PRACT_IND ,PSO.SPCL_SRC_CD AS OUT_SCO_VER_SOURCE ,PSO.SPCL_BD_CERT_CD  AS OUT_SCO_BC,PSO.SPCL_BD_CERT_DT AS OUT_SCO_CERT_DATE,PSO.RCERT_EFF_DT AS OUT_SCO_RE_CERT_DATE ,PSO.SPCL_BD_EXPIR_DT AS OUT_SCO_EXP_DATE,PSO.SPCL_BD_EXAM_DT AS OUT_SCO_BOARD_DATE,PSO.EFF_DT  AS OUT_SCO_EFF_DATE ,PSO.CANC_DT AS OUT_SCO_CAN_DATE ,PSO.RES_IND AS OUT_SCO_RESIDENT ,PSO.PCP_SPCL_OVRD_IND AS OUT_SCO_PCP_OVR, PSO.LST_UPDT_DT AS PSO_LST_UPDT_DT from ${SchemaNm}_PROV_SPCL_CONTR_ORG PSO,${SchemaNm}_SPCL_TYP  SPT ,${SchemaNm}_SPCL_TYP_CATGY STC ,${SchemaNm}_PROV_SPCL  PSP WHERE  PSO.PROV_ID  = ${WS_SQL_PROV_ID}  AND  PSO.SPCL_TYP_CD = ${WS_PSO_SPCL_TYP_CD} AND  PSO.PROV_ID =  PSP.PROV_ID AND  PSO.SPCL_TYP_CD   =  SPT.SPCL_TYP_CD AND  SPT.SPCL_TYP_CD  =  STC.SPCL_TYP_CD ANDSTC.SPCL_TYP_CD = PSP.SPCL_TYP_CD AND  PSO.CONTR_ORG_CD  <> 'UHN'",null,null)
    val query = new Query("PHO_FNL_VIEW1","SELECT * FROM ADD_FNL_VIEW",null,null)
    val queries = Seq(query)
    var segDtls = new SegmentDetails("PHO",
      "14",
      "OUT_PHO_REC_TYP;OUT_PHO_PROV_ID;OUT_PHO_TEL_NBR;OUT_PHO_AREA_CD;OUT_PHO_TYP_CD;OUT_PHO_DIR_IND;OUT_PHO_CHG_IND;OUT_PHO_EXT_NBR;OUT_PHO_PRI_CD;OUT_PHO_ACTV_CD;OUT_PHO_TEL_TYP_CD",
      "3;9;7;3;1;1;1;10;1;1;1",
      "400","",
      queries
    )
    val segDetailsSeq =Seq(segDtls)
    // val inputEntity = new ExtractFileEntity("F5938RK4","PRV;ALT;PSP;SCO;PQI;HAS;PLI;PFA;TIN;PTI;TCO;NCE;ADD;PHO;ACT;LGS;LNG;HRS;HCA;ACO;AD1;CON;CDK;CSP;COS;CUL;NPI;COE","F5938DBE",segDetailsSeq)
    val prevRunDate =""
    val outputFilePath ="maprfs:///datalake/uhclake/tst/developer/EPDE/TestFiles/"
    val spark=globalContext.sparkSession
    //val SchemaNm = "F5938DBE"
    import spark.implicits._
    val s=Seq((1233, 176),
      (234, 2323),
      (30000, 29898))
    val df=s.toDF("OUT_PHO_PROV_ID","OUT_PHO_TEL_NBR")
    df.createOrReplaceTempView("ADD_FNL_VIEW")
    println("======================="+spark.catalog.tableExists("ADD_FNL_VIEW")+"========")

    /*  val thrownExcep = intercept[Exception] {
        acoSegGen(inputEntity,SW_SKIP_ACO, WS_PREV_RUN_DT_YMD, outputFilePath)(globalContext)
      }*/
    assert(phoSegGen(segDtls,outputFilePath,glblVarLst)(globalContext)=="N")
  }
  test("phoSegGen method should be failure if the ADD_FNL_VIEW  does not exist") {
    val SW_SKIP_SCO = "N"
    val SchemaNm = "F5938DBE"
    val inputEntity = mock[ExtractFileEntity]
    //val query = new Query("SCO_PROV_AFFIL","SELECT 'SCO' AS OUT_SCO_REC_TYP_CD, PSO.PROV_ID AS OUT_SCO_PROV_ID,PSO.CONTR_ORG_CD AS OUT_SCO_CONT_ORG,PSO.PRI_CD AS OUT_SCO_PRI_SEC_CD,PSO.SPCL_TYP_CD AS OUT_SCO_CODE, ,SPT.SPCL_TYP_SHRT_DESC  AS OUT_SCO_CODE_DESC,PSO.CRED_VERF_ORG_IND AS OUT_SCO_BOARD,PSO.PRAC_SPCL_IND AS OUT_SCO_PRACT_IND ,PSO.SPCL_SRC_CD AS OUT_SCO_VER_SOURCE ,PSO.SPCL_BD_CERT_CD  AS OUT_SCO_BC,PSO.SPCL_BD_CERT_DT AS OUT_SCO_CERT_DATE,PSO.RCERT_EFF_DT AS OUT_SCO_RE_CERT_DATE ,PSO.SPCL_BD_EXPIR_DT AS OUT_SCO_EXP_DATE,PSO.SPCL_BD_EXAM_DT AS OUT_SCO_BOARD_DATE,PSO.EFF_DT  AS OUT_SCO_EFF_DATE ,PSO.CANC_DT AS OUT_SCO_CAN_DATE ,PSO.RES_IND AS OUT_SCO_RESIDENT ,PSO.PCP_SPCL_OVRD_IND AS OUT_SCO_PCP_OVR, PSO.LST_UPDT_DT AS PSO_LST_UPDT_DT from ${SchemaNm}_PROV_SPCL_CONTR_ORG PSO,${SchemaNm}_SPCL_TYP  SPT ,${SchemaNm}_SPCL_TYP_CATGY STC ,${SchemaNm}_PROV_SPCL  PSP WHERE  PSO.PROV_ID  = ${WS_SQL_PROV_ID}  AND  PSO.SPCL_TYP_CD = ${WS_PSO_SPCL_TYP_CD} AND  PSO.PROV_ID =  PSP.PROV_ID AND  PSO.SPCL_TYP_CD   =  SPT.SPCL_TYP_CD AND  SPT.SPCL_TYP_CD  =  STC.SPCL_TYP_CD ANDSTC.SPCL_TYP_CD = PSP.SPCL_TYP_CD AND  PSO.CONTR_ORG_CD  <> 'UHN'",null,null)
    val query = new Query("PHO_FNL_VIEW","SELECT * FROM ADD_FNL_VIEW2",null,null)
    val queries = Seq(query)
    var segDtls = new SegmentDetails("PHO",
      "14",
      "OUT_PHO_REC_TYP;OUT_PHO_PROV_ID;OUT_PHO_TEL_NBR;OUT_PHO_AREA_CD;OUT_PHO_TYP_CD;OUT_PHO_DIR_IND;OUT_PHO_CHG_IND;OUT_PHO_EXT_NBR;OUT_PHO_PRI_CD;OUT_PHO_ACTV_CD;OUT_PHO_TEL_TYP_CD",
      "3;9;7;3;1;1;1;10;1;1;1",
      "400","",
      queries
    )
    val segDetailsSeq =Seq(segDtls)
    // val inputEntity = new ExtractFileEntity("F5938RK4","PRV;ALT;PSP;SCO;PQI;HAS;PLI;PFA;TIN;PTI;TCO;NCE;ADD;PHO;ACT;LGS;LNG;HRS;HCA;ACO;AD1;CON;CDK;CSP;COS;CUL;NPI;COE","F5938DBE",segDetailsSeq)
    val prevRunDate =""
    val outputFilePath ="maprfs:///datalake/uhclake/tst/developer/EPDE/TestFiles/"
    val spark=globalContext.sparkSession
    //val SchemaNm = "F5938DBE"
    import spark.implicits._
    val s=Seq((1233, 176),
      (234, 2323),
      (30000, 29898))
    val df=s.toDF("OUT_PHO_PROV_ID","OUT_PHO_TEL_NBR")
    df.createOrReplaceTempView("ADD_FNL_VIEW1")
    println("======================="+spark.catalog.tableExists("ADD_FNL_VIEW1")+"========")

    /*  val thrownExcep = intercept[Exception] {
        acoSegGen(inputEntity,SW_SKIP_ACO, WS_PREV_RUN_DT_YMD, outputFilePath)(globalContext)
      }*/
    assertThrows[org.apache.spark.sql.AnalysisException]
      {
        assert(phoSegGen(segDtls,outputFilePath,glblVarLst)(globalContext)=="N")
      }

  }
 test("phoSegGen method should return 'N' if there is no ADR_CNT  query for PHO segment") {
    val query = new Query("ADR_TYP_VIEW", "SELECT DISTINCT 'PHO' AS OUT_PHO_REC_TYP,OUT_PHO_PROV_ID,OUT_PHO_TEL_NBR FROM ADD_FNL_VIEW WHERE OUT_PHO_PROV_ID=11", null, null)
    val query1 = new Query("ADR_CNT1", "SELECT DISTINCT 'PHO' AS OUT_PHO_REC_TYP,OUT_PHO_PROV_ID,OUT_PHO_TEL_NBR FROM ADD_FNL_VIEW WHERE OUT_PHO_PROV_ID=11", null, null)
    val queries = Seq(query,query1)
    val segDtls = new SegmentDetails("PHO",
      "14",
      "OUT_PHO_REC_TYP;OUT_PHO_PROV_ID;OUT_PHO_TEL_NBR;OUT_PHO_AREA_CD;OUT_PHO_TYP_CD;OUT_PHO_DIR_IND;OUT_PHO_CHG_IND;OUT_PHO_EXT_NBR;OUT_PHO_PRI_CD;OUT_PHO_ACTV_CD;OUT_PHO_TEL_TYP_CD",
      "3;9;7;3;1;1;1;10;1;1;1",
      "400","",
      queries
    )
    val segDtlsSeq = Seq(segDtls)
    val prevRunDate = ""
    val outputFilePath = ""
    val spark = globalContext.sparkSession

    import spark.implicits._
    val s = Seq((1233, 176),
      (234, 2323),
      (30000, 29898))
    val df = s.toDF("OUT_PHO_PROV_ID", "OUT_PHO_TEL_NBR")
    df.createOrReplaceTempView("ADD_FNL_VIEW")

    println("=======================" + spark.catalog.tableExists("ADD_FNL_VIEW") + "========")

    assert(phoSegGen(segDtls, outputFilePath,glblVarLst)(globalContext) == "N")
  }

  test("phoSegGen method should return 'N' if there is no PHO_FETCH_PHON  query for PHO segment") {
    val query = new Query("ADR_TYP_VIEW", "SELECT DISTINCT 'PHO' AS OUT_PHO_REC_TYP,OUT_PHO_PROV_ID,OUT_PHO_TEL_NBR FROM ADD_FNL_VIEW WHERE OUT_PHO_PROV_ID=11", null, null)
    val query1 = new Query("ADR_CNT", "SELECT DISTINCT 'PHO' AS OUT_PHO_REC_TYP,OUT_PHO_PROV_ID,OUT_PHO_TEL_NBR FROM ADD_FNL_VIEW WHERE OUT_PHO_PROV_ID=11", null, null)
    val query2 = new Query("PHO_FETCH_PHON1", "SELECT DISTINCT 'PHO' AS OUT_PHO_REC_TYP,OUT_PHO_PROV_ID,OUT_PHO_TEL_NBR FROM ADD_FNL_VIEW WHERE OUT_PHO_PROV_ID=11", null, null)
    val queries = Seq(query,query1,query2)
    val segDtls = new SegmentDetails("PHO",
      "14",
      "OUT_PHO_REC_TYP;OUT_PHO_PROV_ID;OUT_PHO_TEL_NBR;OUT_PHO_AREA_CD;OUT_PHO_TYP_CD;OUT_PHO_DIR_IND;OUT_PHO_CHG_IND;OUT_PHO_EXT_NBR;OUT_PHO_PRI_CD;OUT_PHO_ACTV_CD;OUT_PHO_TEL_TYP_CD",
      "3;9;7;3;1;1;1;10;1;1;1",
      "400","",
      queries
    )
    val segDtlsSeq = Seq(segDtls)
    val prevRunDate = ""
    val outputFilePath = ""
    val spark = globalContext.sparkSession

    import spark.implicits._
    val s = Seq((1233, 176),
      (234, 2323),
      (30000, 29898))
    val df = s.toDF("OUT_PHO_PROV_ID", "OUT_PHO_TEL_NBR")
    df.createOrReplaceTempView("ADD_FNL_VIEW")

    println("=======================" + spark.catalog.tableExists("ADD_FNL_VIEW") + "========")

    assert(phoSegGen(segDtls, outputFilePath,glblVarLst)(globalContext) == "N")
  }

  override def afterAll(): Unit = {
    super.afterAll()
    globalContext.sparkContext.stop()
  }

}

