package com.uhg.optum.provider.extractors

import com.uhg.optum.JobRunner.{PEI, PEIInstanceEmpty}
import com.uhg.optum.dao.LocalRepositoryManager
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDERK4InputJsonSchema.{Query, SegmentDetails}
import com.uhg.optum.provider.extractors.EPDERK4_TIN_SegExt
import com.uhg.optum.tests.base.UnitSpec
import com.uhg.optum.util.CommonUtil


import scala.util.{Failure, Success}

class TestTINSegment extends UnitSpec with EPDERK4_TIN_SegExt {
  var globalContext: GlobalContext = _
  implicit var pei: PEI = _
  var glblVarLst = collection.mutable.Map[String, String]()

  override def beforeAll(): Unit = {
    super.beforeAll()

    globalContext = new GlobalContext("EPDE_OPTUM","local") with LocalRepositoryManager
    import com.uhg.optum.protocols.PEIProtocol._
    globalContext.peTable.get("EPDE-OPTUM", "pei") match {
      case Success(instance) =>
        this.pei = instance
        Success()
      case Failure(ex) =>
        Failure(new PEIInstanceEmpty("Exception while getting the columns info from PEI Table", ex))
    }
    val WS_CANC_DT_1 = "01/01/0001" // used in PSP ; genrated in
    val WS_CANC_DT_2 = "12/31/9999" // used in PSP ; genrated in
    val WS_UPDT_DT_1 = "03/01/2019" // used in PSP
    val WS_UPDT_DT_2 = "12/31/9999" // used in PSP
    val WS_ACTV_CD_1 = "A" // used in ADD
    val WS_ACTV_CD_2 = "I" // used in ADD
    CommonUtil.add2Map(glblVarLst, "${WS_CANC_DT_1}", WS_CANC_DT_1)
    CommonUtil.add2Map(glblVarLst, "${WS_CANC_DT_2}", WS_CANC_DT_2)
    CommonUtil.add2Map(glblVarLst, "${WS_UPDT_DT_1}", WS_UPDT_DT_1)
    CommonUtil.add2Map(glblVarLst, "${WS_UPDT_DT_2}", WS_UPDT_DT_2)
    CommonUtil.add2Map(glblVarLst, "${WS_ACTV_CD_1}", WS_ACTV_CD_1)
    CommonUtil.add2Map(glblVarLst, "${WS_ACTV_CD_2}", WS_ACTV_CD_2)
  }
    /*test("tin method should throw exception if the PRV count is 0") {
      val query = new Query("TIN_DF1", "SELECT 'TIN' AS OUT_TIN_REC_TYP,lpad(PROV_ID,9,0) AS OUT_TIN_PROV_ID, lpad(PTP_TAX_ID_NBR,9,0) AS OUT_TIN_TAX_ID_NBR, lpad(PRO_PROV_ID,9,0) AS OUT_CORP_OWNER_PROV_ID, PTP_ORIG_EFF_DT AS OUT_TIN_EFF_DT, PRO_LST_NM AS OUT_CORP_OWNER_LST_NM,PRO_FST_NM AS OUT_CORP_OWNER_FST_NM, PRO_MDL_NM AS OUT_CORP_OWNER_M_INIT, OUT_TIN_CHG_IND, PTP_TAX_ID_TYP_CD AS OUT_TIN_TAX_ID_TYP_CD,TAX_PROV_TIER_CD AS OUT_TIN_TAX_PROV_TIER_CD,TAX_INC_TYP_CD AS OUT_TIN_TAX_INC_TYP_CD,CONTR_PAPR_TYP_CD AS OUT_TIN_CONTR_PAPR_TYP_CD,PTP_CANC_DT AS OUT_TIN_CANC_DT, TAX_EPS_CD AS OUT_TIN_EFT_IND FROM PRV_df1", null, null)
      val queries = Seq(query)
      val segDtls = new SegmentDetails("TIN",
        "9",
        "OUT_TIN_REC_TYP;OUT_TIN_PROV_ID;OUT_TIN_TAX_ID_NBR;OUT_CORP_OWNER_PROV_ID;OUT_TIN_EFF_DT;OUT_CORP_OWNER_LST_NM;OUT_CORP_OWNER_FST_NM;OUT_CORP_OWNER_M_INIT;OUT_TIN_CHG_IND;OUT_TIN_TAX_ID_TYP_CD;OUT_TIN_TAX_PROV_TIER_CD;OUT_TIN_TAX_INC_TYP_CD;OUT_TIN_CONTR_PAPR_TYP_CD;OUT_TIN_CANC_DT;OUT_TIN_EFT_IND",
        "3;9;9;9;10;40;25;1;1;1;1;7;3;10;1;270",
        "400","",
        queries
      )

      val prevRunDate = ""
      val outputFilePath = ""
      val spark = globalContext.sparkSession
      import spark.implicits._
      /*val s = Seq(1, 2, 3)
      val df = s.toDF*/
      val df_PRV = globalContext.sqlContext.emptyDataFrame
      println("=======================" + spark.catalog.tableExists("PRV_df1") + "========")
      val thrownExcep = intercept[Exception] {
        genTINSeg(segDtls,glblVarLst,glblVarLst,outputFilePath,df_PRV)(globalContext)
      }
      assert(thrownExcep.getMessage == "Exception thrown")
    }*/
  /*test("tin method should return Y for successful Execution") {
    val query = new Query("TIN_DF", "SELECT 'TIN' AS OUT_TIN_REC_TYP,lpad(PROV_ID,7,0) AS OUT_TIN_PROV_ID, CD FROM PRV_df", null, null)
    val queries = Seq(query)
    val segDtls = new SegmentDetails("TIN",
      "9",
      "OUT_TIN_REC_TYP;OUT_TIN_PROV_ID;CD",
      "3;7;390",
      "400","",
      queries
    )
    val spark = globalContext.sparkSession
    import spark.implicits._
    val df_PRV= Seq(
      ("0", "OPTUM"),
      ("36", "OPTUM"),
      ("108", "ABC")
    ).toDF("PROV_ID", "CD")
    val prevRunDate = ""
    val outputFilePath = ""
    println("=======================" + spark.catalog.tableExists("PRV_df") + "========")

      assert(genTINSeg(segDtls,glblVarLst,glblVarLst,outputFilePath,df_PRV)(globalContext)=="Y")
  }*/
  /*test("tin method should return N for successful Execution") {
    val query = new Query("TIN_DF", "SELECT 'TIN' AS OUT_TIN_REC_TYP,lpad(PROV_ID,7,0) AS OUT_TIN_PROV_ID, CD FROM PRV_df1", null, null)
    val queries = Seq(query)
    val segDtls = new SegmentDetails("TIN",
      "9",
      "OUT_TIN_REC_TYP;OUT_TIN_PROV_ID;CD",
      "3;7;390",
      "400","",
      queries
    )
    val spark = globalContext.sparkSession
    import spark.implicits._
    val df_PRV= Seq(
      ("0", "OPTUM"),
      ("36", "OPTUM"),
      ("108", "ABC")
    ).toDF("PROV_ID", "CD")
    val prevRunDate = ""
    val outputFilePath = ""
    val df_PRV1 = globalContext.sqlContext.emptyDataFrame
    df_PRV1.createOrReplaceTempView("PRV_df1")
    assert(genTINSeg(segDtls,glblVarLst,glblVarLst,outputFilePath,df_PRV)(globalContext)=="N")
  }*/
}
