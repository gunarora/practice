package com.uhg.optum.provider.extractors

import com.uhg.optum.JobRunner.{PEI, PEIInstanceEmpty}
import com.uhg.optum.dao.LocalRepositoryManager
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDERK4InputJsonSchema.{ExtractFileEntity, Query, SegmentDetails}
import com.uhg.optum.tests.base.UnitSpec
import com.uhg.optum.util.CommonUtil
import com.uhg.optum.util.CommonUtil.executeQry
import org.apache.spark.sql.DataFrame

import scala.util.{Failure, Success}

class TestPSPSegmentUtil extends UnitSpec with EPDERK4JsonSourceExtractor with EPDERK4_PSP_SegExt {
  var globalContext : GlobalContext = _
  implicit var pei: PEI = _
  var glblVarLst  = collection.mutable.Map[String, String]()
  var varLst = collection.mutable.Map[String, String]()

  override def beforeAll(): Unit = {
    super.beforeAll()
    globalContext = new GlobalContext("EPDE_OPTUM","local") with LocalRepositoryManager
    import com.uhg.optum.protocols.PEIProtocol._
    globalContext.peTable.get("EPDE_OPTUM", "pei") match {
      case Success(instance) =>
        this.pei = instance
        Success()
      case Failure(ex) =>
        Failure(new PEIInstanceEmpty("Exception while getting the columns info from PEI Table", ex))
    }

    val WS_CANC_DT_1="01/01/0001"  // used in PSP ; genrated in
    val WS_CANC_DT_2="12/31/9999"  // used in PSP ; genrated in
    val WS_UPDT_DT_1= "03/01/2019"  // used in PSP
    val WS_UPDT_DT_2="12/31/9999"   // used in PSP
    val WS_ACTV_CD_1="A"  // used in ADD
    val WS_ACTV_CD_2="I"   // used in ADD
    val SchemaNm = "F5938DBE"
    val WS_PREV_RUN_DT_YMD = "99991231"
    CommonUtil.add2Map(glblVarLst,"${WS_CANC_DT_1}",WS_CANC_DT_1)
    CommonUtil.add2Map(glblVarLst,"${WS_CANC_DT_2}",WS_CANC_DT_2)
    CommonUtil.add2Map(glblVarLst,"${WS_UPDT_DT_1}",WS_UPDT_DT_1)
    CommonUtil.add2Map(glblVarLst,"${WS_UPDT_DT_2}",WS_UPDT_DT_2)

    CommonUtil.add2Map(glblVarLst,"${WS_ACTV_CD_1}",WS_ACTV_CD_1)
    CommonUtil.add2Map(glblVarLst,"${WS_ACTV_CD_2}",WS_ACTV_CD_2)
    CommonUtil.add2Map(glblVarLst,"${SchemaNm}",SchemaNm)
    CommonUtil.add2Map(glblVarLst,"${WS_PREV_RUN_DT_YMD}",WS_PREV_RUN_DT_YMD)
    varLst=glblVarLst
  }

  test("Getting the dataframe from empty sql query should not be success") {
    val dataFrame = mock[DataFrame]
    var query1 = mock[Query]
    query1 = new Query("PSP_16_SPCL_RCRDS", "", null, null)

    val thrownExcep = intercept[Exception] {
      CommonUtil.executeQry(glblVarLst, query1)(globalContext)
    }
    assert(thrownExcep.getMessage == "ERROR : Cannot make DF as Query is empty or NULL or does not start with select "+query1.name)
  }

 /* test("genPSPSeg  method should throw exception if the PRV final view doesnt exist") {
    val SchemaNm = "F5938DBE"
    val query = new Query("PSP_16_SPCL_RCRDS","SELECT PST.WS_PROV_TYP_CD_1 AS WS_PROV_TYP_CD_1, PST.WS_PROV_TYP_CD_2 AS WS_PROV_TYP_CD_2, PSP.PROV_ID  AS PSP_PROV_ID , PSP.SPCL_TYP_CD AS PSP_SPCL_TYP_CD ,PSP.SPCL_BD_CERT_CD  AS PSP_SPCL_BD_CERT_CD   ,PSP.SPCL_BD_CERT_DT  AS PSP_SPCL_BD_CERT_DT   ,PSP.SPCL_BD_EXPIR_DT       AS PSP_SPCL_BD_EXPIR_DT  ,PSP.RCERT_EFF_DT  AS PSP_RCERT_EFF_DT  ,PSP.CRED_VERF_ORG_ID  AS PSP_CRED_VERF_ORG_ID  ,PSP.PRI_CD   AS PSP_PRI_CD  ,PSP.DIR_IND AS PSP_DIR_IND  ,from_unixtime(unix_timestamp(PSP.LST_UPDT_DT,'yyyy-MM-dd'),'MM/dd/yyyy') AS PSP_LST_UPDT_DT  ,PSP.PRAC_SPCL_IND  AS PSP_PRAC_SPCL_IND,PSP.SPCL_SRC_CD AS PSP_SPCL_SRC_CD,PSP.SPCL_BD_EXAM_DT AS PSP_SPCL_BD_EXAM_DT  ,PSP.RES_IND AS PSP_RES_IND ,PSP.CANC_DT  AS PSP_CANC_DT ,CASE WHEN unix_timestamp(PSP_CANC_DT,'yyyy-MM-dd') < unix_timestamp('12/31/9999','MM/dd/yyyy')  THEN 'C' ELSE 'Y' END AS PSP_CHG_IND FROM ${SchemaNm}_PROV_SPCL PSP  INNER JOIN PRV_SEG_TBL PST ON PSP.PROV_ID = PST.PRO_PROV_ID WHERE ((unix_timestamp(PSP.CANC_DT,'yyyy-MM-dd') = unix_timestamp('12/31/9999','MM/dd/yyyy')) OR ((unix_timestamp(PSP.CANC_DT,'yyyy-MM-dd') BETWEEN unix_timestamp('${WS_CANC_DT_1}','MM/dd/yyyy') AND unix_timestamp('${WS_CANC_DT_2}','MM/dd/yyyy')) AND (unix_timestamp(PSP.LST_UPDT_DT,'yyyy-MM-dd') BETWEEN unix_timestamp('${WS_UPDT_DT_1}','MM/dd/yyyy') AND unix_timestamp('${WS_UPDT_DT_2}','MM/dd/yyyy'))))",null,null)
    val queries = Seq(query)
    val spark = globalContext.sparkSession
    val segDtls = new SegmentDetails("PSP",
      "3",
      "OUT_PSP_REC_TYP;OUT_PSP_PROV_ID;OUT_PSP_SPCL_TYP_CD;OUT_PSP_BD_CERT_CD;OUT_PSP_BD_CD_1;OUT_PSP_BD_CD_9;OUT_PSP_BD_CERT_DT;OUT_PSP_BD_EXPIR_DT;OUT_PSP_RCERT_EFF_DT;OUT_PSP_PRI_CD;OUT_PSP_DIR_IND;OUT_PSP_CHG_IND;OUT_STC_SPCL_CATGY_CD;OUT_PSP_PRAC_SPCL_IND;OUT_PSP_SPCL_SRC_CD;OUT_PSP_CRED_VERF_ORG_ID;OUT_PSP_SPCL_BD_EXAM_DT;OUT_PSP_RES_IND;OUT_PSP_CANC_DT",
      "03;09;06;01;01;09;10;10;10;01;01;01;4;1;3;9;10;1;10",
      "400","",
      queries
    )
    val outputFilePath=""
    println("=======================" + spark.catalog.tableExists("PRV_SEG_TBL") + "========")
    val thrownExcep = intercept[Exception] {
      genPSPSeg(segDtls,glblVarLst,varLst,outputFilePath)(globalContext)
    }
    assert(thrownExcep.getMessage == "The temporary view PRV_SEG_TBL from PRV segment is required for PSP segment")
  } */

  test("SegDtls Object for PSP Segment when null should throw exception") {
    val spark=globalContext.sparkSession
    import spark.implicits._
    val rkp=Seq(("361765", "WS_PROV_TYP_CD_1_val","WS_PROV_TYP_CD_2_val"),("2237174", "WS_PROV_TYP_CD_2_val","WS_PROV_TYP_CD_2_val"))
    val rkpDF=rkp.toDF("PRO_PROV_ID","WS_PROV_TYP_CD_1","WS_PROV_TYP_CD_2")
    rkpDF.createOrReplaceTempView("PRV_FNL_VIEW")
    val query = new Query("PSP_16_SPCL_RCRDS","SELECT PST.WS_PROV_TYP_CD_1 AS WS_PROV_TYP_CD_1, PST.WS_PROV_TYP_CD_2 AS WS_PROV_TYP_CD_2, PSP.PROV_ID  AS PSP_PROV_ID , PSP.SPCL_TYP_CD AS PSP_SPCL_TYP_CD ,PSP.SPCL_BD_CERT_CD  AS PSP_SPCL_BD_CERT_CD   ,PSP.SPCL_BD_CERT_DT  AS PSP_SPCL_BD_CERT_DT   ,PSP.SPCL_BD_EXPIR_DT       AS PSP_SPCL_BD_EXPIR_DT  ,PSP.RCERT_EFF_DT  AS PSP_RCERT_EFF_DT  ,PSP.CRED_VERF_ORG_ID  AS PSP_CRED_VERF_ORG_ID  ,PSP.PRI_CD   AS PSP_PRI_CD  ,PSP.DIR_IND AS PSP_DIR_IND  ,from_unixtime(unix_timestamp(PSP.LST_UPDT_DT,'yyyy-MM-dd'),'MM/dd/yyyy') AS PSP_LST_UPDT_DT  ,PSP.PRAC_SPCL_IND  AS PSP_PRAC_SPCL_IND,PSP.SPCL_SRC_CD            AS PSP_SPCL_SRC_CD  ,PSP.SPCL_BD_EXAM_DT AS PSP_SPCL_BD_EXAM_DT  ,PSP.RES_IND                AS PSP_RES_IND ,PSP.CANC_DT  AS PSP_CANC_DT ,CASE WHEN unix_timestamp(PSP.CANC_DT,'yyyy-MM-dd') < unix_timestamp('12/31/9999','MM/dd/yyyy')  THEN 'C' ELSE 'Y' END AS PSP_CHG_IND FROM ${SchemaNm}_PROV_SPCL PSP  INNER JOIN PRV_FNL_VIEW PST ON PSP.PROV_ID = PST.LNK_PROV_ID WHERE ((unix_timestamp(PSP.CANC_DT,'yyyy-MM-dd') = unix_timestamp('12/31/9999','MM/dd/yyyy')) OR ((unix_timestamp(PSP.CANC_DT,'yyyy-MM-dd') BETWEEN unix_timestamp('${WS_CANC_DT_1}','MM/dd/yyyy') AND unix_timestamp('${WS_CANC_DT_2}','MM/dd/yyyy')) AND (unix_timestamp(PSP.LST_UPDT_DT,'yyyy-MM-dd') BETWEEN unix_timestamp('${WS_UPDT_DT_1}','MM/dd/yyyy') AND unix_timestamp('${WS_UPDT_DT_2}','MM/dd/yyyy'))))",null,null)
    val queries = Seq(query)
    val segDtls = null
    println("=======================" + segDtls + "========")
    val outputFilePath=""
    val thrownExcep = intercept[Exception] {
      genPSPSeg(segDtls,glblVarLst,varLst,outputFilePath)(globalContext)
    }
    assert(thrownExcep.getMessage == "No segment details present for PSP Segment")
  }

 /* test("SegDtls Object for PSP Segment when not null should be success and return Y") {
    val spark=globalContext.sparkSession
    import spark.implicits._
    var df_ama = mock[DataFrame]
    val rkp=Seq(("361765", "WS_PROV_TYP_CD_1_val","WS_PROV_TYP_CD_2_val"),("2237174", "WS_PROV_TYP_CD_2_val","WS_PROV_TYP_CD_2_val"))
    val rkpDF=rkp.toDF("PRO_PROV_ID","WS_PROV_TYP_CD_1","WS_PROV_TYP_CD_2")
    rkpDF.createOrReplaceTempView("PRV_FNL_VIEW")
    val s=Seq(("ACA", "A"))
    val df=s.toDF("AS_SPCL_TYP_1","AS_PROV_TYP_1")
    df.createOrReplaceTempView("AMA_SPEC_TABLE")

    val PSP_17=Seq(("361765", "ACA", "A", "A"))
    val PSP_17_df=PSP_17.toDF("PRO_PROV_ID","PSP_SPCL_TYP_CD","WS_PROV_TYP_CD_1","WS_PROV_TYP_CD_2")
    PSP_17_df.createOrReplaceTempView("PSP_17_DVC_DTL")

    val PSP_18=Seq(("361765", "ACA", "A", "A"))
    val PSP_18_df=PSP_18.toDF("PRO_PROV_ID","PSP_SPCL_TYP_CD","WS_PROV_TYP_CD_1","WS_PROV_TYP_CD_2")
    PSP_18_df.createOrReplaceTempView("PSP_18_DVC_DTL")

    val SchemaNm = "F5938DBE"
    var skipPrvLst=""
    val query1 = new Query("PSP_16_SPCL_RCRDS","SELECT PST.WS_PROV_TYP_CD_1 AS WS_PROV_TYP_CD_1, PST.WS_PROV_TYP_CD_2 AS WS_PROV_TYP_CD_2, PSP.PROV_ID  AS PSP_PROV_ID , PSP.SPCL_TYP_CD AS PSP_SPCL_TYP_CD ,PSP.SPCL_BD_CERT_CD  AS PSP_SPCL_BD_CERT_CD   ,PSP.SPCL_BD_CERT_DT  AS PSP_SPCL_BD_CERT_DT   ,PSP.SPCL_BD_EXPIR_DT       AS PSP_SPCL_BD_EXPIR_DT  ,PSP.RCERT_EFF_DT  AS PSP_RCERT_EFF_DT  ,PSP.CRED_VERF_ORG_ID  AS PSP_CRED_VERF_ORG_ID  ,PSP.PRI_CD   AS PSP_PRI_CD  ,PSP.DIR_IND AS PSP_DIR_IND  ,from_unixtime(unix_timestamp(PSP.LST_UPDT_DT,'yyyy-MM-dd'),'MM/dd/yyyy') AS PSP_LST_UPDT_DT  ,PSP.PRAC_SPCL_IND  AS PSP_PRAC_SPCL_IND,PSP.SPCL_SRC_CD            AS PSP_SPCL_SRC_CD  ,PSP.SPCL_BD_EXAM_DT AS PSP_SPCL_BD_EXAM_DT  ,PSP.RES_IND                AS PSP_RES_IND ,PSP.CANC_DT  AS PSP_CANC_DT ,CASE WHEN unix_timestamp(PSP.CANC_DT,'yyyy-MM-dd') < unix_timestamp('12/31/9999','MM/dd/yyyy')  THEN 'C' ELSE 'Y' END AS PSP_CHG_IND FROM ${SchemaNm}_PROV_SPCL PSP  INNER JOIN PRV_FNL_VIEW PST ON PSP.PROV_ID = PST.LNK_PROV_ID WHERE ((unix_timestamp(PSP.CANC_DT,'yyyy-MM-dd') = unix_timestamp('12/31/9999','MM/dd/yyyy')) OR ((unix_timestamp(PSP.CANC_DT,'yyyy-MM-dd') BETWEEN unix_timestamp('${WS_CANC_DT_1}','MM/dd/yyyy') AND unix_timestamp('${WS_CANC_DT_2}','MM/dd/yyyy')) AND (unix_timestamp(PSP.LST_UPDT_DT,'yyyy-MM-dd') BETWEEN unix_timestamp('${WS_UPDT_DT_1}','MM/dd/yyyy') AND unix_timestamp('${WS_UPDT_DT_2}','MM/dd/yyyy'))))",null,null)
    val query2 = new Query("PSP_17_DVC_DTL","SELECT  PSP16.PSP_PROV_ID AS PRO_PROV_ID ,PSP16.PSP_SPCL_TYP_CD AS PSP_SPCL_TYP_CD,PSP16.WS_PROV_TYP_CD_1 AS WS_PROV_TYP_CD_1,PSP16.WS_PROV_TYP_CD_2 AS WS_PROV_TYP_CD_2 FROM   ${SchemaNm}_DATA_VEND_CRIT_DTL  DVC INNER JOIN PSP_16_SPCL_RCRDS PSP16 ON DVC.SPCL_TYP_CD  = PSP16.PSP_SPCL_TYP_CD  WHERE  DVC.DATA_VEND_CD = '${WS_VENDR_CD}' AND  DVC.DATA_VEND_FUNC_CD = 'B' AND  DVC.CRIT_COND_CD = 'E' AND  DVC.CRIT_ID = 4 AND  DVC.ACTV_CD     = 'A' AND PSP16.WS_PROV_TYP_CD_1='P'",null,null)
    val query3 = new Query("PSP_18_DVC_DTL","SELECT   PSP16.PSP_PROV_ID AS PRO_PROV_ID ,PSP16.PSP_SPCL_TYP_CD AS PSP_SPCL_TYP_CD,PSP16.WS_PROV_TYP_CD_1 AS WS_PROV_TYP_CD_1,PSP16.WS_PROV_TYP_CD_2 AS WS_PROV_TYP_CD_2 FROM   ${SchemaNm}_DATA_VEND_CRIT_DTL  DVC INNER JOIN PSP_16_SPCL_RCRDS PSP16 ON DVC.SPCL_TYP_CD  = PSP16.PSP_SPCL_TYP_CD  WHERE  DVC.DATA_VEND_CD = '${WS_VENDR_CD}' AND DVC.DATA_VEND_FUNC_CD = 'B' AND  DVC.CRIT_COND_CD = 'E' AND  DVC.CRIT_ID = 7 AND  DVC.ACTV_CD     = 'A' AND PSP16.WS_PROV_TYP_CD_1<>'P'",null,null)
    val query4 = new Query("PSP_AMA_17","SELECT PSP.PRO_PROV_ID as PRO_PROV_ID FROM AMA_SPEC_TABLE_ORIG AMA INNER JOIN PSP_17_DVC_DTL PSP ON AMA.AS_SPCL_TYP = PSP.PSP_SPCL_TYP_CD WHERE AMA.AS_PROV_TYP = PSP.WS_PROV_TYP_CD_1 OR AMA.AS_PROV_TYP = PSP.WS_PROV_TYP_CD_2",null,null)
    val query5 = new Query("PSP_AMA_18","SELECT PSP.PRO_PROV_ID as PRO_PROV_ID FROM AMA_SPEC_TABLE_ORIG AMA INNER JOIN PSP_18_DVC_DTL PSP ON AMA.AS_SPCL_TYP = PSP.PSP_SPCL_TYP_CD WHERE AMA.AS_PROV_TYP = PSP.WS_PROV_TYP_CD_1 OR AMA.AS_PROV_TYP = PSP.WS_PROV_TYP_CD_2",null,null)
    val query6 = new Query("PSP_AMA_UNION","SELECT PSP17.PRO_PROV_ID FROM PSP_AMA_17 PSP17 UNION SELECT PSP18.PRO_PROV_ID FROM PSP_AMA_18 PSP18",null,null)
    val query7 = new Query("PSP_AMA_17_18","SELECT PSP.WS_PROV_TYP_CD_1 AS WS_PROV_TYP_CD_1,PSP.WS_PROV_TYP_CD_2 AS WS_PROV_TYP_CD_2,PSP.PSP_PROV_ID  AS PSP_PROV_ID , PSP.PSP_SPCL_TYP_CD AS PSP_SPCL_TYP_CD ,PSP.PSP_SPCL_BD_CERT_CD  AS PSP_SPCL_BD_CERT_CD   ,PSP.PSP_SPCL_BD_CERT_DT  AS PSP_SPCL_BD_CERT_DT   ,PSP.PSP_SPCL_BD_EXPIR_DT       AS PSP_SPCL_BD_EXPIR_DT  ,PSP.PSP_RCERT_EFF_DT  AS PSP_RCERT_EFF_DT  ,PSP.PSP_CRED_VERF_ORG_ID  AS PSP_CRED_VERF_ORG_ID  ,PSP.PSP_PRI_CD   AS PSP_PRI_CD  ,PSP.PSP_DIR_IND AS PSP_DIR_IND  , PSP.PSP_LST_UPDT_DT AS PSP_LST_UPDT_DT  ,PSP.PSP_PRAC_SPCL_IND  AS PSP_PRAC_SPCL_IND,PSP.PSP_SPCL_SRC_CD AS PSP_SPCL_SRC_CD  ,PSP.PSP_SPCL_BD_EXAM_DT AS PSP_SPCL_BD_EXAM_DT  ,PSP.PSP_RES_IND AS PSP_RES_IND ,PSP.PSP_CANC_DT  AS PSP_CANC_DT ,PSP.PSP_CHG_IND AS PSP_CHG_IND FROM PSP_16_SPCL_RCRDS PSP LEFT OUTER JOIN PSP_AMA_UNION PSPAU ON PSPAU.PRO_PROV_ID=PSP.PSP_PROV_ID WHERE PSPAU.PRO_PROV_ID IS NULL",null,null)
    val query8 = new Query("PSP_19_STC_PSP_CNT","SELECT PSP.PROV_ID AS STC_PSP_PROV_ID,PSP.SPCL_TYP_CD AS STC_PSP_TYP_CD FROM PSP_AMA_17_18 P3050 INNER JOIN ${SchemaNm}_PROV_SPCL PSP ON PSP.SPCL_TYP_CD=P3050.PSP_SPCL_TYP_CD AND PSP.PROV_ID =P3050.PSP_PROV_ID INNER JOIN ${SchemaNm}_SPCL_TYP_CATGY STC  ON  STC.SPCL_TYP_CD = PSP.SPCL_TYP_CD GROUP BY STC_PSP_PROV_ID,STC_PSP_TYP_CD HAVING COUNT(*) =1",null,null)
    val query9 = new Query("PSP_19_STC_PSP_SNGLE","SELECT PSP.PROV_ID AS STC_PSP_PROV_ID,STC.SPCL_CATGY_CD AS OUT_STC_SPCL_CATGY_CD FROM PSP_AMA_17_18 P3050 INNER JOIN ${SchemaNm}_PROV_SPCL PSP ON PSP.SPCL_TYP_CD=P3050.PSP_SPCL_TYP_CD AND PSP.PROV_ID =P3050.PSP_PROV_ID INNER JOIN ${SchemaNm}_SPCL_TYP_CATGY STC  ON  STC.SPCL_TYP_CD = PSP.SPCL_TYP_CD INNER JOIN PSP_19_STC_PSP_CNT PCNT ON  PCNT.STC_PSP_PROV_ID= PSP.PROV_ID AND PCNT.STC_PSP_TYP_CD=PSP.SPCL_TYP_CD",null,null)
    val query10 = new Query("PSP_FNL_VIEW","SELECT PSP_SPCL.PSP_PROV_ID AS LNK_PROV_ID,3 AS LNK_SEQ_NBR,'PSP' AS OUT_PSP_REC_TYP,PSP_SPCL.PSP_PROV_ID AS OUT_PSP_PROV_ID,PSP_SPCL.PSP_SPCL_TYP_CD AS OUT_PSP_SPCL_TYP_CD,CASE WHEN PSP_SPCL.PSP_SPCL_BD_CERT_CD = 'X' THEN '' ELSE PSP_SPCL.PSP_SPCL_BD_CERT_CD END AS OUT_PSP_BD_CERT_CD,'0' AS OUT_PSP_BD_CD_1,PSP_SPCL.PSP_CRED_VERF_ORG_ID AS OUT_PSP_BD_CD_9,from_unixtime(unix_timestamp(PSP_SPCL.PSP_SPCL_BD_CERT_DT,'yyyy-MM-dd'),'MM/dd/yyyy') AS OUT_PSP_BD_CERT_DT,from_unixtime(unix_timestamp(PSP_SPCL.PSP_SPCL_BD_EXPIR_DT,'yyyy-MM-dd'),'MM/dd/yyyy') AS OUT_PSP_BD_EXPIR_DT,from_unixtime(unix_timestamp(PSP_SPCL.PSP_RCERT_EFF_DT,'yyyy-MM-dd'),'MM/dd/yyyy') AS OUT_PSP_RCERT_EFF_DT,PSP_SPCL.PSP_PRI_CD AS OUT_PSP_PRI_CD,PSP_SPCL.PSP_DIR_IND AS OUT_PSP_DIR_IND,CASE WHEN (unix_timestamp(PSP_SPCL.PSP_LST_UPDT_DT,'MM/dd/yyyy') > unix_timestamp('${WS_PREV_RUN_DT_YMD}','yyyyMMdd')) THEN PSP_SPCL.PSP_CHG_IND ELSE 'N' END AS OUT_PSP_CHG_IND,COALESCE(STC.OUT_STC_SPCL_CATGY_CD,'') AS OUT_STC_SPCL_CATGY_CD,PSP_SPCL.PSP_PRAC_SPCL_IND AS OUT_PSP_PRAC_SPCL_IND,PSP_SPCL.PSP_SPCL_SRC_CD AS OUT_PSP_SPCL_SRC_CD,PSP_SPCL.PSP_CRED_VERF_ORG_ID AS OUT_PSP_CRED_VERF_ORG_ID,from_unixtime(unix_timestamp(PSP_SPCL.PSP_SPCL_BD_EXAM_DT,'yyyy-MM-dd'),'MM/dd/yyyy') AS OUT_PSP_SPCL_BD_EXAM_DT,PSP_SPCL.PSP_RES_IND AS OUT_PSP_RES_IND,from_unixtime(unix_timestamp(PSP_SPCL.PSP_CANC_DT,'yyyy-MM-dd'),'MM/dd/yyyy') AS OUT_PSP_CANC_DT FROM PSP_AMA_17_18 PSP_SPCL LEFT OUTER JOIN PSP_19_STC_PSP_SNGLE STC ON PSP_SPCL.PSP_PROV_ID = STC.STC_PSP_PROV_ID",null,null)
    //val queries = Seq(query1)
    val queries = Seq(query1,query2,query3,query4,query5,query6,query7,query8,query9,query10)
    val segDtls = new SegmentDetails("PSP",
      "3",
      "OUT_PSP_REC_TYP;OUT_PSP_PROV_ID;OUT_PSP_SPCL_TYP_CD;OUT_PSP_BD_CERT_CD;OUT_PSP_BD_CD_1;OUT_PSP_BD_CD_9;OUT_PSP_BD_CERT_DT;OUT_PSP_BD_EXPIR_DT;OUT_PSP_RCERT_EFF_DT;OUT_PSP_PRI_CD;OUT_PSP_DIR_IND;OUT_PSP_CHG_IND;OUT_STC_SPCL_CATGY_CD;OUT_PSP_PRAC_SPCL_IND;OUT_PSP_SPCL_SRC_CD;OUT_PSP_CRED_VERF_ORG_ID;OUT_PSP_SPCL_BD_EXAM_DT;OUT_PSP_RES_IND;OUT_PSP_CANC_DT",
      "03;09;06;01;01;09;10;10;10;01;01;01;4;1;3;9;10;1;10",
      "400","",
      "OHPH",
      queries
    )
    val segDetailsSeq =Seq(segDtls)
    val inputEntity = new ExtractFileEntity("F5938RK4","PRV;ALT;PSP;SCO;PQI;HAS;PLI;PFA;TIN;PTI;TCO;NCE;ADD;PHO;ACT;LGS;LNG;HRS;HCA;ACO;AD1;CON;CDK;CSP;COS;CUL;NPI;COE","F5938DBE",segDetailsSeq)
    val prevRunDate,outputFilePath =""
    assert(genPSPSeg(segDtls,glblVarLst,varLst,outputFilePath)(globalContext)== "Y")
  } */

/*  test("genPSPSeg method should return 'N' if no valid values for PSP present in segDtls") {
    val spark=globalContext.sparkSession
    import spark.implicits._
    val rkp=Seq(("361765", "WS_PROV_TYP_CD_1_val","WS_PROV_TYP_CD_2_val"),("2237174", "WS_PROV_TYP_CD_2_val","WS_PROV_TYP_CD_2_val"))
    val rkpDF=rkp.toDF("PRO_PROV_ID","WS_PROV_TYP_CD_1","WS_PROV_TYP_CD_2")
    rkpDF.createOrReplaceTempView("PRV_SEG_TBL")
    val SchemaNm = "F5938DBE"
    val inputEntity = mock[ExtractFileEntity]
    val query = new Query("PSP_16_SPCL_RCRDS","SELECT PST.WS_PROV_TYP_CD_1 AS WS_PROV_TYP_CD_1, PST.WS_PROV_TYP_CD_2 AS WS_PROV_TYP_CD_2, PSP.PROV_ID  AS PSP_PROV_ID , PSP.SPCL_TYP_CD AS PSP_SPCL_TYP_CD ,PSP.SPCL_BD_CERT_CD  AS PSP_SPCL_BD_CERT_CD   ,PSP.SPCL_BD_CERT_DT  AS PSP_SPCL_BD_CERT_DT   ,PSP.SPCL_BD_EXPIR_DT       AS PSP_SPCL_BD_EXPIR_DT  ,PSP.RCERT_EFF_DT  AS PSP_RCERT_EFF_DT  ,PSP.CRED_VERF_ORG_ID  AS PSP_CRED_VERF_ORG_ID  ,PSP.PRI_CD   AS PSP_PRI_CD  ,PSP.DIR_IND AS PSP_DIR_IND  ,from_unixtime(unix_timestamp(PSP.LST_UPDT_DT,'yyyy-MM-dd'),'MM/dd/yyyy') AS PSP_LST_UPDT_DT  ,PSP.PRAC_SPCL_IND  AS PSP_PRAC_SPCL_IND,PSP.SPCL_SRC_CD AS PSP_SPCL_SRC_CD,PSP.SPCL_BD_EXAM_DT AS PSP_SPCL_BD_EXAM_DT  ,PSP.RES_IND AS PSP_RES_IND ,PSP.CANC_DT  AS PSP_CANC_DT ,CASE WHEN unix_timestamp(PSP_CANC_DT,'yyyy-MM-dd') < unix_timestamp('12/31/9999','MM/dd/yyyy')  THEN 'C' ELSE 'Y' END AS PSP_CHG_IND FROM ${SchemaNm}_PROV_SPCL PSP  INNER JOIN PRV_SEG_TBL PST ON PSP.PROV_ID = PST.PRO_PROV_ID WHERE ((unix_timestamp(PSP.CANC_DT,'yyyy-MM-dd') = unix_timestamp('12/31/9999','MM/dd/yyyy')) OR ((unix_timestamp(PSP.CANC_DT,'yyyy-MM-dd') BETWEEN unix_timestamp('${WS_CANC_DT_1}','MM/dd/yyyy') AND unix_timestamp('${WS_CANC_DT_2}','MM/dd/yyyy')) AND (unix_timestamp(PSP.LST_UPDT_DT,'yyyy-MM-dd') BETWEEN unix_timestamp('${WS_UPDT_DT_1}','MM/dd/yyyy') AND unix_timestamp('${WS_UPDT_DT_2}','MM/dd/yyyy'))))",null,null)
    val queries = Seq(query)
    val segDtls = new SegmentDetails("PSPPPP",
      "3",
      "OUT_PSP_REC_TYP;OUT_PSP_PROV_ID;OUT_PSP_SPCL_TYP_CD;OUT_PSP_BD_CERT_CD;OUT_PSP_BD_CD_1;OUT_PSP_BD_CD_9;OUT_PSP_BD_CERT_DT;OUT_PSP_BD_EXPIR_DT;OUT_PSP_RCERT_EFF_DT;OUT_PSP_PRI_CD;OUT_PSP_DIR_IND;OUT_PSP_CHG_IND;OUT_STC_SPCL_CATGY_CD;OUT_PSP_PRAC_SPCL_IND;OUT_PSP_SPCL_SRC_CD;OUT_PSP_CRED_VERF_ORG_ID;OUT_PSP_SPCL_BD_EXAM_DT;OUT_PSP_RES_IND;OUT_PSP_CANC_DT",
      "03;09;06;01;01;09;10;10;10;01;01;01;4;1;3;9;10;1;10",
      "400","",
      queries
    )
    val outputFilePath=""
    val segDetailsSeq =Seq(segDtls)
    assert(genPSPSeg(segDtls,glblVarLst,varLst,outputFilePath)(globalContext)== "N")
  }*/

  override def afterAll(): Unit = {
    super.afterAll()
    globalContext.sparkContext.stop()
  }
}