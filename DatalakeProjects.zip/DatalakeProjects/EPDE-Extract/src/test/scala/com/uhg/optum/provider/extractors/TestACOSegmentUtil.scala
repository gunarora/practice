package com.uhg.optum.provider.extractors

import com.uhg.optum.JobRunner.{PEI, PEIInstanceEmpty}
import com.uhg.optum.dao.LocalRepositoryManager
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDERK4InputJsonSchema.{ExtractFileEntity, Queries, Query, SegmentDetails}
import com.uhg.optum.provider.validators.PreExtractValidator
import com.uhg.optum.util.{CommonUtil, EPDECommonUtil, Logger}
import com.uhg.optum.tests.base.UnitSpec
import org.apache.spark.sql.{DataFrame, Row, SQLContext}
import org.mockito.Mockito.when
import com.uhg.optum.provider.extractors.EPDERK4JsonSourceExtractor
import com.uhg.optum.provider.extractors.EPDERK4_ACO_SegExt

import scala.util.{Failure, Success}
import com.uhg.optum.EPDERK4JobRunner
import org.apache.spark


class TestACOSegmentUtil extends UnitSpec with EPDERK4JsonSourceExtractor with EPDERK4_ACO_SegExt {
  var globalContext : GlobalContext = _
  implicit var pei: PEI = _
  var glblVarLst  = collection.mutable.Map[String, String]()

  override def beforeAll(): Unit = {
    super.beforeAll()

    globalContext = new GlobalContext("EPDE_OPTUM","local") with LocalRepositoryManager
    import com.uhg.optum.protocols.PEIProtocol._
    globalContext.peTable.get("EPDE_OPTUM", "pei") match {
      case Success(instance) =>
        this.pei = instance
        Success()
      case Failure(ex) =>
        Failure(new PEIInstanceEmpty("Exception while getting the columns info from PEI Table", ex))
    }

    val WS_CANC_DT_1="01/01/0001"  // used in PSP ; genrated in
    val WS_CANC_DT_2="12/31/9999"  // used in PSP ; genrated in
    val WS_UPDT_DT_1= "03/01/2019"  // used in PSP
    val WS_UPDT_DT_2="12/31/9999"   // used in PSP
    val WS_ACTV_CD_1="A"  // used in ADD
    val WS_ACTV_CD_2="I"   // used in ADD
    CommonUtil.add2Map(glblVarLst,"${WS_CANC_DT_1}",WS_CANC_DT_1)
    CommonUtil.add2Map(glblVarLst,"${WS_CANC_DT_2}",WS_CANC_DT_2)
    CommonUtil.add2Map(glblVarLst,"${WS_UPDT_DT_1}",WS_UPDT_DT_1)
    CommonUtil.add2Map(glblVarLst,"${WS_UPDT_DT_2}",WS_UPDT_DT_2)

    CommonUtil.add2Map(glblVarLst,"${WS_ACTV_CD_1}",WS_ACTV_CD_1)
    CommonUtil.add2Map(glblVarLst,"${WS_ACTV_CD_2}",WS_ACTV_CD_2)

  }


  test("Getting the dataframe from empty sql query should not be success") {

    val dataFrame = mock[DataFrame]
    var query1 = mock[Query]
    query1 = new Query("ACO_SEL_65_CUR","",null,null)

    val thrownExcep = intercept[Exception] {
      CommonUtil.executeQry(glblVarLst,query1)(globalContext)
    }
    assert(thrownExcep.getMessage == "ERROR : Cannot make DF as Query is empty or NULL or does not start with select ACO_SEL_65_CUR")

  }

  test("SegDtls Object for ACO Segment when null should be failure") {
    val SW_SKIP_ACO = "N"
    val SchemaNm = "F5938DBE"
    val WS_PREV_RUN_DT_YMD = "9999-12-31"
    var inputEntity = mock[ExtractFileEntity]

    val outputFilePath= ""
    val query1 = new Query("ACO_SEL_65_CUR","SELECT ADD.OUT_ADD_PROV_ID AS OUT_ADD_PROV_ID,ADD.OUT_ADD_ADR_ID_9 AS OUT_ADD_ADR_ID_9,ADD.TAX_ID_NBR AS TAX_ID_NBR,ADD.OUT_ADD_TYP_CD AS OUT_ADD_TYP_CD, COUNT(*) FROM ${SchemaNm}_PROV_TIN_ADR_CONTR_ORG PAO INNER JOIN ADD_FINAL_QRY ADD ON (PAO.PROV_ID = ADD.OUT_ADD_PROV_ID AND PAO.ADR_ID = ADD.OUT_ADD_ADR_ID_9) INNER JOIN ${SchemaNm}_PROV_TIN_PAY_AFFIL PTP ON (PTP.PROV_ID = ADD.OUT_ADD_PROV_ID AND PAO.TAX_ID_NBR = PTP.TAX_ID_NBR AND PTP.TAX_ID_NBR = ADD.TAX_ID_NBR ) INNER JOIN ${SchemaNm}_PROV_TIN_ADR PTA ON (PTA.PROV_ID = ADD.OUT_ADD_PROV_ID AND PTP.TAX_ID_NBR = PTA.TAX_ID_NBR AND PTA.TAX_ID_TYP_CD = PTP.TAX_ID_TYP_CD AND PAO.ADR_ID = PTA.ADR_ID AND PTA.ADR_TYP_CD = ADD.OUT_ADD_TYP_CD) GROUP BY ADD.OUT_ADD_PROV_ID ,ADD.OUT_ADD_ADR_ID_9 ,ADD.TAX_ID_NBR ,ADD.OUT_ADD_TYP_CD  HAVING COUNT(*)=1",null,null)
    val query2 = new Query("ACO_65_CUR","SELECT 'ACO' AS OUT_ACO_REC_TYP_CD, PAO.PROV_ID AS OUT_ACO_PROV_ID, PAO.TAX_ID_NBR AS OUT_ACO_TIN, '000' AS OUT_ACO_MAID_3, PAO.ADR_ID AS OUT_ACO_MAID_9, CASE WHEN '${PTA_ADR_TYP_CD}' = 'L' THEN 'PR' WHEN '${PTA_ADR_TYP_CD}' = 'T' THEN 'MAIL' ELSE 'BILL' END AS OUT_ACO_MAID_TYP_CD, PAO.CONTR_ORG_CD AS OUT_ACO_CONT_ORG, PAO.PRI_CD AS OUT_ACO_PRI_CD, PAO.CORSP_ADR_IND AS OUT_ACO_CORR_CD, PAO.EFF_DT AS OUT_ACO_EFF_DATE, PAO.CANC_DT AS OUT_ACO_CAN_DATE, PAO.TMLN_RSN_TYP_CD AS OUT_ACO_CAN_REASON,PAO.LST_UPDT_DT AS PAO_LST_UPDT_DT, case when unix_timestamp(PAO.LST_UPDT_DT,'yyyy-MM-dd')  > unix_timestamp(${WS_PREV_RUN_DT_YMD},'yyyy-MM-dd') then (case when unix_timestamp(PAO.CANC_DT,'yyyy-MM-dd') < unix_timestamp('9999-12-31','yyyy-MM-dd') then 'C' else 'Y' end) else (case when unix_timestamp(PAO.CANC_DT,'yyyy-MM-dd') = unix_timestamp('9999-12-31','yyyy-MM-dd') then 'N' else '' end) end as OUT_ACO_CHG_IND FROM ${SchemaNm}_PROV_TIN_ADR_CONTR_ORG PAO INNER JOIN ACO_SEL_65_CUR SEL ON (PAO.PROV_ID = SEL.OUT_ADD_PROV_ID AND PAO.ADR_ID = SEL.OUT_ADD_ADR_ID_9) INNER JOIN ${SchemaNm}_PROV_TIN_PAY_AFFIL PTP ON (PTP.PROV_ID = SEL.OUT_ADD_PROV_ID AND PAO.TAX_ID_NBR = PTP.TAX_ID_NBR AND PTP.TAX_ID_NBR = SEL.TAX_ID_NBR ) INNER JOIN ${SchemaNm}_PROV_TIN_ADR PTA ON (PTA.PROV_ID = SEL.OUT_ADD_PROV_ID AND PTP.TAX_ID_NBR = PTA.TAX_ID_NBR AND PTA.TAX_ID_TYP_CD = PTP.TAX_ID_TYP_CD AND PAO.ADR_ID = PTA.ADR_ID AND PTA.ADR_TYP_CD = SEL.OUT_ADD_TYP_CD)",null,null)
    val queries = Seq(query1,query2)
    /*    val segDtls = new SegmentDetails("ACO",
          "20",
          "OUT_ACO_REC_TYP_CD;OUT_ACO_PROV_ID;OUT_ACO_TIN;OUT_ACO_MAID_3;OUT_ACO_MAID_9;OUT_ACO_MAID_TYP_CD;OUT_ACO_CONT_ORG;OUT_ACO_PRI_CD;OUT_ACO_CORR_CD;OUT_ACO_EFF_DATE;OUT_ACO_CAN_DATE;OUT_ACO_CAN_REASON;OUT_ACO_CHG_IND",
          "3;9;9;3;9;4;4;1;1;10;10;2;1",
          "400",
          "",
          queries
        )*/

    val segDtls = null
    val segDetailsSeq =Seq(segDtls)
    // inputEntity = new ExtractFileEntity("F5938RK4","PRV;ALT;PSP;SCO;PQI;HAS;PLI;PFA;TIN;PTI;TCO;NCE;ADD;PHO;ACT;LGS;LNG;HRS;HCA;ACO;AD1;CON;CDK;CSP;COS;CUL;NPI;COE","F5938DBE",segDetailsSeq)
    // when(inputEntity.segmentDetails).thenReturn(segDetailsSeq)
    /*   inputEntity.segmentDetails.map{
         s => s.segQueries.map{
           m => var key = m.name
             println("key:: " + key)
             var value = m.query
             println("value:: " +value)
         }
       }*/
    // segDtls = null
    assertThrows[NullPointerException]
      {
        genACOSeg(segDtls,glblVarLst,SW_SKIP_ACO,outputFilePath)(globalContext)
      }

    //  assert(genACOSeg(null,glblVarLst,SW_SKIP_ACO,outputFilePath)(globalContext).isFailure)

  }
  test("SegDtls Object for ACO Segment when not null should be success") {
    val SW_SKIP_ACO = "N"
    val SchemaNm = "F5938DBE"
    val WS_PREV_RUN_DT_YMD = "9999-12-31"
    var inputEntity = mock[ExtractFileEntity]

    val outputFilePath= ""
    //   val query1 = new Query("ACO_SEL_65_CUR","SELECT ADD.OUT_ADD_PROV_ID AS OUT_ADD_PROV_ID,ADD.OUT_ADD_ADR_ID_9 AS OUT_ADD_ADR_ID_9,ADD.TAX_ID_NBR AS TAX_ID_NBR,ADD.OUT_ADD_TYP_CD AS OUT_ADD_TYP_CD, COUNT(*) FROM ${SchemaNm}_PROV_TIN_ADR_CONTR_ORG PAO INNER JOIN ADD_FINAL_QRY ADD ON (PAO.PROV_ID = ADD.OUT_ADD_PROV_ID AND PAO.ADR_ID = ADD.OUT_ADD_ADR_ID_9) INNER JOIN ${SchemaNm}_PROV_TIN_PAY_AFFIL PTP ON (PTP.PROV_ID = ADD.OUT_ADD_PROV_ID AND PAO.TAX_ID_NBR = PTP.TAX_ID_NBR AND PTP.TAX_ID_NBR = ADD.TAX_ID_NBR ) INNER JOIN ${SchemaNm}_PROV_TIN_ADR PTA ON (PTA.PROV_ID = ADD.OUT_ADD_PROV_ID AND PTP.TAX_ID_NBR = PTA.TAX_ID_NBR AND PTA.TAX_ID_TYP_CD = PTP.TAX_ID_TYP_CD AND PAO.ADR_ID = PTA.ADR_ID AND PTA.ADR_TYP_CD = ADD.OUT_ADD_TYP_CD) GROUP BY ADD.OUT_ADD_PROV_ID ,ADD.OUT_ADD_ADR_ID_9 ,ADD.TAX_ID_NBR ,ADD.OUT_ADD_TYP_CD  HAVING COUNT(*)=1",null,null)
    //   val query2 = new Query("ACO_65_CUR","SELECT 'ACO' AS OUT_ACO_REC_TYP_CD, PAO.PROV_ID AS OUT_ACO_PROV_ID, PAO.TAX_ID_NBR AS OUT_ACO_TIN, '000' AS OUT_ACO_MAID_3, PAO.ADR_ID AS OUT_ACO_MAID_9, CASE WHEN '${PTA_ADR_TYP_CD}' = 'L' THEN 'PR' WHEN '${PTA_ADR_TYP_CD}' = 'T' THEN 'MAIL' ELSE 'BILL' END AS OUT_ACO_MAID_TYP_CD, PAO.CONTR_ORG_CD AS OUT_ACO_CONT_ORG, PAO.PRI_CD AS OUT_ACO_PRI_CD, PAO.CORSP_ADR_IND AS OUT_ACO_CORR_CD, PAO.EFF_DT AS OUT_ACO_EFF_DATE, PAO.CANC_DT AS OUT_ACO_CAN_DATE, PAO.TMLN_RSN_TYP_CD AS OUT_ACO_CAN_REASON,PAO.LST_UPDT_DT AS PAO_LST_UPDT_DT, case when unix_timestamp(PAO.LST_UPDT_DT,'yyyy-MM-dd')  > unix_timestamp(${WS_PREV_RUN_DT_YMD},'yyyy-MM-dd') then (case when unix_timestamp(PAO.CANC_DT,'yyyy-MM-dd') < unix_timestamp('9999-12-31','yyyy-MM-dd') then 'C' else 'Y' end) else (case when unix_timestamp(PAO.CANC_DT,'yyyy-MM-dd') = unix_timestamp('9999-12-31','yyyy-MM-dd') then 'N' else '' end) end as OUT_ACO_CHG_IND FROM ${SchemaNm}_PROV_TIN_ADR_CONTR_ORG PAO INNER JOIN ACO_SEL_65_CUR SEL ON (PAO.PROV_ID = SEL.OUT_ADD_PROV_ID AND PAO.ADR_ID = SEL.OUT_ADD_ADR_ID_9) INNER JOIN ${SchemaNm}_PROV_TIN_PAY_AFFIL PTP ON (PTP.PROV_ID = SEL.OUT_ADD_PROV_ID AND PAO.TAX_ID_NBR = PTP.TAX_ID_NBR AND PTP.TAX_ID_NBR = SEL.TAX_ID_NBR ) INNER JOIN ${SchemaNm}_PROV_TIN_ADR PTA ON (PTA.PROV_ID = SEL.OUT_ADD_PROV_ID AND PTP.TAX_ID_NBR = PTA.TAX_ID_NBR AND PTA.TAX_ID_TYP_CD = PTP.TAX_ID_TYP_CD AND PAO.ADR_ID = PTA.ADR_ID AND PTA.ADR_TYP_CD = SEL.OUT_ADD_TYP_CD)",null,null)
    val query3 = new Query(name="ACO_SEL_65_CUR","select * from ADD_FINAL_VIEW",null,null);
    val query4 = new Query(name="ACO_65_CUR","select OUT_ACO_TEL_NBR from ADD_FINAL_VIEW",null,null);
    val queries = Seq(query3,query4)
    val segDtls = new SegmentDetails("ACO",
      "20",
      "OUT_ACO_REC_TYP_CD;OUT_ACO_PROV_ID;OUT_ACO_TIN;OUT_ACO_MAID_3;OUT_ACO_MAID_9;OUT_ACO_MAID_TYP_CD;OUT_ACO_CONT_ORG;OUT_ACO_PRI_CD;OUT_ACO_CORR_CD;OUT_ACO_EFF_DATE;OUT_ACO_CAN_DATE;OUT_ACO_CAN_REASON;OUT_ACO_CHG_IND",
      "3;9;9;3;9;4;4;1;1;10;10;2;1",
      "400","",
      queries
    )
    val segDetailsSeq =Seq(segDtls)
    // inputEntity = new ExtractFileEntity("F5938RK4","PRV;ALT;PSP;SCO;PQI;HAS;PLI;PFA;TIN;PTI;TCO;NCE;ADD;PHO;ACT;LGS;LNG;HRS;HCA;ACO;AD1;CON;CDK;CSP;COS;CUL;NPI;COE","F5938DBE",segDetailsSeq)
    // when(inputEntity.segmentDetails).thenReturn(segDetailsSeq)
    /*   inputEntity.segmentDetails.map{
         s => s.segQueries.map{
           m => var key = m.name
             println("key:: " + key)
             var value = m.query
             println("value:: " +value)
         }
       }*/
    val spark = globalContext.sparkSession
    import spark.implicits._

    val s=Seq((1233, 176),
      (234, 2323),
      (30000, 29898))
    val df=s.toDF("OUT_ACO_PROV_ID","OUT_ACO_TEL_NBR")
    df.createOrReplaceTempView("ADD_FINAL_VIEW")
    println("======================="+spark.catalog.tableExists("ADD_FINAL_VIEW")+"========")
    assert(genACOSeg(segDtls,glblVarLst,SW_SKIP_ACO,outputFilePath)(globalContext).isSuccess)

  }




  test("acoSegGen method should be failure if the ADD final view doesnt exist") {
    // val query1 = new Query("ACO_SEL_65_CUR", "SELECT ADD.OUT_ADD_PROV_ID AS OUT_ADD_PROV_ID,ADD.OUT_ADD_ADR_ID_9 AS OUT_ADD_ADR_ID_9,ADD.TAX_ID_NBR AS TAX_ID_NBR,ADD.OUT_ADD_TYP_CD AS OUT_ADD_TYP_CD, COUNT(*) FROM ${SchemaNm}_PROV_TIN_ADR_CONTR_ORG PAO INNER JOIN ADD_FINAL_QRY ADD ON (PAO.PROV_ID = ADD.OUT_ADD_PROV_ID AND PAO.ADR_ID = ADD.OUT_ADD_ADR_ID_9) INNER JOIN ${SchemaNm}_PROV_TIN_PAY_AFFIL PTP ON (PTP.PROV_ID = ADD.OUT_ADD_PROV_ID AND PAO.TAX_ID_NBR = PTP.TAX_ID_NBR AND PTP.TAX_ID_NBR = ADD.TAX_ID_NBR ) INNER JOIN ${SchemaNm}_PROV_TIN_ADR PTA ON (PTA.PROV_ID = ADD.OUT_ADD_PROV_ID AND PTP.TAX_ID_NBR = PTA.TAX_ID_NBR AND PTA.TAX_ID_TYP_CD = PTP.TAX_ID_TYP_CD AND PAO.ADR_ID = PTA.ADR_ID AND PTA.ADR_TYP_CD = ADD.OUT_ADD_TYP_CD) GROUP BY ADD.OUT_ADD_PROV_ID ,ADD.OUT_ADD_ADR_ID_9 ,ADD.TAX_ID_NBR ,ADD.OUT_ADD_TYP_CD  HAVING COUNT(*)=1", null, null)
    // val query2 = new Query("ACO_65_CUR", "SELECT 'ACO' AS OUT_ACO_REC_TYP_CD, PAO.PROV_ID AS OUT_ACO_PROV_ID, PAO.TAX_ID_NBR AS OUT_ACO_TIN, '000' AS OUT_ACO_MAID_3, PAO.ADR_ID AS OUT_ACO_MAID_9, CASE WHEN '${PTA_ADR_TYP_CD}' = 'L' THEN 'PR' WHEN '${PTA_ADR_TYP_CD}' = 'T' THEN 'MAIL' ELSE 'BILL' END AS OUT_ACO_MAID_TYP_CD, PAO.CONTR_ORG_CD AS OUT_ACO_CONT_ORG, PAO.PRI_CD AS OUT_ACO_PRI_CD, PAO.CORSP_ADR_IND AS OUT_ACO_CORR_CD, PAO.EFF_DT AS OUT_ACO_EFF_DATE, PAO.CANC_DT AS OUT_ACO_CAN_DATE, PAO.TMLN_RSN_TYP_CD AS OUT_ACO_CAN_REASON,PAO.LST_UPDT_DT AS PAO_LST_UPDT_DT, case when unix_timestamp(PAO.LST_UPDT_DT,'yyyy-MM-dd')  > unix_timestamp(${WS_PREV_RUN_DT_YMD},'yyyy-MM-dd') then (case when unix_timestamp(PAO.CANC_DT,'yyyy-MM-dd') < unix_timestamp('9999-12-31','yyyy-MM-dd') then 'C' else 'Y' end) else (case when unix_timestamp(PAO.CANC_DT,'yyyy-MM-dd') = unix_timestamp('9999-12-31','yyyy-MM-dd') then 'N' else '' end) end as OUT_ACO_CHG_IND FROM ${SchemaNm}_PROV_TIN_ADR_CONTR_ORG PAO INNER JOIN ACO_SEL_65_CUR SEL ON (PAO.PROV_ID = SEL.OUT_ADD_PROV_ID AND PAO.ADR_ID = SEL.OUT_ADD_ADR_ID_9) INNER JOIN ${SchemaNm}_PROV_TIN_PAY_AFFIL PTP ON (PTP.PROV_ID = SEL.OUT_ADD_PROV_ID AND PAO.TAX_ID_NBR = PTP.TAX_ID_NBR AND PTP.TAX_ID_NBR = SEL.TAX_ID_NBR ) INNER JOIN ${SchemaNm}_PROV_TIN_ADR PTA ON (PTA.PROV_ID = SEL.OUT_ADD_PROV_ID AND PTP.TAX_ID_NBR = PTA.TAX_ID_NBR AND PTA.TAX_ID_TYP_CD = PTP.TAX_ID_TYP_CD AND PAO.ADR_ID = PTA.ADR_ID AND PTA.ADR_TYP_CD = SEL.OUT_ADD_TYP_CD)", null, null)
    //val queries = Seq(query1, query2)
    val query3 = new Query(name = "ACO_SEL_65_CUR", "select * from ADD_FNL_VIEW", null, null)
    val query4 = new Query(name = "ACO_65_CUR", "select OUT_ACO_TEL_NBR from ADD_FNL_VIEW", null, null)
    val queries = Seq(query3, query4)
    val segDtls = new SegmentDetails("ACO",
      "20",
      "OUT_ACO_REC_TYP_CD;OUT_ACO_PROV_ID;OUT_ACO_TIN;OUT_ACO_MAID_3;OUT_ACO_MAID_9;OUT_ACO_MAID_TYP_CD;OUT_ACO_CONT_ORG;OUT_ACO_PRI_CD;OUT_ACO_CORR_CD;OUT_ACO_EFF_DATE;OUT_ACO_CAN_DATE;OUT_ACO_CAN_REASON;OUT_ACO_CHG_IND",
      "3;9;9;3;9;4;4;1;1;10;10;2;1",
      "400", "",
      queries
    )
    val SW_SKIP_ACO = "N"
    val WS_PREV_RUN_DT_YMD = "9999-12-31"
    val segDetailsSeq = Seq(segDtls)
    val inputEntity = new ExtractFileEntity("F5938RK4", "PRV;ALT;PSP;SCO;PQI;HAS;PLI;PFA;TIN;PTI;TCO;NCE;ADD;PHO;ACT;LGS;LNG;HRS;HCA;ACO;AD1;CON;CDK;CSP;COS;CUL;NPI;COE", "F5938DBE", "NA", "NA", "NA", segDetailsSeq)
    val prevRunDate = ""
    val outputFilePath = "maprfs:///datalake/uhclake/tst/developer/EPDE/TestFiles/"
    val spark = globalContext.sparkSession
    //val SchemaNm = "F5938DBE"
    import spark.implicits._
    val s = Seq((1233, 176),
      (234, 2323),
      (30000, 29898))
    val df = s.toDF("OUT_ACO_PROV_ID", "OUT_ACO_TEL_NBR")
    // df.createOrReplaceTempView("ADD_FINAL_VIEW1")
    // println("=======================" + spark.catalog.tableExists("ADD_FINAL_VIEW1") + "========")

    /*  val thrownExcep = intercept[Exception] {
        acoSegGen(inputEntity,SW_SKIP_ACO, WS_PREV_RUN_DT_YMD, outputFilePath)(globalContext)
      }*/
    assertThrows[org.apache.spark.sql.AnalysisException] {
      assert(genACOSeg(segDtls, glblVarLst, SW_SKIP_ACO, outputFilePath)(globalContext).isFailure)
    }
  }

  /*test("acoSegGen method should be  success if the ADD final view exists") {
    val query3 = new Query(name = "ACO_SEL_65_CUR", "select * from ADD_FINAL_VIEW", null, null)
    val query4 = new Query(name = "ACO_65_CUR", "select OUT_ACO_TEL_NBR from ADD_FINAL_VIEW", null, null)
    //  val query5 = new Query(name = "ACO_FNL_VIEW", "select OUT_ACO_TEL_NBR from ADD_FINAL_VIEW", null, null)

    //val query3 = new Query("ACO_FNL_VIEW","SELECT 'ACO' AS OUT_ACO_REC_TYP_CD, PAO.PROV_ID AS OUT_ACO_PROV_ID, PAO.TAX_ID_NBR AS OUT_ACO_TIN, '000' AS OUT_ACO_MAID_3, PAO.ADR_ID AS OUT_ACO_MAID_9, CASE WHEN '${PTA_ADR_TYP_CD}' = 'L' THEN 'PR' WHEN '${PTA_ADR_TYP_CD}' = 'T' THEN 'MAIL' ELSE 'BILL' END AS OUT_ACO_MAID_TYP_CD, PAO.CONTR_ORG_CD AS OUT_ACO_CONT_ORG, PAO.PRI_CD AS OUT_ACO_PRI_CD, PAO.CORSP_ADR_IND AS OUT_ACO_CORR_CD, PAO.EFF_DT AS OUT_ACO_EFF_DATE, PAO.CANC_DT AS OUT_ACO_CAN_DATE, PAO.TMLN_RSN_TYP_CD AS OUT_ACO_CAN_REASON,PAO.LST_UPDT_DT AS PAO_LST_UPDT_DT, case when unix_timestamp(PAO.LST_UPDT_DT,'yyyy-MM-dd')  > unix_timestamp(${WS_PREV_RUN_DT_YMD},'yyyy-MM-dd') then (case when unix_timestamp(PAO.CANC_DT,'yyyy-MM-dd') < unix_timestamp('9999-12-31','yyyy-MM-dd') then 'C' else 'Y' end) else (case when unix_timestamp(PAO.CANC_DT,'yyyy-MM-dd') = unix_timestamp('9999-12-31','yyyy-MM-dd') then 'N' else '' end) end as OUT_ACO_CHG_IND FROM ${SchemaNm}_PROV_TIN_ADR_CONTR_ORG PAO INNER JOIN ACO_SEL_65_CUR SEL ON (PAO.PROV_ID = SEL.OUT_ADD_PROV_ID AND PAO.ADR_ID = SEL.OUT_ADD_ADR_ID_9) INNER JOIN ${SchemaNm}_PROV_TIN_PAY_AFFIL PTP ON (PTP.PROV_ID = SEL.OUT_ADD_PROV_ID AND PAO.TAX_ID_NBR = PTP.TAX_ID_NBR AND PTP.TAX_ID_NBR = SEL.TAX_ID_NBR ) INNER JOIN ${SchemaNm}_PROV_TIN_ADR PTA ON (PTA.PROV_ID = SEL.OUT_ADD_PROV_ID AND PTP.TAX_ID_NBR = PTA.TAX_ID_NBR AND PTA.TAX_ID_TYP_CD = PTP.TAX_ID_TYP_CD AND PAO.ADR_ID = PTA.ADR_ID AND PTA.ADR_TYP_CD = SEL.OUT_ADD_TYP_CD)",null,null)
    val queries = Seq(query3,query4)

    val segDtls = new SegmentDetails("ACO",
      "20",
      "OUT_ACO_REC_TYP_CD;OUT_ACO_PROV_ID;OUT_ACO_TIN;OUT_ACO_MAID_3;OUT_ACO_MAID_9;OUT_ACO_MAID_TYP_CD;OUT_ACO_CONT_ORG;OUT_ACO_PRI_CD;OUT_ACO_CORR_CD;OUT_ACO_EFF_DATE;OUT_ACO_CAN_DATE;OUT_ACO_CAN_REASON;OUT_ACO_CHG_IND",
      "3;9;9;3;9;4;4;1;1;10;10;2;1",
      "400",
      "",
      queries
    )
    val SW_SKIP_ACO = "N"
    val WS_PREV_RUN_DT_YMD = "9999-12-31"
    val segDetailsSeq =Seq(segDtls)
    val inputEntity = new ExtractFileEntity("F5938RK4","PRV;ALT;PSP;SCO;PQI;HAS;PLI;PFA;TIN;PTI;TCO;NCE;ADD;PHO;ACT;LGS;LNG;HRS;HCA;ACO;AD1;CON;CDK;CSP;COS;CUL;NPI;COE","F5938DBE","NA","NA","NA",segDetailsSeq)
    val prevRunDate =""
    val outputFilePath = "maprfs:///datalake/uhclake/tst/developer/EPDE/TestFiles/"
    val spark = globalContext.sparkSession
    //val SchemaNm = "F5938DBE"
    import spark.implicits._
    val s = Seq((1233, 176),
      (234, 2323),
      (30000, 29898))
    val df = s.toDF("OUT_ACO_PROV_ID", "OUT_ACO_TEL_NBR")
    df.createOrReplaceTempView("ADD_FINAL_VIEW")
    println("=======================" + spark.catalog.tableExists("ADD_FINAL_VIEW") + "========")
    //  var varLst = collection.mutable.Map[String, String]()
    assert(genACOSeg(segDtls,glblVarLst,SW_SKIP_ACO,outputFilePath)(globalContext).equals("Y"))
  }*/



  /*  test("acoSegGen method should return 'Y' if skip flag is 'N'") {
        val query1 = new Query("ACO_SEL_65_CUR","SELECT ADD.OUT_ADD_PROV_ID AS OUT_ADD_PROV_ID,ADD.OUT_ADD_ADR_ID_9 AS OUT_ADD_ADR_ID_9,ADD.TAX_ID_NBR AS TAX_ID_NBR,ADD.OUT_ADD_TYP_CD AS OUT_ADD_TYP_CD, COUNT(*) FROM ${SchemaNm}_PROV_TIN_ADR_CONTR_ORG PAO INNER JOIN ADD_FINAL_QRY ADD ON (PAO.PROV_ID = ADD.OUT_ADD_PROV_ID AND PAO.ADR_ID = ADD.OUT_ADD_ADR_ID_9) INNER JOIN ${SchemaNm}_PROV_TIN_PAY_AFFIL PTP ON (PTP.PROV_ID = ADD.OUT_ADD_PROV_ID AND PAO.TAX_ID_NBR = PTP.TAX_ID_NBR AND PTP.TAX_ID_NBR = ADD.TAX_ID_NBR ) INNER JOIN ${SchemaNm}_PROV_TIN_ADR PTA ON (PTA.PROV_ID = ADD.OUT_ADD_PROV_ID AND PTP.TAX_ID_NBR = PTA.TAX_ID_NBR AND PTA.TAX_ID_TYP_CD = PTP.TAX_ID_TYP_CD AND PAO.ADR_ID = PTA.ADR_ID AND PTA.ADR_TYP_CD = ADD.OUT_ADD_TYP_CD) GROUP BY ADD.OUT_ADD_PROV_ID ,ADD.OUT_ADD_ADR_ID_9 ,ADD.TAX_ID_NBR ,ADD.OUT_ADD_TYP_CD  HAVING COUNT(*)=1",null,null)
        val query2 = new Query("ACO_65_CUR","SELECT 'ACO' AS OUT_ACO_REC_TYP_CD, PAO.PROV_ID AS OUT_ACO_PROV_ID, PAO.TAX_ID_NBR AS OUT_ACO_TIN, '000' AS OUT_ACO_MAID_3, PAO.ADR_ID AS OUT_ACO_MAID_9, CASE WHEN '${PTA_ADR_TYP_CD}' = 'L' THEN 'PR' WHEN '${PTA_ADR_TYP_CD}' = 'T' THEN 'MAIL' ELSE 'BILL' END AS OUT_ACO_MAID_TYP_CD, PAO.CONTR_ORG_CD AS OUT_ACO_CONT_ORG, PAO.PRI_CD AS OUT_ACO_PRI_CD, PAO.CORSP_ADR_IND AS OUT_ACO_CORR_CD, PAO.EFF_DT AS OUT_ACO_EFF_DATE, PAO.CANC_DT AS OUT_ACO_CAN_DATE, PAO.TMLN_RSN_TYP_CD AS OUT_ACO_CAN_REASON,PAO.LST_UPDT_DT AS PAO_LST_UPDT_DT, case when unix_timestamp(PAO.LST_UPDT_DT,'yyyy-MM-dd')  > unix_timestamp(${WS_PREV_RUN_DT_YMD},'yyyy-MM-dd') then (case when unix_timestamp(PAO.CANC_DT,'yyyy-MM-dd') < unix_timestamp('9999-12-31','yyyy-MM-dd') then 'C' else 'Y' end) else (case when unix_timestamp(PAO.CANC_DT,'yyyy-MM-dd') = unix_timestamp('9999-12-31','yyyy-MM-dd') then 'N' else '' end) end as OUT_ACO_CHG_IND FROM ${SchemaNm}_PROV_TIN_ADR_CONTR_ORG PAO INNER JOIN ACO_SEL_65_CUR SEL ON (PAO.PROV_ID = SEL.OUT_ADD_PROV_ID AND PAO.ADR_ID = SEL.OUT_ADD_ADR_ID_9) INNER JOIN ${SchemaNm}_PROV_TIN_PAY_AFFIL PTP ON (PTP.PROV_ID = SEL.OUT_ADD_PROV_ID AND PAO.TAX_ID_NBR = PTP.TAX_ID_NBR AND PTP.TAX_ID_NBR = SEL.TAX_ID_NBR ) INNER JOIN ${SchemaNm}_PROV_TIN_ADR PTA ON (PTA.PROV_ID = SEL.OUT_ADD_PROV_ID AND PTP.TAX_ID_NBR = PTA.TAX_ID_NBR AND PTA.TAX_ID_TYP_CD = PTP.TAX_ID_TYP_CD AND PAO.ADR_ID = PTA.ADR_ID AND PTA.ADR_TYP_CD = SEL.OUT_ADD_TYP_CD)",null,null)
        val queries = Seq(query1,query2)
        val segDtls = new SegmentDetails("ACO",
          "20",
          "OUT_ACO_REC_TYP_CD;OUT_ACO_PROV_ID;OUT_ACO_TIN;OUT_ACO_MAID_3;OUT_ACO_MAID_9;OUT_ACO_MAID_TYP_CD;OUT_ACO_CONT_ORG;OUT_ACO_PRI_CD;OUT_ACO_CORR_CD;OUT_ACO_EFF_DATE;OUT_ACO_CAN_DATE;OUT_ACO_CAN_REASON;OUT_ACO_CHG_IND",
          "3;9;9;3;9;4;4;1;1;10;10;2;1",
          "400",
          queries
        )
        val SW_SKIP_ACO = "N"
        val WS_PREV_RUN_DT_YMD = "9999-12-31"
        val segDetailsSeq =Seq(segDtls)
        val inputEntity = new ExtractFileEntity("F5938RK4","PRV;ALT;PSP;SCO;PQI;HAS;PLI;PFA;TIN;PTI;TCO;NCE;ADD;PHO;ACT;LGS;LNG;HRS;HCA;ACO;AD1;CON;CDK;CSP;COS;CUL;NPI;COE","F5938DBE",segDetailsSeq)
        val prevRunDate =""
        val outputFilePath ="maprfs:///user/sgoyal34"
        val spark=globalContext.sparkSession
        //val SchemaNm = "F5938DBE"
        import spark.implicits._
        val s=Seq((1233, 176),
          (234, 2323),
          (30000, 29898))
        val df=s.toDF("OUT_PHO_PROV_ID","OUT_PHO_TEL_NBR")
        df.createOrReplaceTempView("ADD_FINAL_QRY")

        println("=======================" + spark.catalog.tableExists("ADD_FINAL_QRY") + "========")
        var varLst = collection.mutable.Map[String, String]()

        assert(genACOSeg(segDtls,glblVarLst,SW_SKIP_ACO, WS_PREV_RUN_DT_YMD, outputFilePath)(globalContext).get.equals("Y"))
      }*/


  test("acoSegGen method should return 'N' if the skip flag is 'Y'") {
    val query1 = new Query("ACO_SEL_65_CUR","SELECT ADD.OUT_ADD_PROV_ID AS OUT_ADD_PROV_ID,ADD.OUT_ADD_ADR_ID_9 AS OUT_ADD_ADR_ID_9,ADD.TAX_ID_NBR AS TAX_ID_NBR,ADD.OUT_ADD_TYP_CD AS OUT_ADD_TYP_CD, COUNT(*) FROM ${SchemaNm}_PROV_TIN_ADR_CONTR_ORG PAO INNER JOIN ADD_FINAL_QRY ADD ON (PAO.PROV_ID = ADD.OUT_ADD_PROV_ID AND PAO.ADR_ID = ADD.OUT_ADD_ADR_ID_9) INNER JOIN ${SchemaNm}_PROV_TIN_PAY_AFFIL PTP ON (PTP.PROV_ID = ADD.OUT_ADD_PROV_ID AND PAO.TAX_ID_NBR = PTP.TAX_ID_NBR AND PTP.TAX_ID_NBR = ADD.TAX_ID_NBR ) INNER JOIN ${SchemaNm}_PROV_TIN_ADR PTA ON (PTA.PROV_ID = ADD.OUT_ADD_PROV_ID AND PTP.TAX_ID_NBR = PTA.TAX_ID_NBR AND PTA.TAX_ID_TYP_CD = PTP.TAX_ID_TYP_CD AND PAO.ADR_ID = PTA.ADR_ID AND PTA.ADR_TYP_CD = ADD.OUT_ADD_TYP_CD) GROUP BY ADD.OUT_ADD_PROV_ID ,ADD.OUT_ADD_ADR_ID_9 ,ADD.TAX_ID_NBR ,ADD.OUT_ADD_TYP_CD  HAVING COUNT(*)=1",null,null)
    val query2 = new Query("ACO_65_CUR","SELECT 'ACO' AS OUT_ACO_REC_TYP_CD, PAO.PROV_ID AS OUT_ACO_PROV_ID, PAO.TAX_ID_NBR AS OUT_ACO_TIN, '000' AS OUT_ACO_MAID_3, PAO.ADR_ID AS OUT_ACO_MAID_9, CASE WHEN '${PTA_ADR_TYP_CD}' = 'L' THEN 'PR' WHEN '${PTA_ADR_TYP_CD}' = 'T' THEN 'MAIL' ELSE 'BILL' END AS OUT_ACO_MAID_TYP_CD, PAO.CONTR_ORG_CD AS OUT_ACO_CONT_ORG, PAO.PRI_CD AS OUT_ACO_PRI_CD, PAO.CORSP_ADR_IND AS OUT_ACO_CORR_CD, PAO.EFF_DT AS OUT_ACO_EFF_DATE, PAO.CANC_DT AS OUT_ACO_CAN_DATE, PAO.TMLN_RSN_TYP_CD AS OUT_ACO_CAN_REASON,PAO.LST_UPDT_DT AS PAO_LST_UPDT_DT, case when unix_timestamp(PAO.LST_UPDT_DT,'yyyy-MM-dd')  > unix_timestamp(${WS_PREV_RUN_DT_YMD},'yyyy-MM-dd') then (case when unix_timestamp(PAO.CANC_DT,'yyyy-MM-dd') < unix_timestamp('9999-12-31','yyyy-MM-dd') then 'C' else 'Y' end) else (case when unix_timestamp(PAO.CANC_DT,'yyyy-MM-dd') = unix_timestamp('9999-12-31','yyyy-MM-dd') then 'N' else '' end) end as OUT_ACO_CHG_IND FROM ${SchemaNm}_PROV_TIN_ADR_CONTR_ORG PAO INNER JOIN ACO_SEL_65_CUR SEL ON (PAO.PROV_ID = SEL.OUT_ADD_PROV_ID AND PAO.ADR_ID = SEL.OUT_ADD_ADR_ID_9) INNER JOIN ${SchemaNm}_PROV_TIN_PAY_AFFIL PTP ON (PTP.PROV_ID = SEL.OUT_ADD_PROV_ID AND PAO.TAX_ID_NBR = PTP.TAX_ID_NBR AND PTP.TAX_ID_NBR = SEL.TAX_ID_NBR ) INNER JOIN ${SchemaNm}_PROV_TIN_ADR PTA ON (PTA.PROV_ID = SEL.OUT_ADD_PROV_ID AND PTP.TAX_ID_NBR = PTA.TAX_ID_NBR AND PTA.TAX_ID_TYP_CD = PTP.TAX_ID_TYP_CD AND PAO.ADR_ID = PTA.ADR_ID AND PTA.ADR_TYP_CD = SEL.OUT_ADD_TYP_CD)",null,null)
    val queries = Seq(query1,query2)
    val segDtls = new SegmentDetails("ACO",
      "20",
      "OUT_ACO_REC_TYP_CD;OUT_ACO_PROV_ID;OUT_ACO_TIN;OUT_ACO_MAID_3;OUT_ACO_MAID_9;OUT_ACO_MAID_TYP_CD;OUT_ACO_CONT_ORG;OUT_ACO_PRI_CD;OUT_ACO_CORR_CD;OUT_ACO_EFF_DATE;OUT_ACO_CAN_DATE;OUT_ACO_CAN_REASON;OUT_ACO_CHG_IND",
      "3;9;9;3;9;4;4;1;1;10;10;2;1",
      "400",
      "",
      queries
    )
    val SW_SKIP_ACO = "Y"
    val WS_PREV_RUN_DT_YMD = "9999-12-31"
    val segDetailsSeq =Seq(segDtls)
    val inputEntity = new ExtractFileEntity("F5938RK4","PRV;ALT;PSP;SCO;PQI;HAS;PLI;PFA;TIN;PTI;TCO;NCE;ADD;PHO;ACT;LGS;LNG;HRS;HCA;ACO;AD1;CON;CDK;CSP;COS;CUL;NPI;COE","F5938DBE","NA","NA","NA",segDetailsSeq)
    val prevRunDate =""
    val outputFilePath ="maprfs:///user/sgoyal34"
    val spark=globalContext.sparkSession
    //val SchemaNm = "F5938DBE"
    import spark.implicits._
    val s=Seq((1233, 176),
      (234, 2323),
      (30000, 29898))
    val df=s.toDF("OUT_PHO_PROV_ID","OUT_PHO_TEL_NBR")
    df.createOrReplaceTempView("ADD_FINAL_QRY")

    println("=======================" + spark.catalog.tableExists("ADD_FINAL_QRY") + "========")
    assert(genACOSeg(segDtls,glblVarLst,SW_SKIP_ACO, outputFilePath)(globalContext).get.equals("N"))
  }


  test("acoSegGen method should return 'N' if no valid values for ACO present in segDtls") {
    val query1 = new Query("ACO_SEL_65_CUR","SELECT ADD.OUT_ADD_PROV_ID AS OUT_ADD_PROV_ID,ADD.OUT_ADD_ADR_ID_9 AS OUT_ADD_ADR_ID_9,ADD.TAX_ID_NBR AS TAX_ID_NBR,ADD.OUT_ADD_TYP_CD AS OUT_ADD_TYP_CD, COUNT(*) FROM ${SchemaNm}_PROV_TIN_ADR_CONTR_ORG PAO INNER JOIN ADD_FINAL_QRY ADD ON (PAO.PROV_ID = ADD.OUT_ADD_PROV_ID AND PAO.ADR_ID = ADD.OUT_ADD_ADR_ID_9) INNER JOIN ${SchemaNm}_PROV_TIN_PAY_AFFIL PTP ON (PTP.PROV_ID = ADD.OUT_ADD_PROV_ID AND PAO.TAX_ID_NBR = PTP.TAX_ID_NBR AND PTP.TAX_ID_NBR = ADD.TAX_ID_NBR ) INNER JOIN ${SchemaNm}_PROV_TIN_ADR PTA ON (PTA.PROV_ID = ADD.OUT_ADD_PROV_ID AND PTP.TAX_ID_NBR = PTA.TAX_ID_NBR AND PTA.TAX_ID_TYP_CD = PTP.TAX_ID_TYP_CD AND PAO.ADR_ID = PTA.ADR_ID AND PTA.ADR_TYP_CD = ADD.OUT_ADD_TYP_CD) GROUP BY ADD.OUT_ADD_PROV_ID ,ADD.OUT_ADD_ADR_ID_9 ,ADD.TAX_ID_NBR ,ADD.OUT_ADD_TYP_CD  HAVING COUNT(*)=1",null,null)
    val query2 = new Query("ACO_65_CUR","SELECT 'ACO' AS OUT_ACO_REC_TYP_CD, PAO.PROV_ID AS OUT_ACO_PROV_ID, PAO.TAX_ID_NBR AS OUT_ACO_TIN, '000' AS OUT_ACO_MAID_3, PAO.ADR_ID AS OUT_ACO_MAID_9, CASE WHEN '${PTA_ADR_TYP_CD}' = 'L' THEN 'PR' WHEN '${PTA_ADR_TYP_CD}' = 'T' THEN 'MAIL' ELSE 'BILL' END AS OUT_ACO_MAID_TYP_CD, PAO.CONTR_ORG_CD AS OUT_ACO_CONT_ORG, PAO.PRI_CD AS OUT_ACO_PRI_CD, PAO.CORSP_ADR_IND AS OUT_ACO_CORR_CD, PAO.EFF_DT AS OUT_ACO_EFF_DATE, PAO.CANC_DT AS OUT_ACO_CAN_DATE, PAO.TMLN_RSN_TYP_CD AS OUT_ACO_CAN_REASON,PAO.LST_UPDT_DT AS PAO_LST_UPDT_DT, case when unix_timestamp(PAO.LST_UPDT_DT,'yyyy-MM-dd')  > unix_timestamp(${WS_PREV_RUN_DT_YMD},'yyyy-MM-dd') then (case when unix_timestamp(PAO.CANC_DT,'yyyy-MM-dd') < unix_timestamp('9999-12-31','yyyy-MM-dd') then 'C' else 'Y' end) else (case when unix_timestamp(PAO.CANC_DT,'yyyy-MM-dd') = unix_timestamp('9999-12-31','yyyy-MM-dd') then 'N' else '' end) end as OUT_ACO_CHG_IND FROM ${SchemaNm}_PROV_TIN_ADR_CONTR_ORG PAO INNER JOIN ACO_SEL_65_CUR SEL ON (PAO.PROV_ID = SEL.OUT_ADD_PROV_ID AND PAO.ADR_ID = SEL.OUT_ADD_ADR_ID_9) INNER JOIN ${SchemaNm}_PROV_TIN_PAY_AFFIL PTP ON (PTP.PROV_ID = SEL.OUT_ADD_PROV_ID AND PAO.TAX_ID_NBR = PTP.TAX_ID_NBR AND PTP.TAX_ID_NBR = SEL.TAX_ID_NBR ) INNER JOIN ${SchemaNm}_PROV_TIN_ADR PTA ON (PTA.PROV_ID = SEL.OUT_ADD_PROV_ID AND PTP.TAX_ID_NBR = PTA.TAX_ID_NBR AND PTA.TAX_ID_TYP_CD = PTP.TAX_ID_TYP_CD AND PAO.ADR_ID = PTA.ADR_ID AND PTA.ADR_TYP_CD = SEL.OUT_ADD_TYP_CD)",null,null)
    val queries = Seq(query1,query2)
    val segDtls = new SegmentDetails("ACOOO",
      "20",
      "OUT_ACO_REC_TYP_CD;OUT_ACO_PROV_ID;OUT_ACO_TIN;OUT_ACO_MAID_3;OUT_ACO_MAID_9;OUT_ACO_MAID_TYP_CD;OUT_ACO_CONT_ORG;OUT_ACO_PRI_CD;OUT_ACO_CORR_CD;OUT_ACO_EFF_DATE;OUT_ACO_CAN_DATE;OUT_ACO_CAN_REASON;OUT_ACO_CHG_IND",
      "3;9;9;3;9;4;4;1;1;10;10;2;1",
      "400",
      "",
      queries
    )
    val SW_SKIP_ACO = "N"
    val WS_PREV_RUN_DT_YMD = "9999-12-31"
    val segDetailsSeq =Seq(segDtls)
    val inputEntity = new ExtractFileEntity("F5938RK4","PRV;ALT;PSP;SCO;PQI;HAS;PLI;PFA;TIN;PTI;TCO;NCE;ADD;PHO;ACT;LGS;LNG;HRS;HCA;ACO;AD1;CON;CDK;CSP;COS;CUL;NPI;COE","F5938DBE","NA","NA","NA",segDetailsSeq)
    val prevRunDate =""
    val outputFilePath ="maprfs:///user/sgoyal34"
    val spark=globalContext.sparkSession
    //val SchemaNm = "F5938DBE"
    /*    import spark.implicits._
        val s=Seq((1233, 176),
          (234, 2323),
          (30000, 29898))
        val df=s.toDF("OUT_PHO_PROV_ID","OUT_PHO_TEL_NBR")
        df.createOrReplaceTempView("ADD_FINAL_QRY")*/

    println("=======================" + spark.catalog.tableExists("ADD_FINAL_QRY") + "========")
    assert(genACOSeg(segDtls,glblVarLst,SW_SKIP_ACO,outputFilePath)(globalContext).get.equals("N"))
  }


  override def afterAll(): Unit = {
    super.afterAll()
    globalContext.sparkContext.stop()
  }

}




