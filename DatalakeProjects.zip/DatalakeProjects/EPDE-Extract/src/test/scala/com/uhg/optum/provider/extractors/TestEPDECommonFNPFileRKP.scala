package com.uhg.optum.provider.extractors

import com.uhg.optum.JobRunner.{PEI, PEIInstanceEmpty}
import com.uhg.optum.dao.{HbaseRepositoryManager, LocalRepositoryManager}
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.provider.extractors.EPDECommonFNPFile
import com.uhg.optum.tests.base.UnitSpec
import org.apache.spark.sql.DataFrame

import scala.util.{Failure, Success}

class TestEPDECommonFNPFileRKP extends UnitSpec with EPDECommonFNPFile{
  var globalContext: GlobalContext = _
  implicit var pei: PEI = _

  override def beforeAll(): Unit = {
    super.beforeAll()
    globalContext = new GlobalContext("EPDE-OPTUM","local") with LocalRepositoryManager
    import com.uhg.optum.protocols.PEIProtocol._
    globalContext.peTable.get("EPDE-OPTUM", "pei") match {
      case Success(instance) =>
        this.pei = instance
        Success()
      case Failure(ex) =>
        Failure(new PEIInstanceEmpty("Exception while getting the columns info from PEI Table", ex))
    }

  }
  test("common2200ExportProcess method should return dataframe for cri_ind as Y") {
    val sparkSession = globalContext.sparkSession
    import sparkSession.implicits._
    val dfInput= mock[DataFrame]
    val commQuery =Map(("df11_query","SELECT *  FROM  F5938DBE_PROV_NTWK_CONTR PNC"),("df11_query_tables",""),("df11_9_join","SELECT * FROM df11_query"),("df11_9_join_tables",""),("df24_query","SELECT * FROM df11_9_join"),("df24_query_tables",""),("df9_skip1","SELECT * FROM df24_query"),("df9_skip1_tables",""),("df12_query","SELECT * FROM df9_skip1"),("df12_query_tables",""),("df9_skip2","SELECT * FROM df12_query"),("df9_skip2_tables",""),("df13_query","SELECT * FROM df9_skip2"),("df13_query_tables",""),("df14_query","SELECT * FROM df13_query"),("df14_query_tables",""),("df9_skip3","SELECT * FROM df14_query"),("df9_skip3_tables",""))
    println("in the test case")
    val exp_df= Seq(
      ("P", "OPTUM"),
      ("W", "OPTUM"),
      ("L", "ABC")
    ).toDF("CRIT_TXT_VAL_1", "DATA_VEND_CD")
    exp_df.createOrReplaceTempView("df11_query")
    exp_df.createOrReplaceTempView("df9_skip1")
    exp_df.createOrReplaceTempView("df9_skip2")
    exp_df.createOrReplaceTempView("F5938DBE_PROV_NTWK_CONTR")
    val act_df=common2200ExportProcess(dfInput:DataFrame,"2019-02-26", "Y", commQuery, "OPTUM")(globalContext,pei)
    assert(exp_df.except(act_df).count()===0)
    }
  test("common2200ExportProcess method should return dataframe for cri_ind as N") {
    val sparkSession = globalContext.sparkSession
    import sparkSession.implicits._
    val dfInput= mock[DataFrame]
    val commQuery =Map(("df11_query","SELECT *  FROM  F5938DBE_PROV_NTWK_CONTR PNC"),("df11_query_tables",""),("df11_9_join","SELECT * FROM df11_query"),("df11_9_join_tables",""),("df24_query","SELECT * FROM df11_9_join"),("df24_query_tables",""),("df9_skip1","SELECT * FROM df24_query"),("df9_skip1_tables",""),("df12_query","SELECT * FROM df9_skip1"),("df12_query_tables",""),("df9_skip2","SELECT * FROM df12_query"),("df9_skip2_tables",""),("df13_query","SELECT * FROM df9_skip2"),("df13_query_tables",""),("df14_query","SELECT * FROM df13_query"),("df14_query_tables",""),("df9_skip3","SELECT * FROM df14_query"),("df9_skip3_tables",""))
    println("in the test case")
    val exp_df= Seq(
      ("P", "OPTUM"),
      ("W", "OPTUM"),
      ("L", "ABC")
    ).toDF("CRIT_TXT_VAL_1", "DATA_VEND_CD")
    exp_df.createOrReplaceTempView("df11_query")
    exp_df.createOrReplaceTempView("df9_skip1")
    exp_df.createOrReplaceTempView("df9_skip2")
    exp_df.createOrReplaceTempView("F5938DBE_PROV_NTWK_CONTR")
    val act_df=common2200ExportProcess(dfInput:DataFrame,"2019-02-26", "N", commQuery, "OPTUM")(globalContext,pei)
    assert(exp_df.except(act_df).count()===0)

  }
  }
