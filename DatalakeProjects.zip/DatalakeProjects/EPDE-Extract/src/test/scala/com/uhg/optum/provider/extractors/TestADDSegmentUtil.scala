package com.uhg.optum.provider.extractors

import com.uhg.optum.JobRunner.{PEI, PEIInstanceEmpty}
import com.uhg.optum.dao.LocalRepositoryManager
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDERK4InputJsonSchema.{ExtractFileEntity, Query, SegmentDetails}
import com.uhg.optum.provider.extractors.{EPDERK4JsonSourceExtractor, EPDERK4_ACO_SegExt, EPDERK4_ADD_SegExt}
import com.uhg.optum.util.CommonUtil
import com.uhg.optum.tests.base.UnitSpec
import org.apache.spark.sql.DataFrame

import scala.util.{Failure, Success}


class TestADDSegmentUtil extends UnitSpec with EPDERK4JsonSourceExtractor with EPDERK4_ADD_SegExt {
  var globalContext : GlobalContext = _
  implicit var pei: PEI = _
  var glblVarLst  = collection.mutable.Map[String, String]()

  override def beforeAll(): Unit = {
    super.beforeAll()

    globalContext = new GlobalContext("EPDE_OPTUM","local") with LocalRepositoryManager
    import com.uhg.optum.protocols.PEIProtocol._
    globalContext.peTable.get("EPDE_OPTUM", "pei") match {
      case Success(instance) =>
        this.pei = instance
        Success()
      case Failure(ex) =>
        Failure(new PEIInstanceEmpty("Exception while getting the columns info from PEI Table", ex))
    }

    val WS_CANC_DT_1="01/01/0001"  // used in PSP ; genrated in
    val WS_CANC_DT_2="12/31/9999"  // used in PSP ; genrated in
    val WS_UPDT_DT_1= "03/01/2019"  // used in PSP
    val WS_UPDT_DT_2="12/31/9999"   // used in PSP
    val WS_ACTV_CD_1="A"  // used in ADD
    val WS_ACTV_CD_2="I"   // used in ADD
    CommonUtil.add2Map(glblVarLst,"${WS_CANC_DT_1}",WS_CANC_DT_1)
    CommonUtil.add2Map(glblVarLst,"${WS_CANC_DT_2}",WS_CANC_DT_2)
    CommonUtil.add2Map(glblVarLst,"${WS_UPDT_DT_1}",WS_UPDT_DT_1)
    CommonUtil.add2Map(glblVarLst,"${WS_UPDT_DT_2}",WS_UPDT_DT_2)

    CommonUtil.add2Map(glblVarLst,"${WS_ACTV_CD_1}",WS_ACTV_CD_1)
    CommonUtil.add2Map(glblVarLst,"${WS_ACTV_CD_2}",WS_ACTV_CD_2)

  }


  /*  test("Getting the dataframe from empty sql query should not be success") {

      val dataFrame = mock[DataFrame]
      var query1 = mock[Query]
      query1 = new Query("ADD_SEL_65_CUR","",null,null)

      val thrownExcep = intercept[Exception] {
        CommonUtil.executeQry(glblVarLst,query1)(globalContext)
      }
      assert(thrownExcep.getMessage == "ERROR : Cannot make DF as Query is empty or NULL or does not start with select")

    }*/

  /*
    test("Getting the dataframe from NULL sql query should not be success") {

      val dataFrame = mock[DataFrame]
      var query1 = mock[Query]
      query1 = new Query("ADD_SEL_65_CUR",null,null,null)

      val thrownExcep = intercept[Exception] {
        CommonUtil.executeQry(glblVarLst,query1)(globalContext)
      }
      assert(thrownExcep.getMessage == "ERROR : Cannot make DF as Query is empty or NULL or does not start with select")

    }*/


  test("SegDtls Object for ADD Segment when not null should be success") {
    val SW_SKIP_ADD = "N"
    val SchemaNm = "F5938DBE"
    val WS_PREV_RUN_DT_YMD = "9999-12-31"
    var inputEntity = mock[ExtractFileEntity]

    val outputFilePath = "maprfs:///datalake/uhclake/tst/developer/EPDE/TestFiles/"
    val query1 = new Query("TIN_FNL_DF","SELECT * FROM TIN_FNL_VIEW",null,null)
    val query2 = new Query("TIN_ADR_CD_D","SELECT * FROM TIN_FNL_VIEW",null,null)
 //   val query3 = new Query("ADD_FNL_VIEW","SELECT * FROM TIN_FNL_VIEW",null,null)
    val queries = Seq(query1,query2)
    val segDtls = new SegmentDetails("ADD",
      "20",
      "OUT_ACO_REC_TYP_CD;OUT_ACO_PROV_ID;OUT_ACO_TIN;OUT_ACO_MAID_3;OUT_ACO_MAID_9;OUT_ACO_MAID_TYP_CD;OUT_ACO_CONT_ORG;OUT_ACO_PRI_CD;OUT_ACO_CORR_CD;OUT_ACO_EFF_DATE;OUT_ACO_CAN_DATE;OUT_ACO_CAN_REASON;OUT_ACO_CHG_IND",
      "3;9;9;3;9;4;4;1;1;10;10;2;1",
      "400","",
      queries
    )
    val segDetailsSeq =Seq(segDtls)
    // inputEntity = new ExtractFileEntity("F5938RK4","PRV;ALT;PSP;SCO;PQI;HAS;PLI;PFA;TIN;PTI;TCO;NCE;ADD;PHO;ACT;LGS;LNG;HRS;HCA;ACO;AD1;CON;CDK;CSP;COS;CUL;NPI;COE","F5938DBE",segDetailsSeq)
    // when(inputEntity.segmentDetails).thenReturn(segDetailsSeq)
    /*   inputEntity.segmentDetails.map{
         s => s.segQueries.map{
           m => var key = m.name
             println("key:: " + key)
             var value = m.query
             println("value:: " +value)
         }
       }*/

    val spark=globalContext.sparkSession
    //val SchemaNm = "F5938DBE"
    import spark.implicits._
    val s=Seq((1233, 176),
      (234, 2323),
      (30000, 29898))
    val df=s.toDF("OUT_PHO_PROV_ID","OUT_PHO_TEL_NBR")
    df.createOrReplaceTempView("TIN_FNL_VIEW")

    val s1=Seq((1233, 176),
      (234, 2323),
      (30000, 29898))
    val df1=s1.toDF("OUT_PHO_PROV_ID","OUT_PHO_TEL_NBR")
    df1.createOrReplaceTempView("TIN_DF_28")
    assert(genADDSeg(segDtls,glblVarLst,SW_SKIP_ADD,outputFilePath)(globalContext).equals("N"))

  }


  test("SegDtls Object for ADD Segment when null should be failure") {
    val SW_SKIP_ADD = "N"
    val SchemaNm = "F5938DBE"
    val WS_PREV_RUN_DT_YMD = "9999-12-31"
    var inputEntity = mock[ExtractFileEntity]

    val outputFilePath = "maprfs:///datalake/uhclake/tst/developer/EPDE/TestFiles/"
    val query1 = new Query("TIN_FNL_DF","SELECT * FROM TIN_FNL_VIEW",null,null)
    val query2 = new Query("TIN_ADR_CD_D","SELECT * FROM TIN_FNL_VIEW",null,null)
    val query3 = new Query("ADD_FNL_VIEW","SELECT * FROM TIN_FNL_VIEW",null,null)
    val queries = Seq(query1,query2,query3)
    val segDtls = null
    assertThrows[NullPointerException]
      {
        genADDSeg(segDtls,glblVarLst,SW_SKIP_ADD,outputFilePath)(globalContext)
      }

  }




  test("addSegGen method should be failure if the TIN final view doesnt exist") {
    val outputFilePath = "maprfs:///datalake/uhclake/tst/developer/EPDE/TestFiles/"
    val query1 = new Query("TIN_FNL_DF","SELECT * FROM TIN_FNL_VIEW_1",null,null)
    val query2 = new Query("TIN_ADR_CD_D","SELECT * FROM TIN_FNL_VIEW_1",null,null)
 //   val query3 = new Query("ADD_FNL_VIEW","SELECT * FROM TIN_FNL_VIEW_1",null,null)
    val queries = Seq(query1,query2)
    val segDtls = new SegmentDetails("ADD",
      "20",
      "OUT_ACO_REC_TYP_CD;OUT_ACO_PROV_ID;OUT_ACO_TIN;OUT_ACO_MAID_3;OUT_ACO_MAID_9;OUT_ACO_MAID_TYP_CD;OUT_ACO_CONT_ORG;OUT_ACO_PRI_CD;OUT_ACO_CORR_CD;OUT_ACO_EFF_DATE;OUT_ACO_CAN_DATE;OUT_ACO_CAN_REASON;OUT_ACO_CHG_IND",
      "3;9;9;3;9;4;4;1;1;10;10;2;1",
      "400",
      "",
      queries
    )
    val SW_SKIP_ADD = "N"
    val WS_PREV_RUN_DT_YMD = "9999-12-31"
    val segDetailsSeq =Seq(segDtls)
    val inputEntity =new ExtractFileEntity("F5938RK4","PRV;ALT;PSP;SCO;PQI;HAS;PLI;PFA;TIN;PTI;TCO;NCE;ADD;PHO;ACT;LGS;LNG;HRS;HCA;ACO;AD1;CON;CDK;CSP;COS;CUL;NPI;COE","F5938DBE","NA","NA","NA",segDetailsSeq)
    val prevRunDate =""
 //   val outputFilePath ="maprfs:///user/sgoyal34"
    val spark=globalContext.sparkSession
    //val SchemaNm = "F5938DBE"
    import spark.implicits._
    val s=Seq((1233, 176),
      (234, 2323),
      (30000, 29898))
    val df=s.toDF("OUT_PHO_PROV_ID","OUT_PHO_TEL_NBR")
    //  df.createOrReplaceTempView("TIN_FINAL_VIEW")
    //println("======================="+spark.catalog.tableExists("TIN_FNL_VIEW")+"========")

    /*  val thrownExcep = intercept[Exception] {
        acoSegGen(inputEntity,SW_SKIP_ACO, WS_PREV_RUN_DT_YMD, outputFilePath)(globalContext)
      }*/
    assertThrows[org.apache.spark.sql.AnalysisException] {
      assert(genADDSeg(segDtls, glblVarLst, SW_SKIP_ADD, outputFilePath)(globalContext).equals("N"))
    }
  }



  test("addSegGen method should be  success if the TIN final view exists") {
    val outputFilePath = "maprfs:///datalake/uhclake/tst/developer/EPDE/TestFiles/"
    val query1 = new Query("TIN_FNL_DF","SELECT * FROM TIN_FNL_VIEW",null,null)
    val query2 = new Query("TIN_ADR_CD_D","SELECT * FROM TIN_FNL_VIEW",null,null)
  //  val query3 = new Query("ADD_FNL_VIEW","SELECT * FROM TIN_FNL_VIEW",null,null)
    val queries = Seq(query1,query2)
    val segDtls = new SegmentDetails("ADD",
      "20",
      "OUT_ACO_REC_TYP_CD;OUT_ACO_PROV_ID;OUT_ACO_TIN;OUT_ACO_MAID_3;OUT_ACO_MAID_9;OUT_ACO_MAID_TYP_CD;OUT_ACO_CONT_ORG;OUT_ACO_PRI_CD;OUT_ACO_CORR_CD;OUT_ACO_EFF_DATE;OUT_ACO_CAN_DATE;OUT_ACO_CAN_REASON;OUT_ACO_CHG_IND",
      "3;9;9;3;9;4;4;1;1;10;10;2;1",
      "400",
      "",
      queries
    )
    val SW_SKIP_ADD = "N"
    val WS_PREV_RUN_DT_YMD = "9999-12-31"
    val segDetailsSeq =Seq(segDtls)
    val inputEntity =new ExtractFileEntity("F5938RK4","PRV;ALT;PSP;SCO;PQI;HAS;PLI;PFA;TIN;PTI;TCO;NCE;ADD;PHO;ACT;LGS;LNG;HRS;HCA;ACO;AD1;CON;CDK;CSP;COS;CUL;NPI;COE","F5938DBE","NA","NA","NA",segDetailsSeq)
    val prevRunDate =""
  //  val outputFilePath ="maprfs:///user/sgoyal34"
    val spark=globalContext.sparkSession
    var varLst = collection.mutable.Map[String, String]()
    import spark.implicits._
    val s=Seq((1233, 176),
      (234, 2323),
      (30000, 29898))
    val df=s.toDF("OUT_PHO_PROV_ID","OUT_PHO_TEL_NBR")
    df.createOrReplaceTempView("TIN_FNL_VIEW")
    assert(genADDSeg(segDtls,glblVarLst,SW_SKIP_ADD,outputFilePath)(globalContext).equals("N"))
  }



  test("addSegGen method should return 'Y' if skip flag is 'N'") {
    val query1 = new Query("TIN_FNL_DF","SELECT * from TIN_FNL_VIEW",null,null)
    val query2 = new Query("TIN_ADR_CD_D","SELECT * from TIN_FNL_VIEW",null,null)
    val query3 = new Query("TIN_ADR_UNION_RNUM","SELECT * from TIN_FNL_VIEW",null,null)
    val query4 = new Query("TIN_ADR_UNION","SELECT * from TIN_FNL_VIEW",null,null)
    val query5 = new Query("ADD_FLAG","SELECT * from TIN_FNL_VIEW",null,null)
    val query6 = new Query("ADD_76_TR","SELECT * from TIN_FNL_VIEW",null,null)
    val query7 = new Query("ADD_UNION","SELECT * from TIN_FNL_VIEW",null,null)
    val query8 = new Query("ADD_57_RCDS","SELECT * from TIN_FNL_VIEW",null,null)
    val query9 = new Query("ADD_57_NORCDS","SELECT * from TIN_FNL_VIEW",null,null)
    val query10 = new Query("ADD_57_NORCDS_T","SELECT * from TIN_FNL_VIEW",null,null)
    val query11 = new Query("ADD_58_SEL","SELECT * from TIN_FNL_VIEW",null,null)
    val query12 = new Query("ADD_58_RCDS","SELECT * from TIN_FNL_VIEW",null,null)
    val query13 = new Query("ADD_58_NORCDS","SELECT * from TIN_FNL_VIEW",null,null)
    val query14 = new Query("ADD_UNION_RCDS","SELECT * from TIN_FNL_VIEW",null,null)
//    val query15 = new Query("ADD_FNL_VIEW","SELECT * from TIN_FNL_VIEW",null,null)
    val queries = Seq(query1,query2,query3,query4,query5,query6,query7,query8,query9,query10,query11,query12,query13,query14)
    val segDtls = new SegmentDetails("ADD",
      "20",
      "OUT_ACO_REC_TYP_CD;OUT_ACO_PROV_ID;OUT_ACO_TIN;OUT_ACO_MAID_3;OUT_ACO_MAID_9;OUT_ACO_MAID_TYP_CD;OUT_ACO_CONT_ORG;OUT_ACO_PRI_CD;OUT_ACO_CORR_CD;OUT_ACO_EFF_DATE;OUT_ACO_CAN_DATE;OUT_ACO_CAN_REASON;OUT_ACO_CHG_IND",
      "3;9;9;3;9;4;4;1;1;10;10;2;1",
      "400",
      "",
      queries
    )
    val SW_SKIP_ADD = "N"
    val WS_PREV_RUN_DT_YMD = "9999-12-31"
    val segDetailsSeq =Seq(segDtls)
    val inputEntity =new ExtractFileEntity("F5938RK4","PRV;ALT;PSP;SCO;PQI;HAS;PLI;PFA;TIN;PTI;TCO;NCE;ADD;PHO;ACT;LGS;LNG;HRS;HCA;ACO;AD1;CON;CDK;CSP;COS;CUL;NPI;COE","F5938DBE","NA","NA","NA",segDetailsSeq)
    val prevRunDate =""
    val outputFilePath = "maprfs:///datalake/uhclake/tst/developer/EPDE/TestFiles/"
    val spark=globalContext.sparkSession
    //val SchemaNm = "F5938DBE"
    import spark.implicits._
    val s=Seq((1233, 176),
      (234, 2323),
      (30000, 29898))
    val df=s.toDF("OUT_PHO_PROV_ID","OUT_PHO_TEL_NBR")
    df.createOrReplaceTempView("TIN_FNL_VIEW")

    println("=======================" + spark.catalog.tableExists("TIN_FNL_VIEW") + "========")
    var varLst = collection.mutable.Map[String, String]()

    assert(genADDSeg(segDtls,glblVarLst,SW_SKIP_ADD,outputFilePath)(globalContext).equals("N"))
  }


  test("addSegGen method should return 'N' if the skip flag is 'Y'") {
    val query1 = new Query("ADD_SEL_65_CUR","SELECT * FROM TIN_FNL_VIEW",null,null)
    val query2 = new Query("ADD_65_CUR","SELECT * FROM TIN_FNL_VIEW",null,null)
    val queries = Seq(query1,query2)
    val segDtls = new SegmentDetails("ADD",
      "20",
      "OUT_ACO_REC_TYP_CD;OUT_ACO_PROV_ID;OUT_ACO_TIN;OUT_ACO_MAID_3;OUT_ACO_MAID_9;OUT_ACO_MAID_TYP_CD;OUT_ACO_CONT_ORG;OUT_ACO_PRI_CD;OUT_ACO_CORR_CD;OUT_ACO_EFF_DATE;OUT_ACO_CAN_DATE;OUT_ACO_CAN_REASON;OUT_ACO_CHG_IND",
      "3;9;9;3;9;4;4;1;1;10;10;2;1",
      "400",
      "",
      queries
    )
    val SW_SKIP_ADD = "Y"
    val WS_PREV_RUN_DT_YMD = "9999-12-31"
    val segDetailsSeq =Seq(segDtls)
    val inputEntity =new ExtractFileEntity("F5938RK4","PRV;ALT;PSP;SCO;PQI;HAS;PLI;PFA;TIN;PTI;TCO;NCE;ADD;PHO;ACT;LGS;LNG;HRS;HCA;ACO;AD1;CON;CDK;CSP;COS;CUL;NPI;COE","F5938DBE","NA","NA","NA",segDetailsSeq)
    val prevRunDate =""
    val outputFilePath ="maprfs:///user/sgoyal34"
    val spark=globalContext.sparkSession
    //val SchemaNm = "F5938DBE"
    import spark.implicits._
    val s=Seq((1233, 176),
      (234, 2323),
      (30000, 29898))
    val df=s.toDF("OUT_PHO_PROV_ID","OUT_PHO_TEL_NBR")
    df.createOrReplaceTempView("TIN_FNL_VIEW")

    println("=======================" + spark.catalog.tableExists("TIN_FNL_VIEW") + "========")
    assert(genADDSeg(segDtls,glblVarLst,SW_SKIP_ADD, outputFilePath)(globalContext).equals("N"))
  }


  test("AddSegGen method should return 'N' if no valid values for ADD present in segDtls") {
    val query1 = new Query("ADD_SEL_65_CUR","SELECT * FROM TIN_FNL_VIEW",null,null)
    val query2 = new Query("ADD_65_CUR","SELECT * FROM TIN_FNL_VIEW",null,null)
    val queries = Seq(query1,query2)
    val segDtls = new SegmentDetails("ADDDD",
      "20",
      "OUT_ACO_REC_TYP_CD;OUT_ACO_PROV_ID;OUT_ACO_TIN;OUT_ACO_MAID_3;OUT_ACO_MAID_9;OUT_ACO_MAID_TYP_CD;OUT_ACO_CONT_ORG;OUT_ACO_PRI_CD;OUT_ACO_CORR_CD;OUT_ACO_EFF_DATE;OUT_ACO_CAN_DATE;OUT_ACO_CAN_REASON;OUT_ACO_CHG_IND",
      "3;9;9;3;9;4;4;1;1;10;10;2;1",
      "400",
      "",
      queries
    )
    val SW_SKIP_ADD = "N"
    val WS_PREV_RUN_DT_YMD = "9999-12-31"
    val segDetailsSeq =Seq(segDtls)
    val inputEntity =new ExtractFileEntity("F5938RK4","PRV;ALT;PSP;SCO;PQI;HAS;PLI;PFA;TIN;PTI;TCO;NCE;ADD;PHO;ACT;LGS;LNG;HRS;HCA;ACO;AD1;CON;CDK;CSP;COS;CUL;NPI;COE","F5938DBE","NA","NA","NA",segDetailsSeq)
    val prevRunDate =""
    val outputFilePath ="maprfs:///user/sgoyal34"
    val spark=globalContext.sparkSession
    //val SchemaNm = "F5938DBE"
    import spark.implicits._
    val s=Seq((1233, 17),
      (234, 2323),
      (30000, 29898))
    val df=s.toDF("OUT_PHO_PROV_ID","OUT_PHO_TEL_NBR")
    df.createOrReplaceTempView("TIN_FNL_VIEW")

    println("=======================" + spark.catalog.tableExists("TIN_FNL_VIEW") + "========")
    assert(genADDSeg(segDtls,glblVarLst,SW_SKIP_ADD,outputFilePath)(globalContext).equals("N"))
  }


  override def afterAll(): Unit = {
    super.afterAll()
    globalContext.sparkContext.stop()
  }

}




