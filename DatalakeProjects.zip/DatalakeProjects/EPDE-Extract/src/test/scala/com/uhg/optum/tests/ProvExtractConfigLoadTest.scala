package com.uhg.optum.tests

import com.uhg.optum.conf.ApplicationUTConfig._
import com.uhg.optum.dao.{HbaseRepositoryManager, LocalRepositoryManager}
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.tests.base.UnitSpec
import com.uhg.optum.util.PEConfigLoadUtil
import org.apache.hadoop.hbase.client.Put
import org.apache.hadoop.hbase.io.ImmutableBytesWritable
import org.apache.hadoop.hbase.{HTableDescriptor, TableName}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.mockito.Matchers
import org.mockito.Mockito.when

import scala.collection.mutable.ListBuffer
import scala.util.Success

class ProvExtractConfigLoadTest extends UnitSpec {

  var sparkSession : SparkSession = _
  implicit var context : GlobalContext = _

  val mockPEConfigLoadUtil = mock[PEConfigLoadUtil]
  val peConfigLoadUtil = new PEConfigLoadUtil

  override def beforeAll(): Unit = {
    super.beforeAll()

    context = new GlobalContext("EPDE-OPTUM","local") with LocalRepositoryManager
    sparkSession = context.sparkSession
  }
/*

  // Test Case #1
  test("Test1 - When a string in passed to getRowkey, " +
    "Then it should return first 2 args concatenated (post split by delimiter) back, parsing the string") {

    val actualOp = peConfigLoadUtil.getRowkey(dsvLine)
    val expectedOp = rowKey

    assertResult(expectedOp, "Invalid rowKey returned "){actualOp}
  }

  // Test Case #2
  test("Test2 - When ColumnFamily & dsv data is passed, convertToKeyValuePairs should be able to return Put object") {

    val actualOp = peConfigLoadUtil.convertToKeyValuePairs(cfName, dsvHeader, dsvLine,ListBuffer(0,1))

    val expectedOp1 = new ImmutableBytesWritable(rowKey.getBytes()).get().mkString
    val actualOp1 = actualOp._1.get().mkString

    assertResult(expectedOp1, "ImmutableBytesWritable didn't match" ){actualOp1}

    val putMatch1 = actualOp._2.has(cfName.getBytes(), hdrCol1.getBytes, dsvVal1.getBytes())
    val putMatch2 = actualOp._2.has(cfName.getBytes(), hdrCol2.getBytes, dsvVal2.getBytes())
    val putMatch3 = actualOp._2.has(cfName.getBytes(), hdrCol3.getBytes, dsvVal3.getBytes())
    val putMatch4 = actualOp._2.has(cfName.getBytes(), hdrCol4.getBytes, dsvVal4.getBytes())

    assert(putMatch1 && putMatch2 && putMatch3 && putMatch4, "Put object didn't match")
  }

  // Test Case #3
  test("Test3 - Given table doesn't exist, when \"pei\" is passed to loadDSVToHbase, along with fileName" +
    " and TableName, then table should be created and data should be loaded to table") {

    val mockFileRDD = context.sparkContext.parallelize(List(dsvHeader, dsvLine))
    when(mockPEConfigLoadUtil.getDsvData(Matchers.any[String]) (Matchers.any[GlobalContext])).
      thenReturn(mockFileRDD)

    when(mockPEConfigLoadUtil.saveDataToHbase(Matchers.any[RDD[(ImmutableBytesWritable, Put)]],
      Matchers.any[TableName], Matchers.any[HTableDescriptor]) (Matchers.any[GlobalContext])).
      thenReturn(Success())

    val tableNameObj = TableName.valueOf(tableName)

    val mockTRDD = mock[RDD[(ImmutableBytesWritable, Put)]]
    when(mockPEConfigLoadUtil.getMassPut(Matchers.any[RDD[String]], Matchers.any[String], Matchers.any[String],Matchers.any[ListBuffer[Int]])).thenReturn(mockTRDD)

    when(mockPEConfigLoadUtil.loadDSVToHbase(tableToLoad, dsvFileName, tableNameObj)(context)).thenCallRealMethod()

    val actualOp = mockPEConfigLoadUtil.loadDSVToHbase(tableToLoad, dsvFileName, tableNameObj) (context)
    assert(actualOp.isSuccess)
  }
*/


  override def afterAll(): Unit = {
    super.afterAll()
    sparkSession.stop()
  }
}

