package com.uhg.optum.provider

import com.uhg.optum.JobRunner.{PEI, PEIInstanceEmpty}
import com.uhg.optum.conf.ApplicationUTConfig
import com.uhg.optum.conf.ApplicationUTConfig._
import com.uhg.optum.dao.{HbaseRepositoryManager, LocalRepositoryManager}
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.tests.base.UnitSpec
import com.uhg.optum.util.PITUpdateUtil
import org.apache.spark.rdd.RDD
import org.mockito.Matchers
import org.mockito.Mockito.when

import scala.util.{Failure, Success, Try}

class TestPITUpdate extends UnitSpec {

  implicit var globalContext: GlobalContext = _
  implicit var pei: PEI = _
  implicit var pITUpdate:PITUpdateUtil = _

  override def beforeAll(): Unit = {
    super.beforeAll()

    //val peiRowKey = "MCAD_Reporting-TOPS"
    globalContext = new GlobalContext("EPDE-OPTUM","local") with LocalRepositoryManager

    import com.uhg.optum.protocols.PEIProtocol._
    globalContext.peTable.get("EPDE-OPTUM", "pei") match {
      case Success(instance) =>
        this.pei = instance
        Success()
      case Failure(ex) =>
        Failure(new PEIInstanceEmpty("Exception while getting the columns info from PEI Table", ex))
    }
    pITUpdate = mock[PITUpdateUtil]
    // globalContext = mock[GlobalContext with LocalRepositoryManager]
  }

  test("Test1 PITUpdateUtil should succeed") {

    val pITUpdate = mock[PITUpdateUtil]
    // val logFileName = "file:///src/main/resources/PITUpdate.log"
    val logRDD = mock[RDD[String]]
    when(pITUpdate.getRDD(Matchers.any(),Matchers.contains(ApplicationUTConfig.logFileName))).thenReturn(logRDD)
    when(pITUpdate.getTempExtractPath(logRDD)).thenReturn(Try(ApplicationUTConfig.extractPath))
    val testMockRDD = globalContext.sparkContext.parallelize(List(ApplicationUTConfig.pitRowKeyRdd))

    when(pITUpdate.getRDD(Matchers.any(),Matchers.contains(ApplicationUTConfig.extractMeta))).thenReturn(testMockRDD)

    when(pITUpdate.extractRowWithFilter(Matchers.contains(ApplicationUTConfig.pitRowKeyCF),Matchers.any())).
      thenReturn(Try{ApplicationUTConfig.peiRowKey})
    when(pITUpdate.extractRowWithFilter(Matchers.contains(ApplicationUTConfig.extractFilePathCF),Matchers.any())).
      thenReturn(Try{ApplicationUTConfig.extractPath})
    when(pITUpdate.updateHBaseField(globalContext,ApplicationUTConfig.peiRowKey,ApplicationUTConfig.status)).
      thenReturn(Try{true})
    when(pITUpdate.rmFileOrPath(ApplicationUTConfig.extractPath)).
      thenReturn(Try{true})

    when(pITUpdate.updatePIT(ApplicationUTConfig.status,ApplicationUTConfig.logFileName,globalContext)).thenCallRealMethod()

    assert(pITUpdate.updatePIT(ApplicationUTConfig.status,ApplicationUTConfig.logFileName,globalContext).isSuccess)

  }

  test("Test2 PITUpdateUtil should throw exception") {

    val logRDD = mock[RDD[String]]
    when(pITUpdate.getRDD(Matchers.any(),Matchers.contains(ApplicationUTConfig.logFileName))).thenReturn(logRDD)
    when(pITUpdate.getTempExtractPath(logRDD)).thenReturn(Try(ApplicationUTConfig.extractPath))
    val testMockRDD = globalContext.sparkContext.parallelize(List(ApplicationUTConfig.peiRowKey))

    when(pITUpdate.getRDD(Matchers.any(),Matchers.contains(ApplicationUTConfig.extractMeta))).thenReturn(testMockRDD)

    when(pITUpdate.extractRowWithFilter(Matchers.contains(ApplicationUTConfig.pitRowKeyCF),Matchers.any())).
      thenReturn(Try{ApplicationUTConfig.peiRowKey})
    when(pITUpdate.extractRowWithFilter(Matchers.contains(ApplicationUTConfig.extractFilePathCF),Matchers.any())).
      thenReturn(Try{ApplicationUTConfig.extractPath})
    when(pITUpdate.updateHBaseField(Matchers.any(),Matchers.contains(ApplicationUTConfig.peiRowKey),Matchers.contains(ApplicationUTConfig.status))).
      thenThrow(new RuntimeException())
    when(pITUpdate.rmFileOrPath(ApplicationUTConfig.extractPath)).
      thenReturn(Try{true})

    when(pITUpdate.updatePIT(ApplicationUTConfig.status,ApplicationUTConfig.logFileName,globalContext)).thenCallRealMethod()

    assert(pITUpdate.updatePIT(ApplicationUTConfig.status,ApplicationUTConfig.logFileName,globalContext).isFailure)

  }

  override def afterAll(): Unit = {

    super.afterAll()
    globalContext.sparkContext.stop()
  }

}
