package com.uhg.optum.provider.extractors

import com.uhg.optum.JobRunner.{PEI, PEIInstanceEmpty}
import com.uhg.optum.dao.LocalRepositoryManager
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDERK4InputJsonSchema.{ExtractFileEntity, Query, SegmentDetails}
import com.uhg.optum.provider.extractors.EPDERK4JsonSourceExtractor
import com.uhg.optum.util.EPDECommonUtil
import com.uhg.optum.tests.base.UnitSpec
import org.apache.spark.sql.{DataFrame, SQLContext}
import org.mockito.Mockito.when

import scala.util.{Failure, Success}


class TestCommonUtil extends UnitSpec with EPDERK4JsonSourceExtractor {
  var globalContext : GlobalContext = _
  implicit var pei: PEI = _


  override def beforeAll(): Unit = {
    super.beforeAll()

    globalContext = new GlobalContext("EPDE_OPTUM", "local") with LocalRepositoryManager
    import com.uhg.optum.protocols.PEIProtocol._
    globalContext.peTable.get("EPDE_OPTUM", "pei") match {
      case Success(instance) =>
        this.pei = instance
        Success()
      case Failure(ex) =>
        Failure(new PEIInstanceEmpty("Exception while getting the columns info from PEI Table", ex))
    }

  }

  /*test("Getting the dataframe from empty sql query should be failure") {
    val sqlContext = mock[SQLContext]
    // when(globalContext.sqlContext).thenReturn(sqlContext)
    val dataFrame = mock[DataFrame]
    val query = ""
    when(sqlContext.sql(query)).thenReturn(dataFrame)
    assert(EPDECommonUtil.getDataframeFromQuery(query)(globalContext).isFailure)
  }
  test("Getting the dataframe from null sql query should be failure") {
    val sqlContext = mock[SQLContext]
    // when(globalContext.sqlContext).thenReturn(sqlContext)
    val dataFrame = mock[DataFrame]
    val query = null
    when(sqlContext.sql(query)).thenReturn(dataFrame)
    assert(EPDECommonUtil.getDataframeFromQuery(query)(globalContext).isFailure)
  }
  test("Getting the dataframe from non Select sql query should be failure") {
    val sqlContext = mock[SQLContext]
    // when(globalContext.sqlContext).thenReturn(sqlContext)
    val dataFrame = mock[DataFrame]
    val query = "c Select "
    when(sqlContext.sql(query)).thenReturn(dataFrame)
    assert(EPDECommonUtil.getDataframeFromQuery(query)(globalContext).isFailure)
  }*/

  test("Getting the dataframe from sql query should be success") {
    val sqlcontext = mock[SQLContext]
    //when(globalContext.sqlContext).thenReturn(sqlcontext)
    val dataFrame = mock[DataFrame]
    val query = "Select * "
    when(sqlcontext.sql(query)).thenReturn(dataFrame)
    assert(EPDECommonUtil.getDataframeFromQuery(query)(globalContext).isSuccess)
  }
/*
  test("createOrReplaceTempView on null table name should be failure") {
    val sqlcontext = mock[SQLContext]
    val dataFrame = mock[DataFrame]
    val tblNm = null
    //when(dataFrame.createOrReplaceTempView(tblNm)).thenReturn(Unit)
    //when(dataFrame.createOrReplaceTempView(tblNm)).catch(new Exception)
    assert(CommonUtil.createOrReplaceTempViewFn(dataFrame,tblNm)(globalContext).isFailure)
    //  assertThrows(CommonUtil.createOrReplaceTempViewFn(dataFrame,tblNm))
  }

  test("createOrReplaceTempView on empty table name should be failure") {
    val sqlcontext = mock[SQLContext]
    val dataFrame = mock[DataFrame]
    val tblNm = ""
    // when(dataFrame.createOrReplaceTempView(tblNm)).thenReturn(Unit)
    assert(CommonUtil.createOrReplaceTempViewFn(dataFrame,tblNm)(globalContext).isFailure)
  }

  test("createOrReplaceTempView on non-empty table name name should be success") {
    val sqlcontext = mock[SQLContext]
    val dataFrame = mock[DataFrame]
    val tblNm = "ABC"
    // when(dataFrame.createOrReplaceTempView(tblNm)).thenReturn(Unit)
    assert(CommonUtil.createOrReplaceTempViewFn(dataFrame,tblNm)(globalContext).isSuccess)
  }*/



  override def afterAll(): Unit = {
    super.afterAll()
    globalContext.sparkContext.stop()
  }

}




