#########################################################################################################################
# Script Name                   : runOozieExtracts.sh
# Author Name                   : Pankaj Kumar Vashistha
# Execution                     : runOozieExtracts.sh
##########################################################################################################################
# sh runOozieExtracts.sh
#!/bin/bash

echo "########################################################################################" | tee -ai $5
echo "Running all extracts Process Started" | tee -ai $5
echo "DEBUG : Inputs to the runOozieExtracts.sh "$1" :: "$2" :: "$3" :: "$4 | tee -ai $5

##===========================Assign Constant Val=======================================##
vendorFileLoc=$1
vendorFilePrefix=$2
ooziHostURL=$3
propertyFile=$4
logFileName=$5

echo "DEBUG : Inputs to the runOozieExtracts.sh "$vendorFileLoc" :: "$vendorFilePrefix" :: ${propertyFile} :: "$logFileName | tee -ai ${logFileName}
##===========================Assign Constant Val=======================================##

#source ${paramFileLoc}

#source /mapr/datalake/uhclake/dataplatform/ndb/t_scripts/genric_extract.param
#LogDate=`date '+%Y%m%d%H%M%S'`
#LogFile=logs/NDB_OOZIE_$LogDate.log
#process=running_process_$LogDate.txt

##=====================================================================================##
##========================== Logic For Reading All Batch file==========================##
#for input_property_file in `cat ${propertyFilePrefix}*`
for input_property_file in `cat ${vendorFileLoc}/${vendorFilePrefix}*`
do
 echo "Extract is started for ${input_property_file}"  | tee -ai ${logFileName}
 echo "Vendor Name is : ${input_property_file}" | tee -ai ${logFileName}
 echo "/opt/mapr/oozie/oozie-4.3.0/bin/oozie job -oozie="https://${ooziHostURL}:11443/oozie" -config ${propertyFile} -run" -Dvendor_cd=${input_property_file} | tee -ai ${logFileName}
 execute=`/opt/mapr/oozie/oozie-4.3.0/bin/oozie job -oozie="https://${ooziHostURL}:11443/oozie" -config ${propertyFile} -run -Dvendor_cd=${input_property_file}` | tee -ai ${logFileName}
 echo $execute  | tee -ai ${logFileName}
 exe_val=`echo $execute | cut -d':' -f 2`
 echo $exe_val  | tee -ai ${logFileName}
done
##=====================================================================================##
echo "Process Ended"  | tee -ai ${logFileName}
echo "Running all extracts Process Ended" | tee -ai ${logFileName}
echo "########################################################################################" | tee -ai ${logFileName}
exit 0

