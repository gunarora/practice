#!/bin/bash

#Author@Poorvi
#Date@09Jan2020
#script Args <number of days> <dir path> <log file name>

dt1=$(date +'%Y-%m-%d %H:%M:%S')
###Number of days
num_days=$1
###Archive directory absolute path
dir_path=$2
logFileName=$3
echo "Purge script started at $dt1" >> ${logFileName} 2>&1
if [ -d ${dir_path} ] ; then
    echo "Going to purge extracts/files from $dir_path which are $num_days old" >> ${logFileName} 2>&1
    find ${dir_path} -mtime +${num_days} -type f -delete
else
        echo"Dir ${dir_path} not found for Purging" >> ${logFileName} 2>&1
        exit 2
fi
dt2=$(date +'%Y-%m-%d %H:%M:%S')
echo "Purge script completed at $dt2" >> ${logFileName} 2>&1
exit 0