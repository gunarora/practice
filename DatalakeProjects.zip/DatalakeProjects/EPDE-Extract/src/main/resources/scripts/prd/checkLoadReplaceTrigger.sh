#########################################################################################################################
# Script Name                   : checkProvTrans.sh
# Author Name                   : Poorvi Lashkary
# Execution        		        : checkLoadReplaceTrigger.sh <time_frequency> <max_time_count> <triggerFileLoc> <logFileName>
##########################################################################################################################

#!/bin/bash

echo "########################################################################################" | tee -ai $5
echo "Check Load Replace Trigger File Process Started" | tee -ai $5
echo "DEBUG : Check Load Replace Trigger File Existence-  time_frequency "$1 "  max_time_count:: "$2 "  loadReplaceFileLoc:: "$3 " logFileName:: "$4 | tee -ai $5

##========================== Logic For Recursion ======================================##
time_cnt=0
time_frequency=$1
max_time_count=$2
##=====================================================================================##
##===========================Assign Constant Val=======================================##
loadReplaceFileLoc=$3
logFileName=$4
##=====================================================================================##
echo "DEBUG : Check Load Replace Trigger File Existence- time_frequency "$1 "  max_time_count:: "$2 "  loadReplaceFileLoc:: "$3  " logFileName:: "$4 | tee -ai ${logFileName}
##========================== Logic applied Below ======================================##
echo "DEBUG : Logic to Check loadReplace File Existence started" | tee -ai ${logFileName}
startTime=`date +%s`
#dt=$(date +'%Y-%m-%d %H:%M:%S')
#dtOnly=${dt:0:4}${dt:5:2}${dt:8:2}
#loadReplaceFilePattern="${loadReplaceFileLoc}/NDB_Load_replace_"$dtOnly"*.trig"
#echo "EPDEStats: Start time for CheckLoad Replace trigger: $dt" | tee -ai ${logFileName}
while [ $time_cnt -lt $max_time_count ]
do
    dt=$(date +'%Y-%m-%d %H:%M:%S')
    dtOnly=${dt:0:4}${dt:5:2}${dt:8:2}
    loadReplaceFilePattern="${loadReplaceFileLoc}/NDB_Load_replace_"$dtOnly"*.trig"
    echo "EPDEStats: Start time for CheckLoad Replace trigger: $dt" | tee -ai ${logFileName}
    fileExistance=`ls $loadReplaceFilePattern | wc -l`
    echo "fileExistance result for $loadReplaceFilePattern:: $fileExistance"
	if [ $fileExistance -eq 1 ]; then
		echo "Load Replace Trigger File Exists" | tee -ai ${logFileName} | tee -ai ${logFileName}
		echo "DEBUG : Logic to Check Load Replace Trigger File Existence Completed" | tee -ai ${logFileName}
		dt1=$(date +'%Y-%m-%d %H:%M:%S')
        echo "EPDECaptureStats: End time for CheckLoadReplaceTrigger: $dt1" | tee -ai ${logFileName}
        endTime=`date +%s`
        totalTimeInSec=`echo "$endTime - $startTime" | bc`
        totalTimeInMin=`echo "$totalTimeInSec / 60" | bc`
        echo "EPDECaptureStats: Total time taken in Minutes: ${totalTimeInMin}"  >> ${logFileName} 2>&1
        echo "removing trigger file" | tee -ai ${logFileName}
        rm -f $loadReplaceFilePattern
		exit 0
	fi
	time_cnt=$(($time_cnt+1))
	sleep $time_frequency
done

echo "DEBUG : Load Replace Trigger File does not Exist" | tee -ai ${logFileName}
##=====================================================================================##
echo "Load Replace Trigger File does not Exist: Process Failed" | tee -ai ${logFileName}
echo "########################################################################################" | tee -ai ${logFileName}
exit 1
