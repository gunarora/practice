#!/bin/bash
config_file=$1
environment=$2
logFileName=$3
startTime=`date +%s`
dt1=$(date +'%Y-%m-%d %H:%M:%S.%3N')
echo "PLCUpdateStats: Start time for Ingestion wrapper: $dt1" | tee -ai ${logFileName}
source $config_file
export MAPR_TICKETFILE_LOCATION=/opt/mapr/tickets/maprticket_dpobdprd

echo "update PLC table generic value" >> ${logFileName} 2>&1
plcDt=$(date +'%Y-%m-%d %H:%M:%S')
echo "PLC Date that need to update in vendor -> " $plcDt >> ${logFileName} 2>&1
echo "PLC Table -> "${PLC_TABLE} >> ${logFileName} 2>&1
echo "get '${PLC_TABLE}','EPDE-STANDARD','plc:lastRunDt'" | hbase shell >> ${logFileName} 2>&1
echo "put '${PLC_TABLE}','EPDE-STANDARD','plc:lastRunDt','${plcDt}'" | hbase shell >> ${logFileName} 2>&1

echo "PLCUpdateStats: End Time: "$(date +'%Y-%m-%d %H:%M:%S') | tee -ai $2
endTime=`date +%s`
totalTimeInSec=`echo "$endTime - $startTime" | bc`
#totalTimeInMin=`echo "$totalTimeInSec / 60" | bc`
echo "EPDECaptureStats: Total time taken in Seconds: ${totalTimeInSec}"  >> ${logFileName} 2>&1
