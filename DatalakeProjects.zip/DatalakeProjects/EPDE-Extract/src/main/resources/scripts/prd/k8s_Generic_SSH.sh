#!/bin/bash

echo "########################################################################################" | tee -ai $2
echo "k8s_Generic_SSH Process Started" | tee -ai $2
echo "DEBUG : First 2 Inputs to the k8s_Generic_SSH.sh "$1" :: "$2 | tee -ai $2
echo "EPDECaptureStats: Start Time: "$(date +'%Y-%m-%d %H:%M:%S') | tee -ai $2
##===========================Assign Constant Val=======================================##

startTime=`date +%s`
argCnt=$#
argStr=""
className=" "
logFileName=" "
className=$1
logFileName=$2
kube_envt=$3

i=1
for arg in "$@" ; do
         if [ $i -gt 3 ] ; then
                argStr="$argStr $arg"
         fi
i=$((i+1))
done
echo "className= $className" | tee -ai ${logFileName}
echo "logFileName= $logFileName" | tee -ai ${logFileName}
echo "argStr= $argStr" | tee -ai ${logFileName}
echo "argCnt= $argCnt" | tee -ai ${logFileName}
echo "kube envt= ${kube_envt}" | tee -ai ${logFileName}
logFileBaseName=`basename ${logFileName} | cut -f1 -d'.'`
echo "logFileBaseName= $logFileBaseName" | tee -ai ${logFileName}
EMAIL=poorvi.lashkary@optum.com,pankaj.kumar@optum.com

#Driver name handling
vendorKey=`echo "${argStr}" | cut -f2 -d' '`

#PHYSICIAN case handeling
SOURCE="PHYSICIAN"
GroupStr="GROUP"
FacilityStr="FACILITY"
phyFlag="N"
ccnFlag="N"
RK4Suf="EPDE_Reporting"
if echo "$argStr" | grep -iq "$SOURCE"; then
        phyFlag="Y"
	RK4Suf="PHY"
	vendorKey=`echo "${argStr}" | cut -f6 -d' '`
fi
RKPFlag="N"
if [ ${className} == "com.uhg.optum.Driver" ] ; then
        RKPFlag="Y"
	RK4Suf="RKP"
fi
if echo "$argStr" | grep -iq "$GroupStr"; then
        RK4Suf="GRP"
	vendorKey=`echo "${argStr}" | cut -f6 -d' '`
fi
if echo "$argStr" | grep -iq "$FacilityStr"; then
        RK4Suf="FAC"
	vendorKey=`echo "${argStr}" | cut -f6 -d' '`
fi
CCN="CCN_"
if echo "$argStr" | grep -iq "$CCN"; then
	ccnFlag="Y"
fi

if [ ${kube_envt} == "EPIC" ] ; then
        source /mapr/datalake/uhclake/dataplatform/epde/p_conf/k8s_epic_param.properties
        if [ ${RKPFlag} == "Y" ] || [ ${phyFlag} == "Y" ] ; then
				if [ ${ccnFlag} == "Y" ] ; then
					echo "For CCN RKP and Physician in EPIC -> nohup spark-submit --master ${k8s_master} --class ${className} --conf spark.kryoserializer.buffer.max=2046 --conf spark.sql.shuffle.partitions=800 --conf spark.network.timeout=800000 --conf spark.executor.heartbeatInterval=120000 --conf spark.sql.broadcastTimeout=800000 --conf spark.sql.autoBroadcastJoinThreshold=62914560 --driver-memory 64g --executor-memory 38g --conf spark.executor.instances=20 --executor-cores 8 --conf spark.kubernetes.executor.limit.cores=8 --conf spark.executor.memoryOverhead=2240 --deploy-mode cluster --driver-java-options "-Dconfig.resource=${conf_name} -Dlog4j.configuration=${log4j} -DlogFilePath=${logFilePath} -DlogFileName=${logFileBaseName} -DrootLoggerOpt=${rootLoggerOpt}" --conf spark.app.name=${vendorKey}${RK4Suf} ${k8s_jar_path}${argStr}"  >> ${logFileName} 2>&1
					echo "For CCN RKP and Physician in EPIC -> CPU : 150 + 1 Driver=151" >> ${logFileName} 2>&1
					echo "For CCN RKP and Physician in EPIC -> Memory : 800 + 64 Driver=864" >> ${logFileName} 2>&1
					nohup spark-submit --master ${k8s_master} --class ${className} --conf spark.kryoserializer.buffer.max=2046 --conf spark.sql.shuffle.partitions=800 --conf spark.network.timeout=800000 --conf spark.executor.heartbeatInterval=120000 --conf spark.sql.broadcastTimeout=800000 --conf spark.sql.autoBroadcastJoinThreshold=62914560 --driver-memory 64g --executor-memory 32g --conf spark.executor.instances=25 --executor-cores 6 --conf spark.kubernetes.executor.limit.cores=6 --conf spark.executor.memoryOverhead=2240 --deploy-mode cluster --driver-java-options "-Dconfig.resource=${conf_name} -Dlog4j.configuration=${log4j} -DlogFilePath=${logFilePath} -DlogFileName=${logFileBaseName} -DrootLoggerOpt=${rootLoggerOpt}" --conf spark.app.name=${vendorKey}${RK4Suf} ${k8s_jar_path}${argStr} >> ${logFileName} 2>&1
					ret_code=$?
				else
					echo "For RKP and Physician in EPIC -> nohup spark-submit --master ${k8s_master} --class ${className} --conf spark.kryoserializer.buffer.max=2046 --conf spark.sql.shuffle.partitions=800 --conf spark.network.timeout=800000 --conf spark.executor.heartbeatInterval=120000 --conf spark.sql.broadcastTimeout=800000 --conf spark.sql.autoBroadcastJoinThreshold=62914560 --driver-memory 64g --executor-memory 32g --conf spark.executor.instances=10 --executor-cores 8 --conf spark.kubernetes.executor.limit.cores=8 --conf spark.executor.memoryOverhead=2240 --deploy-mode cluster --driver-java-options "-Dconfig.resource=${conf_name} -Dlog4j.configuration=${log4j} -DlogFilePath=${logFilePath} -DlogFileName=${logFileBaseName} -DrootLoggerOpt=${rootLoggerOpt}" --conf spark.app.name=${vendorKey}${RK4Suf} ${k8s_jar_path}${argStr}"  >> ${logFileName} 2>&1
					echo "For RKP and Physician in EPIC -> CPU : 72 + 1 Driver=71" >> ${logFileName} 2>&1
					echo "For RKP and Physician in EPIC -> Memory : 384 + 64 Driver=448" >> ${logFileName} 2>&1
					nohup spark-submit --master ${k8s_master} --class ${className} --conf spark.kryoserializer.buffer.max=2046 --conf spark.sql.shuffle.partitions=800 --conf spark.network.timeout=800000 --conf spark.executor.heartbeatInterval=120000 --conf spark.sql.broadcastTimeout=800000 --conf spark.sql.autoBroadcastJoinThreshold=62914560 --driver-memory 64g --executor-memory 32g --conf spark.executor.instances=12 --executor-cores 6 --conf spark.kubernetes.executor.limit.cores=6 --conf spark.executor.memoryOverhead=2240 --deploy-mode cluster --driver-java-options "-Dconfig.resource=${conf_name} -Dlog4j.configuration=${log4j} -DlogFilePath=${logFilePath} -DlogFileName=${logFileBaseName} -DrootLoggerOpt=${rootLoggerOpt}" --conf spark.app.name=${vendorKey}${RK4Suf} ${k8s_jar_path}${argStr} >> ${logFileName} 2>&1
					ret_code=$?
				fi

        else
                echo "For Others in EPIC -> nohup spark-submit --master ${k8s_master} --class ${className} --conf spark.kryoserializer.buffer.max=2046 --conf spark.sql.shuffle.partitions=800 --conf spark.network.timeout=800000 --conf spark.executor.heartbeatInterval=120000 --conf spark.sql.broadcastTimeout=800000 --conf spark.sql.autoBroadcastJoinThreshold=62914560 --driver-memory 64g --executor-memory 32g --conf spark.executor.instances=6 --executor-cores 8 --conf spark.kubernetes.executor.limit.cores=8 --conf spark.executor.memoryOverhead=2240 --deploy-mode cluster --driver-java-options "-Dconfig.resource=${conf_name} -Dlog4j.configuration=${log4j} -DlogFilePath=${logFilePath} -DlogFileName=${logFileBaseName} -DrootLoggerOpt=${rootLoggerOpt}" --conf spark.app.name=${vendorKey}${RK4Suf} ${k8s_jar_path}${argStr}"  >> ${logFileName} 2>&1
                echo "For Others in EPIC -> CPU : 42 + 1 Driver=43" >> ${logFileName} 2>&1
				echo "For Others in EPIC -> Memory : 224 + 64 Driver=288" >> ${logFileName} 2>&1
                nohup spark-submit --master ${k8s_master} --class ${className} --conf spark.kryoserializer.buffer.max=2046 --conf spark.sql.shuffle.partitions=800 --conf spark.network.timeout=800000 --conf spark.executor.heartbeatInterval=120000 --conf spark.sql.broadcastTimeout=800000 --conf spark.sql.autoBroadcastJoinThreshold=62914560 --driver-memory 64g --executor-memory 32g --conf spark.executor.instances=7 --executor-cores 6 --conf spark.kubernetes.executor.limit.cores=6 --conf spark.executor.memoryOverhead=2240 --deploy-mode cluster --driver-java-options "-Dconfig.resource=${conf_name} -Dlog4j.configuration=${log4j} -DlogFilePath=${logFilePath} -DlogFileName=${logFileBaseName} -DrootLoggerOpt=${rootLoggerOpt}" --conf spark.app.name=${vendorKey}${RK4Suf} ${k8s_jar_path}${argStr} >> ${logFileName} 2>&1
                ret_code=$?
        fi
else
        source /mapr/datalake/uhclake/dataplatform/epde/p_conf/k8s_param.properties
        if [ ${RKPFlag} == "Y" ] || [ ${phyFlag} == "Y" ] ; then
			if [ ${ccnFlag} == "Y" ] ; then
					echo "For CCN RKP and Physician in EPDE -> nohup spark-submit --master ${k8s_master} --class ${className} --conf spark.kryoserializer.buffer.max=2046 --conf spark.sql.shuffle.partitions=800 --conf spark.network.timeout=800000 --conf spark.executor.heartbeatInterval=120000 --conf spark.sql.broadcastTimeout=800000 --conf spark.sql.autoBroadcastJoinThreshold=62914560 --driver-memory 64g --executor-memory 36g --conf spark.executor.instances=20 --executor-cores 8 --conf spark.kubernetes.executor.limit.cores=8 --conf spark.executor.memoryOverhead=2240 --deploy-mode cluster --driver-java-options "-Dconfig.resource=${conf_name} -Dlog4j.configuration=${log4j} -DlogFilePath=${logFilePath} -DlogFileName=${logFileBaseName} -DrootLoggerOpt=${rootLoggerOpt}" --conf spark.app.name=${vendorKey}${RK4Suf} ${k8s_jar_path}${argStr}"  >> ${logFileName} 2>&1
					echo "For CCN RKP and Physician in EPDE -> CPU : 150 + 1 Driver=151" >> ${logFileName} 2>&1
					echo "For CCN RKP and Physician in EPDE -> Memory : 800 + 64 Driver=864" >> ${logFileName} 2>&1
					nohup spark-submit --master ${k8s_master} --class ${className} --conf spark.kryoserializer.buffer.max=2046 --conf spark.sql.shuffle.partitions=1000 --conf spark.network.timeout=800000 --conf spark.executor.heartbeatInterval=120000 --conf spark.sql.broadcastTimeout=800000 --conf spark.sql.autoBroadcastJoinThreshold=62914560 --driver-memory 64g --executor-memory 32g --conf spark.executor.instances=25 --executor-cores 6 --conf spark.kubernetes.executor.limit.cores=6 --conf spark.executor.memoryOverhead=2240 --deploy-mode cluster --driver-java-options "-Dconfig.resource=${conf_name} -Dlog4j.configuration=${log4j} -DlogFilePath=${logFilePath} -DlogFileName=${logFileBaseName} -DrootLoggerOpt=${rootLoggerOpt}" --conf spark.app.name=${vendorKey}${RK4Suf} ${k8s_jar_path}${argStr} >> ${logFileName} 2>&1
					ret_code=$?
			else
					echo "For RKP and Physician in EPDE -> nohup spark-submit --master ${k8s_master} --class ${className} --conf spark.kryoserializer.buffer.max=2046 --conf spark.sql.shuffle.partitions=800 --conf spark.network.timeout=800000 --conf spark.executor.heartbeatInterval=120000 --conf spark.sql.broadcastTimeout=800000 --conf spark.sql.autoBroadcastJoinThreshold=62914560 --driver-memory 64g --executor-memory 32g --conf spark.executor.instances=9 --executor-cores 6 --conf spark.kubernetes.executor.limit.cores=6 --conf spark.executor.memoryOverhead=2240 --deploy-mode cluster --driver-java-options "-Dconfig.resource=${conf_name} -Dlog4j.configuration=${log4j} -DlogFilePath=${logFilePath} -DlogFileName=${logFileBaseName} -DrootLoggerOpt=${rootLoggerOpt}" --conf spark.app.name=${vendorKey}${RK4Suf} ${k8s_jar_path}${argStr}"  >> ${logFileName} 2>&1
					echo "For RKP and Physician in EPDE -> CPU : 54 + 1 Driver=55" >> ${logFileName} 2>&1
					echo "For RKP and Physician in EPDE -> Memory : 288 + 64 Driver=352" >> ${logFileName} 2>&1
					nohup spark-submit --master ${k8s_master} --class ${className} --conf spark.kryoserializer.buffer.max=2046 --conf spark.sql.shuffle.partitions=800 --conf spark.network.timeout=800000 --conf spark.executor.heartbeatInterval=120000 --conf spark.sql.broadcastTimeout=800000 --conf spark.sql.autoBroadcastJoinThreshold=62914560 --driver-memory 64g --executor-memory 32g --conf spark.executor.instances=8 --executor-cores 5 --conf spark.kubernetes.executor.limit.cores=5 --conf spark.executor.memoryOverhead=2240 --deploy-mode cluster --driver-java-options "-Dconfig.resource=${conf_name} -Dlog4j.configuration=${log4j} -DlogFilePath=${logFilePath} -DlogFileName=${logFileBaseName} -DrootLoggerOpt=${rootLoggerOpt}" --conf spark.app.name=${vendorKey}${RK4Suf} ${k8s_jar_path}${argStr} >> ${logFileName} 2>&1
					ret_code=$?
			fi

        else
                echo "For Others in EPDE -> nohup spark-submit --master ${k8s_master} --class ${className} --conf spark.kryoserializer.buffer.max=2046 --conf spark.sql.shuffle.partitions=800 --conf spark.network.timeout=800000 --conf spark.executor.heartbeatInterval=120000 --conf spark.sql.broadcastTimeout=800000 --conf spark.sql.autoBroadcastJoinThreshold=62914560 --driver-memory 64g --executor-memory 32g --conf spark.executor.instances=6 --executor-cores 6 --conf spark.kubernetes.executor.limit.cores=6 --conf spark.executor.memoryOverhead=2240 --deploy-mode cluster --driver-java-options "-Dconfig.resource=${conf_name} -Dlog4j.configuration=${log4j} -DlogFilePath=${logFilePath} -DlogFileName=${logFileBaseName} -DrootLoggerOpt=${rootLoggerOpt}" --conf spark.app.name=${vendorKey}${RK4Suf} ${k8s_jar_path}${argStr}"  >> ${logFileName} 2>&1
                echo "For Others in EPDE -> CPU : 54 + 1 Driver=55" >> ${logFileName} 2>&1
				echo "For Others in EPDE -> Memory : 192 + 64 Driver=256" >> ${logFileName} 2>&1
                nohup spark-submit --master ${k8s_master} --class ${className} --conf spark.kryoserializer.buffer.max=2046 --conf spark.sql.shuffle.partitions=800 --conf spark.network.timeout=800000 --conf spark.executor.heartbeatInterval=120000 --conf spark.sql.broadcastTimeout=800000 --conf spark.sql.autoBroadcastJoinThreshold=62914560 --driver-memory 64g --executor-memory 32g --conf spark.executor.instances=6 --executor-cores 5 --conf spark.kubernetes.executor.limit.cores=5 --conf spark.executor.memoryOverhead=2240 --deploy-mode cluster --driver-java-options "-Dconfig.resource=${conf_name} -Dlog4j.configuration=${log4j} -DlogFilePath=${logFilePath} -DlogFileName=${logFileBaseName} -DrootLoggerOpt=${rootLoggerOpt}" --conf spark.app.name=${vendorKey}${RK4Suf} ${k8s_jar_path}${argStr} >> ${logFileName} 2>&1
                ret_code=$?
        fi
fi
echo "EPDECaptureStats: End Time: "$(date +'%Y-%m-%d %H:%M:%S') | tee -ai $2
endTime=`date +%s`
totalTimeInSec=`echo "$endTime - $startTime" | bc`
totalTimeInMin=`echo "$totalTimeInSec / 60" | bc`
echo "EPDECaptureStats: " ${vendorKey} " - " ${RK4Suf} "Total time taken in Minutes: ${totalTimeInMin}"  >> ${logFileName} 2>&1
if [[ ${ret_code} -eq 0 ]] ; then
        #echo -e "Hi,\n\t k8s_Generic_SSH Successfull for ${className}.\n\tNext Process is going to run\n\nRegards,\nEPIC Team"| mutt -s "k8s_Generic_SSH Success" -- $EMAIL
        echo "k8s_Generic_SSH Process Ended Successfully with arguments ${argStr}." >> ${logFileName} 2>&1
        echo "###############################Exit Code: ${ret_code} ###############################################" >> ${logFileName} 2>&1
        exit 0
else
        echo -e "Hi,\n\t k8s_Generic_SSH Program ${className} Failed with arguments ${argStr}\n\nRegards,\nEPIC Team"| mutt -s "k8s_Generic_SSH Failed" -- $EMAIL
        echo "k8s_Generic_SSH Process Ended WITH SOME ISSUE" >> ${logFileName} 2>&1
        echo "###################################Exit Code: ${ret_code} ##############################" >> ${logFileName} 2>&1
        exit ${ret_code}
fi


##=====================================================================================##
echo "End Time: "$(date +'%Y-%m-%d %H:%M:%S')  >> ${logFileName} 2>&1
echo "k8s_Generic_SSH Process Ended"  >> ${logFileName} 2>&1
#echo "########################################################################################" >> ${logFileName} 2>&1
#exit 0
