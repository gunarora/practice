#-------------------------------------------------#
# Script Name: Transporter.sh    #
# Description: Move Files to Inbound #
# Interface to Run the script: Oozie Job   #
# Developed and Owned by: EPIC Team           #
# Last updated: 08/08/2019                        #
#-------------------------------------------------#
#!/bin/bash

echo "########################################################################################" | tee -ai $4
if [ $# != 4 ]
	then
	echo "entered arguments are invalid "
	exit
fi

startTime=`date +%s`
dt1=$(date +'%Y-%m-%d %H:%M:%S.%3N')
Tm="T";
dt=${dt1:0:4}${dt1:5:2}${dt1:8:2}$Tm${dt1:11:2}${dt1:14:2}${dt1:17:2};

config_file=$1
environment=$2
changeGroupName=$3
logFileName=$4

source $config_file

echo "Start time for Transporter: $dt1" | tee -ai ${logFileName}

echo "Creating dat meta ctl files" | tee -ai ${logFileName}

mv ${EcgInbox}/${UNLOAD_FILE_NAME} ${TempPath}/${src}_${DBSchema}_${tablename}_$dt.dat
cp ${MetaFile} ${TempPath}/${src}_${DBSchema}_${tablename}_$dt.meta
cp ${ctl_path} ${TempPath}/${src}_${DBSchema}_${tablename}_$dt.ctl
#perl -p -e 's/\n//' ${EcgInbox}/${UNLOAD_FILE_NAME} > ${TempPath}/HIST_${src}_${DBSchema}_${tablename}_$dt.dat
echo "adding cdc_flag and cdc_timestamp and name of the file is -"${TempPath}/${src}_${DBSchema}_${tablename}_$dt".*" | tee -ai ${logFileName}
sed -i 's|^|I\x01'"$dt1"'\x01|' ${TempPath}/${src}_${DBSchema}_${tablename}_$dt.dat
oldfilecount=`wc -l ${EcgInbox}/${UNLOAD_FILE_NAME}`
#newfilecount=`awk 'BEGIN{RS="^B"} END {print NR}' ${TempPath}/${src}_${DBSchema}_${tablename}_$dt.dat`
echo "original file count from ECG: ${oldfilecount}" | tee -ai ${logFileName}

if [[ $(tail -c1 ${TempPath}/${src}_${DBSchema}_${tablename}_$dt.dat | wc -l) == 1 ]]; then
	truncate -s -1 ${TempPath}/${src}_${DBSchema}_${tablename}_$dt.dat
fi

retrievedCount=`tr -cd "\002" < ${TempPath}/${src}_${DBSchema}_${tablename}_$dt.dat|wc -c`

echo "updating count $retrievedCount" | tee -ai ${logFileName}

sed -i "s/RecordCount=/RecordCount=$retrievedCount/g" ${TempPath}/${src}_${DBSchema}_${tablename}_$dt.ctl

dt_ctl=$(date +'%Y-%m-%d %H:%M:%S')
dt_only=$(date +'%Y-%m-%d')
tm_only=$(date +'%H:%M:%S')

sed -i "s/ExtractDate=/ExtractDate=$dt_only/g" ${TempPath}/${src}_${DBSchema}_${tablename}_$dt.ctl
sed -i "s/ExtractTime=/ExtractTime=$tm_only/g" ${TempPath}/${src}_${DBSchema}_${tablename}_$dt.ctl
sed -i "s/FileTimeStamp=/FileTimeStamp=$tm_only/g" ${TempPath}/${src}_${DBSchema}_${tablename}_$dt.ctl
sed -i "s/ExtractDateTime=/ExtractDateTime=$dt_ctl/g" ${TempPath}/${src}_${DBSchema}_${tablename}_$dt.ctl
sed -i "s/EffectiveDate=/EffectiveDate=$dt_only/g" ${TempPath}/${src}_${DBSchema}_${tablename}_$dt.ctl

echo "dat meta ctl files created Successfully "${TempPath}/${src}_${DBSchema}_${tablename}_$dt".*" | tee -ai ${logFileName}

if [ $environment != "prd" ]
then
        echo "Starting the ingestion process for non prod environment" | tee -ai ${logFileName}
        echo "Current Path - "`pwd` | tee -ai ${logFileName}
        cd /mapr/datalake/uhclake/tst/tst_oozie/t_temp/df3
        echo "Modified Current Path for ingestion- "`pwd` | tee -ai ${logFileName}
        echo "UHG-NDB" > df3_ScanFilesList.lst
        echo "UHG-NDB" > df3_SchedulerList.lst
        echo "Started the ingestion process for non prod environment" | tee -ai ${logFileName}
fi

echo "Changing the group to fabbtndb and permission" | tee -ai ${logFileName}

chgrp $changeGroupName ${TempPath}/${src}_${DBSchema}_${tablename}_$dt.*
chmod 655 ${TempPath}/${src}_${DBSchema}_${tablename}_$dt.*

echo "Moving dat, meta, ctl files to inbound location- "${FwInbound} | tee -ai ${logFileName}
#if [ ${oldfilecount} -eq ${retrievedCount} ] ; then
    mv ${TempPath}/${src}_${DBSchema}_${tablename}_$dt.dat ${FwInbound}
    mv ${TempPath}/${src}_${DBSchema}_${tablename}_$dt.meta ${FwInbound}
    mv ${TempPath}/${src}_${DBSchema}_${tablename}_$dt.ctl ${FwInbound}
    echo "moved file ${src}_${DBSchema}_${tablename}_$dt.dat" | tee -ai ${logFileName}
    #rm -f ${EcgInbox}/${UNLOAD_FILE_NAME}
#else
#   echo "PROV_TRANS ingestion job: Counts not matching after \n removal so not going to ingest."  >> ${logFileName} 2>&1
#fi

echo "########################################################################################" | tee -ai ${logFileName}
dt2=$(date +'%Y-%m-%d %H:%M:%S')
endTime=`date +%s`
totalTimeInSec=`echo "$endTime - $startTime" | bc`
totalTimeInMin=`echo "$totalTimeInSec / 60" | bc`
echo "EPDECaptureStats: Total time taken in Minutes: ${totalTimeInMin}"  >> ${logFileName} 2>&1
echo "End time for Transporter: $dt2" | tee -ai ${logFileName}
#-------- End of the Script -------------#

