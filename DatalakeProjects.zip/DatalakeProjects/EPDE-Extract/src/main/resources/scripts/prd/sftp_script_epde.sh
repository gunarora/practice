#########################################################################################################################
# Script Name                   : sftp_script_epde.sh
# Author Name                   : Pankaj Kumar Vashistha
# Execution        		        : sftp_script_epde.sh <transferFlag> <ctl_file_path> <ctl_file_name> <user_id> <destination_server> <logFileName>
##########################################################################################################################
#sh sftp_script_uhn.sh Y /mapr/datalake/uhclake/dataplatform/epde/t_data/OHPH touch_OHPH_SFTP is00dpv ecgpi.healthtechnologygroup.com /mapr/datalake/uhclake/dataplatform/epde/t_logs/group_SFTP_OHPH.log
#!/bin/bash

echo "########################################################################################" | tee -ai $6
echo "SFTP Process Started" | tee -ai $6
echo "DEBUG : Inputs to the sftp_script_uhn.sh - transferFlag "$1"  ctl_file_path:: "$2" ctl_file_name:: "$3"  user_id:: "$4"  destination_server:: "$5"  logFileName:: "$6"  checkFileFlag:: "$7"  checkFileName:: "$8 | tee -ai $6

transferFlag=$1
ctl_file_path=$2
ctl_file_name=$3
user_id=$4
destination_server=$5
logFileName=$6
checkFileFlag=$7
checkFileName=$8
startTime=`date +%s`

echo "DEBUG : Inputs to the sftp_script_uhn.sh --> transferFlag:: "$1"  ctl_file_path:: "$2" ctl_file_name:: "$3"  user_id:: "$4"  destination_server:: "$5"  logFileName:: "$6"  checkFileFlag:: "$7"  checkFileName:: "$8 | tee -ai ${logFileName}
##=====================================================================================##
if [ "X"$checkFileFlag == "XY" ] || [ "X"$checkFileFlag == "Xy" ]
then
echo "Trigger file Status for NDB transfer is " $checkFileFlag | tee -ai ${logFileName}
if [ -f "${ctl_file_path}/${checkFileName}" ]; then
    echo "$checkFileName exist" | tee -ai ${logFileName}
    transferFlag="Y"
    echo "Assigned transferFlag---"$transferFlag
else
    echo "$checkFileName does not exist" | tee -ai ${logFileName}
fi
fi


if [ "X"$transferFlag == "XY" ] || [ "X"$transferFlag == "Xy" ]
then
echo "SFTP: File Transfer started" | tee -ai ${logFileName}
cd ${ctl_file_path}
sftp -b ${ctl_file_name} ${user_id}@${destination_server}  <<SCRIPT
binary
echo "binary sftp"
quit
SCRIPT

EXITSTATUS=$?

if [ $EXITSTATUS != "0" ]
then
  echo $EXITSTATUS
  echo "ERROR OCCURRED DURING FILE TRANSFER" | tee -ai ${logFileName}
##  mail -s "FILE TRANSFER FAILED" "$email" < File $filename transfer failed.
  exit 49
else
  echo "FILE TRANSFERED" | tee -ai ${logFileName}
fi
##=====================================================================================##
echo "SFTP Process Ended" | tee -ai ${logFileName}
else
echo "File Transfer is not required as it is not active in properties" | tee -ai ${logFileName}
fi
endTime=`date +%s`
totalTimeInSec=`echo "$endTime - $startTime" | bc`
totalTimeInMin=`echo "$totalTimeInSec / 60" | bc`
echo "EPDECaptureStats: Total time taken in Minutes: ${totalTimeInMin}"  >> ${logFileName} 2>&1
echo "########################################################################################" | tee -ai ${logFileName}
exit 0