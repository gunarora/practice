#-------------------------------------------------#
# Script Name: Transporter.sh    #
# Description: Check ingestion status #
# Interface to Run the script: Oozie Job   #
# Developed and Owned by: EPIC Team           #
# Last updated: 08/08/2019                        #
#-------------------------------------------------#
#!/bin/bash

echo "########################################################################################" | tee -ai $5

##========================== Logic For Recursion ======================================##
time_cnt=0
time_frequency=$3
max_time_count=$4
##=====================================================================================##

if [ $# != 5 ]
	then
	echo "here entered arguments are invalid " 
	exit
fi

startTime=`date +%s`
dt1=$(date +'%Y-%m-%d %H:%M:%S.%3N')
echo "IngestionWrapperStats: Start time for Ingestion wrapper: $dt1" | tee -ai ${logFileName}
Tm="T";
dt=${dt1:0:4}${dt1:5:2}${dt1:8:2}$Tm${dt1:11:2}${dt1:14:2}${dt1:17:2};

config_file=$1
environment=$2
logFileName=$5
cnt=0
source $config_file
#transport_logname=`ls -t ${Logdirectory}/${src}_Transporter*|head -n1`

transport_logname=$logFileName

echo "checking in ${transport_logname}" | tee -ai ${logFileName}

INGESTED_FILE_NAME=`grep -oh "[^ ]*\.dat" ${transport_logname} | head -1`

echo "Checking EIT for INGESTED_FILE_NAME ${INGESTED_FILE_NAME}" | tee -ai ${logFileName}

while [ $time_cnt -lt $max_time_count ]
do
    status=`sh ${ScriptPath}/ingestionStatus.sh $config_file $INGESTED_FILE_NAME`
    echo "status--"$status | tee -ai ${logFileName}
    if grep -q "Success" <<< $status; then
        echo "file ingested in $time_cnt attempt for file - ${INGESTED_FILE_NAME}" | tee -ai ${logFileName}
        touch ${touch_file_location}/${touch_file_name}

        if [ $environment != "prd" ]
        then
            echo "Stoping the ingestion process for non prod environment" | tee -ai ${logFileName}
            echo "Current Path - "`pwd` | tee -ai ${logFileName}
            cd /mapr/datalake/uhclake/tst/tst_oozie/t_temp/df3
            echo "Modified Current Path for ingestion- "`pwd` | tee -ai ${logFileName}
            echo "UHG-NDB" > df3_KillScanFilesList.lst
            echo "UHG-NDB" > df3_KillSchedulerList.lst
            echo "Stopped the ingestion process for non prod environment" | tee -ai ${logFileName}
        fi
        echo "IngestionWrapperStats: End Time: "$(date +'%Y-%m-%d %H:%M:%S') | tee -ai $2
        endTime=`date +%s`
        totalTimeInSec=`echo "$endTime - $startTime" | bc`
        totalTimeInMin=`echo "$totalTimeInSec / 60" | bc`
        echo "IngestionWrapperStats: Total time taken in Minutes: ${totalTimeInMin}"  >> ${logFileName} 2>&1
        exit 0
    else
        if [ $cnt -eq 0 ] ; then
            if grep -q "Failure" <<< $status; then
                echo -e "Hi,\n\t PROV_TRANS entity Failed for ${INGESTED_FILE_NAME}\n\nRegards,\nEPIC Team"| mutt -s "EPDE: PROV_TRANS Ingestion Failed" -- $EMAIL
                cnt=$((cnt+1))
            fi
        fi
        echo "file not ingested in "$time_cnt " attempt" | tee -ai ${logFileName}
    fi
    time_cnt=$(($time_cnt+1))
	sleep $time_frequency
done

echo "########################################################################################" | tee -ai ${logFileName}
#-------- End of the Script -------------#

