#-------------------------------------------------#
# Script Name: USHolidays.sh    #
# Description: Provide US holidays list year wise #
# Interface to Run the script: Oozie Job   #
# Developed and Owned by: Poorvi EPIC Team           #
# Last updated: 03/01/2020                        #
#-------------------------------------------------#
#!/bin/bash

ARCH=$(arch)
ARGC=$#

function Usage
{

echo "Usage: $(basename $0) Year"
echo "Eg. $(basename $0) 2014"
exit 1

}

# we will need the year as argument in YYYY format
[[ $ARGC -ne 1 ]] &&  Usage
logFileName=$1
echo "US HOlidays script started" >> ${logFileName} 2>&1

myyear=`date '+%Y'`
curDate=`date '+%Y-%m-%d'`
#curDate="2020-12-25"
#dformat='+%A, %B %d, %Y'
dformat='+%Y-%m-%d'
[[ "$myyear" -ge 2038 ]] && [[ "$ARCH" = "i686" ]] && echo 'Year 2038 problem : http://en.wikipedia.org/wiki/Year_2038_problem ' && exit 1

#We will ignore any year below 1902
[[ "$myyear" -lt 1902 ]] && [[ "$ARCH" = "i686" ]] && exit 1

##Function to get the nth day week of the month, for instance, Third Monday of March.

function nth_xday_of_month
{

my_nth=$1
my_xday=$2
my_month=$3
my_year=$4

case "$my_nth" in

1)  mydate=$(echo {01..07})
    ;;
2)  mydate=$(echo {08..14})
    ;;
3)  mydate=$(seq 15 21)
    ;;
4)  mydate=$(seq 22 28)
   ;;
5)  mydate=$(seq 29 31)
    ;;
*) echo "Echo wrong day of the week" >> ${logFileName} 2>&1
   exit 1
   ;;
esac


for x in $mydate; do
  nthday=$(date '+%u' -d "${my_year}${my_month}${x}")
  if [ "$nthday" -eq "$my_xday" ]; then
   date "${dformat}" -d "${my_year}${my_month}${x}"
  fi
done
}

#dformat='+%Y-%m-%d'

##Memorial day - Last Monday of May.

for x in {31..01}; do y=$(date '+%u' -d "${myyear}05${x}"); if [ "$y" -eq 1 ]; then memday="${x}" ; break; fi ; done

echo "New Year's Day:              " $(date "${dformat}"  -d "${myyear}0101") >> ${logFileName} 2>&1
echo "Martin Luther King, Jr. Day: " $(nth_xday_of_month 3 1 01 ${myyear}) >> ${logFileName} 2>&1
#echo "Washington's Birthday:       " $(nth_xday_of_month 3 1 02 ${myyear})
echo "Memorial Day:                " $(date "${dformat}" -d "${myyear}05${memday}") >> ${logFileName} 2>&1
echo "Independence Day:            " $(date "${dformat}" -d "${myyear}0704") >> ${logFileName} 2>&1
echo "Labor Day:                   " $(nth_xday_of_month 1 1 09 ${myyear}) >> ${logFileName} 2>&1
#echo "Columbus Day:                " $(nth_xday_of_month 2 1 10 ${myyear})
#echo "Veteran's Day:               " $(date "${dformat}" -d "${myyear}1111")
echo "Thanksgiving:                " $(nth_xday_of_month 4 4 11 ${myyear}) >> ${logFileName} 2>&1
echo "Day after Thanksgiving:       "`date "${dformat}" -d "$(nth_xday_of_month 4 4 11 ${myyear}) + 1 day"` >> ${logFileName} 2>&1
echo "Christmas Day:               " $(date "${dformat}" -d "${myyear}1225") >> ${logFileName} 2>&1

dateStr=$(date "${dformat}"  -d "${myyear}0101")"|"$(nth_xday_of_month 3 1 01 ${myyear})"|"$(date "${dformat}" -d "${myyear}05${memday}")"|"$(date "${dformat}" -d "${myyear}0704")"|"$(nth_xday_of_month 1 1 09 ${myyear})"|"$(nth_xday_of_month 4 4 11 ${myyear})"|"`date "${dformat}" -d "$(nth_xday_of_month 4 4 11 ${myyear}) + 1 day"`"|"$(date "${dformat}" -d "${myyear}1225")

echo $dateStr >> ${logFileName} 2>&1

for i in $(echo $dateStr | sed "s/|/ /g")
do
        if [ $i == $curDate ] ; then
                echo "US Holiday on $i" >> ${logFileName} 2>&1
                echo "End US Holidays script and Extracts should not be generated today" >> ${logFileName} 2>&1
                exit 2
        fi
done
echo "Good to run extract today on $curDate" >> ${logFileName} 2>&1
echo "End US Holidays script" >> ${logFileName} 2>&1
exit 0