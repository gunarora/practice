#########################################################################################################################
# Script Name                   : killOozieExtracts.sh
# Author Name                   : Pankaj Kumar Vashistha
# Execution        		        : killOozieExtracts.sh <input_property_file>
##########################################################################################################################
# sh killOozieExtracts.sh /mapr/datalake/uhclake/tst/developer/pankaj/scripts/ndb_extract/oozie/final /mapr/datalake/uhclake/tst/developer/pankaj/scripts/ndb_extract/oozie/final/test ZIP /mapr/datalake/uhclake/dataplatform/ndb/p_logs/UHN_Reporting-F5938P_PROD_LANTYP_ZIP_0000246-180730073548993-oozie-mapr-W.log
#!/bin/bash

echo "Process Started" 

input_property_file=$1

for line in $(cat ${input_property_file}); do
 echo "Extract is started for ${line}" 
 extName=`echo ${line}`

 execute=`/opt/mapr/oozie/oozie-4.3.0/bin/oozie job -oozie="https://apsrp05783.uhc.com:11443/oozie" -kill ${extName}`
 echo $execute
 
done

echo "Process Ended"

