#########################################################################################################################
# Script Name                   : runOozieExtracts.sh
# Author Name                   : Pankaj Kumar Vashistha
# Execution                     : runOozieExtracts.sh
##########################################################################################################################
# sh runOozieExtracts.sh
#!/bin/bash

echo "########################################################################################" | tee -ai $5
echo "Running all extracts Process Started" | tee -ai $5
echo "DEBUG : Inputs to the runOozieExtracts.sh "$1" :: "$2" :: "$3" :: "$4 | tee -ai $5

##===========================Assign Constant Val=======================================##
#vendorFileLoc=$1
#vendorFilePrefix=$2
ooziHostURL=$1
propertyFile=$2
vendor_cd=$3
kube_envt=$4
logFileName=$5

echo "DEBUG : Inputs to the runOozieExtracts.sh "$vendorFileLoc" :: "$vendorFilePrefix" :: ${propertyFile} :: "$logFileName | tee -ai ${logFileName}

if [ ${kube_envt} == "EPIC" ] ; then
	source /mapr/datalake/uhclake/dataplatform/epde/p_conf/k8s_epic_param.properties
else
	source /mapr/datalake/uhclake/dataplatform/epde/p_conf/k8s_param.properties
fi

##=====================================================================================##
##========================== Logic For Reading All Batch file==========================##
#for input_property_file in `cat ${vendorFileLoc}/${vendorFilePrefix}`
#do
 echo "Extract is started for ${input_property_file}"  | tee -ai ${logFileName}
 echo "Vendor Name is : ${input_property_file}" | tee -ai ${logFileName}
 echo "/opt/mapr/oozie/oozie-4.3.0/bin/oozie job -oozie="https://${ooziHostURL}:11443/oozie" -config ${propertyFile} -run" -Dvendor_cd=${vendor_cd} | tee -ai ${logFileName}
 execute=`/opt/mapr/oozie/oozie-4.3.0/bin/oozie job -oozie="https://${ooziHostURL}:11443/oozie" -config ${propertyFile} -run -Dvendor_cd=${vendor_cd}` | tee -ai ${logFileName}
 echo $execute  | tee -ai ${logFileName}
 exe_val=`echo $execute | cut -d':' -f 2`
 echo $exe_val  | tee -ai ${logFileName}
#done
##=====================================================================================##
echo "Process Ended"  | tee -ai ${logFileName}
echo "Running all extracts Process Ended" | tee -ai ${logFileName}
echo "########################################################################################" | tee -ai ${logFileName}
exit 0