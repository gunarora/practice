# Author Name                   : Pankaj Kumar Vashistha
# Execution                     : runOozieExtracts.sh
##########################################################################################################################
# sh runOozieExtracts.sh
#!/bin/bash

echo "########################################################################################" | tee -ai $5
echo "Running all extracts Process Started" | tee -ai $5
echo "DEBUG : Inputs to the runOozieExtracts.sh "$1" :: "$2" :: "$3" :: "$4 | tee -ai $5

##===========================Assign Constant Val=======================================##
vendorFileLoc=$1
vendorFilePrefix=$2
ooziHostURL=$3
propertyFile=$4
logFileName=$5
startTime=`date +%s`
echo "DEBUG : Inputs to the runOozieExtracts.sh "$vendorFileLoc" :: "$vendorFilePrefix" :: ${propertyFile} :: "$logFileName | tee -ai ${logFileName}

##=====================================================================================##
##========================== Logic For Reading All Batch file==========================##
for input_property_file1 in `cat ${vendorFileLoc}/${vendorFilePrefix}`
do
 input_property_file=`echo ${input_property_file1}|cut -f1 -d'|'`
 kube_envt=`echo ${input_property_file1}|cut -f2 -d'|'`
 echo "Extract is started for ${input_property_file} & ${kube_envt} namespace"  | tee -ai ${logFileName}
 echo "Vendor Name is : ${input_property_file}" | tee -ai ${logFileName}
 echo "/opt/mapr/oozie/oozie-4.3.0/bin/oozie job -oozie="https://${ooziHostURL}:11443/oozie" -config ${propertyFile} -run" -Dvendor_cd=${input_property_file} -Dkube_envt=${kube_envt} | tee -ai ${logFileName}
 execute=`/opt/mapr/oozie/oozie-4.3.0/bin/oozie job -oozie="https://${ooziHostURL}:11443/oozie" -config ${propertyFile} -run -Dvendor_cd=${input_property_file} -Dkube_envt=${kube_envt}` | tee -ai ${logFileName}
 echo $execute  | tee -ai ${logFileName}
 exe_val=`echo $execute | cut -d':' -f 2`
 echo $exe_val  | tee -ai ${logFileName}
 if [ ${input_property_file} == "CCN_DAILY" ] ; then
	sleep 60
 else
 	sleep 900
 fi
done
##=====================================================================================##
endTime=`date +%s`
totalTimeInSec=`echo "$endTime - $startTime" | bc`
totalTimeInMin=`echo "$totalTimeInSec / 60" | bc`
echo "EPDECaptureStats: Total time taken in Minutes: ${totalTimeInMin}"  >> ${logFileName} 2>&1
echo "Process Ended"  | tee -ai ${logFileName}
echo "Running all extracts Process Ended" | tee -ai ${logFileName}
echo "########################################################################################" | tee -ai ${logFileName}
exit 0