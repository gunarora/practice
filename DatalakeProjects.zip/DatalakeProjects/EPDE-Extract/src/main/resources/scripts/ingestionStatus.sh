#-------------------------------------------------#
# Script Name: Transporter.sh    #
# Description: Check ingestion status #
# Interface to Run the script: Oozie Job   #
# Developed and Owned by: EPIC Team           #
# Last updated: 08/08/2019                        #
#-------------------------------------------------#

#!/bin/bash


dt1=$(date +'%Y-%m-%d %H:%M:%S.%3N')
Tm="T";
dt=${dt1:0:4}${dt1:5:2}${dt1:8:2}$Tm${dt1:11:2}${dt1:14:2}${dt1:17:2};

config_file=$1
source $config_file
INGESTED_FILE_NAME=$2

export MAPR_TICKETFILE_LOCATION=${MAPR_TICKETFILE_LOCATION}

status=`echo "scan '${EIT_TABLE}',{COLUMNS=>['fi:srcFileNm','exi:ingProcLogSts'],FILTER=>\"PrefixFilter('${prtnrCd}-${src}-${DBSchema}_${tablename}') AND SingleColumnValueFilter('fi','srcFileNm',=, 'binary:${INGESTED_FILE_NAME}')\"}"|hbase shell`

echo $status

#-------- End of the Script -------------#

