#########################################################################################################################
# Script Name                   : checkProvTrans.sh
# Author Name                   : Pankaj Kumar Vashistha
# Execution        		        : checkProvTrans.sh <time_frequency> <max_time_count> <provTransFileLoc> <provTransFileName> <logFileName> 
##########################################################################################################################

#!/bin/bash

echo "########################################################################################" | tee -ai $5
echo "Check Prov Trans File Process Started" | tee -ai $5
echo "DEBUG : Check Prov Trans File Existence-  time_frequency "$1 "  max_time_count:: "$2 "  provTransFileLoc:: "$3 "  provTransFileName:: "$4 " logFileName:: "$5 | tee -ai $5

##========================== Logic For Recursion ======================================##
time_cnt=0
time_frequency=$1
max_time_count=$2
##=====================================================================================##
##===========================Assign Constant Val=======================================##
provTransFileLoc=$3
provTransFileName=$4
logFileName=$5
##=====================================================================================##
echo "DEBUG : Check Prov Trans File Existence- time_frequency "$1 "  max_time_count:: "$2 "  provTransFileLoc:: "$3 "  provTransFileName:: "$4 " logFileName:: "$5 | tee -ai ${logFileName}
##========================== Logic applied Below ======================================##
echo "DEBUG : Logic to Check Prov Trans File Existence started" | tee -ai ${logFileName}

while [ $time_cnt -lt $max_time_count ]
do
	if [ -f "${provTransFileLoc}/${provTransFileName}" ]; then
		echo "Prov Trans File Exists" | tee -ai ${logFileName}
		echo "DEBUG : Logic to Check Prov Trans File Existence Completed" | tee -ai ${logFileName}
		exit 0
	fi
	time_cnt=$(($time_cnt+1))
	sleep $time_frequency
done

echo "DEBUG : Prov Trans File does not Exist" | tee -ai ${logFileName}
##=====================================================================================##
echo "Prov Trans File does not Exist: Process Failed" | tee -ai ${logFileName}
echo "########################################################################################" | tee -ai ${logFileName}
exit 1
