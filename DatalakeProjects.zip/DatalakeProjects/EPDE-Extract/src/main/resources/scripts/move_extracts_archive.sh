#########################################################################################################################
# Script Name                   : move_extracts_archive.sh
# Author Name                   : Pankaj Kumar Vashistha
# Execution        		        : move_extracts_archive.sh <extractLoc> <extractArchiveLoc> <configFileLocation> <configArchiveLoc> <touchFileName> <triggerFileName> <checkTriggerFileName> <logFileName>
##########################################################################################################################
# sh move_extracts_archive.sh
#!/bin/bash

echo "########################################################################################" | tee -ai $8
echo "Move Extracts to Archive Location Process Started" | tee -ai $8
echo "DEBUG : Move Extracts to Archive extractLoc "$1 "  extractArchiveLoc:: "$2 "  configFileLoc:: "$3 "  configArchiveLoc:: "$4 " touchFileName:: "$5 " triggerFileName:: "$6 "  checkTriggerFileName:: "$7 "  logFileName:: "$8 | tee -ai $8

##===========================Assign Constant Val=======================================##
extractLoc=$1
extractArchiveLoc=$2
configFileLoc=$3
configArchiveLoc=$4
touchFileName=$5
triggerFileName=$6
checkTriggerFileName=$7
logFileName=$8
dt1=$(date +'%Y-%m-%d %H:%M:%S.%3N')
Tm="T";
dt=${dt1:0:4}${dt1:5:2}${dt1:8:2}$Tm${dt1:11:2}${dt1:14:2}${dt1:17:2};

echo "DEBUG : Adding timestamp in zip before moving to archive location" | tee -ai ${logFileName}

##=====================================================================================##
##========================== Logic applied Below ======================================##

if [ -d "${extractLoc}/GROUP" ]; then
    echo "GROUP is available" | tee -ai ${logFileName}
    mkdir -p $extractArchiveLoc/GROUP
    fullFileName=`ls -1 ${extractLoc}/GROUP/`
    for word in $fullFileName
	do
    archFileName=`echo ${word} | sed -e "s/\(.*\)\(\..*$\)/\1\.$dt\2/g"`
    mv ${extractLoc}/GROUP/${word} ${extractArchiveLoc}/GROUP/${archFileName}
    echo "DEBUG : Extract moved to archive location: ${extractArchiveLoc}/GROUP/${archFileName}" | tee -ai ${logFileName}
	done
fi

if [ -d "${extractLoc}/PHYSICIAN" ]; then
    echo "PHYSICIAN is available" | tee -ai ${logFileName}
    mkdir -p $extractArchiveLoc/PHYSICIAN
    fullFileName=`ls -1 ${extractLoc}/PHYSICIAN/`
    for word in $fullFileName
    do
    archFileName=`echo ${word} | sed -e "s/\(.*\)\(\..*$\)/\1\.$dt\2/g"`
    mv ${extractLoc}/PHYSICIAN/${word} ${extractArchiveLoc}/PHYSICIAN/${archFileName}
    echo "DEBUG : Extract moved to archive location: ${extractArchiveLoc}/PHYSICIAN/${archFileName}" | tee -ai ${logFileName}
    done
fi

if [ -d "${extractLoc}/FACILITY" ]; then
    echo "FACILITY is available" | tee -ai ${logFileName}
    mkdir -p $extractArchiveLoc/FACILITY
    fullFileName=`ls -1 ${extractLoc}/FACILITY/`
    for word in $fullFileName
    do
    archFileName=`echo ${word} | sed -e "s/\(.*\)\(\..*$\)/\1\.$dt\2/g"`
    mv ${extractLoc}/FACILITY/${word} ${extractArchiveLoc}/FACILITY/${archFileName}
    echo "DEBUG : Extract moved to archive location: ${extractArchiveLoc}/FACILITY/${archFileName}" | tee -ai ${logFileName}
    done
fi

echo "DEBUG : All ZIP Files moved to archive extract location" | tee -ai ${logFileName}
echo "DEBUG : Now Moving config files to archive config location" | tee -ai ${logFileName}



    confTouchFileName=`echo ${touchFileName}_${dt}`
    confTriggerFileName=`echo ${triggerFileName}_${dt}`
    confCheckTriggerFileName=`echo ${checkTriggerFileName}_${dt}`
    #confAllRowKeyFileNm=`echo ${allRowKeyFileNm}_${dt}`
	mv ${configFileLoc}/${touchFileName} $configArchiveLoc/${confTouchFileName}
	mv ${configFileLoc}/${triggerFileName} $configArchiveLoc/${confTriggerFileName}
	mv ${configFileLoc}/${checkTriggerFileName} $configArchiveLoc/${confCheckTriggerFileName}
	#mv $extractLoc/$allRowKeyFileNm $configArchiveLoc/$confAllRowKeyFileNm

echo "DEBUG : All config files moved to archive config location" | tee -ai ${logFileName}

##=====================================================================================##
echo "Move Extracts to Archive Location Process Ended" | tee -ai ${logFileName}
echo "########################################################################################" | tee -ai ${logFileName}
exit 0