#-------------------------------------------------#
# Script Name: Transporter.sh    #
# Description: Check ingestion status #
# Interface to Run the script: Oozie Job   #
# Developed and Owned by: EPIC Team           #
# Last updated: 08/08/2019                        #
#-------------------------------------------------#
#!/bin/bash

echo "########################################################################################" | tee -ai $5

##========================== Logic For Recursion ======================================##
time_cnt=0
time_frequency=$3
max_time_count=$4
##=====================================================================================##

if [ $# != 5 ]
	then
	echo "here entered arguments are invalid " 
	exit
fi

dt1=$(date +'%Y-%m-%d %H:%M:%S.%3N')
Tm="T";
dt=${dt1:0:4}${dt1:5:2}${dt1:8:2}$Tm${dt1:11:2}${dt1:14:2}${dt1:17:2};

config_file=$1
environment=$2
logFileName=$5

source $config_file
#transport_logname=`ls -t ${Logdirectory}/${src}_Transporter*|head -n1`

transport_logname=$logFileName

echo "checking in ${transport_logname}" | tee -ai ${logFileName}

INGESTED_FILE_NAME=`grep -oh "[^ ]*\.dat" ${transport_logname} | head -1`

echo "Checking EIT for INGESTED_FILE_NAME ${INGESTED_FILE_NAME}" | tee -ai ${logFileName}

while [ $time_cnt -lt $max_time_count ]
do
    status=`sh ${ScriptPath}/ingestionStatus.sh $config_file $INGESTED_FILE_NAME`
    echo "status--"$status | tee -ai ${logFileName}
    if grep -q "Success" <<< $status; then
        echo "file ingested in $time_cnt attempt for file - ${INGESTED_FILE_NAME}" | tee -ai ${logFileName}
        touch ${touch_file_location}/${touch_file_name}

        if [ $environment != "prd" ]
        then
            echo "Stoping the ingestion process for non prod environment" | tee -ai ${logFileName}
            echo "Current Path - "`pwd` | tee -ai ${logFileName}
            cd /mapr/datalake/uhclake/tst/tst_oozie/t_temp/df3
            echo "Modified Current Path for ingestion- "`pwd` | tee -ai ${logFileName}
            echo "UHG-NDB" > df3_KillScanFilesList.lst
            echo "UHG-NDB" > df3_KillSchedulerList.lst
            echo "Stopped the ingestion process for non prod environment" | tee -ai ${logFileName}
        fi

        exit 0
    else
        echo "file not ingested in "$time_cnt " attempt" | tee -ai ${logFileName}
    fi
    time_cnt=$(($time_cnt+1))
	sleep $time_frequency
done
echo "########################################################################################" | tee -ai ${logFileName}
#-------- End of the Script -------------#

