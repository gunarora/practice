#-------------------------------------------------#
# Script Name: Transporter.sh    #
# Description: Move Files to Inbound #
# Interface to Run the script: Oozie Job   #
# Developed and Owned by: EPIC Team           #
# Last updated: 08/08/2019                        #
#-------------------------------------------------#
#!/bin/bash

echo "########################################################################################" | tee -ai $4
if [ $# != 4 ]
	then
	echo "entered arguments are invalid "
	exit
fi

dt1=$(date +'%Y-%m-%d %H:%M:%S.%3N')
Tm="T";
dt=${dt1:0:4}${dt1:5:2}${dt1:8:2}$Tm${dt1:11:2}${dt1:14:2}${dt1:17:2};

config_file=$1
environment=$2
changeGroupName=$3
logFileName=$4

source $config_file

echo "Creating dat meta ctl files" | tee -ai ${logFileName}

mv ${EcgInbox}/${UNLOAD_FILE_NAME} ${TempPath}/${src}_${DBSchema}_${tablename}_$dt.dat
cp ${MetaFile} ${TempPath}/${src}_${DBSchema}_${tablename}_$dt.meta
cp ${ctl_path} ${TempPath}/${src}_${DBSchema}_${tablename}_$dt.ctl

echo "adding cdc_flag and cdc_timestamp and name of the file is -"${TempPath}/${src}_${DBSchema}_${tablename}_$dt".*" | tee -ai ${logFileName}

sed -i 's|^|I\x01'"$dt1"'\x01|' ${TempPath}/${src}_${DBSchema}_${tablename}_$dt.dat


if [[ $(tail -c1 ${TempPath}/${src}_${DBSchema}_${tablename}_$dt.dat | wc -l) == 1 ]]; then
	truncate -s -1 ${TempPath}/${src}_${DBSchema}_${tablename}_$dt.dat
fi

retrievedCount=`tr -cd "\002" < ${TempPath}/${src}_${DBSchema}_${tablename}_$dt.dat|wc -c`

echo "updating count $retrievedCount" | tee -ai ${logFileName}

sed -i "s/RecordCount=/RecordCount=$retrievedCount/g" ${TempPath}/${src}_${DBSchema}_${tablename}_$dt.ctl

echo "dat meta ctl files created Successfully "${TempPath}/${src}_${DBSchema}_${tablename}_$dt".*" | tee -ai ${logFileName}

if [ $environment != "prd" ]
then
        echo "Starting the ingestion process for non prod environment" | tee -ai ${logFileName}
        echo "Current Path - "`pwd` | tee -ai ${logFileName}
        cd /mapr/datalake/uhclake/tst/tst_oozie/t_temp/df3
        echo "Modified Current Path for ingestion- "`pwd` | tee -ai ${logFileName}
        echo "UHG-NDB" > df3_ScanFilesList.lst
        echo "UHG-NDB" > df3_SchedulerList.lst
        echo "Started the ingestion process for non prod environment" | tee -ai ${logFileName}
fi

echo "Changing the group to fabbtndb" | tee -ai ${logFileName}

chgrp $changeGroupName ${TempPath}/${src}_${DBSchema}_${tablename}_$dt.*

echo "Moving dat, meta, ctl files to inbound location- "${FwInbound} | tee -ai ${logFileName}

mv ${TempPath}/${src}_${DBSchema}_${tablename}_$dt.* ${FwInbound}

echo "moved file ${src}_${DBSchema}_${tablename}_$dt.dat" | tee -ai ${logFileName}

echo "########################################################################################" | tee -ai ${logFileName}
#-------- End of the Script -------------#

