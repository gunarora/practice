package com.uhg.optum

import com.uhg.optum.dao.{HbaseRepositoryManager, LocalRepositoryManager}
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.util.exceptions.{InsufficientArgsException, QueryFailureException, VendorSetupException}
import com.uhg.optum.util.{CommonUtil, Logger}

/**
  * Description : Program to generate the extract based on PEI, PSC,PLC configurations with snapBudType raw / snapshot / pjs (with source as File for CHY)
  */
object Driver {
  def main(args: Array[String]): Unit = {
    try {

      Logger.log.info("=============> Starting RKP EPDE Extract WorkFlow <=============")
      if (args.length != 5) {
        Logger.log.info("===> Please Pass feedName-vendorName Environment thriftServerUrl \" EPDE-OPTUM  local/yarn thrift://dbsls0306.uhc.com:11018 F/N dev/tst/prd\" for Provisioning extract <===")
        Logger.log.error("===> Since No args as per usage(FeedName-ExtractName,Environment mode, thrift server,full file param,environment)  is Passed ending Provisioning extract <===")
        //System.exit(1)
        throw new InsufficientArgsException("Invalid RKP Arguments")
      }

      val peiRowKey = args(0).trim
      val env = args(1).trim.toLowerCase
      val metaURI = args(2).trim
      val fullFileParam = args(3).trim
      val loc_env = args(4).trim
      implicit val globalContext = if(env.equalsIgnoreCase("local")) {
        new GlobalContext(peiRowKey,"local") with LocalRepositoryManager
      } else {
        new GlobalContext(peiRowKey,"yarn") with HbaseRepositoryManager
      }

     // val jobRunner = new EPDEJobRunner(peiRowKey)
      val jobRunner = new JobRunner(peiRowKey, env,fullFileParam,loc_env)
      jobRunner.start()
      globalContext.sparkSession.stop()
    } catch {
      case v: VendorSetupException => {
        Logger.log.error("RKP: Driver: " + v.getMessage)
        Logger.log.error("Error occured : " + v.getStackTrace.mkString("\n"))
        System.exit(1)
        throw v
      }
      case q: QueryFailureException => {
        Logger.log.error("RKP: Driver: " + q.getMessage)
        Logger.log.error("Error occured : " + q.getStackTrace.mkString("\n"))
        System.exit(2)
        throw q
      }
      case i: InsufficientArgsException => {
        Logger.log.error("RKP: Driver: " + i.getMessage)
        Logger.log.error("Error occured : " + i.getStackTrace.mkString("\n"))
        System.exit(3)
        throw i
      }
      case e: Exception => {
        Logger.log.error("RKP: Driver: " + e.getMessage)
        Logger.log.error("Error occured : " + e.getStackTrace.mkString("\n"))
        System.exit(4)
        throw e
      }
        //throw e
    }
  }
}
