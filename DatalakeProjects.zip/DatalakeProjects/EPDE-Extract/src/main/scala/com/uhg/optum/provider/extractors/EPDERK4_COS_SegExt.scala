package com.uhg.optum.provider.extractors

import com.uhg.optum.common.DPOConstants
import com.uhg.optum.conf.ApplicationConfig.datafilesDir
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDERK4InputJsonSchema.SegmentDetails
import com.uhg.optum.util.{CommonUtil, EPDECommonUtil, FileSystemUtil, Logger}

trait EPDERK4_COS_SegExt {

  def cosSegGen(segDetails: SegmentDetails, outputFilePath: String, glblVarLst: collection.mutable.Map[String, String])(implicit context: GlobalContext): String = {
try{
    var df=context.sqlContext.emptyDataFrame
    var resStr = "N"
    EPDECommonUtil.generateSegTables(segDetails.segTables, glblVarLst)
    println("length of the se details list for the COS "+segDetails.segQueries.size)
   // segDetails.segQueries.foreach(println())
    segDetails.segQueries.map { qryKey =>
      Logger.log.info("qryKey.name --> " + qryKey.name)
      if (qryKey.name.matches("COS_FNL_VIEW")) {
        df = CommonUtil.executeQry(glblVarLst, qryKey)
        CommonUtil.createOrReplaceTempViewFn(df, qryKey.name)
       // if (df.count > 0) {
        //  df.dropDuplicates()
          //RPAD QUERY -> result -> write df res in file
          /*        val pspDf = CommonUtil.generateRpadQry(segDtls.segTarCol, segDtls.segTarLen, segDtls.segTolLen, qryKey.name)
                generateOpFile(pspDf, outputFilePath, segDtls.segSeq)*/

          datafilesDir+"/"+glblVarLst("${WS_VENDR_CD}")+"/"+glblVarLst("provTypCd")+"/"
          FileSystemUtil.saveFileToMapRFSNoRepartitionParquet( df.dropDuplicates(), outputFilePath, qryKey.name, "", DPOConstants.PARQUET)
          resStr = "Y"
        }
     // }
     /* else if (qryKey.name.matches("COS_FNL_GROUP_VIEW")) {
        df = CommonUtil.executeQry(glblVarLst, qryKey)
        CommonUtil.createOrReplaceTempViewFn(df, qryKey.name)
      //  if (df.count > 0) {
        //  df.dropDuplicates()
          //RPAD QUERY -> result -> write df res in file
          /*        val pspDf = CommonUtil.generateRpadQry(segDtls.segTarCol, segDtls.segTarLen, segDtls.segTolLen, qryKey.name)
                generateOpFile(pspDf, outputFilePath, segDtls.segSeq)*/

          //datafilesDir+"/"+glblVarLst("${WS_VENDR_CD}")+"/"+glblVarLst("provTypCd")+"/"
          FileSystemUtil.saveFileToMapRFS( df.dropDuplicates(), outputFilePath, qryKey.name, "", DPOConstants.PARQUET)
          resStr = "Y"
        }*/
      //}
      else {
        df = CommonUtil.executeQry(glblVarLst, qryKey)
        CommonUtil.createOrReplaceTempViewFn(df, qryKey.name)
      }
    }
    resStr
}catch {

  case e: Exception => {
    Logger.log.info(s"RK4 : EPDERK4_COS_SegExt.genCOSSeg() : "+e.getMessage)
    throw e
  }

}
  }

}
