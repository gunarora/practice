package com.uhg.optum.provider.extractors

import com.uhg.optum.common.DPOConstants
import com.uhg.optum.conf.ApplicationConfig.workingDir
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDERK4InputJsonSchema.SegmentDetails
import com.uhg.optum.util.CommonUtil.{createOrReplaceTempViewFn, executeQry}
import com.uhg.optum.util.{CommonUtil, EPDECommonUtil, FileSystemUtil, Logger}

trait EPDERK4_CSP_SegExt {
  def genCSPSeg(segDtls: SegmentDetails,varLst:collection.mutable.Map[String, String],glblVarLst:collection.mutable.Map[String, String],outputFilePath:String)(implicit context: GlobalContext): String = {
/*    import context.sparkSession.implicits._
    ///PHA
    var df_PRV= Seq(
      ("PHA","P","C","1336663","","",""), //OK
      ("PHA","P","C","1900110","","",""), //OK
      ("PHA","P","C","2348658","","",""), //OK
      ("PHA","P","C","2554718","","",""), //
      ("PHA","P","C","2565298","","",""), //
      ("PHA","P","C","2660177","","",""), //
      ("PHA","P","C","2803875","","",""), //
      ("PHA","P","C","2975674","","",""), //
      ("PHA","P","C","3057758","","",""), //
      ("PHA","P","C","3104170","","",""), //
      ("PHA","O","C","2546134","","","033"), //OK
      ("PHA","O","C","6311285","","","058"), //OK
      ("PHA","p","C","3297248","","","033"), //
      ("PHA","P","C","3523856","","","033"), //
      ("PHA","P","C","3602981","","","033")
    ).toDF("PROV_OUT_VENDR_CD","PROV_OUT_PROV_TYP_CD","PROV_OUT_UPDT_TYP_CD","PROV_OUT_PROV_ID","PROV_OUT_VEND_KEY","PROV_PQD_OR_FQD_CNT","PROV_OUT_ORG_TYP_CD")


    var df_CONT=Seq(
      ("PHA","P", "1336663", "148942800", "200136459", ""),
      ("PHA","P", "1900110", "130410137", "760622487", ""),
      ("PHA","P", "1900110", "130405655", "205523513", ""),
      ("PHA","P", "1900110", "91674414", "205523513", ""),
      ("PHA","P", "1900110", "156615635", "760622487", ""),
      ("PHA","P", "1900110", "131031634", "205523513", ""),
      ("PHA","P", "1900110", "130446942", "760622487", ""),
      ("PHA","P", "2348658", "136851194", "760622487", ""),
      ("PHA","P", "2348658", "136131200", "760622487", ""),
      ("PHA","P", "2348658", "136131061", "760622487", ""),
      ("PHA","O", "2546134", "130382789", "223875437", "033"),
      ("PHA","O", "2546134", "131036608", "223875437", "033"),
      ("PHA","O", "2546134", "130382789", "223875437", "033"),
      ("PHA","O", "2546134", "131036608", "223875437", "033"),
      ("PHA","O", "6311285", "130386029", "760622487", "058"),
      ("PHA","O", "6311285", "130346957", "760622487", "058"),
      ("PHA","O", "6311285", "130138314", "760622487", "058")
    ).toDF("CONTR_OUT_VENDR_CD","CONTR_OUT_PROV_TYP_CD","CONTR_OUT_PROV_ID","CONTR_OUT_CONTR_ID","CONTR_OUT_TAX_ID_NBR","CONTR_OUT_ORG_TYP_CD")
    createOrReplaceTempViewFn(df_CONT,"SELCONT")*/
try{
    Logger.log.info("INFO:: inside CSP")

/*
    val rkpLoc=s"/datalake/uhclakedev/dataplatform/epde/d_datafiles/PHA/GROUP/TIN_FNL_VIEW"
    var rkpDF=context.sparkSession.read.parquet(rkpLoc)
    createOrReplaceTempViewFn(rkpDF,"TIN_FNL_VIEW")
*/

    var resStr="N"

    var df = context.sqlContext.emptyDataFrame
    EPDECommonUtil.generateSegTables(segDtls.segTables,glblVarLst)
    segDtls.segQueries.map { qryKey =>

      if (qryKey.name.equals("CSP_FNL_VIEW")) {
        df = executeQry(varLst, qryKey)
        createOrReplaceTempViewFn(df, qryKey.name)
        //df.show
        FileSystemUtil.saveFileToMapRFSNoRepartitionParquet(df,outputFilePath,qryKey.name,"",DPOConstants.PARQUET)
        //if (df.count > 0) {
          //RPAD QUERY -> result -> write df res in file
         // val actDf = CommonUtil.generateRpadQry(segDtls.segTarCol, segDtls.segTarLen, segDtls.segTolLen, qryKey.name)
         // actDf.show
         // FileSystemUtil.saveFileToMapRFS(actDf,glblVarLst.get("tmpVwPath").getOrElse(workingDir),qryKey.name,"",DPOConstants.TEXT)
          // generateOpFile(actDf, outputFilePath, qryKey.name+"rpad")
          //FileSystemUtil.saveFileToMapRFS(prvDf,outputFilePath,qryKey.name,"",DPOConstants.CSV)
         /* FileSystemUtil.saveFileToMapRFS(df,outputFilePath,qryKey.name,"",DPOConstants.PARQUET)*/
          resStr="Y"
        //}
      }
      else  {
        df = executeQry(varLst, qryKey)
        createOrReplaceTempViewFn(df, qryKey.name)
        //df.show
        //FileSystemUtil.saveFileToMapRFS(df,glblVarLst.get("tmpVwPath").getOrElse(workingDir),qryKey.name,"",DPOConstants.PARQUET)
      }
    }
    resStr
}catch {

  case e: Exception => {
    Logger.log.info(s"RK4 : EPDERK4_CSP_SegExt.genCSPSeg() : "+e.getMessage)
    throw e
  }

}
  }

}
