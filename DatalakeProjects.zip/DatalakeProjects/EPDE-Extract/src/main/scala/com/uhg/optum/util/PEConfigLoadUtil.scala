package com.uhg.optum.util

import com.uhg.optum.common.DPOConstants
import com.uhg.optum.conf.ApplicationConfig.{DSVConfigLocation, hbase_zookeeper_quorum}
import com.uhg.optum.executors.GlobalContext
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.hbase.client.{Admin, ConnectionFactory, Put}
import org.apache.hadoop.hbase.io.ImmutableBytesWritable
import org.apache.hadoop.hbase.mapreduce.TableOutputFormat
import org.apache.hadoop.hbase.util.Bytes
import org.apache.hadoop.hbase.{HColumnDescriptor, HTableDescriptor, TableName}
import org.apache.hadoop.io.{LongWritable, Text}
import org.apache.spark.rdd.RDD

import scala.collection.mutable.ListBuffer
import scala.util.Try

class PEConfigLoadUtil extends Serializable {


  def loadDSVToHbase(tableToLoad: String, dsvFileName: String, tableNameObj: TableName)(implicit globalContext: GlobalContext): Try[Unit] = {

    Try {
      Logger.log.info(s" DSV File location being considered as per properties file  : ${DSVConfigLocation} ")
      //val DSVConfigFullPath = DSVConfigLocation + dsvFileName
      val DSVConfigFullPath = DSVConfigLocation
      Logger.log.info(s" Final DSV path used (including file name) : ${DSVConfigFullPath} ")

      val dsvData = getDsvData(DSVConfigFullPath)
      val dsvHeader = dsvData.first()
      val dsvFileWoHdrRDD = dsvData.
        mapPartitionsWithIndex { (idx, iter) => if (idx == 0) iter.drop(1) else iter }

      val dsvColumns = dsvHeader.split(DPOConstants.DSV_DELIMITER)
      val dsvColBytes = dsvColumns.map(x => Bytes.toBytes(x))


      val rowKeyInd = getRowKeyInd(dsvHeader)
      val transformedRDD = getMassPut(dsvFileWoHdrRDD, tableToLoad, dsvHeader, rowKeyInd)
      val tableDesc = buildTabDesc(tableToLoad, tableNameObj)
      saveDataToHbase(transformedRDD, tableNameObj, tableDesc)
    }
  }

  def getRowKeyInd(dsvHeader: String): ListBuffer[Int] = {
    var rowKeys = ""
    var retRowKeyInds= new ListBuffer[Int]()
    if (dsvHeader.contains(DPOConstants.UNIQUE_PSC_COL)) {
      rowKeys = DPOConstants.PSC_ROW_KEYS
    } else if (dsvHeader.contains(DPOConstants.UNIQUE_PEI_COL)) {
      rowKeys = DPOConstants.PEI_ROW_KEYS
    } else if (dsvHeader.contains(DPOConstants.UNIQUE_PLC_COL)) {
      rowKeys = DPOConstants.PLC_ROW_KEYS
    }
    val dsvHeaderArray = dsvHeader.split(DPOConstants.DSV_DELIMITER)
    rowKeys.split(";").foreach((s: String) => {
      retRowKeyInds += dsvHeaderArray.indexOf(s)
      /*retString = retString+semiColon + dsvHeaderArray.indexOf(s)
      semiColon=";"*/

    })
    retRowKeyInds
  }

  def getDsvData(filePath: String)(implicit globalContext: GlobalContext): RDD[String] = {
    val rdd = globalContext.sparkContext.textFile(DSVConfigLocation)

    rdd
  }

  def getMassPut(dsvFileWoHdrRDD: RDD[String], tableToLoad: String, dsvHeader: String, rowKeyInd: ListBuffer[Int]): RDD[(ImmutableBytesWritable, Put)] = {
    dsvFileWoHdrRDD.map(line => convertToKeyValuePairs(tableToLoad, dsvHeader, line, rowKeyInd))
  }

  def convertToKeyValuePairs(cf: String, dsvHeader: String, line: String, rowKeyInd: ListBuffer[Int]): (ImmutableBytesWritable, Put) = {
    val cfDataBytes = Bytes.toBytes(cf)
    /*val row = getRowkey(line)*/
    val row = getRowKey(line, rowKeyInd)
    val rowkey = row.getBytes()
    val put = new Put(rowkey)

    dsvHeader.split(DPOConstants.DSV_DELIMITER).zipWithIndex.foreach({
      case (dsvHeaderCol, count) =>
        put.addColumn(cfDataBytes, dsvHeaderCol.getBytes(), line.split(DPOConstants.DSV_DELIMITER)(count).getBytes())
    })

    (new ImmutableBytesWritable(rowkey), put)
  }

  def getRowKey(line: String, keyColsInd: ListBuffer[Int]): String = {
    val row = line.split(DPOConstants.DSV_DELIMITER)
    var retStr = ""
    var delimiter = ""
    Logger.log.info(" Row Value : " + row)
    keyColsInd.foreach((r: Int) => {
      retStr = retStr + delimiter + row(r)
      delimiter = "-"
    })
    retStr
  }

  def getRowkey(line: String): String = {
    val row = line.split(DPOConstants.DSV_DELIMITER)
    Logger.log.info(" Row Value : " + row)
    row(0) + "-" + row(1)
  }

  def buildTabDesc(tableToLoad: String, tableNameObj: TableName): HTableDescriptor = {

    val tableDesc = new HTableDescriptor(tableNameObj)
    val idsColumnFamilyDesc = new HColumnDescriptor(Bytes.toBytes(tableToLoad))
    tableDesc.addFamily(idsColumnFamilyDesc)

    tableDesc
  }


  def saveDataToHbase(transformedRDD: RDD[(ImmutableBytesWritable, Put)], tableNameObj: TableName,
                      tableDesc: HTableDescriptor)(implicit globalContext: GlobalContext): Try[Unit] = {

    Try {
      val admin = getConnection(tableNameObj.getNameAsString)

      if (admin.tableExists(tableNameObj)) {
        Logger.log.info(s" HBase table ${tableNameObj.getNameAsString} already exists, hence not creating it")
      } else {
        Logger.log.info(s" HBase table ${tableNameObj.getNameAsString} doesn't exist, hence creating it")
        admin.createTable(tableDesc)
      }

      val jobConf = new Configuration(globalContext.hBaseConf)
      jobConf.set("mapreduce.job.output.key.class", classOf[Text].getName)
      jobConf.set("mapreduce.job.output.value.class", classOf[LongWritable].getName)
      jobConf.set("mapreduce.outputformat.class", classOf[TableOutputFormat[Text]].getName)
      Logger.log.info(" PEI table files getting saved")
      transformedRDD.saveAsNewAPIHadoopDataset(jobConf)
    }
  }

  def getConnection(tableName: String)(implicit globalContext: GlobalContext): Admin = {
    globalContext.hBaseConf.set("hbase.zookeeper.quorum", hbase_zookeeper_quorum)
    globalContext.hBaseConf.set(TableOutputFormat.OUTPUT_TABLE, tableName)
    val connection = ConnectionFactory.createConnection(globalContext.hBaseConf)
    val admin = connection.getAdmin()
    admin
  }
}

