package com.uhg.optum.provider.extractors

import com.uhg.optum.common.DPOConstants
import com.uhg.optum.conf.ApplicationConfig.datafilesDir
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDERK4InputJsonSchema.SegmentDetails
import com.uhg.optum.util.{CommonUtil, EPDECommonUtil, FileSystemUtil, Logger}

trait EPDERK4_TCO_SegExt {
  def tcoSegGen(segDetails: SegmentDetails, outputFilePath: String, glblVarLst: collection.mutable.Map[String, String])(implicit context: GlobalContext): String = {
    try{
    var df=context.sqlContext.emptyDataFrame
    var resStr = "N"
    EPDECommonUtil.generateSegTables(segDetails.segTables, glblVarLst)
    segDetails.segQueries.map { qryKey =>
      Logger.log.info("qryKey.name --> " + qryKey.name)
      if (qryKey.name.trim.equalsIgnoreCase("TCO_FNL_VIEW")) {
        df = CommonUtil.executeQry(glblVarLst, qryKey)
        CommonUtil.createOrReplaceTempViewFn(df, qryKey.name)

        FileSystemUtil.saveFileToMapRFSNoRepartitionParquet( df.dropDuplicates(), outputFilePath, qryKey.name, "", DPOConstants.PARQUET)
        //if (df.count > 0) {
          //df.dropDuplicates()
          datafilesDir+"/"+glblVarLst("${WS_VENDR_CD}")+"/"+glblVarLst("provTypCd")+"/"
          /*FileSystemUtil.saveFileToMapRFS(df, outputFilePath, qryKey.name, "", DPOConstants.PARQUET)*/
          resStr = "Y"
        //}
      }
      else {
        df = CommonUtil.executeQry(glblVarLst, qryKey)
        CommonUtil.createOrReplaceTempViewFn(df, qryKey.name)
      }
    }
    resStr
    }catch {

      case e: Exception => {
        Logger.log.info(s"RK4 : EPDERK4_TCO_SegExt.genTCOSeg() : "+e.getMessage)
        throw e
      }

    }
  }
}
