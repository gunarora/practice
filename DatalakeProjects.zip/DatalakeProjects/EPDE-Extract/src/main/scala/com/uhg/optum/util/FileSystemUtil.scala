package com.uhg.optum.util

import java.io.{File, PrintWriter}
import javax.jws.soap.SOAPBinding.Use

import com.uhg.optum.common.DPOConstants
import com.uhg.optum.common.DPOConstants._
import com.uhg.optum.executors.GlobalContext
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, FileUtil, Path}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.DataFrame

import java.io.{ BufferedInputStream, FileInputStream, FileOutputStream }
import java.util.zip.{ ZipEntry, ZipOutputStream }

/**
  * Created by paror18 on 10/17/2018.
  */
object FileSystemUtil {

  var fsConf = new Configuration()
  var fileSystem = FileSystem.get(fsConf)

  def zipFile(zipFilePath : String,outputFileName : String,entryName : String): Unit ={

    Logger.log.info(s"zipFilePath "+zipFilePath)

    val BUFFER : Int = 4096
    var data = new Array[Byte](BUFFER)

    val zip = new ZipOutputStream(new FileOutputStream(zipFilePath))
    zip.putNextEntry(new ZipEntry(entryName))
    val in = new BufferedInputStream(new FileInputStream(outputFileName),BUFFER)

    var b = in.read(data, 0, BUFFER)

    while (b != -1) {
      zip.write(data, 0, b)
      b = in.read(data, 0, BUFFER)
    }
    in.close()
    zip.closeEntry()
    zip.close()


  }

  /** Purpose : Def to create folder(s)/directories in MapR FileSystem
    * input : path of the folder
    * output: Given folder path should be created in FileSystem */
  def mkdirs(folderPath: String): Unit = {
    try {
      Logger.log.info(s" Created Path : " + folderPath)
      fileSystem.mkdirs(new Path(folderPath))
    } catch {
      case e: Exception => {
        Logger.log.info(" Exception at mkdirs definition : " + e.getStackTrace.toString)
        // Logger.log.error("Error occured : " + e.getStackTrace.mkString("\n"))
      }
        throw e
    }
  }

  /**
    * This method is used to move multiple files from different lcoations to one location.
    * @param provFilesPath
    * @param provTempLoc
    */
  def moveProvsToOneLoc(provFilesPath: Seq[String], provTempLoc: String): Unit = {
    try {
      Logger.log.info(s"moveProvsToOneLoc inititated with values provFilesPath : ${provFilesPath.mkString(DPOConstants.TILDE)} , provTempLoc : $provTempLoc")
      mkdirs(provTempLoc)
      Logger.log.info(s" total number of Prov files : " + provFilesPath.size)
      provFilesPath.foreach(provFilePath => {
        Logger.log.info(s" Source File to move " + provFilePath)
        renamePath(provFilePath, provTempLoc + DPOConstants.SLASH)
      })
      Logger.log.info(s" Multiple ProvExtarcts saved under : " + provTempLoc)
    } catch {
      case e: Exception => {
        Logger.log.info(" Exception at moveProvsToOneLoc definition : " + e.getMessage)
        // Logger.log.error("Error occured : " + e.getStackTrace.mkString("\n"))
      }
        throw e
    }
  }


  /** Purpose : Def to rename  hadoop file path
    * input : filePath
    * output: Returns integer value 0 for successful file renaming , 1 for error */
  def renamePath(srcPath: String, destPath: String): Unit = {
    try {
      println(".............Inside renamePath...........")
      println(".........srcPath, destPath........." + srcPath + " " + destPath)
      if (fileSystem.exists(new Path(s"$srcPath"))) {
        Logger.log.info(s" Renaming/Move from ( $srcPath ) to ( $destPath )")
        var success = fileSystem.rename(new Path(srcPath), new Path(destPath))
        Logger.log.info(s" success flag--( $success )")
      } else {
        Logger.log.info(s" Path : $srcPath doesn't exist, Not proceeding for move/Rename .")
      }
    } catch {
      case e: Exception => Logger.log.info(" Exception at renamePath definition : " + e.getStackTrace.mkString("\n"))
        throw e
    }

  }

  /** Purpose : Def to move  hadoop file from one to another path
    * input : filePath
    * output: Returns integer value 0 for successful file renaming , 1 for error */
  def copyFSFile(srcPath: String, destPath: String): Unit = {
    try {
      Logger.log.info(s" Given srcPath ( $srcPath ) ")
      if (fileSystem.exists(new Path(srcPath))) {
        Logger.log.info(s" Copying from ( $srcPath ) to ( $destPath )")
        FileUtil.copy(fileSystem, new Path(srcPath.replace("/mapr/", "/")), fileSystem, new Path(destPath.replace("/mapr/", "/")), false, fsConf)
        //FileUtil.copy(fileSystem, new Path(srcPath), fileSystem, new Path(destPath), false, fsConf, null)
        //fileSystem.cop(new Path(srcPath),new Path(destPath))
      } else {
        Logger.log.info(s" Path : $srcPath doesn't exist, Not proceeding for Copy .")
      }
    } catch {
      case e: Exception => Logger.log.info(" Exception at renamePath definition : " + e.getStackTrace.mkString("\n"))
        throw e
    }

  }

  /** Purpose : Def to check  hadoop file path
    * input : hadoopFilePath
    * output: Returns Boolean value as 0 if the file is exists else 1 for not exists */
  def filterRawFileExist(filePath: String)(implicit globalContext: GlobalContext): Boolean = {
    try {
      Logger.log.info(s" filterRawFileExist inintiated with argument filepath : $filePath ")
      globalContext.fs.exists(new Path(s"$filePath"))
    } catch {
      case e: Exception => {
        Logger.log.info(" Exception at filterRawFileExist definition : " + e.getMessage)
        //Logger.log.error("Error occured : " + e.getStackTrace.mkString("\n"))
      }
        throw e
    }
  }

  /** Purpose : Def to check directory is empty or not
    * input : filePath
    * output : A boolean flag which is true in case of non-empty dir */
  def isNonEmptyDir(filePath: String): Boolean = {

    try {
      var resFlg = false
      val filePathT = filePath.replace("maprfs://", "/mapr")
      var file = new File(filePathT)
      if (file.isDirectory()) {
        if (file.list().length > 0) {
          Logger.log.info(s" Directory is not empty! " + filePathT);
          resFlg = true
        } else {
          resFlg = false
          Logger.log.info(s" Directory is  empty! " + filePathT);
        }
      } else {
        resFlg = false
        Logger.log.info(s" Not a Directory  " + filePathT);
      }
      resFlg
    } catch {
      case e: Exception => {
        Logger.log.info(" Exception at isNonEmptyDir definition : " + e.getMessage)
        //Logger.log.error("Error occured : " + e.getStackTrace.mkString("\n"))
      }
        throw e
    }
  }

  /** Purpose : Def to merge hadoop files
    * input : sourceFilesPath, destinationFilePath
    * output: Returns Boolean value as 0 if the merge is success else 1 for error */
  def merge(srcPath: String, dstPath: String)(implicit globalContext: GlobalContext): Boolean = {
    try {
      Logger.log.info(s" merge inintiated with srcPath : $srcPath & dstPath : $dstPath ")
      val hdfs = FileSystem.get(globalContext.sparkContext.hadoopConfiguration)
      FileUtil.copyMerge(hdfs, new Path(srcPath), hdfs, new Path(dstPath), false, globalContext.sparkContext.hadoopConfiguration, null)
    } catch {
      case e: Exception => {
        Logger.log.info(" Exception at merge definition : " + e.getMessage)
        // Logger.log.error("Error occured : " + e.getStackTrace.mkString("\n"))
      }
        throw e
    }
  }

  /** Purpose : Def to check given hadoop file path exists or not
    * input : filePath
    * output: Returns integer value 0 for file exists, 1 for not exists */
  // Fix : use existing def filterRawFileExist
  def fileExists(filePath: String): Boolean = {

    try {
      Logger.log.info(s" Path Existence Check for : " + filePath)
      fileSystem.exists(new Path(filePath))

    } catch {
      case e: Exception => {
        Logger.log.info("Exception at fileExists definition : " + e.getMessage)
        // Logger.log.error("Error occured : " + e.getStackTrace.mkString("\n"))
      }
        throw e
    }
  }

  /** Purpose : Def to remove hadoop directory if exists
    * input : hadoopDirectoryPath
    * output: Returns Boolean value as 0 if the file is exists else 1 for not exists */
  //Fix : not used anywhere, later we can use this instead of commandline commands
  def rmPathIfExist(path: String): Unit = {
    try {
      Logger.log.info("---Inside rmPathIfExist---"+path+"    "+fileSystem.getScheme)
      //   println("------"+"    "+fileSystem.exists(new Path(path))+"  ")
      if (fileSystem.exists(new Path((path.replace("/mapr/", "/"))))) {
        // if (fileSystem.exists(new Path((path)))) {
        Logger.log.info(s" Deleted intermediate file/dir : " + path)
        fileSystem.delete(new Path(path.replace("/mapr/", "/")), true)
        //  fileSystem.deleteOnExit(new Path(path))
      } else {
        Logger.log.info(s" Path: $path doesn't exist, Not proceeding for removing.")
      }
    } catch {
      case e: Exception => Logger.log.info(" RK4 : FileSystemUtil.rmPathIfExist: " + e.getMessage)
        throw e
    }
  }

  /** Purpose : Def to get the list of directories from MapR FileSystem
    * input : path of the folder
    * output: Returns List which includes the list of directories present in the given path */
  def getListOfFiles(dir: String): List[File] = {
    try {
      val d = new File(dir)
      if (d.exists && d.isDirectory) {
        d.listFiles.toList
      } else {
        List[File]()
      }
    } catch {
      case e: Exception => {
        Logger.log.info(" Exception while executing getListOfFiles : " + e.getMessage)
        //Logger.log.error("Error occured : " + e.getStackTrace.mkString("\n"))
      }
        throw e
    }
  }
  /** Purpose : Def to save Dataframe to resultant location, Also renaming the outfile with given name instead of part-00000
    * input : DataFrame, outputLocation, outputFileName
    * output: Output file should be created in specified location with specified filename */
  def saveFileToMapRFS(finalDF: DataFrame, outFileLoc: String, outFileName: String, outFileColDelim: String, typeOfFile: String)(implicit context: GlobalContext): Long = {
    println(".............Inside saveFileToMapRFS.............")

    try {
      FileSystemUtil.rmPathIfExist(outFileLoc + DPOConstants.SLASH + outFileName)
      val outLoc = outFileLoc.replace("/mapr/", "/")
      val outLocTemp = outFileLoc.replace("/mapr/", "/")+"/"+outFileName+"_temp"
      mkdirs(outLocTemp)
      finalDF.dropDuplicates()
      Logger.log.debug(s" Saving DF to /mapr$outLoc/$outFileName")
      var savedFileName = ""
      typeOfFile match{
        case DPOConstants.TEXT => {
          finalDF.rdd.map(rec => rec.mkString(outFileColDelim)).repartition(1).saveAsTextFile(outLocTemp)
          savedFileName = FileSystemUtil.fileSystem.globStatus(new Path(outLocTemp + "/p*"))(0).getPath.getName
        }
        case DPOConstants.CSV => {
          mkdirs(outLocTemp)
          finalDF.repartition(1).write.mode("overwrite").option("delimiter", outFileColDelim).option("quote","\u0000").csv(outLocTemp)
          savedFileName = fileSystem.globStatus(new Path(outLocTemp + "/*.csv"))(0).getPath.getName
        }
        case DPOConstants.PARQUET => {
          mkdirs(outLocTemp)
          finalDF.repartition(1).write.mode("overwrite").format("parquet").save(outLocTemp)
          savedFileName = fileSystem.globStatus(new Path(outLocTemp + "/*.parquet"))(0).getPath.getName
        }
      }
      Logger.log.debug(s" DF file Name before renaming " + savedFileName)
      renamePath(outLocTemp + DPOConstants.SLASH + savedFileName, outLoc + DPOConstants.SLASH + outFileName)
      Logger.log.debug(s" Renamed DF part output to  $outLoc/$outFileName")
      //rmPathIfExist(outLoc + "/_SUCCESS")
      rmPathIfExist(outLocTemp)
      //FileSystemUtil.getHDFSFileRecCount(outLoc + "/" + outFileName)
      0
    }
    catch {
      case e: Exception => {
        Logger.log.info("RK4 : FileSystemUtil.saveFileToMapRFS() "+e.getMessage)
        throw e
      }

    }
  }

  def saveFileToMapRFS_noDrop(finalDF: DataFrame, outFileLoc: String, outFileName: String, outFileColDelim: String, typeOfFile: String)(implicit context: GlobalContext): Long = {
    println(".............Inside saveFileToMapRFS.............")

    try {
      FileSystemUtil.rmPathIfExist(outFileLoc + DPOConstants.SLASH + outFileName)
      val outLoc = outFileLoc.replace("/mapr/", "/")
      val outLocTemp = outFileLoc.replace("/mapr/", "/")+"/"+outFileName+"_temp"
      mkdirs(outLocTemp)
      //finalDF.dropDuplicates()  // commenting out so that duplicates remain intact in the final file/view
      Logger.log.debug(s" Saving DF to /mapr$outLoc/$outFileName")
      var savedFileName = ""
      typeOfFile match{
        case DPOConstants.TEXT => {
          finalDF.rdd.map(rec => rec.mkString(outFileColDelim)).repartition(1).saveAsTextFile(outLocTemp)
          savedFileName = FileSystemUtil.fileSystem.globStatus(new Path(outLocTemp + "/p*"))(0).getPath.getName
        }
        case DPOConstants.CSV => {
          mkdirs(outLocTemp)
          finalDF.repartition(1).write.mode("overwrite").option("delimiter", outFileColDelim).option("quote","\u0000").csv(outLocTemp)
          savedFileName = fileSystem.globStatus(new Path(outLocTemp + "/*.csv"))(0).getPath.getName
        }
        case DPOConstants.PARQUET => {
          mkdirs(outLocTemp)
          finalDF.repartition(1).write.mode("overwrite").format("parquet").save(outLocTemp)
          savedFileName = fileSystem.globStatus(new Path(outLocTemp + "/*.parquet"))(0).getPath.getName
        }
      }
      Logger.log.debug(s" DF file Name before renaming " + savedFileName)
      renamePath(outLocTemp + DPOConstants.SLASH + savedFileName, outLoc + DPOConstants.SLASH + outFileName)
      Logger.log.debug(s" Renamed DF part output to  $outLoc/$outFileName")
      //rmPathIfExist(outLoc + "/_SUCCESS")
      rmPathIfExist(outLocTemp)
      //FileSystemUtil.getHDFSFileRecCount(outLoc + "/" + outFileName)
      0
    }
    catch {
      case e: Exception => {
        Logger.log.info("RK4 : FileSystemUtil.saveFileToMapRFS() "+e.getMessage)
        throw e
      }

    }
  }
  /** Purpose : Def to get file name dynamically saved by spark context
    * input : Directory path
    * output : file name
    */
  def getSavedFileName(outFileLoc: String): String = {
    val savedFileName = fileSystem.globStatus(new Path(outFileLoc + "/p*"))(0).getPath.getName
    savedFileName
  }

  /*
      get the total number of lines present in a file
 */
  def getHDFSFileRecCount(dataFilePath: String)(implicit context: GlobalContext): Long = {
    try {
      val dataPath = dataFilePath.replaceAll("/mapr/datalake", "/datalake")
      //TODO: Make it run locally.
      val totalRecords = context.sparkContext.textFile(dataPath).count()
      //val totalRecords = scala.io.Source.fromFile(dataPath).getLines.size
      totalRecords
    } catch {
      case e: Exception => {
        Logger.log.info(" RK4 : FileSystemUtil.getHDFSFileRecCount : Exception at getTotalLines definition : " + e.getMessage)
      }
        throw e
    }
  }

  /** Purpose : Def to save Dataframe to resultant location with default files part-00000
    * input : DataFrame, outputLocation
    * output: Output file should be created in specified location */
  def saveDFOutputToMapR(diffRec: DataFrame, outFileLoc: String): Unit = {
    try {
      Logger.log.info(s" saveDFOutputToMapR inintiated with input arguments -> diffRec : $diffRec , outFileLoc : $outFileLoc ")
      val outLoc = outFileLoc.replace("/mapr/", "/")
      mkdirs(outLoc)
      Logger.log.info(s" OutputLocation is : ${outLoc}  ")
      diffRec.repartition(1).write.mode("overwrite").csv(outLoc)
    } catch {
      case e: Exception => {
        Logger.log.info(" Exception at saveDFOutputToMapR definition : " + e.getMessage)
        // Logger.log.error("Error occured : " + e.getStackTrace.mkString("\n"))
      }
        throw e
    }
  }

  /** Purpose : Def to merge files in MapR FileSystem to one file in particular location
    * input :  provFilesPath
    * output: number of provisioned files should be merged to one file extract location in FileSystem */

  def mergeToOneFile(srcPath: String, dstPath: String): Unit = {
    try {
      println(".............Inside mergeToOneFile.............")
      Logger.log.info(s"mergeToOneFile inititated with values srcPath : $srcPath ,  dstPath : $dstPath")
      Logger.log.info(s" Files copied to ( " + dstPath + " ) one location  ");
      FileUtil.copyMerge(fileSystem, new Path(srcPath), fileSystem, new Path(dstPath), false, fsConf, null)
      Logger.log.info(s" Files copied to ( " + dstPath + " ) one location  ");
    } catch {
      case e: Exception => {
        Logger.log.info(" Exception at mergeToOneFile definition : " + e.getMessage)
        // Logger.log.error("Error occured : " + e.getStackTrace.mkString("\n"))
      }
        throw e
    }
  }

  /**
    * This method is used to remove files from MaprFS from a particular location
    * @param filePath
    * @param fileNames
    */

  def removeFilesfromMaprFS(filePath: String, fileNames: Seq[String]):Unit = {
    try{
      fileNames.foreach(fileName => {
        Logger.log.info(s" Source File to remove ${fileName}" )
        rmPathIfExist(filePath + DPOConstants.SLASH + fileName)
      })
    }catch {
      case e: Exception => {
        Logger.log.info(" Exception at removeSpecFiles definition : " + e.getMessage)
        // Logger.log.error("Error occured : " + e.getStackTrace.mkString("\n"))
      }
        throw e
    }
  }

  //  /** Purpose : Def to remove files in MapR FileSystem from particular location
  //    * input :   specified filenames separated by ;
  //    * output: specified files should be removed from FileSystem */
  //  def removeSpecFiles(provFilesPath: String, fileNames: String): Unit = {
  //    try {
  //      Logger.log.info(s"removeSpecFiles inititated with values provFilesPath : $provFilesPath ,  fileNames : $fileNames")
  //      val totalFiles = fileNames.split(';')
  //      Logger.log.info(s" total number of Prov files : " + totalFilePaths)
  //      totalFiles.foreach(fileName => {
  //        Logger.log.info(s" Source File to remove ${fileName}" )
  //        rmPathIfExist(provFilesPath + DPOConstants.SLASH + fileName)
  //      }
  //      )
  ////
  ////      var i = 1;
  ////      val n = totalFilePaths;
  ////      for (i <- 1 to n) {
  ////        Logger.log.info(s" Source File to remove " + fileNames.split(';')(i - 1))
  ////        rmPathIfExist(provFilesPath + "/" + fileNames.split(';')(i - 1))
  ////      }
  //      Logger.log.info(s" Removed Successfully")
  //    } catch {
  //      case e: Exception => {
  //        Logger.log.info(" Exception at removeSpecFiles definition : " + e.getMessage)
  //        Logger.log.error("Error occured : " + e.getStackTrace.mkString("\n"))
  //      }
  //        throw e
  //    }
  //  }

  /** Purpose : Def to create file in MapR FileSystem
    * input : path , content of the file
    * output: Given file should be created in FileSystem */
  def createHDFSFile(filePath: String, content: String) {
    try {
      Logger.log.info(s"createHDFSFile inititated with values filePath : $filePath , content : $content")
      Logger.log.info(s" Trying to write to HDFS...")
      val output = fileSystem.create(new Path(filePath))
      val writer = new PrintWriter(output)
      try {
        writer.write(content)
      }
      finally {
        writer.close()
        Logger.log.info(s" Writer Closed..")
      }
    } catch {
      case e: Exception => {
        Logger.log.info(" Exception at createHDFSFile definition : " + e.getMessage)
        Logger.log.error("Error occured : " + e.getStackTrace.mkString("\n"))
      }
        throw e
    }
  }

  def readFileFromMapRFS(filePath: String)(implicit globalContext: GlobalContext) : RDD[String] = {
    try{
      val fileRDD = globalContext.sparkContext.textFile(filePath)
      fileRDD
    } catch {
      case e: Exception => {
        Logger.log.info(" Exception at readFileFromMapRFS definition : " + e.getMessage)
        Logger.log.error(DPOConstants.ERROR_OCCURRED + DPOConstants.COLON  + e.getStackTrace.mkString(DPOConstants.NEWLINECHAR))
      }
        throw e
    }

  }

  /** Purpose : Def to save Dataframe to resultant location, Also renaming the outfile with given name instead of part-00000
    * input : DataFrame, outputLocation, outputFileName
    * output: Output file should be created in specified location with specified filename */
  def saveFileToMapRFSWithoutShuffle(finalDF: DataFrame, outFileLoc: String, outFileName: String, outFileColDelim: String, typeOfFile: String)(implicit context: GlobalContext): Long = {
    //println(".............Inside saveFileToMapRFS.............")
    try {
      Logger.log.info(s" .............Inside saveFileToMapRFS.............")
      FileSystemUtil.rmPathIfExist(outFileLoc + DPOConstants.SLASH)
      val outLoc = outFileLoc.replace("/mapr/", "/")
      val outLocTemp = outFileLoc.replace("/mapr/", "/") + "/" + outFileName + "_temp"
      // mkdirs(outLoc)
      finalDF.dropDuplicates()
      Logger.log.debug(s" Saving DF to /mapr$outLoc/$outFileName")
      var savedFileName = ""
      typeOfFile match {
        case DPOConstants.TEXT => {
          // finalDF.rdd.map(rec => rec.mkString(outFileColDelim)).repartition(1).saveAsTextFile(outLocTemp)
          finalDF.rdd.map(rec => rec.mkString(outFileColDelim)).coalesce(1, false).saveAsTextFile(outLocTemp)
          savedFileName = FileSystemUtil.fileSystem.globStatus(new Path(outLocTemp + "/p*"))(0).getPath.getName
        }
      }
      Logger.log.debug(s" DF file Name before renaming " + savedFileName)
      renamePath(outLocTemp + DPOConstants.SLASH + savedFileName, outLoc + DPOConstants.SLASH + outFileName)
      Logger.log.debug(s" Renamed DF part output to  $outLoc/$outFileName")
      //rmPathIfExist(outLoc + "/_SUCCESS")
      rmPathIfExist(outLocTemp)
      FileSystemUtil.getHDFSFileRecCount(outLoc + "/" + outFileName)
    } catch {
      case e: Exception => {
        Logger.log.info("RK4 : FileSystemUtil.saveFileToMapRFSWithoutShuffle() "+e.getMessage)
        throw e
      }

    }
  }

  def moveFile(currentPath:String,desiredPath:String)(implicit context: GlobalContext):Unit= {
    import org.apache.hadoop.fs._;
    Logger.log.info("Move file from "+currentPath+ " to "+desiredPath)
    val fs = FileSystem.get(context.sparkContext.hadoopConfiguration)
    val file = fs.globStatus(new Path(currentPath+"/part*"))(0).getPath().getName()
    fs.rename(new Path(currentPath+"/"+file), new Path(desiredPath))
    Logger.log.info("Moved file from "+currentPath+"/"+file+ "to "+desiredPath)
  }
  def isNotEmptyDirMaprfs(filePath: String): Boolean = {
    if (fileSystem.exists(new Path(filePath)) && fileSystem.isDirectory(new Path(filePath))) {
      Logger.log.info(s"$filePath is a directory")
      if(fileSystem.listStatus(new Path(filePath)).length > 0 ) true else false
    }else {
      Logger.log.info(s"$filePath is not a directory")
      false
    }
  }
  /** Purpose : Def to save Dataframe to resultant location, Also renaming the outfile with given name instead of part-00000
    * input : DataFrame, outputLocation, outputFileName
    * output: Output file should be created in specified location with specified filename */
  def saveFileToMapRFSNoRepartitionParquet(finalDF: DataFrame, outFileLoc: String, outFileName: String, outFileColDelim: String, typeOfFile: String)(implicit context: GlobalContext): Long = {
    println(".............Inside saveFileToMapRFSNoRepartitionParquet.............")

    try {
      FileSystemUtil.rmPathIfExist(outFileLoc + DPOConstants.SLASH + outFileName)
      val outLoc = outFileLoc.replace("/mapr/", "/")
      finalDF.dropDuplicates()
      Logger.log.debug(s" Saving DF to /mapr$outLoc/$outFileName")
      typeOfFile match{
         case DPOConstants.PARQUET => {
          rmPathIfExist(outLoc+"/"+outFileName)
          mkdirs(outLoc)
          //finalDF.write.format("parquet").save(outLoc+"/"+outFileName)
           finalDF.write.parquet(outLoc+"/"+outFileName)
        }
      }
      0
    }
    catch {
      case e: Exception => {
        Logger.log.info("RK4 : FileSystemUtil.saveFileToMapRFSNoRepartitionParquet() "+e.getMessage)
        throw e
      }

    }
  }

  def saveFileToMapRFS_noDropNoRepartitionParquet(finalDF: DataFrame, outFileLoc: String, outFileName: String, outFileColDelim: String, typeOfFile: String)(implicit context: GlobalContext): Long = {
    println(".............Inside saveFileToMapRFS_noDropNoRepartitionParquet.............")

    try {
      FileSystemUtil.rmPathIfExist(outFileLoc + DPOConstants.SLASH + outFileName)
      val outLoc = outFileLoc.replace("/mapr/", "/")
      Logger.log.debug(s" Saving DF to /mapr$outLoc/$outFileName")
      typeOfFile match{
        case DPOConstants.PARQUET => {
          rmPathIfExist(outLoc+"/"+outFileName)
          mkdirs(outLoc)
          //finalDF.write.format("parquet").save(outLoc+"/"+outFileName)
          finalDF.write.parquet(outLoc+"/"+outFileName)
        }
      }
      0
    }
    catch {
      case e: Exception => {
        Logger.log.info("RK4 : FileSystemUtil.saveFileToMapRFS_noDropNoRepartitionParquet() "+e.getMessage)
        throw e
      }

    }
  }
}
