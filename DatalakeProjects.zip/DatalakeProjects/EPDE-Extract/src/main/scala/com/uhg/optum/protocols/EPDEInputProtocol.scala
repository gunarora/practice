package com.uhg.optum.protocols

import java.util.Optional

import com.uhg.optum.protocols.EPDEInputJsonSchema._


import spray.json._

object EPDEInputJsonSchema {
  type Queries = Seq[Query]

  case class Query(name: String, query: String)

  case class FeedDetails (
                   feedName: String,
                   extraction: Seq[ExtractFileEntity]
                 )

  case class ExtractFileEntity(
                                programName: String,
                                entityList:String,
                                isOutputMerge: String,
                                isSchemaChange: String,
                                extractHeaderTrailerRequired: String,
                                inputFileDetails: Seq[InputFileDetails],
                                commonQueries: Option[Queries],
                                extractDetails: Seq[ExtractDetail]



                  )

  case class InputFileDetails(
                               inputFileColumns: String,
                               inputFileDataTypeLength: String,
                               isInputFileRowDelimited: String,
                               inputFileRowDelimiter: String,
                               isInputFileFixedWidth: String,
                               isInputFileColumnDelimited: String,
                               inputFileColumnDelimiter: String,
                               isInputFileValidationRequired: String,
                               inputFileValidationRules: Seq[InputFileValidationRule]
                             )

  case class InputFileValidationRule(
                                      inputHeaderValidationRule: String,
                                      inputDataValidationRule: String,
                                      inputTrailerValidationRule: String
                                    )

  case class ExtractDetail(
                            provNo: String,
                            provName: String,
                            provHeaderDesc: String,
                            provHeaderDateFormat: String,
                            provTrailerDesc: String,
                            provOutFileColDelim: String,
                            provTrgColumn: String,
                            provTrgDataTypeLen: String,
                            provDataQueries: Queries,
                            commonQueries: Seq[QueryDetail],
                            providerQueries: Seq[QueryDetail],
                            contractQueries: Seq[QueryDetail]
                          )

  case class QueryDetail(
                        headerDesc: String,
                        headerDateFormat: String,
                        trailerDesc: String,
                        outFileColDelim: String,
                        trgColumn: String,
                        trgDataTypeLen: String,
                        queries: Map[String,String]
                        )

  case class EPDEInputExtractInfo(items: Array[FeedDetails]) extends IndexedSeq[FeedDetails] {
    def apply(index: Int) = items(index)

    def length = items.length
  }

}

object EPDEInputProtocol extends DefaultJsonProtocol {

  implicit object EPDEInputExtractInfoJsonFormat extends RootJsonFormat[EPDEInputExtractInfo] {
    def read(value: JsValue) = EPDEInputExtractInfo(value.convertTo[Array[FeedDetails]])
    def write(f: EPDEInputExtractInfo) = JsArray(f.toJson)
  }

    implicit val query = jsonFormat2(Query)
    implicit val queryDetail = jsonFormat7(QueryDetail)
    implicit val extractDetail = jsonFormat12(ExtractDetail)
    implicit val inputFileValidationRule = jsonFormat3(InputFileValidationRule)
    implicit val inputFile = jsonFormat9(InputFileDetails)
    implicit val extract = jsonFormat8(ExtractFileEntity)
    implicit val feed = jsonFormat2(FeedDetails)


}