package com.uhg.optum.dao

import com.uhg.optum.JobRunner.CustomFilter
import com.uhg.optum.common.{BaseRepository, BaseRepositoryManager, DAOModel}
import com.uhg.optum.util.{CommonUtil, Logger}
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.hbase.{HBaseConfiguration, TableName}
import org.apache.hadoop.hbase.client._
import org.apache.hadoop.hbase.filter.CompareFilter.CompareOp
import org.apache.hadoop.hbase.filter._
import org.apache.hadoop.hbase.mapreduce.TableInputFormat
import org.apache.hadoop.hbase.util.Bytes

import scala.util.{Failure, Success, Try}
import com.uhg.optum.conf.ApplicationConfig._
import com.uhg.optum.executors.GlobalContext
import org.apache.hadoop.hbase.filter.CompareFilter.CompareOp
import org.apache.hadoop.hbase.filter._
import org.apache.spark.rdd.RDD

import scala.collection.JavaConversions.seqAsJavaList

/**
  *
  * @param result
  * @param colFamily
  */
class HbaseDAOModel(val result: Result, val colFamily: String) extends DAOModel {

}

/**
  * Created by paror18 on 9/16/2018.
  */
trait HbaseRepositoryManager extends BaseRepositoryManager {

  def getRepository(tableName: String): HbaseRepository = {
    val hBaseConf: Configuration = HBaseConfiguration.create()
    hBaseConf.set(TableInputFormat.INPUT_TABLE, tableName)
    val hbaseTab: HTable = new HTable(hBaseConf, tableName) //TODO: Replace with new API
    new HbaseRepository(hbaseTab)
  }

  def closeRepository(repo: BaseRepository) : Unit = {
    repo.close()
  }


  class HbaseRepository(htable: HTable) extends BaseRepository {

    //TODO: Check if all can be put into try catch

    def getValueByRowKey(rowKey: String, colFm: String, colNm: String): String = {
      val g = new Get(Bytes.toBytes(rowKey));
      val result = htable.get(g)
      Bytes.toString(result.getValue(Bytes.toBytes(colFm.toString), Bytes.toBytes(colNm.toString)));
    }


    def get(rowKey: String, colFm: String): Try[HbaseDAOModel] = {
      //var resDef = new HbaseDAOModel(new Result, colFm)
      Try {
        val g = new Get(Bytes.toBytes(rowKey))
        val result = htable.get(g)
        var resDef= new HbaseDAOModel(result, colFm)
        resDef
        // added for excpetion Handling -I - starts
      } match {
        case Success(resDef) => {
          Logger.log.info("HbaseRepositoryManager.get : Success")
          Success(resDef)
        }
        case Failure(ex) => {
          Logger.log.info("HbaseRepositoryManager.get : " + ex.getMessage)
          throw ex
        }
        // added for excpetion Handling -I - ends
      }
    }

    def getWithFilter(rowKey: String, colFm: String, filters: CustomFilter*): Option[HbaseDAOModel] = {
      val get = new Get(Bytes.toBytes(rowKey))
      val hbaseFilters = for(filter <- filters) yield {
        val compareOperator = filter.compareOp.toString
        new SingleColumnValueFilter(Bytes.toBytes(filter.colFm),
          Bytes.toBytes(filter.colValue), CompareOp.valueOf(compareOperator), Bytes.toBytes(filter.valueToBeCompared))
      }
      get.setFilter(new FilterList(FilterList.Operator.MUST_PASS_ALL, hbaseFilters: _*))
      val result = htable.get(get)
      Some(new HbaseDAOModel(result, colFm))
    }

    def put(rowKey: String, colFm: String, colNm: String, value: String): Unit = {
      try {
        val p = new Put(s"$rowKey".getBytes())
        p.addColumn(s"$colFm".getBytes(), s"$colNm".getBytes(), s"$value".getBytes())
        htable.put(p)
        Logger.log.debug(s" Updating $htable table for the column : $colNm as Registered , " +
          s"cf : $colFm, RowKey : $rowKey ")
      } catch {
        case e: Exception => Logger.log.info(s" Exception at HBase Put Commands at hTable : $htable :" + e.getStackTrace.mkString("\n"))
          throw e
      }
    }

    def put(values: Tuple4[String, String, String, String]*): Try[Unit] = {
      import scala.collection.JavaConversions._
      Try {
        val puts = values.map { v =>
          val p = new Put(s"$v._1".getBytes())
          p.addColumn(s"$v._2".getBytes(), s"$v._3".getBytes(), s"$v._4".getBytes())
        }
        htable.put(puts)
      }
        // added for excpetion Handling -I - starts
      match {
        case Success(instance) => {
          Logger.log.info("HbaseRepositoryManager.put : Success")
          Success()
        }
        case Failure(ex) => {
          Logger.log.info("HbaseRepositoryManager.put : " + ex.getMessage)
          throw ex
        }
      }
      // added for excpetion Handling -I - ends
    }

    //    def scan[T](filters: Filter*)(implicit marshal: (Result) => T): Try[Seq[T]] = {
    //      Try {
    //        val scanner = new Scan().setCaching(1000).setCacheBlocks(false)
    //        //val filter1 = new RowFilter(CompareOp.EQUAL, new BinaryComparator(Bytes.toBytes(s"$rowKeyConfig")))
    //        //val filter2 = new SingleColumnValueFilter(Bytes.toBytes("psc"), Bytes.toBytes("activeflag"), CompareOp.EQUAL, Bytes.toBytes("Y"));
    //        scanner.setFilter(new FilterList(FilterList.Operator.MUST_PASS_ALL, filters: _*))
    //        val resultScanner = htable.getScanner(scanner)
    //        import scala.collection.JavaConverters._
    //        resultScanner.asScala.map(marshal(_)).toSeq
    //      }
    //    }


    def close(): Unit = {
      htable.close()
    }
  }


}
