package com.uhg.optum.provider

import com.uhg.optum.JobRunner.PEI
import com.uhg.optum.common.EPDEBaseExtractor
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDEInputJsonSchema._
import com.uhg.optum.provider.extractors.{EPDEJsonSourceExtractor, MetaSourceExtractor}
import com.uhg.optum.provider.output.OuptutGenerator
import com.uhg.optum.util.Logger
import com.uhg.optum.util.exceptions.{QueryFailureException, VendorSetupException}

import scala.util.{Failure, Success, Try}

/**
  * Created by paror18 on 10/19/2018.
  */
class EPDEExtractProvider extends EPDEBaseExtractor with EPDEJsonSourceExtractor with MetaSourceExtractor with OuptutGenerator{

  override def extractEPDE( jsonFile: Option[ExtractFileEntity], pitRowKey: String,fullFileParam:String,peiRowKey: String)(implicit context: GlobalContext,pei:PEI): Try[Tuple2[String,String]] = {
    Try {
      var outExtractor=""
      val extractDF = jsonFile match {

        case Some(inputEntity) => {
//          generateExtractFromJson(pei: PEI, inputEntity: ExtractFileEntity)
          //try {
            outExtractor = generateExtractFromJson(inputEntity: ExtractFileEntity, fullFileParam: String, peiRowKey)
          /*}catch {
              case v: VendorSetupException => {
                Logger.log.info("RKP: Extract Provider: " + v.getMessage)
                Logger.log.error("Error occured : " + v.getStackTrace.mkString("\n"))
                throw v
              }
              case e: Exception => {
                Logger.log.error("Error occured : " + e.getStackTrace.mkString("\n"))
                //throw e
              }
              //throw e
            }*/
        }
        case None => generateExtractFromMetaData(pei: PEI)
      }

      //val outputFilePath = generateOpFile(extractDF)
    /*  val metaFilePath = createMetaFile

      (outputFilePath, metaFilePath)*/
      (outExtractor,"")
    } match {
      case Success(outExtractor) => Logger.log.info("Success")
        Success(outExtractor)
      case Failure(ex: VendorSetupException) => {
        Logger.log.error("RKP: Extract Provider: " + ex.getMessage)
        //Logger.log.error("Error occured  ")
        throw ex
      }
      case Failure(ex: QueryFailureException) => {
        Logger.log.error("RKP: Extract Provider: " + ex.getMessage)
        //Logger.log.error("Error occured ")
        throw ex
      }
      case Failure(ex) => {
        Logger.log.error("RKP: Extract Provider: " + ex.getMessage)
        //Logger.log.error("Error occured ")
        throw ex
    }
    }
  }
}
