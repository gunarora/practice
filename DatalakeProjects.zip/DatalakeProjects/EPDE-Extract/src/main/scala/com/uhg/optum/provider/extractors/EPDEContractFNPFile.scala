package com.uhg.optum.provider.extractors

import java.text.SimpleDateFormat

import com.uhg.optum.JobRunner.PEI
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDEInputJsonSchema.ExtractFileEntity
import org.apache.spark.sql.DataFrame
import com.uhg.optum.util.{EPDECommonUtil, Logger}

import scala.util.{Failure, Success, Try}

trait EPDEContractFNPFile {

  /**
    *
    * @param df6
    * @param df7
    * @param df19
    * @param lastRunPlc
    * @param fullFileInd
    * @param contQuery
    * @param vendor_cd
    * @param context
    * @return Dataframe
    */
  def common4000ExportProcess(df6: DataFrame, df7: DataFrame, df19: DataFrame, lastRunPlc: String, fullFileInd: String, contQuery: Map[String, String], vendor_cd: String)(implicit context: GlobalContext, pei: PEI): DataFrame = {
    //val commQuery = inputEntity.extractDetails.head.commonQueries.head.queries
    //val contQuery = inputEntity.extractDetails.head.contractQueries.head.queries
    Logger.log.info(s"Started common4000ExportProcess RKP")
    try {
      var df20, df_all_inc_exc, df_all_inc, dfout, df_all_inc_exc_final = context.sqlContext.emptyDataFrame
      df19.createOrReplaceTempView("df19_query")
      if (fullFileInd.equals("F")) {
        df20 = EPDECommonUtil.getDataframe(contQuery, "df_20Full_query", "$vendor_cd", vendor_cd: String, lastRunPlc).get
        Logger.log.info(s"Full file query executed for Contract")
      } else {
        df20 = EPDECommonUtil.getDataframe(contQuery, "df_20_query", "$vendor_cd", vendor_cd: String, lastRunPlc).get
        Logger.log.info(s"No Full or Partial file query executed for Contract")
      }
      df20.createOrReplaceTempView("df_20_query")
      df6.createOrReplaceTempView("df6_query")
      df_all_inc = EPDECommonUtil.getDataframe(contQuery, "df_all_inc", "$vendor_cd", vendor_cd: String, lastRunPlc).get
      df_all_inc.createOrReplaceTempView("df_all_inc")
      Logger.log.info(s"Include load query executed for Contract")
      dfout = df_all_inc
      if (!fullFileInd.equals("P") && df7.count() != 0) {
        df7.createOrReplaceTempView("df7_query")
        df_all_inc_exc = EPDECommonUtil.getDataframe(contQuery, "df_all_inc_exc", "$vendor_cd", vendor_cd: String, lastRunPlc).get
        df_all_inc_exc.createOrReplaceTempView("df_all_inc_exc")
        df_all_inc_exc_final = EPDECommonUtil.getDataframe(contQuery, "df_all_inc_exc_final", "$vendor_cd", vendor_cd: String, lastRunPlc).get
        dfout = df_all_inc_exc_final.dropDuplicates
        Logger.log.info(s"Exclude load query executed for Contract")
      }
      Logger.log.info(s"End common4000ExportProcess RKP")
      dfout
    }catch{
      case e: Exception => {
        Logger.log.error("RKP : EPDEContractFNPFile.common4000ExportProcess() "+e.getMessage )
        throw e
      }
    }
  }

  /**
    *
    * @param dfin
    * @param contQuery
    * @param vendor_cd
    * @param context
    * @return Dataframe
    */
  def common2250ExportProcess(dfin: DataFrame, contQuery: Map[String, String], vendor_cd: String,lastRunPlc: String)(implicit context: GlobalContext, pei: PEI): Try[DataFrame] = {
    Try {
      Logger.log.info(s"Started common2250ExportProcess RKP")
      var df_20_newContracts, df_20_ActContracts, df_20_TermContracts, df_20_VendorChg, df20_skip1, contract_df = context.sqlContext.emptyDataFrame
      dfin.createOrReplaceTempView("df_20_query_2250")
      df_20_newContracts = EPDECommonUtil.getDataframe(contQuery, "df_20_newContracts", "$vendor_cd", vendor_cd,lastRunPlc).get
      df_20_ActContracts=EPDECommonUtil.getDataframe(contQuery, "df_20_ActContracts", "$vendor_cd", vendor_cd,lastRunPlc).get
      df_20_TermContracts=EPDECommonUtil.getDataframe(contQuery, "df_20_TermContracts", "$vendor_cd", vendor_cd,lastRunPlc).get
      df_20_VendorChg = EPDECommonUtil.getDataframe(contQuery, "df_20_VendorChg", "$vendor_cd", vendor_cd,lastRunPlc).get

      df_20_newContracts.dropDuplicates.createOrReplaceTempView("df_20_newContracts")
      df_20_ActContracts.dropDuplicates.createOrReplaceTempView("df_20_ActContracts")
      df_20_TermContracts.dropDuplicates.createOrReplaceTempView("df_20_TermContracts")
      df_20_VendorChg.dropDuplicates.createOrReplaceTempView("df_20_VendorChg")
      df20_skip1 = EPDECommonUtil.getDataframe(contQuery, "df20_skip1", "$vendor_cd", vendor_cd,lastRunPlc).get

      df20_skip1.dropDuplicates.createOrReplaceTempView("df20_skip1")
      contract_df = EPDECommonUtil.getDataframe(contQuery, "contract_df", "$vendor_cd", vendor_cd,lastRunPlc).get.dropDuplicates
      Logger.log.info(s"End common2250ExportProcess RKP")
      contract_df
    }match {
      case Success(contract_df) => Logger.log.info("common2250ExportProcess: Success")
        Success(contract_df)
      case Failure(ex) => {
        Logger.log.info("RKP: EPDEContractFNPFile: common2250ExportProcess " + ex.getMessage)
        Logger.log.error("Error occured : " + ex.getStackTrace.mkString("\n"))
        throw ex
      }
    }
  }
}
