package com.uhg.optum.provider.extractors

import com.uhg.optum.common.DPOConstants
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDERK4InputJsonSchema.{ExtractFileEntity, SegmentDetails}
import com.uhg.optum.provider.output.OuptutGenerator
import com.uhg.optum.util.CommonUtil._
import com.uhg.optum.util.{EPDECommonUtil, FileSystemUtil, Logger}
import com.uhg.optum.conf.ApplicationConfig.{schema, workingDir}

import scala.util.{Failure, Success, Try}

trait EPDERK4_SCO_SegExt extends OuptutGenerator{

  def genSCOSeg(segDtls: SegmentDetails,glblVarLst:collection.mutable.Map[String, String],SW_SKIP_SCO: String,outputFilePath:String)(implicit context: GlobalContext): Try[String]= {
    Logger.log.info("....Inside scoSegGen()......")

    Try {
      var df = context.sqlContext.emptyDataFrame
      var retStr = "N"

      if(segDtls.equals("") || segDtls == null){
        Logger.log.info("No segment details present for SCO Segment")
      }

      if(!context.sparkSession.catalog.tableExists("PSP_FINAL_VIEW")){
        Logger.log.info("The temporary view PSP_FINAL_VIEW from PSP segment is required for SCO segment")
      }


      if (SW_SKIP_SCO.equals("N")) {
        if (segDtls.segName.equals("SCO")) {
          EPDECommonUtil.generateSegTables(segDtls.segTables,glblVarLst)
          Logger.log.info("Inside SCO")
          segDtls.segQueries.map { qryKey =>
            Logger.log.info("qryKey.name --> " + qryKey.name)

            if (qryKey.name.matches("SCO_FNL_VIEW")) {
              Logger.log.info("Inside SCO_FNL_VIEW")
              df=executeQry(glblVarLst,qryKey)
              createOrReplaceTempViewFn(df, qryKey.name)
              // Logger.log.info(".........count SCO_FNL_VIEW.........." + df.count)
              //  if (df.count > 0) {
              FileSystemUtil.saveFileToMapRFSNoRepartitionParquet(df.dropDuplicates(),outputFilePath,qryKey.name,"",DPOConstants.PARQUET)
              retStr = "Y"

              /*}  else {
                Logger.log.info("3060A-DB ERROR FETCHING SCO_CUR")
                Logger.log.info("INFO : SCO Final View count is  zero")
              }
*/
            }
            else{ df = executeQry(glblVarLst, qryKey)
              createOrReplaceTempViewFn(df, qryKey.name)
              /// df.show()
              //FileSystemUtil.saveFileToMapRFS(df,glblVarLst.get("tmpVwPath").getOrElse(workingDir),qryKey.name,"",DPOConstants.PARQUET)
              retStr
            }
          }
        }else{
          retStr
        }


      }else{
        Logger.log.info("SCO Segment skipped...")
        retStr
      }
      retStr
    }
    match {
      case Success(retStr) => {
        Logger.log.info("RK4 : EPDERK4_SCO_SegExt.genSCOSeg(): Success")
        Success(retStr)
      }
      case Failure(ex) => {
        Logger.log.info(s"RK4 : EPDERK4_SCO_SegExt.genSCOSeg() : " + ex.getMessage)
        throw ex
      }
    }
  }

}
