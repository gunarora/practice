package com.uhg.optum.provider.extractors

import java.util.Calendar

import com.uhg.optum.JobRunner.PEI
import com.uhg.optum.common.DPOConstants
import com.uhg.optum.conf.ApplicationConfig.inboxDir
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDEInputJsonSchema.ExtractFileEntity
import com.uhg.optum.provider.DefaultExtractProvider
import com.uhg.optum.provider.validators.PreExtractValidator
import com.uhg.optum.util.exceptions.{QueryFailureException, VendorSetupException}
import com.uhg.optum.util.{CommonUtil, EPDECommonUtil, FileSystemUtil, Logger}
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, FileUtil, Path}
import org.apache.spark.sql.DataFrame
/**
  * Created by paror18 on 10/19/2018.
  */
trait EPDEJsonSourceExtractor extends EPDECommonFNPFile with EPDEContractFNPFile {
  /**
    *
    * @param pei
    * @param inputEntity
    * @param fullFileParam
    * @param peiRowKey
    * @param context
    * @return status
    */

  def generateExtractFromJson(inputEntity: ExtractFileEntity, fullFileParam: String, peiRowKey: String)(implicit context: GlobalContext, pei: PEI): String = {

    //Read key,value pairs from JSON

    try {
      com.uhg.optum.util.Logger.log.info("===> Strarting RKP Program <===")
      val vendorCode = pei.consumingApp.trim.toUpperCase
      val vendor_cd_folder = peiRowKey.split("-")(1).toString
      Logger.log.info(s"====> Vendor code for RKP process: $vendorCode <======")
      Logger.log.info(s"====> Vendor code for RKP process dir creation: $vendor_cd_folder <======")
      val today = Calendar.getInstance()
      val currWeekOfMonth = today.get(Calendar.WEEK_OF_MONTH)
      val currDayOfWeek = today.get(Calendar.DAY_OF_WEEK)
      val lastRunPlc = CommonUtil.fetchPLCLastRunDt("EPDE-" + vendorCode)
      //val lastRunPlc="2019-04-01"
      val fullFileParamInd = fullFileParam
      var non_par_ind = "N"
      var df6, df7, df9, df9_skip3, df15_1, df15_2, df15_3, df_16, df_17, dfFNPall, df19, df22, df20, df9N22_skip4 = context.sqlContext.emptyDataFrame
      val commQuery = EPDECommonUtil.getCommonQueriesDetails(inputEntity).get.head.queries

      // TR1 and TR2 for vendor setup error check
      val start = preExtractValidate(inputEntity, vendorCode, commQuery, lastRunPlc: String)
      if (!start) {
        com.uhg.optum.util.Logger.log.info("RKP: JsonExtractor: Exit due to vendor setup error")
        throw new VendorSetupException("Vendor Setup Error: Inactive vendor through TR1 or TR2")
        // System.exit(0)
      }
      // TR3 for finding participation of a vendor
      val nonParFlag = PreExtractValidator.validate(commQuery, "df3_query", "$vendor_cd", vendorCode: String, lastRunPlc: String).get
      Logger.log.info("RKP: JsonExtractor: nonParFlag: " + nonParFlag)
      if (nonParFlag) {
        non_par_ind = "Y"
      }
      Logger.log.info(s"RKP: JsonExtractor: non_par_ind: $non_par_ind")
      // TR4 Facility file should generate or not
      val facilityFlag_typ = PreExtractValidator.validate(commQuery, "df4_query", "$vendor_cd", vendorCode: String, lastRunPlc: String).get
      Logger.log.info("RKP: JsonExtractor: facilityFlag_typ: " + facilityFlag_typ)
      var facilityFlag = "Y"
      if (facilityFlag_typ) {
        facilityFlag = "N"
      }
      Logger.log.info(s"RKP: JsonExtractor: facilityFlag: $facilityFlag")
      // TR5 to know full,no full or partial file in full file indicator
      var fullFileInd = fullFileParamInd
      Logger.log.info(s"RKP: JsonExtractor: fullFileInd by property: "+fullFileInd)
      if (!fullFileParamInd.equals("F")) {
        fullFileInd = PreExtractValidator.checkFullFileIndicator(commQuery, vendorCode, currDayOfWeek, currWeekOfMonth, lastRunPlc: String).get
      }
      Logger.log.info(s"RKP: JsonExtractor: fullFileInd to be set: $fullFileInd")
      //vendor setup error for invalid return of full file ind
      if (fullFileInd.equals("V")) {
        throw new VendorSetupException("Vendor Setup Error: Invalid FullFileInd")
      }

      val contQueries = EPDECommonUtil.getContractQueriesDetails(inputEntity).get.head.queries
      // TR6 to create internal include table
      df6 = EPDECommonUtil.loadIncludeTable(contQueries: Map[String, String], vendorCode: String, inputEntity: ExtractFileEntity, lastRunPlc: String)

      var critInd = "N"
      if (fullFileInd != 'P') {
        // TR7 to create internal exclude table
        df7 = EPDECommonUtil.loadExcludeTable(contQueries: Map[String, String], vendorCode: String, inputEntity: ExtractFileEntity, lastRunPlc: String)
        // TR8 to get criteria indicator flag
        critInd = PreExtractValidator.getCriteriaIndicator(commQuery, "df8_query", "$vendor_cd", vendorCode, lastRunPlc: String)
      }
      Logger.log.info(s"RKP: JsonExtractor: critInd: ${critInd}")
      if (fullFileInd.equalsIgnoreCase("F") || fullFileInd.equalsIgnoreCase("P")) {
        // TR9 Get all valid prov_ids for full and partial file
        df9 = EPDECommonUtil.getDataframe(commQuery, "df9_query", "$vendor_cd", vendorCode: String, lastRunPlc: String).get
        df9.persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)
        // Process 2200 Calling for skipping few prov_ids
        df9_skip3 = common2200ExportProcess(df9, lastRunPlc, critInd, commQuery, vendorCode)
        df9.createOrReplaceTempView("df9_query")
        df9_skip3.createOrReplaceTempView("df9_skip3")
        df9_skip3.persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)
        dfFNPall = EPDECommonUtil.getDataframe(commQuery, "df9_FP", "$vendor_cd", vendorCode: String, lastRunPlc: String).get
      } else {
        // TR22 to get prov_ids and update table type for no full file
        df22 = EPDECommonUtil.getTempView(commQuery, "df22_query", "$vendor_cd", vendorCode, lastRunPlc: String)
        // FileSystemUtil.saveFileToMapRFS(df22.dropDuplicates(),inboxDir+"/"+vendorCode,"DF22All","",DPOConstants.PARQUET)
        // Step to get unique first prov_id on the basis of asc ordering after union from all tables
        val df22_unique_provs = EPDECommonUtil.getTempView(commQuery, "df22_unique_provs", "$vendor_cd", vendorCode, lastRunPlc: String)
        //FileSystemUtil.saveFileToMapRFS(df22_unique_provs.dropDuplicates(),inboxDir+"/"+vendorCode,"DF22NF","",DPOConstants.PARQUET)
        //df22_unique_provs.persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)
        //df22_unique_provs.createOrReplaceTempView("df22_unique_provs")
        //if (df22_unique_provs.count() > 0) {
          Logger.log.info("RKP: JsonExtractor: 2200Export Process for No Full")
          // Process 2200 Calling for skipping few prov_ids
          val df22_out: DataFrame = common2200ExportProcess(df22_unique_provs, lastRunPlc: String, critInd, commQuery, vendorCode)
          //df22_out.persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)
          df22_out.createOrReplaceTempView("df22_out")
          // TR15_1 for update table type CRED for skipping few prov_ids
          df15_1 = EPDECommonUtil.getTempView(commQuery, "df15_1_query", "$vendor_cd", vendorCode, lastRunPlc: String)
          // TR15_2 for update table type TRAN or PDE for skipping few prov_ids
          df15_2 = EPDECommonUtil.getTempView(commQuery, "df15_2_query", "$vendor_cd", vendorCode, lastRunPlc: String)
          df15_3 = EPDECommonUtil.getTempView(commQuery, "df15_3_query", "$vendor_cd", vendorCode, lastRunPlc: String)
          // TR16 to get
          df_16 = EPDECommonUtil.getTempView(commQuery, "df16_query", "$vendor_cd", vendorCode, lastRunPlc: String)
          // TR 17 for update table type TRAN or PDE for skipping few prov_ids
          df_17 = EPDECommonUtil.getTempView(commQuery, "df15_2_17_query", "$vendor_cd", vendorCode, lastRunPlc: String)
          val df22_skip1 = EPDECommonUtil.getDataframe(commQuery, "df22_query_skip1", "$vendor_cd", vendorCode, lastRunPlc: String).get
          //df22_skip1.persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)
          df22_skip1.createOrReplaceTempView("df22_query_skip1")
      //  }
        dfFNPall = EPDECommonUtil.getDataframe(commQuery, "df18_query", "$vendor_cd", vendorCode, lastRunPlc: String).get
        //Logger.log.info(s"Going to save dfFNPall")
        //FileSystemUtil.saveFileToMapRFS(dfFNPall.dropDuplicates(), inboxDir + "/" + vendor_cd_folder,"DF18NF","",DPOConstants.PARQUET)
      }
      //dfFNPall.persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)
      dfFNPall.createOrReplaceTempView("df18FNPAll")
      //If facility not required then skip those prov_ids
      if (facilityFlag.equals("N")) {
        dfFNPall = EPDECommonUtil.getDataframe(commQuery, "df_skip_fac", "$vendor_cd", vendorCode, lastRunPlc: String).get
      }
      //FileSystemUtil.saveFileToMapRFS(dfFNPall.dropDuplicates(),pei.inputFileLocation+"/"+vendorCode,"DF18FP","",DPOConstants.PARQUET)
      dfFNPall.createOrReplaceTempView("df18FNPAll")
      df19 = EPDECommonUtil.getDataframe(contQueries, "df19_query", "$vendor_cd", vendorCode, lastRunPlc: String).get.dropDuplicates
      //df19.persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)
      //Logger.log.info(s"df19 count:" + df19.count())
      //df19.show(50,false)
      df19.createOrReplaceTempView("df19_query")
      df20 = common4000ExportProcess(df6, df7, df19, lastRunPlc: String, fullFileInd, contQueries, vendorCode)
      //df20.persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)
      df20.createOrReplaceTempView("df_20_query_2250")
      //Logger.log.info("RKP: JsonExtractor: Saving df_20_con dataframe for no full")
      //FileSystemUtil.saveFileToMapRFS(df20.dropDuplicates(),inboxDir + "/" + vendor_cd_folder,"df_20_con","",DPOConstants.PARQUET)
      val df_20_newContracts = EPDECommonUtil.getDataframe(contQueries, "df_20_newContracts", "$vendor_cd", vendorCode, lastRunPlc: String).get
      val df_20_ActContracts = EPDECommonUtil.getDataframe(contQueries, "df_20_ActContracts", "$vendor_cd", vendorCode, lastRunPlc: String).get
      df_20_ActContracts.createOrReplaceTempView("df_20_ActContracts")
      //FileSystemUtil.saveFileToMapRFS(df_20_ActContracts.dropDuplicates(),pei.inputFileLocation+"/"+vendorCode,"df_20_ActContracts","",DPOConstants.PARQUET)
      val df_20_TermContracts = EPDECommonUtil.getDataframe(contQueries, "df_20_TermContracts", "$vendor_cd", vendorCode, lastRunPlc: String).get
      df_20_TermContracts.createOrReplaceTempView("df_20_TermContracts")
      val df_20_VendorChg = EPDECommonUtil.getDataframe(contQueries, "df_20_VendorChg", "$vendor_cd", vendorCode, lastRunPlc: String).get

      //Contract file creation
      val contractDf = common2250ExportProcess(df20, contQueries, vendorCode, lastRunPlc: String).get
      contractDf.printSchema()
      dfFNPall.createOrReplaceTempView("df9N22_skip3")
      val provQuery = inputEntity.extractDetails.head.providerQueries.head.queries
      val df_newProvs = EPDECommonUtil.getDataframe(provQuery, "df_newProvs", "$vendor_cd", vendorCode, lastRunPlc: String).get
      val df_actProvs = EPDECommonUtil.getDataframe(provQuery, "df_actProvs", "$vendor_cd", vendorCode, lastRunPlc: String).get
      val df_noChgProvs = EPDECommonUtil.getDataframe(provQuery, "df_noChgProvs", "$vendor_cd", vendorCode, lastRunPlc: String).get
      val df_termProvs = EPDECommonUtil.getDataframe(provQuery, "df_termProvs", "$vendor_cd", vendorCode, lastRunPlc: String).get
      df19.createOrReplaceTempView("df19_query")
      contractDf.persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)
      //Logger.log.info("contract_cnt: " + contractDf.count())
      contractDf.createOrReplaceTempView("contract_df")
      val df_allProviders = EPDECommonUtil.getDataframe(provQuery, "df_allProviders", "$vendor_cd", vendorCode, "$non_par_ind", non_par_ind, lastRunPlc: String).get.dropDuplicates
      df_allProviders.createOrReplaceTempView("df_allProviders")
      df_allProviders.persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)
      //Logger.log.info(s"df_allProviders count::: ${df_allProviders.count()}")
      df_16.createOrReplaceTempView("df16_query")
      df_20_newContracts.createOrReplaceTempView("df_20_newContracts")
      df_20_VendorChg.createOrReplaceTempView("df_20_VendorChg")

      var pre_provider_df = df_allProviders
      //Logger.log.info(s"pre_provider_df count1:: ${pre_provider_df.count()}")
      var skip1, skip_prov_df = context.sqlContext.emptyDataFrame
      if (!fullFileInd.equals("F")) {
        df9N22_skip4 = pre_provider_df
        if (!fullFileInd.equals("P")) {
          skip1 = EPDECommonUtil.getDataframe(provQuery, "skip1", "$vendor_cd", vendorCode, lastRunPlc: String).get
          skip1.createOrReplaceTempView("skip1")
          skip_prov_df = EPDECommonUtil.getDataframe(provQuery, "skip_prov_df", "$vendor_cd", vendorCode, lastRunPlc: String).get
          skip_prov_df.createOrReplaceTempView("skip_prov_df")
          df9N22_skip4 = EPDECommonUtil.getDataframe(provQuery, "df9N22_skip4", "$vendor_cd", vendorCode, lastRunPlc: String).get
        }
        //FileSystemUtil.saveFileToMapRFS(df9N22_skip4.dropDuplicates(),pei.inputFileLocation+"/"+vendorCode,"DFlastSkipNF","",DPOConstants.PARQUET)
        df9N22_skip4.createOrReplaceTempView("df9N22_skip4")
        //Logger.log.info(s"df9N22_skip4 counts:: ${df9N22_skip4.count()}")
        df_newProvs.createOrReplaceTempView("df_newProvs")
        val upd_NP_new_prov = EPDECommonUtil.getDataframe(provQuery, "upd_NP_new_prov", "$vendor_cd", vendorCode, "$non_par_ind", non_par_ind, lastRunPlc).get
        df_actProvs.createOrReplaceTempView("df_actProvs")
        val upd_NP_act_prov = EPDECommonUtil.getDataframe(provQuery, "upd_NP_act_prov", "$vendor_cd", vendorCode, "$non_par_ind", non_par_ind, lastRunPlc).get
        df_termProvs.createOrReplaceTempView("df_termProvs")
        df_noChgProvs.createOrReplaceTempView("df_noChgProvs")
        val upd_NP_term_prov = EPDECommonUtil.getDataframe(provQuery, "upd_NP_term_prov", "$vendor_cd", vendorCode, "$non_par_ind", non_par_ind, lastRunPlc).get

        upd_NP_new_prov.createOrReplaceTempView("upd_NP_new_prov")
        upd_NP_act_prov.createOrReplaceTempView("upd_NP_act_prov")
        upd_NP_term_prov.createOrReplaceTempView("upd_NP_term_prov")

        val update_typ_set1 = EPDECommonUtil.getDataframe(provQuery, "update_typ_set1", "$vendor_cd", vendorCode, lastRunPlc).get
        update_typ_set1.createOrReplaceTempView("update_typ_set1")
        df_20_newContracts.createOrReplaceTempView("df_20_newContracts")
        df_20_ActContracts.createOrReplaceTempView("df_20_ActContracts")
        df_20_TermContracts.createOrReplaceTempView("df_20_TermContracts")
        val upd_NP_nat_con = EPDECommonUtil.getDataframe(provQuery, "upd_NP_nat_con", "$vendor_cd", vendorCode, lastRunPlc).get.dropDuplicates()
        upd_NP_nat_con.createOrReplaceTempView("upd_NP_nat_con")
        val upd_NP_new_con = EPDECommonUtil.getDataframe(provQuery, "upd_NP_new_con", "$vendor_cd", vendorCode, lastRunPlc: String).get
        val upd_NP_at_con = EPDECommonUtil.getDataframe(provQuery, "upd_NP_at_con", "$vendor_cd", vendorCode, lastRunPlc: String).get.dropDuplicates
        upd_NP_at_con.createOrReplaceTempView("upd_NP_at_con")
        val upd_NP_act_con = EPDECommonUtil.getDataframe(provQuery, "upd_NP_act_con", "$vendor_cd", vendorCode, lastRunPlc: String).get

        val upd_NP_term_con = EPDECommonUtil.getDataframe(provQuery, "upd_NP_term_con", "$vendor_cd", vendorCode, lastRunPlc: String).get

        upd_NP_new_con.createOrReplaceTempView("upd_NP_new_con")
        upd_NP_act_con.createOrReplaceTempView("upd_NP_act_con")
        upd_NP_term_con.createOrReplaceTempView("upd_NP_term_con")
        //val df_upd_typ_all = EPDECommonUtil.getDataframe(provQuery, "df_upd_typ_all", "$vendor_cd", vendorCode, lastRunPlc: String).get
        //df_upd_typ_all.createOrReplaceTempView("df_upd_typ_all")
       // val df_upd_typ_all_unique = EPDECommonUtil.getDataframe(provQuery, "df_upd_typ_all_unique", "$vendor_cd", vendorCode, lastRunPlc: String).get
        //df_upd_typ_all_unique.dropDuplicates().createOrReplaceTempView("df_upd_typ_all_unique")
        //Logger.log.info(s"df_upd_typ_all_unique count::: ${df_upd_typ_all_unique.count()}")
        pre_provider_df = EPDECommonUtil.getDataframe(provQuery, "pre_provider_df", "$vendor_cd", vendorCode, lastRunPlc: String).get.dropDuplicates()
      }
      var vendorCodeTemp = vendorCode
      Logger.log.info(s"Temp vendor Code setting: ${vendorCodeTemp}")
      if (vendorCode.equals("OHBS")) {
        Logger.log.info("OHBS converted to UBH for query excution")
        vendorCodeTemp = "UBH"
      }
      //pre_provider_df.persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)
      Logger.log.info("Going to drop duplicate from pre_provider_df")
      pre_provider_df.createOrReplaceTempView("pre_provider_df")
      //Logger.log.info(s"Done drop duplicate from pre_provider_df now count: ${pre_provider_df.count()}")
      val df21_query = EPDECommonUtil.getDataframe(provQuery, "df21_query", "$vendor_cd", vendorCodeTemp, lastRunPlc: String).get
      df21_query.createOrReplaceTempView("df21_query")
      var provider_df = context.sqlContext.emptyDataFrame
      if (fullFileInd.equalsIgnoreCase("F")) {
        provider_df = EPDECommonUtil.getDataframe(provQuery, "provider_df_full", "$vendor_cd", vendorCode, lastRunPlc: String).get
      } else {
        provider_df = EPDECommonUtil.getDataframe(provQuery, "provider_df", "$vendor_cd", vendorCode, lastRunPlc: String).get
      }
      provider_df.printSchema()
      //Logger.log.info(s"provider_df count final: ${provider_df.count()}")
      //provider_df.take(1)
      val defaultExtProv = new DefaultExtractProvider()
      //provider_df.persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)
      //Saving file as text Code to be commented
      //val provNContExtractOutput = defaultExtProv.generateJsonExtract(provider_df, contractDf, inputEntity.extractDetails.head, "EPDE-" + vendor_cd_folder + "-xyzw")
      //Saving file as Parquet
      //provider_df.repartition(1).write.mode("overwrite").format("parquet").save(pei.inputFileLocation+"/provider.parquet")
      //contractDf.repartition(1).write.mode("overwrite").format("parquet").save(pei.inputFileLocation+"/contract.parquet")

      FileSystemUtil.saveFileToMapRFSNoRepartitionParquet(provider_df.dropDuplicates(), inboxDir + "/" + vendor_cd_folder, "Provider", "", DPOConstants.PARQUET)
      FileSystemUtil.saveFileToMapRFSNoRepartitionParquet(contractDf.dropDuplicates(), inboxDir + "/" + vendor_cd_folder, "Contract", "", DPOConstants.PARQUET)

      // println("Provider File   @ "+provNContExtractOutput.outLoc+"/"+provNContExtractOutput.provFileName)
      //println("Contract File   @ "+provNContExtractOutput.outLoc+"/"+provNContExtractOutput.contFileName)
      /*if (fileSystem.exists(new Path((inboxDir+"/"+vendor_cd_folder,"Provider".replace("/mapr/", "/"))))) {
      "Done"
    } else {
      "Error"
    }*/
      "Done"
    }
    catch {
      case v: VendorSetupException => {
        Logger.log.error("RKP: JsonSourceExtractor")
        throw v
      }
      case q: QueryFailureException => {
        Logger.log.error("RKP: JsonSourceExtractor")
        throw q
      }
      case e: Exception => {
        Logger.log.info("RKP: EPDEJsonSourceExtractor" + e.printStackTrace())
        Logger.log.error("............Error occured : .............. " + e.getStackTrace.mkString("\n"))
        throw e
      }
      //throw e
    }

  }

  /**
    *
    * @param inputEntity
    * @param vendorCode
    * @param commQuery
    * @param context
    * @return status
    */

  private def preExtractValidate(inputEntity: ExtractFileEntity, vendorCode: String, commQuery: Map[String, String],lastRunPlc:String)(implicit context: GlobalContext,pei:PEI) = {
    try{
      var start = true
      val isVenActive = PreExtractValidator.validate(commQuery, "df1_query", "$vendor_cd", vendorCode: String,lastRunPlc:String).get
      Logger.log.info(s"RKP: JSONExtractor: preExtractValidate: isVenActive   " + isVenActive)
      if (!isVenActive) {
        start = false
      }
      val isEPDEFunction = PreExtractValidator.validate(commQuery, "df2_query", "$vendor_cd", vendorCode: String,lastRunPlc:String).get
      Logger.log.info(s"RKP: JSONExtractor: preExtractValidate: " + isEPDEFunction)
      if (!isEPDEFunction) {
        start = false
      }
      start
    } catch{
      case e: Exception => {
        Logger.log.error("EPDEJsonSourceExtractor: preExtractValidate " + e.getMessage)
        throw e
      }
    }
  }
}
