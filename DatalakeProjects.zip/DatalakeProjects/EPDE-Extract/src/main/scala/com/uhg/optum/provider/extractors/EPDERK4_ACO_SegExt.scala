package com.uhg.optum.provider.extractors


import com.uhg.optum.common.DPOConstants
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDERK4InputJsonSchema.{ExtractFileEntity, SegmentDetails}
import com.uhg.optum.provider.output.OuptutGenerator
import com.uhg.optum.util.CommonUtil._
import com.uhg.optum.util.{EPDECommonUtil, FileSystemUtil, Logger}
import com.uhg.optum.conf.ApplicationConfig.workingDir

import scala.util.{Failure, Success, Try}

trait EPDERK4_ACO_SegExt extends OuptutGenerator{

  def genACOSeg(segDtls: SegmentDetails,glblVarLst:collection.mutable.Map[String, String],SW_SKIP_ACO : String, outputFilePath: String)(implicit context: GlobalContext): Try[String] = {
    Logger.log.info("Inside acoSegGen...")
    Logger.log.info("Initializing variables...")
    //var acoStr = ""
    /*
        import context.sparkSession.implicits._
        var addDF1 = context.sparkContext.parallelize(Seq((108,114642,109626092,"L"))).toDF("OUT_ADD_PROV_ID", "OUT_ADD_ADR_ID_9", "TAX_ID_NBR", "OUT_ADD_TYP_CD")
        var addDF2 = context.sparkContext.parallelize(Seq((1055718,1192522,741796484,"L"))).toDF("OUT_ADD_PROV_ID", "OUT_ADD_ADR_ID_9", "TAX_ID_NBR", "OUT_ADD_TYP_CD")

        var addDF = addDF1.union(addDF2)
        addDF.createOrReplaceTempView("ADD_FINAL_QRY")

        Logger.log.info("---Registered ADD_FINAL_QRY ----")
        //TODO::To be removed this declaration
        var WS_PREV_RUN_DT_YMD = "99991231"
     //   var WS_PREV_RUN_DT_YMD = glblVarLst.get("WS_PREV_RUN_DT_YMD")*/

    var df = context.sqlContext.emptyDataFrame
    var retStr = "N"
    Try {
      if(segDtls.equals("") || segDtls == null){
        Logger.log.info("No segment details present for ACO Segment")
      }
      if(!context.sparkSession.catalog.tableExists("ADD_FINAL_QRY")){
        Logger.log.info("The temporary view ADD_FINAL_QRY from ADD segment is required for ACO segment")
      }

      if (SW_SKIP_ACO.equals("N")) {
        var SchemaNm=DPOConstants.SCHEMA
        if (segDtls.segName.equals("ACO")) {
          EPDECommonUtil.generateSegTables(segDtls.segTables,glblVarLst)
          var segNm = segDtls.segName
          var seg_Seq = segDtls.segSeq
          Logger.log.info("Inside ACO")
          //Iterate over all the segment keys one by one
          segDtls.segQueries.map { qryKey =>
            if (qryKey.name.matches("ACO_FNL_VIEW")) {
              try {
                Logger.log.info("Inside ACO_FNL_VIEW")
                /*var qryStr = qryKey.query.replace("${SchemaNm}", SchemaNm).replace("${WS_PREV_RUN_DT_YMD}", WS_PREV_RUN_DT_YMD)
                 df = context.sqlContext.sql(qryStr)*/
                df=executeQry(glblVarLst,qryKey)
                createOrReplaceTempViewFn(df, qryKey.name)
                /*Logger.log.info("ACO_FNL_VIEW Query --> " + qryKey.query)*/
                Logger.log.info("ACO_FNL_VIEW")
                // df.show
                FileSystemUtil.saveFileToMapRFSNoRepartitionParquet(df,outputFilePath,qryKey.name,"",DPOConstants.PARQUET)
                //Logger.log.info("df.count --> " + df.count)
                //if (df.count > 0) {
                  /*FileSystemUtil.saveFileToMapRFS(df.dropDuplicates(),outputFilePath,qryKey.name,"",DPOConstants.PARQUET)*/
                  retStr = "Y"
                //}
              } catch {
                case e: Exception => {
                  Logger.log.info("'DB2 ERROR ON SELECT ACO_FNL_VIEW SQLCODE'")
                }
              }
            } else {
              Logger.log.info("No query key matches ACO_FNL_VIEW ")
              df = executeQry(glblVarLst, qryKey)
              createOrReplaceTempViewFn(df, qryKey.name)
         //     FileSystemUtil.saveFileToMapRFS(df,glblVarLst.get("tmpVwPath").getOrElse(workingDir),qryKey.name,"",DPOConstants.PARQUET)
            }
          }
        }else{
          retStr
        }

      } else {
        Logger.log.info("ACO Segment skipped...")
        retStr
      }
      retStr
    }    match {
      case Success(retStr) => {
        Logger.log.info("RK4 : EPDERK4_ACO_SegExt.genACOSeg(): Success")
        Success(retStr)
      }
      case Failure(ex) => {
        Logger.log.info(s"RK4 : EPDERK4_ACO_SegExt.genACOSeg() : " + ex.getMessage)
        throw ex
      }
    }
  }


}
