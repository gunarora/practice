package com.uhg.optum.common

import com.uhg.optum.common.Job.JobFailedException
import com.uhg.optum.conf.ApplicationConfig._
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.util._

import scala.util.{Failure, Success, Try}

/**
  * Created by paror18 on 9/16/2018.
  */

object Job {

  case class JobFailedException(msg: String, throwable: Throwable) extends Exception(msg, throwable)

}


trait Job {
  val pitRowKey = s"${this.jobName}-${java.util.UUID.randomUUID.toString}"

  def jobName: String

  def start()(implicit context: GlobalContext): Unit = {
    val startTm = CommonUtil.getCurrentTimeFormat
    val jobResult = preStart().recover {
      case th: Throwable => throw JobFailedException("Job Failed in pre-start stage", th)
    }.flatMap(_ =>
      postStart().recover {
        case th: Throwable => throw JobFailedException("Job Failed in post-start stage", th)
      }.flatMap(_ =>
        run().recover {
          case th: Throwable => throw JobFailedException("Job Failed in run stage", th)
        }
      ))

    jobResult match {
      case Success(result) =>
        Logger.log.info("PE Extraction Process Successfully Executed")
      //We will be updating PIT table accordingly here
      case Failure(ex) => {
        Try {
          val provEndTs = CommonUtil.getCurrentTimeFormat
          val duration = CommonUtil.getDuration(provEndTs, startTm)
          Logger.log.error("PE Extraction Job Failed!!", ex)
          context.pitTable.put(pitRowKey, "exi", "provEndTs", provEndTs)
          context.pitTable.put(pitRowKey, "exi", "provCompSts", "fail")
        } match {
          case Success(result) => Logger.log.error("Job Terminated Succesfully.")
          case Failure(ex) =>
            Logger.log.error("Failed to terminate the job succesfully", ex)
        }
        throw ex // added for excpetion Handling -I - starts
      }
      //closeRepository(context.pitTable) TODO:Close all repositories
    }
  }

  def postStart()(implicit context: GlobalContext): Try[Unit] = {
    Try(Nil)
  }


  def preStart()(implicit context: GlobalContext): Try[Unit]  = {
    Try {
      Logger.log.info("=============> Updating PIT table before hitting to PEI & Snapshot Config table in Hbase <=============")
      val prcStTm = CommonUtil.getCurrentTimeFormat

      context.pitTable.put(pitRowKey, "exi", "provCompSts", "registered")
      context.pitTable.put(pitRowKey, "exi", "provStrTs", prcStTm)
      context.pitTable.put(pitRowKey, "exi", "provExecTrkId", pitRowKey)
      context.pitTable.put(pitRowKey, "fi", "dataownr", dataownr)
    }
        // added for excpetion Handling -I - starts
    match{
      case Success(instance) =>
        Logger.log.info("Job.preStart : Success")
        Success()
      case Failure(ex) =>
        Logger.log.info("Job.preStart : "+ex.getMessage)
        //Logger.log.error("RK4 : HbaseRepositoryManager: Error occurred : " + ex.getStackTrace.mkString("\n"))
        throw ex
    }
    // added for excpetion Handling -I - ends
  }

  def run(): Try[Unit] = {
    Try(Nil)
  }

}
