package com.uhg.optum.common

import com.uhg.optum.JobRunner.PEI
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDEInputJsonSchema
import com.uhg.optum.protocols.EPDEInputJsonSchema.{EPDEInputExtractInfo, ExtractFileEntity}

import com.uhg.optum.provider.DefaultExtractProvider.ExtractOutput

import scala.util.Try

/**
  * Created by paror18 on 10/19/2018.
  */
trait BaseExtractor {

 // def extract(pei: PEI,jsonFile: Option[ExtractFileEntity], pitRowKey: String)(implicit context: GlobalContext): Try[Tuple2[String,String]]
 def extract(jsonFile: Option[ExtractFileEntity], pitRowKey: String): ExtractOutput



}
