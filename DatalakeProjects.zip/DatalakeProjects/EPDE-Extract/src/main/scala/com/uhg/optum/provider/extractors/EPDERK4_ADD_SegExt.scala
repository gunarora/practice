package com.uhg.optum.provider.extractors

import com.uhg.optum.common.DPOConstants
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDERK4InputJsonSchema.SegmentDetails
import com.uhg.optum.provider.output.OuptutGenerator
import com.uhg.optum.util.CommonUtil._
import com.uhg.optum.util.{EPDECommonUtil, FileSystemUtil, Logger}
import org.apache.spark.sql.DataFrame

import scala.util.Try

trait EPDERK4_ADD_SegExt extends OuptutGenerator{
  def genADDSeg(segDtls: SegmentDetails, glblVarLst:scala.collection.mutable.Map[String,String],SW_SKIP_ADD : String, outputFilePath : String)(implicit context: GlobalContext): String = {
try{
    Logger.log.info("Inside addSegGen")
    Logger.log.info("Initializing variables..")
    var Seg_Nm, Seg_Seq = ""
    var retStr = "N"


      if (segDtls.equals("") || segDtls == null) {
        Logger.log.info("No segment details present for ADD Segment")
      }
      if (!context.sparkSession.catalog.tableExists("TIN_FNL_VIEW")) {
        Logger.log.info("The temporary view TIN_FNL_VIEW from ADD segment is required for ADD segment")
      }
      var ADD_FNL_VIEW = context.sparkSession.emptyDataFrame

      if (SW_SKIP_ADD.equals("N")) {
        var SchemaNm = DPOConstants.SCHEMA
        Logger.log.info("SchemaNm: " + SchemaNm)
        if (segDtls.segName.equals("ADD")) {
          EPDECommonUtil.generateSegTables(segDtls.segTables,glblVarLst)
          Seg_Nm = segDtls.segName
          Seg_Seq = segDtls.segSeq
          Logger.log.info("Inside ADD")
          segDtls.segQueries.map { qryKey =>
            if (qryKey.name.equals("ADD_FNL_VIEW")) {
              Logger.log.info("Inside ADD_FNL_VIEW")
              val ADD_FNL_VIEW =executeQry(glblVarLst,qryKey)
              createOrReplaceTempViewFn(ADD_FNL_VIEW, qryKey.name)
              FileSystemUtil.saveFileToMapRFSNoRepartitionParquet(ADD_FNL_VIEW.dropDuplicates(),outputFilePath,qryKey.name,"",DPOConstants.PARQUET)
              //if(ADD_FNL_VIEW.count > 0){
                /*FileSystemUtil.saveFileToMapRFS(NPI_FNL_VIEW.dropDuplicates(),outputFilePath,qryKey.name,"",DPOConstants.PARQUET)*/
                retStr = "Y"
              //}
            }else{
              Logger.log.info("ADD : Inside else")
              val df = executeQry(glblVarLst, qryKey)
              createOrReplaceTempViewFn(df, qryKey.name)
            }
          }
        } else {
          retStr
        }
      } else {
        Logger.log.info("ADD Segment skipped...")
        retStr
      }
      retStr
}catch {

  case e: Exception => {
    Logger.log.info(s"RK4 : EPDERK4_ADD_SegExt.genADDSeg() : "+e.getMessage)
    throw e
  }

}
  }



}
