package com.uhg.optum.protocols

import com.uhg.optum.protocols.EPDERK4InputJsonSchema.{EPDERK4InputExtractInfo, ExtractFileEntity, FeedDetails, SegmentDetails,Query}
import spray.json._

object EPDERK4InputJsonSchema {

  type Queries = Seq[Query]
  case class Query(name: String, query: String , occurStmnt:Option[String], occursNm:Option[String])
  case class FeedDetails (
                           feedName: String,
                           extraction: Seq[ExtractFileEntity]
                         )

  case class ExtractFileEntity(
                                programName: String,
                                segmentList: String,
                                schemaNm: String,
                                extractHdrCol: String,
                                extractHdrLen: String,
                                extractTolLen: String,
                                segmentDetails: Seq[SegmentDetails]
                              )
  case class SegmentDetails(
                             segName: String,
                             segSeq: String,
                             segTarCol: String,
                             segTarLen: String,
                             segTolLen: String,
                             segTables: String,
                             segQueries: Queries
                           )

  case class EPDERK4InputExtractInfo(items: Array[FeedDetails]) extends IndexedSeq[FeedDetails] {
    def apply(index: Int) = items(index)
    def length = items.length
  }

}

object EPDERK4InputProtocol extends DefaultJsonProtocol {
  import DefaultJsonProtocol._

  implicit val query = jsonFormat4(Query)
  implicit val segmentDetails = jsonFormat7(SegmentDetails)
  implicit val extract = jsonFormat7(ExtractFileEntity)
  implicit val feed = jsonFormat2(FeedDetails)

  implicit object EPDERK4InputExtractInfoJsonFormat extends RootJsonFormat[EPDERK4InputExtractInfo] {
    def read(value: JsValue) = EPDERK4InputExtractInfo(value.convertTo[Array[FeedDetails]])
    def write(f: EPDERK4InputExtractInfo) = JsArray(f.toJson)
  }
}

