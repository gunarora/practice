package com.uhg.optum

import java.text.SimpleDateFormat
import java.util.Properties

import com.uhg.optum.common.DPOConstants
import com.uhg.optum.conf.ApplicationConfig
import com.uhg.optum.conf.ApplicationConfig.{mountPrefix, workingDir}
import com.uhg.optum.dao.{HbaseRepositoryManager, LocalRepositoryManager}
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.util.{FileSystemUtil, Logger}
import org.apache.hadoop.hbase.TableName
import org.apache.hadoop.hbase.client.Scan
import org.apache.hadoop.hbase.filter.CompareFilter.CompareOp
import org.apache.hadoop.hbase.filter.{Filter, FilterList, PrefixFilter, SingleColumnValueFilter}
import org.apache.hadoop.hbase.mapreduce.TableInputFormat
import org.apache.hadoop.hbase.util.Bytes

object EitCapture {
  def main(args: Array[String]): Unit = {

    Logger.log.info("=============> Starting EIT Capture Workflow <=============")
    if (args.length != 3) {
      Logger.log.info("===> Please Pass Arg1: Feed name for properties path Arg2: Environment Arg3: Refresh flag <===")
      Logger.log.error("===> Since No args(Feed Name,Environment,refreshFlag)  is Passed ending Eit Capture creation <===")
      //System.exit(-1)
    }

    val fdNm = args(0).trim
    val env = args(1).trim
    val refreshFlag = args(2).trim
    val peiRowKey = "EPDE-OPTUM"
    implicit val globalContext = if (env.equalsIgnoreCase("local")) {
      new GlobalContext(peiRowKey, "local") with LocalRepositoryManager
    } else {
      new GlobalContext(peiRowKey, "yarn") with HbaseRepositoryManager
    }

    if (FileSystemUtil.fileExists(workingDir + "/" + DPOConstants.EIT_FILE_PATH) && refreshFlag.trim().equals("N")) {
      Logger.log.info("As refresh flag is N and eit file already exists at path: " + workingDir + "/" + DPOConstants.EIT_FILE_PATH)
      Logger.log.info("Terminating the process EITCapture")
      Logger.log.info("=============> Ending EIT Capture Workflow <=============")
    }
    else {
    /*  val peiRowKey = "EPDE-OPTUM"
      implicit val globalContext = if (env.equalsIgnoreCase("local")) {
        new GlobalContext(peiRowKey, "local") with LocalRepositoryManager
      } else {
        new GlobalContext(peiRowKey, "yarn") with HbaseRepositoryManager
      }*/

      val eitCaptureFlg = readFeedBasedProperties(s"common_snapshot", fdNm, s"eitCaptureFlg", env)

      // workingDir
      if (eitCaptureFlg.equalsIgnoreCase("Y")) {
        Logger.log.info(s"Since  eitCaptureFlg is $eitCaptureFlg, proceeding towards capturing the eit into HBASEEit.txt file")

        val allExtractsPitRowKeys = ApplicationConfig.allExtractsPitRowKeys
        try {
          Logger.log.info(s"Removing from rootDir(if present)${allExtractsPitRowKeys.replace("/" + DPOConstants.MAPR + "/", "/")}")
          FileSystemUtil.rmPathIfExist(allExtractsPitRowKeys.replace("/" + DPOConstants.MAPR + "/", "/"))

          globalContext.hBaseConf.set(TableInputFormat.SCAN_COLUMNS, "fi:entprtnfldr fi:entNm exi:ingEndTs");

          val scan = new Scan()
          val ptnr = readFeedBasedProperties(s"common_snapshot", fdNm, s"prtnrCd", env)
          val src = readFeedBasedProperties(s"common_snapshot", fdNm, s"srcCd", env)
          val eitschema = readFeedBasedProperties(s"common_snapshot", fdNm, s"eitschema", env)

          val lakeEitTableName = ApplicationConfig.lakeEitTableName
          Logger.log.info("lakeEitTableName Considered is :" + lakeEitTableName)
          Logger.log.info("Schema Considered is :" + eitschema)
          Logger.log.info("prtnrCd Considered is :" + ptnr)
          Logger.log.info("srcCd Considered is :" + src)

          val filter = new PrefixFilter(Bytes.toBytes(s"${ptnr}-${src}-${eitschema}_"))
          val filter1 = new SingleColumnValueFilter(Bytes.toBytes("exi"), Bytes.toBytes("ingProcLogSts"), CompareOp.EQUAL, Bytes.toBytes("Success"));
          scan.setCaching(10000)
          scan.setCacheBlocks(false)
          filter1.setFilterIfMissing(true)
          scan.setFilter(filterList(filter, filter1))

          val eitVal = globalContext.hbaseContext.hbaseRDD(TableName.valueOf(lakeEitTableName), scan).cache
          val eitCnt = eitVal.count()
          Logger.log.info(s"EIT count is :: ${eitCnt}")

          val eitInfo = eitVal.map(tuple => {
            val result = tuple._2
            (Bytes.toString(result.getRow()), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("entprtnfldr"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("entNm"))), Bytes.toString(result.getValue(Bytes.toBytes("exi"), Bytes.toBytes("ingEndTs"))))
          })


          val eitInfoFinal = eitInfo.filter(x => x._4 != null)
          val eitInfoFinalCnt = eitInfoFinal.count()
          Logger.log.info(s"Final EIT count is :: ${eitInfoFinalCnt}")

          if (eitInfoFinalCnt > 0) {
            FileSystemUtil.rmPathIfExist(workingDir + "/" + DPOConstants.EIT)
            //val saveEit =eitInfo.filter(x=>x._3=="F5938DBJ_MKT_IPA").map(x=> getEitEpochFrmt(x._1,x._2,x._3,x._4)).repartition(1).saveAsTextFile(s"${workingDir}/EIT")
            val saveEit = eitInfoFinal.map(x => getEitEpochFrmt(x._1, x._2, x._3, x._4)).repartition(1).saveAsTextFile(s"${workingDir}/EIT")

            //val eitSchm = StructType(List(StructField("eitRowKey", StringType, true),StructField("prtnFldr", StringType, true),StructField("entNm", StringType, true),StructField("endTsEpoch", StringType, true)))
            // val eitSchm = StructType(List(StructField("eitRowKey", StringType, true)))
            //val abc =globalContext.sparkSession.sqlContext.createDataFrame(globalContext.spark.parallelize(eitInfo.filter(x=>x._3=="F5938DBJ_MKT_IPA").map(x=> getEitEpochFrmt(x._1,x._2,x._3,x._4))).collect().toList).repartition(1).write.mode("overwrite").csv(s"${workingDir}/EIT")
            /*FileSystemUtil.renamePath(workingDir + "/EIT/part-00000", workingDir + "/EIT/HbaseEit.txt")
          FileSystemUtil.rmPathIfExist(workingDir + "/EIT/_SUCCESS")*/
            FileSystemUtil.renamePath(workingDir + "/" + DPOConstants.EIT + "/" + DPOConstants.PART_FILE, workingDir + "/" + DPOConstants.EIT_FILE_PATH)
            FileSystemUtil.rmPathIfExist(workingDir + "/" + DPOConstants.EIT + "/" + DPOConstants.SUCCES_FILE)
            Logger.log.info(s"===================> completed  EIT capture workflow <===================")
          }
          else {
            Logger.log.info(s"Since FInal EIT count is :: ${eitInfoFinalCnt} , then exiting EIT capture workflow")

          }
        } catch {
          case e: Exception =>
            FileSystemUtil.rmPathIfExist(workingDir + "/" + DPOConstants.EIT)
            Logger.log.error(s" Exception while capturing EIT" :+ e.getStackTrace.mkString)
            System.exit(4)
            throw e
        }
      }
      else {
        Logger.log.info(s"Since  eitCaptureFlg is $eitCaptureFlg, NOT proceeding towards capturing the eit into HBASEEit.txt file")
        FileSystemUtil.rmPathIfExist(workingDir + "/" + DPOConstants.EIT)
      }


    }
    Logger.log.info("=====================================================================")
    globalContext.sparkSession.stop()
  }

  /** Purpose : Def to convert the timestamp to epoche time
    * input : eitRowKey : String,ptrnFldr:String,entNm:String,dtStr:String
    * output: eitRowKey : String,ptrnFldr:String,entNm:String,dtStr In epochFormat:String */
  def getEitEpochFrmt(eitRowKey: String, ptrnFldr: String, entNm: String, dtStr: String): String = {
    Logger.log.info("dtStr :: " + dtStr)
    val epochVal = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(dtStr).getTime().toString;
    eitRowKey + "|" + ptrnFldr + "|" + entNm + "|" + epochVal
  }

  /** Purpose : Def to read the configuration values from the properties file based mentioned under resources
    * input : configurationProperty
    * output: Returns the given configurationProperty value as string */
  def readFeedBasedProperties(dirNm: String, feedName: String, input: String, envParam: String): String = {
    val prop = new Properties()
    val path = "/" + dirNm + "/" + feedName + "_" + envParam + ".properties"
    val in = this.getClass.getResourceAsStream(path)
    prop.load(in)
    val value = prop.getProperty(s"$input")
    value
  }

  def filterList(filters: Filter*) = new FilterList(FilterList.Operator.MUST_PASS_ALL, filters: _*)

}