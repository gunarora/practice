package com.uhg.optum.provider.extractors

import java.io.File

import com.uhg.optum.common.DPOConstants
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDECommonInputJsonSchema.ExtractFileEntity
import com.uhg.optum.provider.output.OuptutGenerator
import com.uhg.optum.util.CommonUtil.{add2Map, mkdirs}
import com.uhg.optum.util.FileSystemUtil.fileSystem
import com.uhg.optum.util.{CommonUtil, EPDECommonUtil, FileSystemUtil, Logger}
import com.uhg.optum.util.SparkUtil.createDataFrameFromParquet
import org.apache.hadoop.fs.Path
import com.uhg.optum.util.CommonUtil.executeQry
import org.apache.spark.sql
import org.apache.spark.sql.DataFrame

import scala.collection.mutable
import scala.util.Try

trait EPDECommonJsonSourceExtractor extends OuptutGenerator  {


  def generateExtractFromJson(inputEntity: ExtractFileEntity, peiRowKey: String, inpParqFilePath:String, outputFilePath: String, vndrCdDir : String,vendor_cd: String)(implicit context: GlobalContext): Try[String] = {

    var glblVarLst = collection.mutable.Map[String, String]()
    var dfsMap = collection.mutable.Map[String, DataFrame]()
    add2Map(glblVarLst, "${vendor_cd}", vendor_cd)

    var retStr = "N"

    Try {

      if(inputEntity.equals("") || inputEntity == null){
        Logger.log.info("No input entity details present for RKP Common Program")
      }
      if(inpParqFilePath.isEmpty || inpParqFilePath.equals("") || inpParqFilePath == null){
        Logger.log.info("No paquet file path details present for RKP Common Program")
      }
      if(vndrCdDir.isEmpty || vndrCdDir.equals("") || vndrCdDir == null){
        Logger.log.info("No vndrCd details present for RKP Common Program")
      }
      var input = inpParqFilePath
      var flag = "N"

     /* import context.sparkSession.implicits._
      var provDF = context.sparkContext.parallelize(Seq(("OPTUM","1979519"))).toDF("PROV_OUT_VENDR_CD", "PROV_OUT_PROV_ID")
      var contDF = context.sparkContext.parallelize(Seq(("OPTUM","1757082","20703708","106183632"))).toDF("CONTR_OUT_VENDR_CD", "CONTR_OUT_PROV_ID", "CONTR_OUT_TAX_ID_NBR", "CONTR_OUT_CONTR_ID")
*/


      var provPath = fileSystem.globStatus(new Path(input + "/Provider"))(0).getPath.toString
      var contPath = fileSystem.globStatus(new Path(input + "/Contract"))(0).getPath.toString

      val provDF = createDataFrameFromParquet(provPath)
      val contDF = createDataFrameFromParquet(contPath)


      Logger.log.info(":Dataframe on parquet file created:")
     provDF.createOrReplaceTempView("PROV_df")
      Logger.log.info("Inside :PROV_df:")
    //  provDF.show
     contDF.createOrReplaceTempView("CON_df")
      Logger.log.info("Inside :CON_df:")
     // contDF.show

      if (!context.sparkSession.catalog.tableExists("PROV_df")) {
        Logger.log.info("The temporary view PROV_df from ADD segment is required for ADD segment")
      }

      if (!context.sparkSession.catalog.tableExists("CON_df")) {
        Logger.log.info("The temporary view PROV_df from ADD segment is required for ADD segment")
      }

      if(inputEntity.segmentDetails == null){
        Logger.log.info("No info for segment details present")
      }


      var schNm = inputEntity.schemaNm
      inputEntity.segmentDetails.map {
        s =>
          println(" Schema NAME " + schNm)
          //val tab = context.sparkSession.sql("select * from DF2_NDB_ODFR2TST.F5938DBE_DATA_VEND_CRIT_DTL")
          //tab.createOrReplaceTempView("F5938DBE_DATA_VEND_CRIT_DTL")
          s.segTables.toString.split(";").foreach { (tableName: String) => {
            if (tableName.trim.equalsIgnoreCase("") || tableName==null) {
              Logger.log.info("INFO: No entity to be formed")
            }
            else {
              CommonUtil.getCommonSnapshotPerEntity(schNm + "_" + tableName)
            }
          }
          }
          if (s.segName.equals("PROVIDER")) {
            Logger.log.info("Inside :PROVIDER:")
            s.segQueries.map {
              k =>
                if (k.name.equals("FAC")) {
                  Logger.log.info("Inside :: " + k.name)
                  var df_Fac = context.sqlContext.sql(k.query.replace("${SchemaNm}", schNm).replace("${vendor_cd}", vendor_cd))
                  CommonUtil.createOrReplaceTempViewFn(df_Fac, k.name)
                  import org.apache.spark.sql.functions._
                  if (df_Fac.count == 0) {
                    flag = "Y"
                    //flag = df_Fac.select(col("fac_temp")).first.getString(0)
                    Logger.log.info("::flag:: " + flag)
                  }
                } else if (k.name.equals("UNIQUE_PROV")) {
                  Logger.log.info("Inside :: " + k.name)
                  var df_Uniq_Prov = context.sqlContext.sql(k.query.replace("${schema}", schNm))
                  CommonUtil.createOrReplaceTempViewFn(df_Uniq_Prov, k.name)
                } else if (k.name.equals("PHYSICIAN")) {
                  Logger.log.info("Inside :: " + k.name)
                  var df_P_Phy = context.sqlContext.sql(k.query.replace("${schema}", schNm))
                  CommonUtil.createOrReplaceTempViewFn(df_P_Phy, k.name)
                  //   dfs += df_P_Phy
                  dfsMap.put("PHYSICIAN_PROVIDER", df_P_Phy)
                //  df_P_Phy.show()
                } else if (k.name.equals("GROUP")) {
                  Logger.log.info("Inside :GROUP:")
                  var df_P_Grp = context.sqlContext.sql(k.query)
                  CommonUtil.createOrReplaceTempViewFn(df_P_Grp, k.name)
                  //   dfs += df_P_Grp
                  dfsMap.put("GROUP_PROVIDER", df_P_Grp)
              //    df_P_Grp.show()
                }
                else if (k.name.equals("FACILITY")) {
                  if (flag == "Y") {
                    Logger.log.info("Inside :FACILITY:")
                    var df_P_Fac = context.sqlContext.sql(k.query)
                    CommonUtil.createOrReplaceTempViewFn(df_P_Fac, k.name)
                    //  dfs += df_P_Fac
                    dfsMap.put("FACILITY_PROVIDER", df_P_Fac)
             //       df_P_Fac.show()
                  }
                }
                else{
                  retStr = "N"
                }
            }

          } else if (s.segName.equals("CONTRACT")) {
            Logger.log.info("Inside :CONTRACT:")
            s.segQueries.map {
              k =>
                if (k.name.equals("UNIQUE_CON")) {
                  Logger.log.info("Inside :: " + k.name)
                  var df_Uniq_Con = context.sqlContext.sql(k.query.replace("${schema}", schNm))
                  CommonUtil.createOrReplaceTempViewFn(df_Uniq_Con, k.name)
                } else if (k.name.equals("PHYSICIAN")) {
                  Logger.log.info("Inside :: " + k.name)
                  var df_C_Phy = context.sqlContext.sql(k.query)
                  CommonUtil.createOrReplaceTempViewFn(df_C_Phy, k.name)
                  // dfs += df_C_Phy
                  dfsMap.put("PHYSICIAN_CONTRACT", df_C_Phy)
              //    df_C_Phy.show()
                } else if (k.name.equals("GROUP")) {
                  Logger.log.info("Inside :GROUP:")
                  var df_C_Grp = context.sqlContext.sql(k.query)
                  CommonUtil.createOrReplaceTempViewFn(df_C_Grp, k.name)
                  // dfs += df_C_Grp
                  dfsMap.put("GROUP_CONTRACT", df_C_Grp)
              //    df_C_Grp.show()
                }
                else if (k.name.equals("FACILITY")) {
                  if (flag == "Y") {
                    Logger.log.info("Inside :FACILITY:")
                    var df_C_Fac = context.sqlContext.sql(k.query)
                    CommonUtil.createOrReplaceTempViewFn(df_C_Fac, k.name)
                    // dfs += df_C_Fac
                    dfsMap.put("FACILITY_CONTRACT", df_C_Fac)
                //    df_C_Fac.show()
                  }
                }else{
                  retStr = "N"
                }
            }
          }else
            {
              retStr = "N"
            }

      }
      Logger.log.info(s"INFO : vendorwise common output path ${outputFilePath + DPOConstants.SLASH + vndrCdDir}")


      if(dfsMap.isEmpty || dfsMap == null){
        Logger.log.info("No info for saving parquet files in map present")
      }else {

        var outLoc = s"${outputFilePath + DPOConstants.SLASH + vndrCdDir}"
        //   mkdirs(outLoc)


        CommonUtil.createParquetFromMap(dfsMap, outLoc)
        retStr = "Y"
      }
      retStr
    }
  }
}
