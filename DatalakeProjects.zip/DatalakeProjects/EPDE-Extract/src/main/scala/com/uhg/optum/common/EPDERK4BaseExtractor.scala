package com.uhg.optum.common

import com.uhg.optum.JobRunner.PEI
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDERK4InputJsonSchema


import scala.util.Try


trait EPDERK4BaseExtractor {

  //def extractEPDERK4( jsonFile: Option[EPDERK4InputJsonSchema.ExtractFileEntity], pitRowKey: String)(implicit context: GlobalContext): Tuple2[String,String]
  def extractEPDERK4( jsonFile: Option[EPDERK4InputJsonSchema.ExtractFileEntity], peiRowKey: String,vndrCd:String,provTypCd:String,lastRunPlc:String,varfeedName:String,peiExtractName:String)(implicit context: GlobalContext, pei: PEI): Tuple2[String,String]


}
