package com.uhg.optum.provider.snapshot

import com.uhg.optum.JobRunner.PEI
import com.uhg.optum.executors.GlobalContext
import org.apache.spark.sql.DataFrame

import scala.util.Try

/**
  * Created by paror18 on 10/24/2018.
  */
trait RawSnapshotProvider {
  def getCommonSnapshotPerEntity(entity: String)(implicit context: GlobalContext): String
  // def getSnapshotExtractPerEntity(rowKeyConfig: String, entity: String)(implicit context: GlobalContext): Try[String]
  def getSnapshotExtractPerEntity(rowKeyConfig: String, entity: String, pei: PEI, pitRowKey: String,eitFlag:String)(implicit context: GlobalContext): String
  def getSnapshotExtractPerEntity(rowKeyConfig: String, entity: String, pei: PEI, pitRowKey: String)(implicit context: GlobalContext): String
}