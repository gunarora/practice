package com.uhg.optum.provider.extractors

import com.uhg.optum.common.DPOConstants
import com.uhg.optum.conf.ApplicationConfig.{workingDir,schema}
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDERK4InputJsonSchema.{ExtractFileEntity, SegmentDetails}
import com.uhg.optum.provider.output.OuptutGenerator
import com.uhg.optum.util.CommonUtil.{add2Map, amaSpecTblLoop, createOrReplaceTempViewFn, executeQry, occursCreation}
import com.uhg.optum.util.{CommonUtil, EPDECommonUtil, FileSystemUtil, Logger}
import org.apache.spark.sql.Row
import org.apache.spark.sql.types.StructType

import scala.collection.mutable.ListBuffer

trait EPDERK4_PRV_SegExt extends OuptutGenerator{

  def genPRVSeg(segDtls: SegmentDetails,varLst:collection.mutable.Map[String, String],glblVarLst:collection.mutable.Map[String, String],outputFilePath:String)(implicit context: GlobalContext): String = {
    /*    val rkpLoc=s"/datalake/uhclakedev/dataplatform/epde/d_inbox/OPTUM_PROVIDER"
        var rkpDF=context.sparkSession.read.format("csv").option("delimiter","\t").load(s"$rkpLoc").toDF("PROV_OUT_VENDR_CD","PROV_OUT_PROV_TYP_CD","PROV_OUT_UPDT_TYP_CD","PROV_OUT_PROV_ID","PROV_OUT_VEND_KEY","PROV_PQD_OR_FQD_CNT","PROV_OUT_ORG_TYP_CD").dropDuplicates()
        createOrReplaceTempViewFn(rkpDF,"SELPROV")*/

    import context.sparkSession.implicits._

    /*    ///OHPH
        var df_PRV= Seq(
          ("OHPH","P","C","528719","","",""),
        ("OHPH","P","C","530799","","",""),
        ("OHPH","P","C","2022991","","",""),
        ("OHPH","P","C","2031856","","",""),
        ("OHPH","O","C","2426556","","","050"),
        ("OHPH","O","C","2450934","","","050"),
        ("OHPH","P","C","2499661","","",""),
        ("OHPH","P","C","2635284","","",""),
        ("OHPH","O","C","2851044","","","050"),
        ("OHPH","P","C","2871697","","","")
        ).toDF("PROV_OUT_VENDR_CD","PROV_OUT_PROV_TYP_CD","PROV_OUT_UPDT_TYP_CD","PROV_OUT_PROV_ID","PROV_OUT_VEND_KEY","PROV_PQD_OR_FQD_CNT","PROV_OUT_ORG_TYP_CD")
        createOrReplaceTempViewFn(df_PRV,"SELPROV")*/


    /* ///SDM
       var df_PRV= Seq(
         ("SDM","O","C","6876","","","033"), //group
         ("SDM","O","C","25959","","","033"), // group
         ("SDM","P","C","35883","","",""),
         ("SDM","P","C","79474","","",""),
         ("SDM","O","C","87288","","","033"), // group
         ("SDM","P","C","112515","","",""),
         ("SDM","O","C","131413","","","033"), // group
         ("SDM","P","C","162799","","",""),
         ("SDM","P","C","167699","","",""),
         ("SDM","P","C","188612","","",""),
        ("SDM","O","C","195573","","","033"), //group
        ("SDM","O","C","250594","","","033"), //group
        ("SDM","P","C","257931","","",""),
        ("SDM","P","C","263935","","",""),
        ("SDM","O","C","317342","","","025")
       ).toDF("PROV_OUT_VENDR_CD","PROV_OUT_PROV_TYP_CD","PROV_OUT_UPDT_TYP_CD","PROV_OUT_PROV_ID","PROV_OUT_VEND_KEY","PROV_PQD_OR_FQD_CNT","PROV_OUT_ORG_TYP_CD")
       createOrReplaceTempViewFn(df_PRV,"SELPROV")*/

    /* ///UMR
     var df_PRV= Seq(
       ("UMR","P","C","31","","",""), //
       ("UMR","P","C","105","","",""), //
       ("UMR","P","C","149","","",""), //
       ("UMR","P","C","185","","",""), //
       ("UMR","P","C","205","","",""), //
       ("UMR","P","C","376","","",""), //
       ("UMR","P","C","813","","",""), //
       ("UMR","P","C","913","","",""), //
       ("UMR","P","C","1053","","",""), //
       ("UMR","P","C","1323","","",""), //
       ("UMR","O","C","4895","","","001"), //
       ("UMR","O","C","8677","","","025"), //
       ("UMR","O","C","10398","","","012"), //
       ("UMR","O","C","13456","","","033"), //
       ("UMR","O","C","15668","","","058"),
       ("UMR","O","C","20655","","","007"),
       ("UMR","O","C","27244","","","037")
     ).toDF("PROV_OUT_VENDR_CD","PROV_OUT_PROV_TYP_CD","PROV_OUT_UPDT_TYP_CD","PROV_OUT_PROV_ID","PROV_OUT_VEND_KEY","PROV_PQD_OR_FQD_CNT","PROV_OUT_ORG_TYP_CD")
     createOrReplaceTempViewFn(df_PRV,"SELPROV")*/

    /*  ///EXMNR
       var df_PRV= Seq(
         ("EXMNR","P","C","30","","",""), //
         ("EXMNR","P","C","1304","","",""), //
         ("EXMNR","P","C","3907","","",""), //
         ("EXMNR","P","C","25447","","",""), //
         ("EXMNR","P","C","42225","","",""), //
         ("EXMNR","P","C","89387","","",""), //
         ("EXMNR","P","C","90001","","",""), //
         ("EXMNR","P","C","93678","","",""), //
         ("EXMNR","P","C","95349","","",""), //
         ("EXMNR","P","C","150259","","",""), //
         ("EXMNR","O","C","2492","","","033"), //
         ("EXMNR","O","C","100510","","","033"), //
         ("EXMNR","O","C","116328","","","033"), //
         ("EXMNR","O","C","131413","","","033"), //
         ("EXMNR","O","C","250926","","","033")
       ).toDF("PROV_OUT_VENDR_CD","PROV_OUT_PROV_TYP_CD","PROV_OUT_UPDT_TYP_CD","PROV_OUT_PROV_ID","PROV_OUT_VEND_KEY","PROV_PQD_OR_FQD_CNT","PROV_OUT_ORG_TYP_CD")
       createOrReplaceTempViewFn(df_PRV,"SELPROV")
   */
    /*    ///PHA
        var df_PRV= Seq(
          ("PHA","P","C","1336663","","",""), //
          ("PHA","P","C","1900110","","",""), //
          ("PHA","P","C","2348658","","",""), //
          ("PHA","P","C","2554718","","",""), //
          ("PHA","P","C","2565298","","",""), //
          ("PHA","P","C","2660177","","",""), //
          ("PHA","P","C","2803875","","",""), //
          ("PHA","P","C","2975674","","",""), //
          ("PHA","P","C","3057758","","",""), //
          ("PHA","P","C","3104170","","",""), //
          ("PHA","O","C","2546134","","","033"), //
          ("PHA","O","C","6311285","","","058"), //
          ("PHA","p","C","3297248","","","033"), //
          ("PHA","P","C","3523856","","","033"), //
          ("PHA","P","C","3602981","","","033")
        ).toDF("PROV_OUT_VENDR_CD","PROV_OUT_PROV_TYP_CD","PROV_OUT_UPDT_TYP_CD","PROV_OUT_PROV_ID","PROV_OUT_VEND_KEY","PROV_PQD_OR_FQD_CNT","PROV_OUT_ORG_TYP_CD")
        createOrReplaceTempViewFn(df_PRV,"SELPROV")*/

    /*    ///OHBS
        var df_PRV= Seq(
          ("OHBS","P","C","369023","000119107","",""), //
          ("OHBS","P","C","859134","000223646","",""), //
          ("OHBS","O","C","1467384","FAC00018310","0","042"), //
          ("OHBS","P","C","1981218","000096516","",""), //
          ("OHBS","P","C","2571767","000668492","",""), //
          ("OHBS","P","C","2789610","000628218","",""), //
          ("OHBS","P","C","5239444","000814416","","")
        ).toDF("PROV_OUT_VENDR_CD","PROV_OUT_PROV_TYP_CD","PROV_OUT_UPDT_TYP_CD","PROV_OUT_PROV_ID","PROV_OUT_VEND_KEY","PROV_PQD_OR_FQD_CNT","PROV_OUT_ORG_TYP_CD")
        createOrReplaceTempViewFn(df_PRV,"SELPROV")*/

    /*   ///AMS
        var df_PRV= Seq(
          ("AMS","P","C","30","","",""), //
          ("AMS","P","C","3907","","",""), //
          ("AMS","O","C","2492","","","033"), //
          ("AMS","P","C","25447","","",""), //
          ("AMS","P","C","42225","","",""), //
          ("AMS","P","C","89387","","",""), //
          ("AMS","P","C","90001","","",""),
          ("AMS","P","C","93678","","",""),
          ("AMS","P","C","95349","","",""),
          ("AMS","O","C","100510","","","033"),
          ("AMS","O","C","309361","","","040")
        ).toDF("PROV_OUT_VENDR_CD","PROV_OUT_PROV_TYP_CD","PROV_OUT_UPDT_TYP_CD","PROV_OUT_PROV_ID","PROV_OUT_VEND_KEY","PROV_PQD_OR_FQD_CNT","PROV_OUT_ORG_TYP_CD")
        createOrReplaceTempViewFn(df_PRV,"SELPROV")*/

    //var AMA_SPEC_TABLE_Cnt = glblVarLst.get("AMA_SPEC_TABLE_Cnt").mkString.toInt
    //var AMA_SPEC_TABLE_Cnt=10
    //Logger.log.info("INFO: inside genPRVSeg, AMA_SPEC_TABLE count is " + AMA_SPEC_TABLE_Cnt)
    try {
      /*var amaSpecTblLoop_Flg17, amaSpecTblLoop_Flg18 = false*/
      var degExecFlg = false

      //var SchemaNm = glblVarLst.get("SchemaNm").mkString
      var SchemaNm = schema
      var resStr = "N"


      var emptyLst, tempLst = collection.mutable.Map[String, String]()
      var df, df_DEGCNT = context.sqlContext.emptyDataFrame
      /*var prvDegNoRcrdsDf: org.apache.spark.sql.types.StructType = null*/

      Logger.log.info("PRV")
      EPDECommonUtil.generateSegTables(segDtls.segTables, glblVarLst)
      segDtls.segQueries.map { qryKey =>

        if (qryKey.name.equals("PRV_SEL_RKP_Prov")) {

          df = executeQry(emptyLst, qryKey)
          createOrReplaceTempViewFn(df, qryKey.name)
          FileSystemUtil.saveFileToMapRFSNoRepartitionParquet(df, glblVarLst.get("tmpVwPath").getOrElse(workingDir), qryKey.name, "", DPOConstants.PARQUET)
        }
        //fetches provided prov_id which are unique and have count as 1
        /* else if (qryKey.name.equals("PRV_SEL_7_PROV")) {
         df = executeQry(varLst, qryKey)
         createOrReplaceTempViewFn(df, qryKey.name)
       }
       //fetches details of the prov_id filtered in PRV_SEL_7_PROV qry  #2210-GET-PROV-INFO # "7 PROV"
       else if (qryKey.name.equals("PRV_7_PROV")) {
         df = executeQry(varLst, qryKey)
         createOrReplaceTempViewFn(df, qryKey.name)
       }
       //prov_id exclusion process for facility type #5020-FAC-PROCESS #TR "8 FAC_EXCL" and "9 DATA_VEND_CRIT_DTL"
       else if (qryKey.name.equals("PRV_5020_FAC_PRC")) {
         df = executeQry(varLst, qryKey)
         createOrReplaceTempViewFn(df, qryKey.name)
       }
       //filters the prov_id from PRV_7_PROV based on result of PRV_5020_FAC_PRC #2100-CHECK-PROV-SPEC-EXCLUSION
       else if (qryKey.name.equals("PRV_SEL_5020_FAC")) {
         df = executeQry(emptyLst, qryKey)
         createOrReplaceTempViewFn(df, qryKey.name)
       }
       // fetches prov_id which fulfills the criteria of  #TR 10 PSP
       else if (qryKey.name.equals("PRV_10_PSP")) {
         df = executeQry(varLst, qryKey)
         // df = executeQry(qryKey, SchemaNm, WS_CANC_DT_1,WS_CANC_DT_2,WS_UPDT_DT_1,WS_UPDT_DT_2)
         createOrReplaceTempViewFn(df, qryKey.name)
       }
       // fetches prov_id which doesn't fulfills the criteria of  #TR 10 PSP
       else if (qryKey.name.equals("PRV_10_PSP_NORCRDS")) {
         df = executeQry(emptyLst, qryKey)
         // df = executeQry(qryKey,'')
         createOrReplaceTempViewFn(df, qryKey.name)
       } else
       // fetches EXCLUSION prov_id which fulfills the criteria of  #TR 17 #5000-SPEC-EXCLUSIONS
       if (qryKey.name.equals("PSP_17_DVC_DTL")) {
         var AMA_SPEC_ENTRY_qry_17 = context.sqlContext.emptyDataFrame
         AMA_SPEC_ENTRY_qry_17 = executeQry(varLst, qryKey)
         var ama17Cnt=AMA_SPEC_ENTRY_qry_17.count()
         if(ama17Cnt==0){
           Logger.log.info(s"INFO:  AMA_SPEC_ENTRY_qry_17 count is $ama17Cnt")
           amaSpecTblLoop_Flg17=false
         }
         else {
           Logger.log.info(s"INFO:  AMA_SPEC_ENTRY_qry_17 count is $ama17Cnt")
           // AMA_SPEC_ENTRY_qry_17 = executeQry(qryKey, SchemaNm, WS_VENDR_CD)
           createOrReplaceTempViewFn(AMA_SPEC_ENTRY_qry_17, qryKey.name)
           amaSpecTblLoop_Flg17=true}
       }
       // fetches EXCLUSION OF  prov_id which fulfills the criteria of  #TR 18 # 5010-SPEC-EXCLUSIONS
       else if (qryKey.name.equals("PSP_18_DVC_DTL")) {
         var AMA_SPEC_ENTRY_qry_18 = context.sqlContext.emptyDataFrame
         AMA_SPEC_ENTRY_qry_18 = executeQry(varLst, qryKey)
         var ama18Cnt=AMA_SPEC_ENTRY_qry_18.count()
         if(ama18Cnt==0){
           Logger.log.info(s"INFO:  AMA_SPEC_ENTRY_qry_18 count is $ama18Cnt")
           amaSpecTblLoop_Flg18=false
         }
         else {
           Logger.log.info(s"INFO:  AMA_SPEC_ENTRY_qry_18 count is $ama18Cnt")
           // AMA_SPEC_ENTRY_qry_17 = executeQry(qryKey, SchemaNm, WS_VENDR_CD)
           createOrReplaceTempViewFn(AMA_SPEC_ENTRY_qry_18, qryKey.name)
           amaSpecTblLoop_Flg18=true}
       }else
       //excludes the prov-id fetched in PRV_17_DVC_DTL and PRV_18_DVC_DTL based on filter for AMA_SPEC_TABLE
       if (qryKey.name.equals("PRV_PSP_AMA")) {
         var skipPrvLst=""
         if (amaSpecTblLoop_Flg18 || amaSpecTblLoop_Flg17 ){
           skipPrvLst = amaSpecTblLoop(AMA_SPEC_TABLE_Cnt).trim
         }else{
           skipPrvLst="''"
         }
         Logger.log.info(s"INFO: output of AMAsepcLoop is $skipPrvLst")
         tempLst.clear()
         tempLst = varLst
         add2Map(tempLst, "${skipPrvLst}", skipPrvLst)
         df = executeQry(tempLst, qryKey)
         // df = executeQry(qryKey,skipPrvLst)
         createOrReplaceTempViewFn(df, qryKey.name)
       }
       // combines the result of PRV_PSP_AMA and PRV_10_PSP_NORCRDS and makes the dataset for 2100 label execution #2100-Label
       // this will provide for columns in PRV segment
       else if (qryKey.name.equals("PRV_2100_LBL")) {
         df = executeQry(emptyLst, qryKey)
         // df = executeQry(qryKey,'')
         createOrReplaceTempViewFn(df, qryKey.name)
       }
       // fetches details from prov_deg tables based on # TR 11 DEGCD #2222-FETCH-DEG process
       */ else if (qryKey.name.equals("PRV_DEG_CD_RCRDS")) {
          df = executeQry(varLst, qryKey)
          // df = executeQry(qryKey, SchemaNm, WS_CANC_DT_1,WS_CANC_DT_2,WS_UPDT_DT_1,WS_UPDT_DT_2)
          createOrReplaceTempViewFn(df.dropDuplicates(), qryKey.name)

          /// df.show()

          /// FileSystemUtil.saveFileToMapRFS(df,glblVarLst.get("tmpVwPath").getOrElse(workingDir),qryKey.name,"",DPOConstants.PARQUET)
          if (df.count() > 0) {

            degExecFlg = true
          }
          Logger.log.info(s"INFO ::${qryKey.name}  ; degExecFlg -- >" + degExecFlg)
          /*
      +-------+------+------+-------+--------------------+
      |PROV_ID|DEG_CD|PRI_CD|ACTV_CD|         LST_UPDT_DT|
      +-------+------+------+-------+--------------------+
      |1624048|   MS |     P|      A|2009-12-14 00:00:...|
      |1624048|   MSW|     S|      A|2009-12-14 00:00:...|
      +-------+------+------+-------+--------------------+
*/
        }
        /* // fetches list of prov_id and default values which doesn't fulfills PRV_DEG_CD logic from PRV_2100_LBL
     else if (qryKey.name.equals("PRV_DEG_CD_NORCRDS")) {
       df = executeQry(emptyLst, qryKey)
       prvDegNoRcrdsDf=df.schema
       Logger.log.info("INFOO ::prvDegNoRcrdsDf -->"+prvDegNoRcrdsDf)
       // df = executeQry(qryKey, '')
       createOrReplaceTempViewFn(df, qryKey.name)
       /// df.show()
       /// FileSystemUtil.saveFileToMapRFS(df,glblVarLst.get("tmpVwPath").getOrElse(workingDir),qryKey.name,"",DPOConstants.PARQUET)
     }

     //calculates the count per prov_id for OCCURS logic
     else if (qryKey.name.equals("PRV_DEG_CNT")) {
       if(degExecFlg) {
         df_DEGCNT = executeQry(emptyLst, qryKey)
         /// df_DEGCNT.show()
       }
       Logger.log.info(s"INFO ::${qryKey.name}  ; degExecFlg -- >"+degExecFlg )
       //df_DEGCNT = executeQry(qryKey,'')
       //createOrReplaceTempViewFn(df_DEGCNT, qryKey.name)
       /// FileSystemUtil.saveFileToMapRFS(df,glblVarLst.get("tmpVwPath").getOrElse(workingDir),qryKey.name,"",DPOConstants.PARQUET)
     }
     // occurs logic implementation based in the counts received from PRV_DEG_CNT
     // it will apply the occurs logic per prov_id basis and then collect the records in a collection then eventually forms a DataFrame
     else if (qryKey.name.equals("PRV_DEG_CD_OCCURS")) {
       Logger.log.info(s"INFO ::${qryKey.name} degExecFlg -- >"+degExecFlg )
       var occrNm = qryKey.occursNm.getOrElse("")
       if(degExecFlg) {
         var z: org.apache.spark.sql.types.StructType = null
         var lst = new ListBuffer[Row]()
         var occurStmnt = qryKey.occurStmnt.getOrElse("")

         var whrClause = occurStmnt.split("~")(3)

         df_DEGCNT.rdd.collect.map { rec =>
           var DEGCNTObj = PRV_DEG_CNT(rec.getAs[String]("PROV_ID"), rec.getAs[String]("CNT"))
           /*var df_DEG = context.sqlContext.emptyDataFrame
                 df_DEG = executeQry(qryKey, SchemaNm, DEGCNTObj.PROV_ID)
                 createOrReplaceTempViewFn(df_DEG, qryKey.name)*/
           Logger.log.info("INFO : capturing deg prov_id and count")
           var DEG_PROV_ID = DEGCNTObj.PROV_ID
           Logger.log.info("INFO : capturing deg prov_id --> " + DEG_PROV_ID)
           var DEG_NUM_temp = DEGCNTObj.CNT
           Logger.log.info("INFO : capturing deg  count --> " + DEG_NUM_temp)
           var DEG_NUM = DEG_NUM_temp.trim.toInt
           Logger.log.info("INFO : capturing deg  count --> " + DEG_NUM)
           /*if (DEG_NUM > 2) {*/
           DEG_NUM = 2
           /*  } else {
                     DEG_NUM = DEG_NUM
                   }*/
           var tblNm = occurStmnt.split("~")(4).replace("${DEG_PROV_ID}", DEG_PROV_ID)
           /*var occurStmnt = qryKey.occurStmnt.getOrElse("")
                 var occrNm=qryKey.occursNm.getOrElse("")
                 var whrClause = occurStmnt.split("~")(3)
                 var tblNm = occurStmnt.split("~")(4).replace("${DEG_PROV_ID}", DEG_PROV_ID)*/
           //the occurs DF has to be of one record per prov_id
           var occurFnlQryDF = occursCreation(occurStmnt, DEG_NUM, occrNm, SchemaNm, whrClause, tblNm)
           //                println("occurStmnt " + occurStmnt)
           /*println(occurFnlQryDF.show)
           println(occurFnlQryDF.schema)*/
           lst += occurFnlQryDF.first()
           z = occurFnlQryDF.schema
         }
         val rdd = context.sparkContext.parallelize(lst.toSeq)
         val outputDf = context.sqlContext.createDataFrame(rdd, z)
         /// outputDf.show()
         createOrReplaceTempViewFn(outputDf, occrNm)
         /// FileSystemUtil.saveFileToMapRFS(outputDf, glblVarLst.get("tmpVwPath").getOrElse(workingDir), occrNm, "", DPOConstants.PARQUET)
       }else{
         Logger.log.info(s"INFO ::${qryKey.name} inside else creating empty DF for $occrNm")
         /*
                 val lst = List("", "", "", "", "")
                 val rdd = context.sparkContext.parallelize(lst.toSeq).map(r => Row.fromSeq(r))
                 Logger.log.info(s"INFO1111 ::${qryKey.name} inside else creating empty DF for $occrNm")
                 val outputDf = context.sqlContext.createDataFrame(rdd,prvDegNoRcrdsDf)
                 Logger.log.info(s"INFO2222 ::${qryKey.name} inside else creating empty DF for $occrNm")
                   //context.sqlContext.createDataFrame(rdd,prvDegNoRcrdsDf)
                 createOrReplaceTempViewFn(outputDf, occrNm)
                 Logger.log.info(s"INFO3333 ::${qryKey.name} inside else creating empty DF for $occrNm")*/
         import context.sparkSession.implicits._
         var df_degtmp= Seq(
           ("", "", "", "", "","")
         ).toDF("PDG_PROV_ID","PDG_DEG_CD_1","PDG_PRI_CD_1","PDG_ACTV_CD_1","PDG_LST_UPDT_DT_1","PDG_LST_UPDT_DT_2")
         createOrReplaceTempViewFn(df_degtmp,occrNm)
         /// FileSystemUtil.saveFileToMapRFS(df,glblVarLst.get("tmpVwPath").getOrElse(workingDir),qryKey.name,"",DPOConstants.PARQUET)

       }
     }*/
        /*// Union of PRV_DEG_CD_NORCRDS and PRV_TBL_DEG_CD
    else if (qryKey.name.equals("PRV_DEG_CD")) {
      df = executeQry(varLst, qryKey)
      // df = executeQry(qryKey, SchemaNm, WS_ACTV_CD_1,WS_ACTV_CD_2,WS_UPDT_DT_1,WS_UPDT_DT_2)
      createOrReplaceTempViewFn(df, qryKey.name)
    }


    // calculates the max(CYC_SEQ_NBR) for the prov_id based on # TR 12A_B
    else if (qryKey.name.equals("PRV_12A_B_1")) {
      df = executeQry(varLst, qryKey)
      // df = executeQry(qryKey, SchemaNm, WS_ACTV_CD_1,WS_ACTV_CD_2,WS_UPDT_DT_1,WS_UPDT_DT_2)
      createOrReplaceTempViewFn(df, qryKey.name)
    }
    // fetches the details from PROV_CRDNTL_STS table based on the max(CYC_SEQ_NBR) for the prov_id got in PRV_12A_B_1
    else if (qryKey.name.equals("PRV_12A_B_RCRDS")) {
      df = executeQry(varLst, qryKey)
      // df = executeQry(qryKey, SchemaNm, WS_ACTV_CD_1,WS_ACTV_CD_2,WS_UPDT_DT_1,WS_UPDT_DT_2)
      createOrReplaceTempViewFn(df, qryKey.name)
    }
    // it fetches records  from PRV_2100_LBL table which doesn't satisfies PRV_12A_B_RCRDS logic
    else if (qryKey.name.equals("PRV_12A_B_NORCRDS")) {
      df = executeQry(varLst, qryKey)
      // df = executeQry(qryKey, SchemaNm)
      createOrReplaceTempViewFn(df, qryKey.name)
    }
    // it's the union of the records PRV_12A_B_RCRDS and PRV_12A_B_NORCRDS (count of whose should be able to match PRV_2100_LBL)
    else if (qryKey.name.equals("PRV_12A_B")) {
      df = executeQry(emptyLst, qryKey)
      // df = executeQry(qryKey,'')
      createOrReplaceTempViewFn(df, qryKey.name)
    }
    // fetches records  from PROV_TIN_ADR with #TR 13
    else if (qryKey.name.equals("PRV_13_PTA_RCRDS")) {
      df = executeQry(emptyLst, qryKey)
      // df = executeQry(qryKey,'')
      createOrReplaceTempViewFn(df, qryKey.name)
    }
    // fetches prov_id list  as per #TR 13 PTA with no space MDCD_ID from PRV_13_PTA_RCRDS
    else if (qryKey.name.equals("PRV_13_PTA_NOSPC")) {
      df = executeQry(varLst, qryKey)
      // df = executeQry(qryKey, SchemaNm, WS_CANC_DT_1,WS_CANC_DT_2,WS_UPDT_DT_1,WS_UPDT_DT_2)
      createOrReplaceTempViewFn(df, qryKey.name)
    }
    // fetches list of the prov_id from 2100 lable which doesn't comply to TR 13 or have  MDCD_ID ='' (spaces);
    // it forms the  basis for #TR 14PTA
    else if (qryKey.name.equals("PRV_13_PTA_NORCRDSSPC")) {
      df = executeQry(varLst, qryKey)
      // df = executeQry(qryKey, SchemaNm)
      createOrReplaceTempViewFn(df, qryKey.name)
    }
    // it fetches prov_id from PROV_TIN_ADR tbl based on # TR 14 PTA and PRV_13_PTA_NORCRDSSPC
    else if (qryKey.name.equals("PRV_14_PTA_RCRDS")) {
      df = executeQry(varLst, qryKey)
      // df = executeQry(qryKey, SchemaNm,  WS_CANC_DT_1,WS_CANC_DT_2,WS_UPDT_DT_1,WS_UPDT_DT_2)
      createOrReplaceTempViewFn(df, qryKey.name)
    }
    // it fetches prov_id from  PRV_13_PTA_NORCRDSSPC which doesn't satisfies  # TR 14 PTA
    else if (qryKey.name.equals("PRV_14_PTA_NORCRDS")) {
      df = executeQry(emptyLst, qryKey)
      // df = executeQry(qryKey, '')
      createOrReplaceTempViewFn(df, qryKey.name)
    }
    // it combines the records from PRV_13_PTA_NOSPC, PRV_14_PTA_RCRDS,PRV_14_PTA_NORCRDS
    else if (qryKey.name.equals("PRV_13_14_PTA")) {
      df = executeQry(varLst, qryKey)
      // df = executeQry(qryKey, '')
      createOrReplaceTempViewFn(df, qryKey.name)
    }
    // this will executed for only OHPH vendor code . this condition handled in Query
    else if (qryKey.name.equals("PRV_75_VREL")) {
      df = executeQry(varLst, qryKey)
      // df = executeQry(qryKey, SchemaNm)
      createOrReplaceTempViewFn(df, qryKey.name)
    }
    // temp query execution for thr PRV segment handling the  various inner if condition and other date transformation.
    else if (qryKey.name.equals("PRV_FINAL_QRY_TMP")) {
      df = executeQry(emptyLst, qryKey)
      // df = executeQry(qryKey'')
      createOrReplaceTempViewFn(df, qryKey.name)
    }*/
        // final query execution for thr PRV segment
        else if (qryKey.name.equals("PRV_FNL_VIEW")) {
          df = executeQry(varLst, qryKey).dropDuplicates()
          // df = executeQry(qryKey'')
          createOrReplaceTempViewFn(df, qryKey.name)
          /// df.show()
          FileSystemUtil.saveFileToMapRFSNoRepartitionParquet(df, outputFilePath, qryKey.name, "", DPOConstants.PARQUET)
          if (df.count > 0) {
            //RPAD QUERY -> result -> write df res in file
            /* val prvDf = CommonUtil.generateRpadQry(segDtls.segTarCol, segDtls.segTarLen, segDtls.segTolLen, qryKey.name)
          generateOpFile(prvDf, outputFilePath, qryKey.name+"rpad")
          prvDf.show()*/
            //FileSystemUtil.saveFileToMapRFS(prvDf,outputFilePath,qryKey.name,"",DPOConstants.CSV)
            /*FileSystemUtil.saveFileToMapRFS(df,outputFilePath,qryKey.name,"",DPOConstants.PARQUET)*/
            resStr = "Y"
          }
        }
        else {
          df = executeQry(varLst, qryKey)
          // df = executeQry(qryKey'')
          createOrReplaceTempViewFn(df, qryKey.name)
          /// df.show()
          ///      FileSystemUtil.saveFileToMapRFS(df,glblVarLst.get("tmpVwPath").getOrElse(workingDir),qryKey.name,"",DPOConstants.PARQUET)
        }

      }
      resStr
    }
    catch {

      case e: Exception => {
        Logger.log.info(s"RK4 : EPDERK4_PRV_SegExt.genPRVSeg() : "+e.getMessage)
        throw e
      }

    }
  }



}
