package com.uhg.optum.common

import com.uhg.optum.executors.GlobalContext
import org.apache.spark.sql.DataFrame

import scala.util.Try

/**
  * Created by paror18 on 10/24/2018.
  */
trait SnapshotProvider {

  def getCommonSnapshotPerEntity(entity: String): DataFrame = ???

  def getSnapshotExtractPerEntity(rowKeyConfig: String, entity: String)(implicit context: GlobalContext): Try[String] = ???

}
