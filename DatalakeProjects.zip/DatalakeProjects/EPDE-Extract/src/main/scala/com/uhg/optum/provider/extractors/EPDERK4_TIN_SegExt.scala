package com.uhg.optum.provider.extractors

import com.uhg.optum.common.DPOConstants
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDERK4InputJsonSchema.SegmentDetails
import com.uhg.optum.provider.output.OuptutGenerator
import com.uhg.optum.util.CommonUtil._
import com.uhg.optum.util.{EPDECommonUtil, FileSystemUtil, Logger}
import org.apache.spark.sql.DataFrame

trait EPDERK4_TIN_SegExt extends OuptutGenerator{
  def genTINSeg(segDetails:SegmentDetails,glblVarLst:collection.mutable.Map[String, String],varLst:collection.mutable.Map[String, String],segLocation:String)(implicit context: GlobalContext): String = {
    try{
    var df_TIN = context.sqlContext.emptyDataFrame
    var rs="N"
    Logger.log.info("Segment TIN Creation Start")
    //df_PRV = context.sqlContext.read.parquet(segLocation + "/PRV")
    val sparkSession = context.sparkSession
    import sparkSession.implicits._
    /*val df_PRV= Seq(
      ("2426556", "P"),
      ("2450934", "O"),
      ("2851044", "C")
    ).toDF("OUT_PRV_PROV_ID", "PRV_PRO_ORG_TYP_CD")*/

  //  if (df_PRV.count() != 0) {
      if (segDetails.segName.equals("TIN")) {
        //Segment query execution in sequence
        EPDECommonUtil.generateSegTables(segDetails.segTables,glblVarLst)
       // df_PRV.createOrReplaceTempView("PRV_FNL_VIEW")

        segDetails.segQueries.foreach { qryKey =>
          Logger.log.info("qryKey.name --> " + qryKey.name)
          df_TIN = executeQry(glblVarLst, qryKey)
          createOrReplaceTempViewFn(df_TIN, qryKey.name)
          if(qryKey.name.equalsIgnoreCase("TIN_DF_28")){
            FileSystemUtil.saveFileToMapRFSNoRepartitionParquet(df_TIN,glblVarLst.get("tmpVwPath").getOrElse(""),qryKey.name,"",DPOConstants.PARQUET)
          }
        }
  //      val segLocation1="/datalake/uhclakedev/dataplatform/epde/d_datafiles/OHPH/GROUP/"
        FileSystemUtil.saveFileToMapRFSNoRepartitionParquet(df_TIN.dropDuplicates(),segLocation,"TIN_FNL_VIEW","",DPOConstants.PARQUET)
        rs="Y"
        // Segment file generation
        /*if (df_TIN.count() > 0) {
          /*FileSystemUtil.saveFileToMapRFS(df_TIN.dropDuplicates(),segLocation,"TIN_FNL_VIEW","",DPOConstants.PARQUET)*/
          //val tinDf = generateRpadQry(segDetails.segTarCol, segDetails.segTarLen, segDetails.segTolLen, "TIN_FNL_VIEW")
          //Logger.log.info("TIN RPAD Query")
          //tinDf.show()
          Logger.log.info("...Inside TIN -> outputFilePath, seg_Seq..." + segLocation + " " + segDetails.segSeq)
         // FileSystemUtil.saveFileToMapRFS(tinDf.dropDuplicates(),segLocation,"TIN_FNL_VIEW_TXT","",DPOConstants.TEXT)
          //generateOpFile(tinDf, segLocation, "TIN_FNL_VIEW_TXT")

        } else {
          Logger.log.info("ERROR FETCHING TIN")
          rs="N"
        }*/
      }
    /*}else{
      Logger.log.error(s"PRV dataframe Should not be Empty")
      throw new Exception("Exception thrown")
    }*/
   /* val tinCount = df_TIN.count()
    Logger.log.info(s"TIN segment count:$tinCount")*/
    rs
    }catch {

      case e: Exception => {
        Logger.log.info(s"RK4 : EPDERK4_TIN_SegExt.genTINSeg() : "+e.getMessage)
        throw e
      }

    }
  }
}
