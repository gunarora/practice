package com.uhg.optum.provider.extractors

import com.uhg.optum.common.DPOConstants
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDERK4InputJsonSchema.SegmentDetails
import com.uhg.optum.provider.output.OuptutGenerator
import com.uhg.optum.util.CommonUtil._
import com.uhg.optum.util.{EPDECommonUtil, FileSystemUtil, Logger}

trait EPDERK4_CDK_SegExt extends OuptutGenerator{
  def genCDKSeg(segDetails:SegmentDetails,varLst:collection.mutable.Map[String, String],glblVarLst:collection.mutable.Map[String, String],segLocation:String,con_flag:String)(implicit context: GlobalContext): String = {

  try{

   var df_CDK = context.sqlContext.emptyDataFrame
    var rs="N"
    //val con_flag="Y"
    Logger.log.info("Segment CDK Creation Start")
    val sparkSession = context.sparkSession
    import sparkSession.implicits._
   /* var df_CONT=Seq(
      ("EXMNR","O", "000002492", "102971859", "341783789", "033"),
      ("EXMNR","O", "000002492", "102971863", "341783789", "033"),
      ("EXMNR","O", "000002492", "102971861", "341783789", "033"),
      ("EXMNR","O", "000002492", "102971862", "341783789", "033"),
      ("EXMNR","O", "000002492", "102971866", "341783789", "033"),
      ("EXMNR","O", "000002492", "102971864", "341783789", "033"),
      ("EXMNR","O", "000002492", "102971865", "341783789", "033"),
      ("EXMNR","O", "000002492", "163171890", "341783789", "033"),
      ("EXMNR","O", "000002492", "163171889", "341783789", "033"),
      ("EXMNR","O", "000002492", "163171888", "341783789", "033"),
      ("EXMNR","O", "000002492", "085124499", "341783789", "033"),
      ("EXMNR","O", "000002492", "085124498", "341783789", "033")
    ).toDF("CONTR_OUT_VENDR_CD","CONTR_OUT_PROV_TYP_CD","CONTR_OUT_PROV_ID","CONTR_OUT_CONTR_ID","CONTR_OUT_TAX_ID_NBR","CONTR_OUT_ORG_TYP_CD")*/
    if (segDetails.segName.equals("CDK")) {
        //Segment query execution in sequence
        EPDECommonUtil.generateSegTables(segDetails.segTables,varLst)

      //df_CONT.createOrReplaceTempView("SELCONT")
        segDetails.segQueries.foreach { qryKey =>
          Logger.log.info("qryKey.name --> " + qryKey.name)
          if(qryKey.name.equalsIgnoreCase("CDK_SELTIN")){
              if(con_flag.equals("N")){
                df_CDK = executeQry(varLst, qryKey)
                createOrReplaceTempViewFn(df_CDK, qryKey.name)
              }
          }else if(qryKey.name.equalsIgnoreCase("CDK_TIN30")){
            if(con_flag.equals("N")){
              df_CDK = executeQry(varLst, qryKey)
              createOrReplaceTempViewFn(df_CDK, "CDK_MAIN_TB")
            }
          }else if(qryKey.name.equalsIgnoreCase("CDK_CON31")){
            if(con_flag.equals("Y")){
              df_CDK = executeQry(varLst, qryKey)
              createOrReplaceTempViewFn(df_CDK, "CDK_MAIN_TB")
            }
          }else{
            df_CDK = executeQry(varLst, qryKey)
            createOrReplaceTempViewFn(df_CDK, qryKey.name)
          }
        }

        // Segment parquet file generation
        FileSystemUtil.saveFileToMapRFSNoRepartitionParquet(df_CDK.dropDuplicates(),segLocation,"CDK_FNL_VIEW","",DPOConstants.PARQUET)
        rs="Y"
        /*if (df_CDK.count() > 0) {
          /*val tinDf = generateRpadQry(segDetails.segTarCol, segDetails.segTarLen, segDetails.segTolLen, "CDK_FNL_VIEW")
          Logger.log.info("CDK RPAD Query")
          tinDf.show()
          Logger.log.info("...Inside CDK -> outputFilePath, seg_Seq..." + segLocation + " " + segDetails.segSeq)
          FileSystemUtil.saveFileToMapRFS(tinDf,segLocation,"CDK_FNL_VIEW_TXT","",DPOConstants.TEXT)*/
          rs="Y"
        } else {
          Logger.log.info("ERROR FETCHING CDK")
          rs="N"
        }*/
      }
    //val cdkCount = df_CDK.count()
    Logger.log.info(s"CDK segment generated")
    rs
  }catch {

    case e: Exception => {
      Logger.log.info(s"RK4 : EPDERK4_CDK_SegExt.genCDKSeg() : "+e.getMessage)
      throw e
    }

  }
  }
}
