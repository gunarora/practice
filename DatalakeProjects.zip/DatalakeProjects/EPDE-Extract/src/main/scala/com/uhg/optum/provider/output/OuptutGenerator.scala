package com.uhg.optum.provider.output


import com.uhg.optum.util.FileSystemUtil._

import org.apache.hadoop.fs.{FileSystem, FileUtil, Path}
import scala.util.Try
import com.uhg.optum.conf.ApplicationConfig
import com.uhg.optum.common.DPOConstants
import com.uhg.optum.util.{CommonUtil, FileSystemUtil, Logger, SparkUtil}
import org.apache.spark.sql.{DataFrame, Row}
import com.uhg.optum.JobRunner.{DPOException, PEI}
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDEInputJsonSchema.{ExtractDetail, ExtractFileEntity}
import com.uhg.optum.provider.DefaultExtractProvider.{ProvExtractOutput, ProvNContExtractOutput}
import com.uhg.optum.conf.ApplicationConfig.inboxDir

/**
  * Created by paror18 on 10/19/2018.
  */
trait OuptutGenerator {

 /**
    * This method generates the output files for the
    * input provider and contractor dataframes at
    * location given in json file
    * @param provDataFrame
    * @param contDataFrame
    * @param inputEntity
    * @param pitRowKey
    * @param context
    * @param pei
    * @return
    */
  def generateFilesForProvNCont(provDataFrame: DataFrame, contDataFrame: DataFrame, inputEntity: ExtractDetail, pitRowKey: String)(implicit context: GlobalContext, pei: PEI): ProvNContExtractOutput = {
    val conGivenFileDelim = inputEntity.contractQueries.head.outFileColDelim
    val provGivenFileDelim = inputEntity.providerQueries.head.outFileColDelim
    /* val contHdrDesc = inputEntity.contractQueries.head.headerDesc
     val contTrlDesc = inputEntity.contractQueries.head.trailerDesc
     val provHdrDesc = inputEntity.providerQueries.head.headerDesc
     val provTrlDesc = inputEntity.providerQueries.head.trailerDesc*/
    val contFileDelim = if (conGivenFileDelim.equalsIgnoreCase(DPOConstants.NA) || conGivenFileDelim.equalsIgnoreCase("\\t")) {
      DPOConstants.TABDELIM
    }
    else {
      conGivenFileDelim
    }
    val provFileDelim = if (provGivenFileDelim.equalsIgnoreCase(DPOConstants.NA) || provGivenFileDelim.equalsIgnoreCase("\\t")) {
      DPOConstants.TABDELIM
    }
    else {
      provGivenFileDelim
    }
    val contDF = DPOConstants.CONTRACT_TEMP_DF
    val provDF = DPOConstants.PROVIDER_TEMP_DF
    contDataFrame.createOrReplaceTempView(contDF)
    provDataFrame.createOrReplaceTempView(provDF)
    val resContDataFrame = generateTransformedExtract(inputEntity.contractQueries.head.trgColumn, inputEntity.contractQueries.head.trgDataTypeLen, contDF, pitRowKey)

    val resProvDataFrame = generateTransformedExtract(inputEntity.providerQueries.head.trgColumn, inputEntity.providerQueries.head.trgDataTypeLen, provDF, pitRowKey)

    /*val contColNames =inputEntity.contractQueries.head.trgColumn.split(";").toSeq
    val resContDataframe = contDataframe.select(contColNames.head, contColNames.tail: _*)
    val provColNames =inputEntity.providerQueries.head.trgColumn.split(";").toSeq
    val resProvDataframe = provDataFrame.select(provColNames.head, provColNames.tail: _*)*/
    //val outFileLoc = pei.inputFileLocation
    val outFileLoc = inboxDir
    println("===============outFileLoc================="+outFileLoc)
    val provFileName = pei.inputFileName.split(";").apply(0)
    println("===============outFileLoc================="+provFileName)
    val contFileName = pei.inputFileName.split(";").apply(1)
    println("===============outFileLoc================="+contFileName)
    val contFileCount = FileSystemUtil.saveFileToMapRFS(resContDataFrame: DataFrame, outFileLoc: String, contFileName: String, contFileDelim: String, DPOConstants.CSV)
    Logger.log.info(s"Total Count For ${outFileLoc} ${DPOConstants.SLASH} ${contFileName}: $contFileCount")
    val provFileCount = FileSystemUtil.saveFileToMapRFS(resProvDataFrame: DataFrame, outFileLoc: String, provFileName: String, provFileDelim: String, DPOConstants.CSV)
    Logger.log.info(s"Total Count For ${outFileLoc} ${DPOConstants.SLASH} ${provFileName}: $provFileCount")
    ProvNContExtractOutput(provFileCount, provFileName, contFileCount, contFileName, outFileLoc)

  }

  def generateOpFile(df: DataFrame, outputFilePath: String, seg_Seq: String) (implicit context: GlobalContext): Try[Unit] = {
    Try{
      println(".........Inside generateOpFile..............")
      var outFileName = seg_Seq
      Logger.log.info("..outFileName.." + outFileName)
      var outFileColDelim = ""
      saveFileToMapRFS(df, outputFilePath, outFileName, outFileColDelim, DPOConstants.PARQUET)

    }}

  def generateEPDEOpFile(extractStr: String, outputFilePath: String, seg_Nm: String, seg_Seq: String)(implicit context : GlobalContext): String ={
      var doc_id = 108
      var file_Nm = /*"3.csv"*/ seg_Seq + ".csv"
      var srcPath = outputFilePath + seg_Nm
      var savedFileName = ""
      println(".......Inside generateEPDEOpFile.......... ")
      println("extractStr, outputFilePath - - "+ extractStr + " " + outputFilePath)
      /*import java.io.PrintWriter
      new PrintWriter(srcPath + file_Nm) { write(extractStr); close }*/

      var rdd = context.sparkContext.parallelize(Seq(extractStr)).repartition(1).saveAsTextFile(srcPath)

      savedFileName = fileSystem.globStatus(new Path(srcPath + "/p*"))(0).getPath.getName

      println(".....savedFileName....."+savedFileName)
      var tempPath = s"/datalake/uhclake/tst/t_inbound/uhg/ndb/inbound/VS/Shivani_1_temp/${doc_id}"
     // var destPath = outputFilePath
      println("...........tempPath........... "+tempPath)

      renamePath(srcPath + DPOConstants.SLASH + savedFileName, tempPath + DPOConstants.SLASH + file_Nm)
      //renamePath(srcPath,destPath)
   //   mergeToOneFile(tempPath, srcPath +  DPOConstants.SLASH + "RK4.csv")
      rmPathIfExist(srcPath)
       tempPath

  }

  def generateOpForProv(inputEntity: ExtractFileEntity, provNo: Int, opView: DataFrame)(implicit context: GlobalContext, pei: PEI): ProvExtractOutput = {
    val provFile = inputEntity.extractDetails(provNo - 1)

    val hdrDesc = if (inputEntity.isOutputMerge.equalsIgnoreCase(DPOConstants.YES)) DPOConstants.NA else provFile.provHeaderDesc
    val trlDesc = if (inputEntity.isOutputMerge.equalsIgnoreCase(DPOConstants.YES)) DPOConstants.NA else provFile.provTrailerDesc
    val givenOutFileColDelim = if (inputEntity.isOutputMerge.equalsIgnoreCase(DPOConstants.YES)) pei.outFileColDelim else provFile.provOutFileColDelim
    Logger.log.info(" Given outFileColDelim is :" + givenOutFileColDelim)

    val outFileColDelim = if (givenOutFileColDelim.equalsIgnoreCase(DPOConstants.NA) || givenOutFileColDelim.equalsIgnoreCase("\\t")) {
      DPOConstants.TABDELIM
    }
    else {
      givenOutFileColDelim
    }
    Logger.log.info(" Considered  outFileColDelim  is  :" + outFileColDelim)

    val extractResult = if (hdrDesc == DPOConstants.NA && trlDesc == DPOConstants.NA) {
      generateOpWithoutHDRTRL(opView, provFile, outFileColDelim)
    }
    else {
      generateOpWithHDRTRL(opView, provFile, outFileColDelim)
    }
    extractResult
  }

  /**
    * This method will take the final extract dataframe and save it on HDFS.
    * Returns the String(provCount + ";" + provTempLoc + ";" + outFileNameTemp)
    *
    * @param opView
    * @param provFile
    * @param outFileColDelim
    * @return
    */
  def generateOpWithoutHDRTRL(opView: DataFrame, provFile: ExtractDetail, outFileColDelim: String)(implicit context: GlobalContext, pei: PEI): ProvExtractOutput = {
    Logger.log.debug("Header and Trailer are found to be NA, therefore, generating Extract without HDR and TRL")

    val currentTs = CommonUtil.getCurrentTsFormat // for directory name purpose storing current time in a varaible
    val provTempLoc = ApplicationConfig.rootDir + DPOConstants.SLASH + pei.feedName +
      DPOConstants.SLASH + pei.extractName + DPOConstants.SLASH + DPOConstants.TEMPLOC + currentTs


    val provCount = opView.count().toInt
    val outFileName = assignOutFileName(provFile.provName, false)
    Logger.log.info(s" OutFileName in generateOpWithoutHDRTRL:" + outFileName)
    if (outFileName.contains(DPOConstants.PDFFileExt)) {
      val outFileNameWithoutPDFExt = outFileName.replace(DPOConstants.PDFFileExt, "")
      val dataFileTotalRecords = FileSystemUtil.saveFileToMapRFS(opView, provTempLoc, outFileNameWithoutPDFExt, outFileColDelim, DPOConstants.TEXT)
      Logger.log.info(s"Total Count For ${provTempLoc} ${DPOConstants.SLASH} ${outFileNameWithoutPDFExt}: $dataFileTotalRecords")
      CommonUtil.createPDFFile(provTempLoc, outFileNameWithoutPDFExt, outFileName)
    } else {
      val dataFileTotalRecords = FileSystemUtil.saveFileToMapRFS(opView, provTempLoc, outFileName, outFileColDelim, DPOConstants.TEXT)
      Logger.log.info(s"Total Count For $provTempLoc $DPOConstants.SLASH $outFileName: $dataFileTotalRecords")
    }

    ProvExtractOutput(provCount, provTempLoc, outFileName, false)
  }

  /**
    *
    * @param opView
    * @param provFile
    * @param outFileColDelim
    * @return
    */
  def generateOpWithHDRTRL(opView: DataFrame, provFile: ExtractDetail, outFileColDelim: String)(implicit context: GlobalContext, pei: PEI): ProvExtractOutput = {
    val currentTs = CommonUtil.getCurrentTsFormat // for directory name purpose storing current time in a varaible
    val provTempLoc = ApplicationConfig.rootDir + DPOConstants.SLASH + pei.feedName +
      DPOConstants.SLASH + pei.extractName + DPOConstants.SLASH + DPOConstants.TEMPLOC + currentTs
    val provTempWorkLoc = ApplicationConfig.workingDir + DPOConstants.SLASH + pei.feedName +
      DPOConstants.SLASH + pei.extractName + DPOConstants.SLASH + DPOConstants.TEMPLOC + currentTs
    //val hdrFileDelim = if(provFile.provHeaderDesc.contains("concat")) COMMA else outFileColDelim
    //val trlFileDelim = if(provFile.provTrailerDesc.contains("concat")) COMMA else outFileColDelim
    val hdrFileDelim = outFileColDelim
    val trlFileDelim = outFileColDelim

    val provCount = opView.count()

    val headerDF = getHdrInfo(provFile.provHeaderDesc, provFile.provHeaderDateFormat)
    Logger.log.info(s"Successfully  constructed headerDF : ${headerDF.show(false)}")
    val trailerDF = getTrlInfo(outFileColDelim, provCount, provFile.provTrailerDesc, false)
    Logger.log.info(s"Successfully  constructed trailerDF : ${trailerDF.show(false)}")

    val opTotalLines = FileSystemUtil.
      saveFileToMapRFS(opView, provTempWorkLoc + DPOConstants.DATATEMPLOC, DPOConstants.DATATEMPFILENAME, outFileColDelim, DPOConstants.TEXT)
    val hdrLines = FileSystemUtil.
      saveFileToMapRFS(headerDF, provTempWorkLoc + DPOConstants.HDRTEMPLOC, DPOConstants.HDRTEMPFILENAME, hdrFileDelim, DPOConstants.CSV)
    val trlLines = FileSystemUtil.
      saveFileToMapRFS(trailerDF, provTempWorkLoc + DPOConstants.TRLTEMPLOC, DPOConstants.TRLTEMPFILENAME, trlFileDelim, DPOConstants.CSV)

    val outFileName = assignOutFileName(provFile.provName, true)
    Logger.log.info(s"OutFileName in generateOpWithHDRTRL ${outFileName}")
    FileSystemUtil.mkdirs(provTempLoc)
    val outFileNameWithoutPDFExt = outFileName.replace(DPOConstants.PDFFileExt, "")
    Logger.log.info(s"OutFileNameWithoutPDFExt in generateOpWithHDRTRL ${outFileNameWithoutPDFExt}")
    fileOrder(provTempWorkLoc, provTempLoc, outFileNameWithoutPDFExt)

    if (outFileName.contains(DPOConstants.PDFFileExt)) {
      CommonUtil.createPDFFile(provTempLoc, outFileNameWithoutPDFExt, outFileName)
    }

    Logger.log.info(s"Successfully  Saved extract to given path ${provTempLoc}")
    Logger.log.info(s"Removing temp working location ${ApplicationConfig.workingDir} ${DPOConstants.SLASH} ${pei.feedName} " +
      s"${DPOConstants.SLASH} ${pei.extractName}")
    FileSystemUtil.rmPathIfExist(ApplicationConfig.workingDir + DPOConstants.SLASH + pei.feedName + DPOConstants.SLASH + pei.extractName)

    ProvExtractOutput(provCount, provTempLoc, outFileName, false)
  }

  /**
    *
    * @param inputEntity
    * @param provInfo
    * @param prtFileNameLen
    * @param context
    * @return
    */
  def generateMergedOpForJsonExtract(inputEntity: ExtractFileEntity, provInfo: Seq[ProvExtractOutput], prtFileNameLen: Int)
                                    (implicit context: GlobalContext, pei: PEI): Tuple2[String, String] = {
    Logger.log.info("Merging outputs for different provisions")
    val currentTs = CommonUtil.getCurrentTsFormat
    val provTempLoc = ApplicationConfig.rootDir + DPOConstants.SLASH + pei.feedName +
      DPOConstants.SLASH + pei.extractName + DPOConstants.SLASH + DPOConstants.TEMPLOC + currentTs
    val provTempWorkLoc = ApplicationConfig.workingDir + DPOConstants.SLASH + pei.feedName +
      DPOConstants.SLASH + pei.extractName + DPOConstants.SLASH + DPOConstants.TEMPLOC + currentTs
    if (prtFileNameLen > 2) {
      Logger.log.info(s"NOT Executing the extract save function for moving to one folder since provName in json has three parts")
    } else {
      Logger.log.info(s"Moving the provisions to one folder:  $provTempLoc ")
      val provFiles = provInfo.map(prov => prov.provLoc + DPOConstants.SLASH + prov.provFileName)
      FileSystemUtil.moveProvsToOneLoc(provFiles, provTempLoc)
    }

    if (inputEntity.isOutputMerge.equalsIgnoreCase(DPOConstants.YES)) {
      if (inputEntity.extractHeaderTrailerRequired.equalsIgnoreCase(DPOConstants.YES) &&
        (!pei.hdrDesc.equalsIgnoreCase(DPOConstants.NA)) &&
        (!pei.trlDesc.equalsIgnoreCase(DPOConstants.NA))) {
        generateMergedOpWithHDRTRL(provTempWorkLoc, provTempLoc, provInfo)
      } else {
        generateMergedOpWithoutHDRTRL(provTempLoc, provInfo)
      }
    }

    (provTempLoc, pei.outFileName.split('|')(0))

  }


  /**
    *
    * @param pei
    * @param provTempLoc
    * @param provInfo
    */
  def generateMergedOpWithoutHDRTRL(provTempLoc: String, provInfo: Seq[ProvExtractOutput])(implicit pei: PEI): Unit = {
    Logger.log.info(s"Generating merged extract without header and trailer")
    Logger.log.info(s"Merging the files from   $provTempLoc to $provTempLoc  ${DPOConstants.SLASH} ${pei.outFileName.split('|')(0)}")
    FileSystemUtil.mergeToOneFile(provTempLoc, provTempLoc + DPOConstants.SLASH + pei.outFileName.split('|')(0))
    val provFileNames = provInfo.map(prov => prov.provFileName)
    Logger.log.info(s"Removing files from Dir $provTempLoc, FileNames ${provFileNames.mkString("~")}")
    FileSystemUtil.removeFilesfromMaprFS(provTempLoc, provFileNames)
  }

  /**
    *
    * @param pei
    * @param provTempLoc
    * @param provInfo
    */
  def generateMergedOpWithHDRTRL(provTempWorkLoc: String, provTempLoc: String, provInfo: Seq[ProvExtractOutput])(implicit context: GlobalContext, pei: PEI): Unit = {
    val hdrFileDelim = if (pei.hdrDesc.contains("concat")) DPOConstants.COMMA else pei.outFileColDelim
    val trlFileDelim = if (pei.trlDesc.contains("concat")) DPOConstants.COMMA else pei.outFileColDelim

    //Merging files from provTempLoc to provTempLoc/data/file2data.csv --- Files in provTempLoc -> all the files generated from all provisions
    Logger.log.info(s" merging the files from( $provTempWorkLoc ) to ( $provTempWorkLoc $DPOConstants.DATATEMPLOC ${DPOConstants.DATATEMPFILENAME} )   ")
    FileSystemUtil.mkdirs(provTempWorkLoc + DPOConstants.DATATEMPLOC)
    FileSystemUtil.mergeToOneFile(provTempWorkLoc, provTempWorkLoc + DPOConstants.DATATEMPLOC + DPOConstants.DATATEMPFILENAME)
    val provFileNames = provInfo.map(prov => prov.provFileName)
    Logger.log.info(s" removing files from Dir( " + provTempWorkLoc + " ), FileNames ( " + provFileNames.mkString("~") + " )   ")
    FileSystemUtil.removeFilesfromMaprFS(provTempWorkLoc, provFileNames)

    val headerDF = getHdrInfo(pei.hdrDesc, pei.hdrDateFormat)
    Logger.log.info(s" Successfully  constructed headerDF : ${headerDF.show(false)}  ")

    val dataDFCount = FileSystemUtil.getHDFSFileRecCount(provTempLoc + DPOConstants.DATATEMPFILENAME)
    val trailerDF = getTrlInfo(pei.outFileColDelim, dataDFCount, pei.trlDesc, true)
    Logger.log.info(s" Successfully  constructed trailerDF : ${trailerDF.show(false)}   ")

    val hdrLines = FileSystemUtil.
      saveFileToMapRFS(headerDF, provTempWorkLoc + DPOConstants.HDRTEMPLOC, DPOConstants.HDRTEMPFILENAME, hdrFileDelim, DPOConstants.CSV)
    val trlLines = FileSystemUtil.
      saveFileToMapRFS(trailerDF, provTempWorkLoc + DPOConstants.TRLTEMPLOC, DPOConstants.TRLTEMPFILENAME, trlFileDelim, DPOConstants.CSV)

    FileSystemUtil.mkdirs(provTempLoc)
    fileOrder(provTempWorkLoc, provTempLoc, pei.outFileName.split('|')(0))
    Logger.log.info(s" Successfully  Saved extract to geven path $provTempLoc ")
    Logger.log.info(s" Removing temp working location " + ApplicationConfig.workingDir +
      DPOConstants.SLASH + pei.feedName + DPOConstants.SLASH + pei.extractName)
    FileSystemUtil.rmPathIfExist(ApplicationConfig.workingDir + DPOConstants.SLASH + pei.feedName + DPOConstants.SLASH + pei.extractName)
  }


  /**
    *
    * @param provName
    * @param context
    * @return
    */
  def assignOutFileName(provName: String, isHdr: Boolean)(implicit context: GlobalContext): String = {

    val provFileNameLen = provName.split('|').length
    val provFileName = if (provFileNameLen > 2) provName.split('|')(0) else provName

    if (provFileName.contains("YYYYMMDD-HHMMSS")) {
      CommonUtil.replaceDateAndTime(provFileName, isHdr)
    } else if (provFileName.contains("$YYYYMMDD")) {
      CommonUtil.replaceDate(provFileName)
    } else if (provFileName.contains("$NUM")) {
      CommonUtil.assignSeqNumFromFile(ApplicationConfig.workingDir + DPOConstants.SLASH + DPOConstants.SEQ_FILE_NAME, provFileName)
    } else {
      provFileName
    }

  }

  /**
    *
    * @param pei
    * @param finalProvView
    * @param pitRowKey
    * @param context
    * @return
    */
  def generateTransformedExtract(outCols: String, outColLen: String, finalProvView: String, pitRowKey: String)
                                (implicit context: GlobalContext, pei: PEI): DataFrame = {
    val transformedView = generateTransformedView(outCols, outColLen, finalProvView)
    val sqlOPDQuery = s"SELECT ${outCols.replace(';', ',')}  FROM $transformedView"
    val finalExtract = context.sqlContext.sql(sqlOPDQuery)
    val provCount = finalExtract.count()
    Logger.log.debug(s" Output file delimiter  Query Record Count : $provCount  ")
    Logger.log.debug(s" Successfully  executed  Output file delimiter  Query : ${finalExtract.show()} ")
    context.pitTable.put(pitRowKey, "exi", "provRecCnt", provCount.toString)
    finalExtract
  }

  /**
    * This method takes the final view and transforms the view as required
    *  - Removes unprintableASCII characters
    *  - Transforms if it is fixed width
    *
    * @param opView
    * @param context
    * @return
    */
  def generateTransformedView(outCols: String, outColLen: String, opView: String)(implicit context: GlobalContext, pei: PEI): String = {

    val finalQuery = s"select * from $opView"
    val finalProvDF = context.sqlContext.sql(finalQuery)

    val transformedRDD = SparkUtil.removeUnPrintableCharFromRDD(finalProvDF.rdd)
    val transformedDF = context.sqlContext.createDataFrame(transformedRDD, finalProvDF.schema)
    transformedDF.createOrReplaceTempView(DPOConstants.TRANSFORMED_FINAL_JSON_DF)

    if (pei.isFixedWidth == "Y") {
      val sqlRPADString = getRPaddedQuery(outCols, outColLen, DPOConstants.TRANSFORMED_FINAL_JSON_DF)
      val RPaddedDF = context.sqlContext.sql(sqlRPADString)
      RPaddedDF.createOrReplaceTempView(DPOConstants.TRANSFORMED_FINAL_JSON_DF)
    }
    DPOConstants.TRANSFORMED_FINAL_JSON_DF
  }

  /**
    * This method takes the final data spark viewname and returns a new query including RPadding
    *
    * @param pei
    * @param viewName
    * @return
    */
  private def getRPaddedQuery(outCols: String, outColLen: String, viewName: String)(implicit pei: PEI): String = {
    val spTrgCols = outCols.split(';')
    val spTrgColsLen = outColLen.split(';')

    if (spTrgCols.length != spTrgColsLen.length) {
      Logger.log.info(s"Number of target columns do not match with number of target Data Type lengths provided, hence ending the workflow with Failed status")
      throw new DPOException("Number of target columns do not match with the number of target Data Type lengths provided")
    }
    val sqlString = spTrgCols.zip(spTrgColsLen).map { (colMeta) => s"RPAD(${colMeta._1},${colMeta._2},' ') AS ${colMeta._1}" }.mkString(",")
    val RPADString = s"SELECT $sqlString FROM $viewName"
    Logger.log.info(s" Constructed sql String is: " + RPADString)
    RPADString
  }


  /**
    *
    * @param hdrDesc
    * @param hdrDateFormat
    * @param context
    * @return
    */
  def getHdrInfo(hdrDesc: String, hdrDateFormat: String)(implicit context: GlobalContext): DataFrame = {
    if (hdrDesc.equalsIgnoreCase(DPOConstants.NA)) {
      context.sqlContext.emptyDataFrame
    } else if (hdrDesc.contains(DPOConstants.SELECT)) {
      createHeaderOrTrailerFromQuery(hdrDesc, "hdrQuery", DPOConstants.HEADER_VIEW)
    } else {
      createHeaderFromHDRDesc(hdrDesc, hdrDateFormat)
    }
  }

  /**
    *
    * @param hdrOrTrlQuery
    * @param hdrOrTrlName
    * @param viewName
    * @return
    */
  def createHeaderOrTrailerFromQuery(hdrOrTrlQuery: String, hdrOrTrlName: String, viewName: String)(implicit context: GlobalContext): DataFrame = {
    import org.apache.spark.sql._
    val hdrOrTrlDF = SparkUtil.createDataFrameFromData(Row(hdrOrTrlQuery), Seq(hdrOrTrlName))
    //hdrOrTrlDF.createOrReplaceTempView(viewName)
    //context.sqlContext.sql(s"select * FROM $viewName")
    val hdrOrTrlSqlDF = context.sqlContext.sql(hdrOrTrlDF.head.getString(0))
    hdrOrTrlSqlDF.persist()
    hdrOrTrlSqlDF.createOrReplaceTempView(viewName)
    hdrOrTrlSqlDF
  }

  /**
    *
    * @param hdrDesc
    * @param hdrDateFormat
    * @return
    */
  def createHeaderFromHDRDesc(hdrDesc: String, hdrDateFormat: String)(implicit context: GlobalContext): DataFrame = {
    val hdrRowID = hdrDesc.split(';')(0)
    val hdrFileName = hdrDesc.split(';')(2)
    val hdrDate = CommonUtil.getCurrentDateTime(hdrDateFormat)

    val hdrDF = SparkUtil.createDataFrameFromData(Row(hdrRowID, hdrDate, hdrFileName), Seq("DATA_ID", "HdrDate", "HdrDes"))
    hdrDF.createOrReplaceTempView(DPOConstants.HEADER_VIEW)
    context.sqlContext.sql(s"SELECT DATA_ID,HdrDate,HdrDes from ${DPOConstants.HEADER_VIEW}")
  }

  /** Purpose : Def to get trailer dataframe
    * input : trailerDelimiter, dataDataFrame for record count , trailerDescription
    * output: Returns trailerDF */
  def getTrlInfo(trlDelimeter: String, dataCount: Long, trlDesc: String, isDelimited: Boolean)(implicit context: GlobalContext): DataFrame = {
    if (trlDesc.equalsIgnoreCase(DPOConstants.NA)) {
      context.sqlContext.emptyDataFrame
    } else if (trlDesc.contains(DPOConstants.SELECT)) {
      createHeaderOrTrailerFromQuery(trlDesc, "trlQuery", DPOConstants.TRAILER_VIEW)
    } else {
      createTrailerFromTrlDesc(trlDelimeter, dataCount, trlDesc, isDelimited)
    }
  }

  /**
    *
    * @param trlDesc
    * @param recordCount
    * @param trlDelimiter
    * @param isDelimited
    * @return
    */
  def createTrailerFromTrlDesc(trlDelimiter: String, recordCount: Long, trlDesc: String, isDelimited: Boolean)(implicit context: GlobalContext): DataFrame = {
    val trlRowID = trlDesc.split(';')(0)
    val leadingNumber = trlDesc.split(';')(1)
    val wildCharac = trlDesc.split(';')(2)
    val trlRecCnt = s"%${wildCharac}${leadingNumber}d".format(recordCount)

    import org.apache.spark.sql._
    // to get rid of  Row is ambiguous from import org.apache.hadoop.hbase.client._
    val trlDF = SparkUtil.createDataFrameFromData(Row(trlRowID, trlRecCnt), Seq("DATA_ID", "RecCnt"))
    trlDF.createOrReplaceTempView(DPOConstants.TRAILER_VIEW)
    if (isDelimited) {
      context.sqlContext.sql(s"select DATA_ID,RecCnt from ${DPOConstants.TRAILER_VIEW}")
    } else {
      context.sqlContext.sql(s"select concat_ws('" + trlDelimiter + "'" + s",DATA_ID,RecCnt) AS RID from ${DPOConstants.TRAILER_VIEW}")
    }
  }

  /**
    *
    * @param opView
    * @param context
    * @param pei
    * @return
    */
  def outputGenratorForMetaExtract(opView: DataFrame)(implicit context: GlobalContext, pei: PEI): ProvExtractOutput = {
    //if (pei.sqlQuery == DPOConstants.NA)
    val outFileColDelim = if (pei.outFileColDelim.equalsIgnoreCase(DPOConstants.NA) || pei.outFileColDelim.equalsIgnoreCase("\\t")) {
      DPOConstants.TABDELIM
    }
    else {
      pei.outFileColDelim
    }
    val extractResult = if (pei.hdrDesc == DPOConstants.NA || pei.trlDesc == DPOConstants.NA) {
      generateMetaOpWithoutHDRTRL(opView, outFileColDelim)
    }
    else {
      generateMetaOpWithHDRTRL(opView, outFileColDelim)
    }
    extractResult
  }

  /**
    *
    * @param opView
    * @param outFileColDelim
    * @param context
    * @param pei
    * @return
    */
  def generateMetaOpWithoutHDRTRL(opView: DataFrame, outFileColDelim: String)(implicit context: GlobalContext, pei: PEI): ProvExtractOutput = {
    Logger.log.debug("Header and Trailer are found to be NA, therefore, generating Extract without HDR and TRL")

    val currentTs = CommonUtil.getCurrentTsFormat // for directory name purpose storing current time in a varaible
    val provTempLoc = ApplicationConfig.rootDir + DPOConstants.SLASH + pei.feedName +
      DPOConstants.SLASH + pei.extractName + DPOConstants.SLASH + DPOConstants.TEMPLOC + currentTs

    val provCount = opView.count().toInt
    val outFileName = assignOutFileName(pei.outFileName.split('|')(0), false)

    if (outFileName.contains(DPOConstants.PDFFileExt)) {
      val outFileNameWithoutPDFExt = outFileName.replace(DPOConstants.PDFFileExt, "")
      val dataFileTotalRecords = FileSystemUtil.saveFileToMapRFS(opView, provTempLoc, outFileNameWithoutPDFExt, outFileColDelim, DPOConstants.TEXT)
      Logger.log.info(s"s total Count For $provTempLoc$DPOConstants.SLASH$outFileNameWithoutPDFExt: $dataFileTotalRecords")
      CommonUtil.createPDFFile(provTempLoc, outFileNameWithoutPDFExt, outFileName)
    } else {
      val dataFileTotalRecords = FileSystemUtil.saveFileToMapRFS(opView, provTempLoc, outFileName, outFileColDelim, DPOConstants.TEXT)
      Logger.log.info(s"s total Count For $provTempLoc$DPOConstants.SLASH$outFileName: $dataFileTotalRecords")
    }

    ProvExtractOutput(provCount, provTempLoc, outFileName, false)
  }

  /**
    *
    * @param opView
    * @param outFileColDelim
    * @return
    */
  def generateMetaOpWithHDRTRL(opView: DataFrame, outFileColDelim: String)(implicit context: GlobalContext, pei: PEI): ProvExtractOutput = {

    val currentTs = CommonUtil.getCurrentTsFormat // for directory name purpose storing current time in a varaible
    val provTempLoc = ApplicationConfig.rootDir + DPOConstants.SLASH + pei.feedName +
      DPOConstants.SLASH + pei.extractName + DPOConstants.SLASH + DPOConstants.TEMPLOC + currentTs
    val provTempWorkLoc = ApplicationConfig.workingDir + DPOConstants.SLASH + pei.feedName +
      DPOConstants.SLASH + pei.extractName + DPOConstants.SLASH + DPOConstants.TEMPLOC + currentTs
    //val hdrFileDelim = if(pei.hdrDesc.contains("concat")) COMMA else outFileColDelim
    //val trlFileDelim = if(pei.trlDesc.contains("concat")) COMMA else outFileColDelim
    val hdrFileDelim = outFileColDelim
    val trlFileDelim = outFileColDelim

    val provCount = opView.count()
    Logger.log.info(s" opView in generateMetaOpWithHDRTRL: ${opView.show()} ")
    Logger.log.info(s" provCount in generateMetaOpWithHDRTRL: $provCount ")
    val headerDF = getHdrInfo(pei.hdrDesc, pei.hdrDateFormat)
    Logger.log.info(s" Successfully  constructed headerDF : ${headerDF.show(false)}  ")
    val trailerDF = getTrlInfo(outFileColDelim, provCount, pei.trlDesc, false)
    Logger.log.info(s" Successfully  constructed trailerDF : ${trailerDF.show(false)}   ")

    val opTotalLines = FileSystemUtil.
      saveFileToMapRFS(opView, provTempWorkLoc + DPOConstants.DATATEMPLOC, DPOConstants.DATATEMPFILENAME, outFileColDelim, DPOConstants.TEXT)
    val hdrLines = FileSystemUtil.
      saveFileToMapRFS(headerDF, provTempWorkLoc + DPOConstants.HDRTEMPLOC, DPOConstants.HDRTEMPFILENAME, hdrFileDelim, DPOConstants.CSV)
    val trlLines = FileSystemUtil.
      saveFileToMapRFS(trailerDF, provTempWorkLoc + DPOConstants.TRLTEMPLOC, DPOConstants.TRLTEMPFILENAME, trlFileDelim, DPOConstants.CSV)

    val outFileName = assignOutFileName(pei.outFileName.split('|')(0), true)
    Logger.log.info(s" outFileName in generateMetaOpWithHDRTRL $outFileName   ")
    FileSystemUtil.mkdirs(provTempLoc)
    fileOrder(provTempWorkLoc, provTempLoc, outFileName)

    if (outFileName.contains(DPOConstants.PDFFileExt)) {
      val outFileNameWithoutPDFExt = outFileName.replace(DPOConstants.PDFFileExt, "")
      CommonUtil.createPDFFile(provTempLoc, outFileNameWithoutPDFExt, outFileName)
    }

    Logger.log.info(s" Successfully  Saved extract to given path $provTempLoc ")
    //Logger.log.info(s" Removing temp working location" + ApplicationConfig.workingDir +  "/" + pei.feedName + "/" + pei.extractName)
    //FileSystemUtil.rmPathIfExist(ApplicationConfig.workingDir +  "/" + pei.feedName + "/" + pei.extractName)
    ProvExtractOutput(provCount, provTempLoc, outFileName, false)
  }

  /**
    *
    * @param provTempWorkLoc
    * @param provTempLoc
    * @param outFileName
    */
  def fileOrder(provTempWorkLoc: String, provTempLoc: String, outFileName: String): Unit = {
    Logger.log.info(s"fileOrder inititated with values provTempWorkLoc : $provTempWorkLoc , provTempLoc : $provTempLoc ,  outFileName : $outFileName")
    Logger.log.info(s" Merging the DF's / Files as per Order Sequence i.e HDR -> DATA -> TRL ")
    Logger.log.info(s" Step1 : moving files from data, hdr, trl locations to temp folder location ")
    FileSystemUtil.
      renamePath(provTempWorkLoc + DPOConstants.DATATEMPLOC + DPOConstants.SLASH +
        DPOConstants.DATATEMPFILENAME, provTempWorkLoc + DPOConstants.SLASH + DPOConstants.DATATEMPFILENAME)
    FileSystemUtil.
      renamePath(provTempWorkLoc + DPOConstants.HDRTEMPLOC + DPOConstants.SLASH +
        DPOConstants.HDRTEMPFILENAME, provTempWorkLoc + DPOConstants.SLASH + DPOConstants.HDRTEMPFILENAME)
    FileSystemUtil.
      renamePath(provTempWorkLoc + DPOConstants.TRLTEMPLOC + DPOConstants.SLASH +
        DPOConstants.TRLTEMPFILENAME, provTempWorkLoc + DPOConstants.SLASH + DPOConstants.TRLTEMPFILENAME)
    Logger.log.info(s" Step2 : removing files from data, hdr, trl folders from temp folder location ")
    FileSystemUtil.rmPathIfExist(provTempWorkLoc + DPOConstants.DATATEMPLOC)
    FileSystemUtil.rmPathIfExist(provTempWorkLoc + DPOConstants.HDRTEMPLOC)
    FileSystemUtil.rmPathIfExist(provTempWorkLoc + DPOConstants.TRLTEMPLOC)

    Logger.log.info(s" Before Merging the 3 files, counts are")
    FileSystemUtil.mergeToOneFile(provTempWorkLoc, provTempLoc + DPOConstants.SLASH + outFileName)

    Logger.log.info(s" Step3 :Removing renamed files from Dir( $provTempWorkLoc ), " +
      s"FileNames (${DPOConstants.HDRTEMPFILENAME}, ${DPOConstants.DATATEMPFILENAME}, ${DPOConstants.TRLTEMPFILENAME} )")

    FileSystemUtil.removeFilesfromMaprFS(provTempWorkLoc, Seq(DPOConstants.HDRTEMPFILENAME, DPOConstants.DATATEMPFILENAME, DPOConstants.TRLTEMPFILENAME))

    Logger.log.info(s" Step4 : moving merged file to actual temp location : ${provTempLoc + DPOConstants.SLASH + outFileName}")

    Logger.log.info(s" Step5 : Removing merged temp location    ")
    FileSystemUtil.rmPathIfExist(provTempWorkLoc)
  }


  /**
    *
    * @param prtFileName
    * @param extractFilePath
    * @param extractFileName
    * @param pitRowKey
    * @param context
    * @param pei
    * @return
    */
  def createMetaFile(prtFileName: String, extractFilePath: String, extractFileName: String, pitRowKey: String)(implicit context: GlobalContext, pei: PEI): String = {
    val prtFileNameLen = prtFileName.split('|').length
    val outFileName = if (prtFileNameLen > 2) prtFileName.split('|')(0) else pei.outFileName.split('|')(0)
    val zipFileName = if (prtFileNameLen > 2) prtFileName.split('|')(2) else if (prtFileNameLen > 1) pei.outFileName.split('|')(1) else DPOConstants.NA
    val updatedZipName = if (zipFileName.contains("$YYYYMMDD")) CommonUtil.replaceDate(zipFileName) else zipFileName

    val metaBuilder = StringBuilder.newBuilder
    metaBuilder.append(s"pitTabName=${ApplicationConfig.pitTabName}${DPOConstants.NEWLINECHAR}")
    metaBuilder.append(s"pitRowKey=$pitRowKey${DPOConstants.NEWLINECHAR}")
    metaBuilder.append(s"extractFilePath=$extractFilePath${DPOConstants.NEWLINECHAR}")
    metaBuilder.append(s"extractFileName=$extractFileName${DPOConstants.NEWLINECHAR}")
    metaBuilder.append(s"outFileLoc=${pei.outFileLoc}${DPOConstants.NEWLINECHAR}")
    metaBuilder.append(s"outFileName=$outFileName${DPOConstants.NEWLINECHAR}")
    metaBuilder.append(s"outFileExt=${pei.outFileExt}${DPOConstants.NEWLINECHAR}")
    metaBuilder.append(s"archLoc=${pei.archLoc}${DPOConstants.NEWLINECHAR}")
    metaBuilder.append(s"peiTab=${ApplicationConfig.peiTabName}${DPOConstants.NEWLINECHAR}")
    metaBuilder.append(s"securityfileLoc=${ApplicationConfig.securityfileLoc}${DPOConstants.NEWLINECHAR}")
    metaBuilder.append(s"zipFileName=$updatedZipName${DPOConstants.NEWLINECHAR}")
    //metaBuilder.append(s"inputFileLocation=${pei.inputFileLocation}${DPOConstants.NEWLINECHAR}")
    metaBuilder.append(s"inputFileLocation=${inboxDir}${DPOConstants.NEWLINECHAR}")
    val metaContent = metaBuilder.mkString("")
    FileSystemUtil.createHDFSFile(extractFilePath + DPOConstants.META_FILE_NAME, metaContent)
    Logger.log.info(s"MetaFile created")
    metaContent
  }


  def createMetaFile : String = ???
}