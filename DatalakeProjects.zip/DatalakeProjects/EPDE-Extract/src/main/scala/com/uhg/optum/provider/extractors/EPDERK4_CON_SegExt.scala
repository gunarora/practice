package com.uhg.optum.provider.extractors

import com.uhg.optum.common.DPOConstants
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDERK4InputJsonSchema.SegmentDetails
import com.uhg.optum.provider.output.OuptutGenerator
import com.uhg.optum.util.CommonUtil._
import com.uhg.optum.util.{EPDECommonUtil, FileSystemUtil, Logger}

trait EPDERK4_CON_SegExt extends OuptutGenerator{
  def genCONSeg(segDetails:SegmentDetails,varLst:collection.mutable.Map[String, String],glblVarLst:collection.mutable.Map[String, String],segLocation:String)(implicit context: GlobalContext): String = {
    try{
    var df_CON = context.sqlContext.emptyDataFrame
    var rs="N"
    Logger.log.info("Segment CON Creation Start")
    val sparkSession = context.sparkSession
    import sparkSession.implicits._
   /* var df_CONT=Seq(
      ("EXMNR","O", "000002492", "102971859", "341783789", "033"),
      ("EXMNR","O", "000002492", "102971863", "341783789", "033"),
      ("EXMNR","O", "000002492", "102971861", "341783789", "033"),
      ("EXMNR","O", "000002492", "102971862", "341783789", "033"),
      ("EXMNR","O", "000002492", "102971866", "341783789", "033"),
      ("EXMNR","O", "000002492", "102971864", "341783789", "033"),
      ("EXMNR","O", "000002492", "102971865", "341783789", "033"),
      ("EXMNR","O", "000002492", "163171890", "341783789", "033"),
      ("EXMNR","O", "000002492", "163171889", "341783789", "033"),
      ("EXMNR","O", "000002492", "163171888", "341783789", "033"),
      ("EXMNR","O", "000002492", "085124499", "341783789", "033"),
      ("EXMNR","O", "000002492", "085124498", "341783789", "033")
    ).toDF("CONTR_OUT_VENDR_CD","CONTR_OUT_PROV_TYP_CD","CONTR_OUT_PROV_ID","CONTR_OUT_CONTR_ID","CONTR_OUT_TAX_ID_NBR","CONTR_OUT_ORG_TYP_CD")*/
    if (segDetails.segName.equals("CON")) {
        //Segment query execution in sequence
        EPDECommonUtil.generateSegTables(segDetails.segTables,varLst)

      //df_CONT.createOrReplaceTempView("SELCONT")
        segDetails.segQueries.foreach { qryKey =>
          Logger.log.info("qryKey.name --> " + qryKey.name)
          df_CON = executeQry(varLst, qryKey)
          createOrReplaceTempViewFn(df_CON.dropDuplicates, qryKey.name)
          //df_CON.printSchema()
          //Logger.log.info(s"${qryKey.name} count :::: ${df_CON.dropDuplicates.count}")
          /*if(qryKey.name.equalsIgnoreCase("CON_SELPRD")){
            FileSystemUtil.saveFileToMapRFS(df_CON,glblVarLst.get("tmpVwPath").getOrElse(""),qryKey.name,"",DPOConstants.PARQUET)
          }*/
        }
        // Segment parquet file generation
        FileSystemUtil.saveFileToMapRFSNoRepartitionParquet(df_CON.dropDuplicates,segLocation,"CON_FNL_VIEW","",DPOConstants.PARQUET)
        rs="Y"
        /*if (df_CON.count() > 0) {
         /* val tinDf = generateRpadQry(segDetails.segTarCol, segDetails.segTarLen, segDetails.segTolLen, "CON_FNL_VIEW")
          Logger.log.info("CON RPAD Query")
          tinDf.show()
          Logger.log.info("...Inside CON -> outputFilePath, seg_Seq..." + segLocation + " " + segDetails.segSeq)
          FileSystemUtil.saveFileToMapRFS(tinDf,segLocation,"CON_FNL_VIEW_TXT","",DPOConstants.TEXT)*/
          rs="Y"
        } else {
          Logger.log.info("ERROR FETCHING CON")
          rs="N"
        }*/
      }
    //val tinCount = df_CON.count()
    Logger.log.info(s"CON segment generated")
    rs
    }catch {

      case e: Exception => {
        Logger.log.info(s"RK4 : EPDERK4_CON_SegExt.genCONSeg() : "+e.getMessage)
        throw e
      }

    }
  }
}
