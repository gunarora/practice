package com.uhg.optum.protocols

import org.apache.hadoop.hbase.client.Result
import org.apache.hadoop.hbase.util.Bytes
import spray.json._
import DefaultJsonProtocol._
import com.uhg.optum.JobRunner.{PEI, PSC}
import com.uhg.optum.common.{DAOModel, DPOConstants}
import com.uhg.optum.dao.{HbaseDAOModel, LocalDAOModel}
import com.uhg.optum.protocols.PEIProtocol.Converter

trait DomainModel

/**
  * Created by paror18 on 9/23/2018.
  */
object PEIProtocol {

  trait Converter[A <: DAOModel, B <: DomainModel] {
    def convert(a: A): B
  }

  implicit object DAOModelToPEIDomain extends Converter[DAOModel, PEI] {
    override def convert(a: DAOModel): PEI = {
      if(a.isInstanceOf[LocalDAOModel]) {
        LocalModelToPEIDomain.convert(a.asInstanceOf[LocalDAOModel])
      } else
        HbaseModelToPEIDomain.convert(a.asInstanceOf[HbaseDAOModel])
    }

  }

  implicit object LocalModelToPEIDomain extends Converter[LocalDAOModel, PEI] {
    override def convert(a: LocalDAOModel): PEI = {
      a.jsObject match {
        case JsObject(value) =>
          value.get(a.colFm).get.convertTo[PEI]
      }
    }
  }

  implicit object HbaseModelToPEIDomain extends Converter[HbaseDAOModel, PEI] {
    override def convert(a: HbaseDAOModel): PEI = {
      val cfDataBytes = Bytes.toBytes(a.colFamily)
      val ext = (fieldName: String) => Bytes.toString(a.result.getValue(cfDataBytes, Bytes.toBytes(fieldName)))
      PEI(
        ext("feedName"), ext("extractName"), ext("hdrDesc"), ext("hdrDateFormat"), ext("trlDesc"),
        ext("isJsonProp"), ext("jsonPropFileLoc"), ext("sqlQuery"), ext("transQuery"), ext("trgColumn"), ext("trgDataTypeLen"),
        ext("outFileName"), ext("outFileExt"), ext("outFileLoc"), ext("archLoc"), ext("isOutFileColDelim"), ext("outFileColDelim"), ext("isFixedWidth"),
        ext("srcCd"), ext("prtnrCd"), ext("entitySet"), ext("snapBuildType"), ext("isOutFileRowDelim"), ext("outFileRowDelim"),
        ext("consumingApp"), ext("inputFileName"), ext("inputFileLocation"), ext("inputLandingLocation")
      )
    }
  }

  import scala.language.implicitConversions
  implicit def DAOModelToDomain[A <: DAOModel, B <: DomainModel](a : A)(implicit converter : Converter[A, B]) : B = converter.convert(a)

  implicit object PEIJsonFormat extends RootJsonFormat[PEI] {

    override def write(obj: PEI): JsValue = {
      JsObject("archLoc" -> JsString(obj.archLoc),
        "consumingApp" -> JsString(obj.consumingApp),
        "entitySet" -> JsString(obj.entitySet),
        "extractName" -> JsString(obj.extractName),
        "feedName" -> JsString(obj.feedName),
        "hdrDateFormat" -> JsString(obj.hdrDateFormat),
        "hdrDesc" -> JsString(obj.hdrDesc),
        "inputFileLocation" -> JsString(obj.inputFileLocation),
        "inputFileName" -> JsString(obj.inputFileName),
        "inputLandingLocation" -> JsString(obj.inputLandingLocation),
        "isFixedWidth" -> JsString(obj.isFixedWidth),
        "isJsonProp" -> JsString(obj.isJsonProp),
        "isOutFileColDelim" -> JsString(obj.isOutFileColDelim),
        "isOutFileRowDelim" -> JsString(obj.isOutFileRowDelim),
        "jsonPropFileLoc" -> JsString(obj.jsonPropFileLoc),
        "outFileColDelim" -> JsString(obj.outFileColDelim),
        "outFileExt" -> JsString(obj.outFileExt),
        "outFileLoc" -> JsString(obj.outFileLoc),
        "outFileName" -> JsString(obj.outFileName),
        "outFileRowDelim" -> JsString(obj.outFileRowDelim),
        "prtnrCd" -> JsString(obj.prtnrCd),
        "snapBuildType" -> JsString(obj.snapBuildType),
        "sqlQuery" -> JsString(obj.sqlQuery),
        "srcCd" -> JsString(obj.srcCd),
        "transQuery" -> JsString(obj.transQuery),
        "trgColumn" -> JsString(obj.trgColumn),
        "trgDataTypeLen" -> JsString(obj.trgDataTypeLen),
        "trlDesc" -> JsString(obj.trlDesc)
      )
    }

    override def read(value: JsValue): PEI = {
      val fields = value.asJsObject("Invalid Json").fields
      val ext = (fieldName :String) => fields.get(fieldName).get.convertTo[String]

      new PEI(ext("feedName"), ext("extractName"), ext("hdrDesc"), ext("hdrDateFormat"), ext("trlDesc"),
        ext("isJsonProp"), ext("jsonPropFileLoc"), ext("sqlQuery"), ext("transQuery"), ext("trgColumn"), ext("trgDataTypeLen"),
        ext("outFileName"), ext("outFileExt"), ext("outFileLoc"), ext("archLoc"), ext("isOutFileColDelim"), ext("outFileColDelim"), ext("isFixedWidth"),
        ext("srcCd"), ext("prtnrCd"), ext("entitySet"), ext("snapBuildType"), ext("isOutFileRowDelim"), ext("outFileRowDelim"),
        ext("consumingApp"), ext("inputFileName"), ext("inputFileLocation"), ext("inputLandingLocation")
      )
    }
  }

}
