package com.uhg.optum.provider.extractors

import com.uhg.optum.common.DPOConstants
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDERK4InputJsonSchema.SegmentDetails
import com.uhg.optum.provider.output.OuptutGenerator
import com.uhg.optum.util.CommonUtil.{createOrReplaceTempViewFn, executeQry}
import com.uhg.optum.util.{CommonUtil, EPDECommonUtil, FileSystemUtil, Logger}
import com.uhg.optum.conf.ApplicationConfig.workingDir

import scala.util.Try

trait EPDERK4_PFA_SegExt extends OuptutGenerator{

  def genPFASeg(segDtls: SegmentDetails,varLst:collection.mutable.Map[String, String],glblVarLst:collection.mutable.Map[String, String],SW_SKIP_PFA:String,outputFilePath:String)(implicit context: GlobalContext): String = {
  try{
    Logger.log.info("Inside pfaSegGen")
    Logger.log.info("Initializing variables..")
    var Seg_Nm, Seg_Seq = ""
    var retStr = "N"

      if (segDtls.equals("") || segDtls == null) {
        Logger.log.info("No segment details present for PFA Segment")
      }
      if (!context.sparkSession.catalog.tableExists("PRV_FINAL_VIEW")) {
        Logger.log.info("The temporary view PRV_FINAL_VIEW from NPI segment is required for PFA segment")
      }
      if (SW_SKIP_PFA.equals("N")) {
        var SchemaNm = DPOConstants.SCHEMA
        Logger.log.info("SchemaNm: " + SchemaNm)
        if (segDtls.segName.equals("PFA")) {
          EPDECommonUtil.generateSegTables(segDtls.segTables,glblVarLst)
          Seg_Nm = segDtls.segName
          Seg_Seq = segDtls.segSeq
          Logger.log.info("Inside PFA")
          segDtls.segQueries.map { qryKey =>
            if (qryKey.name.equals("PFA_FNL_VIEW")) {
              Logger.log.info("Inside PFA_FNL_VIEW")
              val PFA_FNL_VIEW =executeQry(glblVarLst,qryKey)
              createOrReplaceTempViewFn(PFA_FNL_VIEW, qryKey.name)
              FileSystemUtil.saveFileToMapRFSNoRepartitionParquet(PFA_FNL_VIEW.dropDuplicates(),outputFilePath,qryKey.name,"",DPOConstants.PARQUET)
              //if(PFA_FNL_VIEW.count > 0){
                /*FileSystemUtil.saveFileToMapRFS(PFA_FNL_VIEW.dropDuplicates(),outputFilePath,qryKey.name,"",DPOConstants.PARQUET)*/
                retStr = "Y"
              //}
            }else{
              Logger.log.info("Inside else")
              val df = executeQry(glblVarLst, qryKey)
              createOrReplaceTempViewFn(df, qryKey.name)
            }
          }
        } else {
          retStr
        }
      } else {
        Logger.log.info("PFA Segment skipped...")
        retStr
      }
      retStr
    }
  catch {

    case e: Exception => {
      Logger.log.info(s"RK4 : EPDERK4_PFA_SegExt.genPFASeg() : "+e.getMessage)
      throw e
    }

  }
    }




}
