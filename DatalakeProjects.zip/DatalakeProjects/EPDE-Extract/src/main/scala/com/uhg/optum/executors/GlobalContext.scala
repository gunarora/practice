package com.uhg.optum.executors

import com.uhg.optum.JobRunner.PEI
import com.uhg.optum.common.{BaseRepositoryManager, DPOConstants}
import com.uhg.optum.conf.ApplicationConfig
import com.uhg.optum.conf.ApplicationConfig.{peiTabName, pitTabName, plcTabName, pscTabName}
import com.uhg.optum.dao.{HbaseRepositoryManager, LocalRepositoryManager}
import com.uhg.optum.util.Logger
import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.hbase.HBaseConfiguration
import org.apache.hadoop.hbase.spark.HBaseContext
import org.apache.spark.SparkContext
import org.apache.spark.sql.{SQLContext, SparkSession}

/**
  * Description : Program to create spark session on runtime and used wherever needed
  */
class GlobalContext(peiRowKey: String,master: String) {

  this: BaseRepositoryManager =>
  val jobName: String = peiRowKey
  val peTable = getRepository(peiTabName)
  val pscTable = getRepository(pscTabName)
  val plcTable = getRepository(plcTabName)
  val pitTable = getRepository(pitTabName)


  val sparkSession: SparkSession = {
    try {
      this.createSparkSession(peiRowKey, ApplicationConfig.metaUri, master)
    }catch {
      case e: Exception => {
        Logger.log.info("Exception at GlobalContext CreateSparkSession function: " + e.getMessage)
        throw e
      }
       // throw e
    }
  }

  val sparkContext: SparkContext = sparkSession.sparkContext
  val sqlContext: SQLContext = sparkSession.sqlContext
  val sparkConf = sparkContext.getConf
  val fs: FileSystem = FileSystem.get(sparkContext.hadoopConfiguration)

  private def createSparkSession (appName: String, metastoreUri: String, master: String): SparkSession = {
    try {

      val sparkSession : SparkSession =
        if(master.equalsIgnoreCase("yarn")) {
          SparkSession.builder().appName(appName).config("hive.metastore.uris", metastoreUri).enableHiveSupport().getOrCreate()
        } else {
          SparkSession.builder().appName(appName).master("local[1]").getOrCreate()
        }

      //val sparkSession = SparkSession.builder().appName(appName).master("local[1]").getOrCreate()
      Logger.log.info(s" sparkSession is created with thriftServer ($metastoreUri) : $sparkSession")
      sparkSession.conf.set( "spark.serializer", "org.apache.spark.serializer.KryoSerializer" )
      sparkSession.conf.set("spark.crossjoin","spark.sql.crossJoin.enabled")
      sparkSession
    } catch {
      case e: Exception => {
        Logger.log.info("Exception at GlobalContext CreateSparkSession function with metaURI : " + e.getMessage)
      }
        throw e
    }
  }

  private def createSparkSession (appName: String): SparkSession = {
    try {
      val sparkSession = SparkSession.builder().appName(appName).master("local[1]").getOrCreate()
      //val sparkSession = SparkSession.builder().appName(appName).enableHiveSupport().getOrCreate()
      //val sparkSession = SparkSession.builder().appName(appName).getOrCreate()
      Logger.log.info(" sparkSession is created " + sparkSession)
      sparkSession.conf.set( "spark.serializer", "org.apache.spark.serializer.KryoSerializer" )
      sparkSession.conf.set("spark.crossjoin","spark.sql.crossJoin.enabled")
      sparkSession
    } catch {
      case e: Exception => {
        Logger.log.info("Exception at GlobalContext CreateSparkSession function without MetaURi : " + e.getMessage)
      }
        throw e
    }
  }

  val hBaseConf:org.apache.hadoop.conf.Configuration = {
    try{
      HBaseConfiguration.create()
    }catch{
      case e: Exception => {
        Logger.log.info("Exception while initializing hbaseConf in GlobalContext class  : " + e.getMessage)
      }
        throw e
    }
  }

  def closeAllRepositories(): Unit = {
    closeRepository(peTable)
    closeRepository(plcTable)
    closeRepository(pscTable)
    closeRepository(pitTable)
  }

  val hbaseContext = {
    try{
      new HBaseContext(sparkContext, hBaseConf)
    }catch{
      case e: Exception => {
        Logger.log.info(s"Exception while initializing hbaseContext in GlobalContext class  : " + e.getMessage)
        Logger.log.error("Error occured : " + e.getStackTrace.mkString("\n"))
      }
        throw e
    }
  }

  // val fs: FileSystem = FileSystem.get(spark.hadoopConfiguration)
}
