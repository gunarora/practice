package com.uhg.optum.provider.extractors

import com.uhg.optum.common.DPOConstants
import com.uhg.optum.conf.ApplicationConfig.workingDir
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDERK4InputJsonSchema.SegmentDetails
import com.uhg.optum.provider.output.OuptutGenerator
import com.uhg.optum.util.CommonUtil._
import com.uhg.optum.util.{EPDECommonUtil, FileSystemUtil, Logger}

import scala.util.Try

trait EPDERK4_HCA_SegExt extends OuptutGenerator{
  def genHCASeg(segDtls: SegmentDetails, glblVarLst:scala.collection.mutable.Map[String,String],SW_SKIP_HCA : String, outputFilePath : String)(implicit context: GlobalContext): String = {
    try{
    Logger.log.info("Inside hcaSegGen")
    Logger.log.info("Initializing variables..")
    var Seg_Nm, Seg_Seq = ""
    var retStr = "N"

      if (segDtls.equals("") || segDtls == null) {
        Logger.log.info("No segment details present for HCA Segment")
      }
/*      if (!context.sparkSession.catalog.tableExists("ADD_FNL_VIEW")) {
        Logger.log.info("The temporary view ADD_FNL_VIEW from ADD segment is required for HCA segment")
      }*/
       if (SW_SKIP_HCA.equals("N")) {
        var SchemaNm = DPOConstants.SCHEMA
        Logger.log.info("SchemaNm: " + SchemaNm)
        if (segDtls.segName.equals("HCA")) {
          EPDECommonUtil.generateSegTables(segDtls.segTables,glblVarLst)
          Seg_Nm = segDtls.segName
          Seg_Seq = segDtls.segSeq
          Logger.log.info("Inside HCA")
          segDtls.segQueries.map { qryKey =>
           if (qryKey.name.matches("HCA_FNL_VIEW")) {
              Logger.log.info("Inside HCA_FNL_VIEW")
              val HCA_FNL_VIEW =executeQry(glblVarLst,qryKey)
              createOrReplaceTempViewFn(HCA_FNL_VIEW, qryKey.name)
             FileSystemUtil.saveFileToMapRFSNoRepartitionParquet(HCA_FNL_VIEW,outputFilePath,qryKey.name,"",DPOConstants.PARQUET)
              //if(HCA_FNL_VIEW.count > 0){
                //FileSystemUtil.saveFileToMapRFS(HCA_FNL_VIEW.dropDuplicates(),outputFilePath,qryKey.name,"",DPOConstants.PARQUET)
                retStr = "Y"
              //}
            }else{
             Logger.log.info("Inside else")
             val df = executeQry(glblVarLst, qryKey)
             createOrReplaceTempViewFn(df, qryKey.name)
        //     FileSystemUtil.saveFileToMapRFS(df,glblVarLst.get("tmpVwPath").getOrElse(workingDir),qryKey.name,"",DPOConstants.PARQUET)
           }
          }
         } else {
          retStr
        }
      } else {
        Logger.log.info("HCA Segment skipped...")
        retStr
      }
      retStr
    }catch {

      case e: Exception => {
        Logger.log.info(s"RK4 : EPDERK4_HCA_SegExt.genHCASeg() : "+e.getMessage)
        throw e
      }

    }
  }


}
