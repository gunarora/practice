package com.uhg.optum.provider.snapshot

/**
  * Created by paror18 on 10/18/2018.
  */
trait PJSSnapshotProvider {
  def getEntityMetaDataInfo() : Unit = ???
  def genPJSExtractPerEnt() : Unit = ???
}
