package com.uhg.optum.protocols

import com.uhg.optum.protocols.InputJsonSchema._
import spray.json._

/**
  * Created by paror18 on 9/27/2018.
  */
object InputJsonSchema {

  case class FeedDetails (
                   feedName: String,
                   extraction: Seq[ExtractFileEntity]
                 )

  case class ExtractFileEntity(
                      extractName: String,
                      IsOutputMerge: String,
                      IsSchemaChange: String,
                      extractHeaderTrailerRequired: String,
                      InputFileDetails: Seq[InputFileDetails],
                      extractDetails: Seq[ExtractDetail]
                  )

  case class InputFileDetails(
                               inputFileColumns: String,
                               inputFiledataTypeLength: String,
                               IsInputFileRowDelimited: String,
                               InputFileRowDelimiter: String,
                               isInputFileFixedWidth: String,
                               isInputFileColumnDelimited: String,
                               inputFileColumnDelimiter: String,
                               isInputFileValidationRequired: String,
                               inputFileValidationRules: Seq[InputFileValidationRule]
                             )

  case class InputFileValidationRule(
                                      InputHeaderValidationRule: String,
                                      InputDataValidationRule: String,
                                      InputTrailerValidationRule: String
                                    )

  case class ExtractDetail(
                            provNo: String,
                            provName: String,
                            provHeaderDesc: String,
                            provheaderDateFormat: String,
                            provTrailerDesc: String,
                            provoutFileColDelim: String,
                            provTrgColumn: String,
                            provTrgDataTypeLen: String,
                            provDataQueries: Seq[Map[String, String]]
                          )

  case class InputExtractInfo(items: Array[FeedDetails]) extends IndexedSeq[FeedDetails] {
    def apply(index: Int) = items(index)

    def length = items.length
  }

}

object InputProtocol extends DefaultJsonProtocol {
    implicit val extractDetail = jsonFormat9(ExtractDetail)
    implicit val inputFileValidationRule = jsonFormat3(InputFileValidationRule)
    implicit val inputFile = jsonFormat9(InputFileDetails)
    implicit val extract = jsonFormat6(ExtractFileEntity)
    implicit val feed = jsonFormat2(FeedDetails)

    implicit object InputExtractInfoJsonFormat extends RootJsonFormat[InputExtractInfo] {
      def read(value: JsValue) = InputExtractInfo(value.convertTo[Array[FeedDetails]])
      def write(f: InputExtractInfo) = JsArray(f.toJson)
    }
}