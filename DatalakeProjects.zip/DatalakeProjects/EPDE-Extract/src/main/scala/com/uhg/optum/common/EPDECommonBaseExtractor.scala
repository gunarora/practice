package com.uhg.optum.common

import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDECommonInputJsonSchema


trait EPDECommonBaseExtractor {

  def extractEPDECommon( jsonFile: Option[EPDECommonInputJsonSchema.ExtractFileEntity], pitRowKey: String, inboxFilePath: String, vndrCdDir: String,vendor_cd: String)(implicit context: GlobalContext): Tuple2[String,String]

}
