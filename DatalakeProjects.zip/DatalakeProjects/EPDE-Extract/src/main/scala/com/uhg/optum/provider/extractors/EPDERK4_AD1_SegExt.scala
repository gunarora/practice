package com.uhg.optum.provider.extractors

import com.uhg.optum.common.DPOConstants
import com.uhg.optum.conf.ApplicationConfig.datafilesDir
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDERK4InputJsonSchema.SegmentDetails
import com.uhg.optum.provider.output.OuptutGenerator
import com.uhg.optum.util.{CommonUtil, EPDECommonUtil, FileSystemUtil, Logger}
import com.uhg.optum.util.CommonUtil.{createOrReplaceTempViewFn, executeQry}

trait EPDERK4_AD1_SegExt extends OuptutGenerator {
  def ad1SegGen(segDetails: SegmentDetails, outputFilePath: String, glblVarLst: collection.mutable.Map[String, String])(implicit context: GlobalContext): String = {
try{
    var retStr = "N"
   /* val df =context.sparkSession.sql("SELECT PTA.PROV_ID as LNK_ADD_PROV_ID, PTP.TAX_ID_NBR as LNK_ADD_TAX_ID_NBR,PTA.ADR_TYP_CD as LNK_ADD_ADR_TYP_CD,PTA.ADR_ID as LNK_ADD_ADR_ID,PTA.LST_UPDT_DT AS LNK_ADD_LST_UPDT_DT FROM  DF2_NDB_ODFR2TST.F5938DBE_PROV_TIN_ADR PTA,DF2_NDB_ODFR2TST.F5938DBE_PROV_TIN_PAY_AFFIL PTP,DF2_NDB_ODFR2TST.F5938DBE_ADR A,DF2_NDB_ODFR2TST.F5938DBE_PROV P WHERE PTA.PROV_ID       = P.PROV_ID AND PTA.PROV_ID       = PTP.PROV_ID AND PTA.PROV_ID in (33328,42909,25913) and PTA.TAX_ID_NBR    = PTP.TAX_ID_NBR AND PTA.TAX_ID_TYP_CD = PTP.TAX_ID_TYP_CD AND PTA.ADR_TYP_CD   IN ('H','D','L','T') AND PTA.ADR_ID        =  A.ADR_ID AND ((unix_timestamp(PTP.CANC_DT,'yyyy-MM-dd')      = unix_timestamp('12/31/9999','MM/dd/yyyy')) OR (unix_timestamp(PTP.CANC_DT,'yyyy-MM-dd')     BETWEEN unix_timestamp('01/01/0001','MM/dd/yyyy') AND  unix_timestamp('12/31/9999','MM/dd/yyyy') AND unix_timestamp(PTP.LST_UPDT_DT,'yyyy-MM-dd') BETWEEN unix_timestamp('01/01/0001','MM/dd/yyyy') AND unix_timestamp('12/31/9999','MM/dd/yyyy'))) AND ((unix_timestamp(PTA.CANC_DT,'yyyy-MM-dd')  = unix_timestamp('12/31/9999','MM/dd/yyyy')) OR (unix_timestamp(PTA.CANC_DT,'yyyy-MM-dd')     BETWEEN unix_timestamp('01/01/0001','MM/dd/yyyy') AND  unix_timestamp('12/31/9999','MM/dd/yyyy') AND unix_timestamp(PTA.LST_UPDT_DT,'yyyy-MM-dd') BETWEEN unix_timestamp('01/03/2019','MM/dd/yyyy') AND unix_timestamp('12/31/9999','MM/dd/yyyy'))) AND PTP.TAX_ID_NBR NOT IN ( SELECT TAX_ID_NBR FROM  DF2_NDB_ODFR2TST.F5938DBE_DATA_VEND_CRIT_DTL WHERE DATA_VEND_FUNC_CD IN ('E' , 'B') AND  DATA_VEND_CD      =  'OPTUM' AND  CRIT_ID           =  10 AND  CRIT_COND_CD      = 'E' AND  ACTV_CD           = 'A' ) ORDER BY PTP.TAX_ID_NBR, PTA.ADR_TYP_CD limit 10000")
    //val df =context.sparkSession.sql("SELECT PTA.PROV_ID as OUT_ADD_PROV_ID, PTP.TAX_ID_NBR as PTA_TAX_ID_NBR,PTP.TAX_ID_TYP_CD as PTA_TAX_ID_TYP_CD,PTA.ADR_TYP_CD as PTA_ADR_TYP_CD,PTA.ADR_ID as OUT_ADD_ADR_ID,PTA.LST_UPDT_DT AS PTA_LST_UPDT_DT FROM  DF2_NDB_ODFR2TST.F5938DBE_PROV_TIN_ADR PTA,DF2_NDB_ODFR2TST.F5938DBE_PROV_TIN_PAY_AFFIL PTP,DF2_NDB_ODFR2TST.F5938DBE_ADR A,DF2_NDB_ODFR2TST.F5938DBE_PROV P WHERE PTA.PROV_ID       = P.PROV_ID AND PTA.PROV_ID       = PTP.PROV_ID AND PTA.TAX_ID_NBR    = PTP.TAX_ID_NBR AND PTA.TAX_ID_TYP_CD = PTP.TAX_ID_TYP_CD AND PTA.ADR_TYP_CD   IN ('H','D','L','T') AND PTA.ADR_ID        =  A.ADR_ID AND ((unix_timestamp(PTP.CANC_DT,'yyyy-MM-dd')      = unix_timestamp('12/31/9999','MM/dd/yyyy')) OR (unix_timestamp(PTP.CANC_DT,'yyyy-MM-dd')     BETWEEN unix_timestamp('01/01/0001','MM/dd/yyyy') AND  unix_timestamp('12/31/9999','MM/dd/yyyy') AND unix_timestamp(PTP.LST_UPDT_DT,'yyyy-MM-dd') BETWEEN unix_timestamp('01/01/0001','MM/dd/yyyy') AND unix_timestamp('12/31/9999','MM/dd/yyyy'))) AND ((unix_timestamp(PTA.CANC_DT,'yyyy-MM-dd')  = unix_timestamp('12/31/9999','MM/dd/yyyy')) OR (unix_timestamp(PTA.CANC_DT,'yyyy-MM-dd')     BETWEEN unix_timestamp('01/01/0001','MM/dd/yyyy') AND  unix_timestamp('12/31/9999','MM/dd/yyyy') AND unix_timestamp(PTA.LST_UPDT_DT,'yyyy-MM-dd') BETWEEN unix_timestamp('01/03/2019','MM/dd/yyyy') AND unix_timestamp('12/31/9999','MM/dd/yyyy'))) AND PTP.TAX_ID_NBR NOT IN ( SELECT TAX_ID_NBR FROM  DF2_NDB_ODFR2TST.F5938DBE_DATA_VEND_CRIT_DTL WHERE DATA_VEND_FUNC_CD IN ('E' , 'B') AND  DATA_VEND_CD      =  'OPTUM' AND  CRIT_ID           =  10 AND  CRIT_COND_CD      = 'E' AND  ACTV_CD           = 'A' ) ORDER BY PTP.TAX_ID_NBR, PTA.ADR_TYP_CD limit 100000")
    df.createOrReplaceTempView("ADD_FNL_VIEW")
    df.show(false)*/
   /* if (!context.sparkSession.catalog.tableExists("ADD_FNL_VIEW")) {
      throw new Exception("The temporary view ADD_FNL_VIEW from ADD segment is required for AD1 segment")
    }*/

   /* segDetails.map { s =>
      if (s.segName.equals("AD1")) {
*/
          EPDECommonUtil.generateSegTables(segDetails.segTables,glblVarLst)
          segDetails.segQueries.map { qryKey =>
          Logger.log.info("qryKey.name --> " + qryKey.name)
          /*if (qryKey.name.matches("ADD_UNI_FNL_VIEW")) {
            //val tempView=qryKey.name
            val df = executeQry(glblVarLst, qryKey)


            createOrReplaceTempViewFn(df, qryKey.name)


          } else */if (qryKey.name.matches("AD1_FETCH1")) {
            val tempView = qryKey.name
            println("AD1_FETCH1" + qryKey.name)
            var cdf = executeQry(glblVarLst, qryKey)
            createOrReplaceTempViewFn(cdf, qryKey.name)
          } else if (qryKey.name.matches("AD1_FNL_VIEW")) {
            val tempView = qryKey.name
            var df = executeQry(glblVarLst, qryKey)
            createOrReplaceTempViewFn(df, qryKey.name)
            //if (df.count > 0) {
              //df.dropDuplicates()
              //RPAD QUERY -> result -> write df res in file
              //val ad1Df = CommonUtil.generateRpadQry(s.segTarCol, s.segTarLen, s.segTolLen, tempView)
              //Logger.log.info("PHO Final Query:"+phoQry)
              //val phoDf = context.sparkSession.sql(s"$phoQry")
             // val outputFilePath1=datafilesDir+"/"+glblVarLst("${WS_VENDR_CD}")+"/"+glblVarLst("provTypCd")+"/"
              //generateOpFile(df, outputFilePath, "AD1_FNL_VIEW")
              FileSystemUtil.saveFileToMapRFSNoRepartitionParquet(df,outputFilePath,qryKey.name,"",DPOConstants.PARQUET)
              retStr = "Y"
            /*}else{
              Logger.log.info("INFO : The AD1 FINAL view count is Zero")
            }*/
          }

        }
      //} else {
        //println("seg" + s.segName)
        //throw new Exception("Segment details for PHO are not present")
      //}

    //}
    /*if(segDetails.segName.equals("PHO"))
    var qryStr = qryKey.query.replace("${WS_PREV_RUN_DT}", WS_PREV_RUN_DT)

  */
    retStr
}catch {

  case e: Exception => {
    Logger.log.info(s"RK4 : EPDERK4_AD1_SegExt.genAD1Seg() : "+e.getMessage)
    throw e
  }

}
  }

}
