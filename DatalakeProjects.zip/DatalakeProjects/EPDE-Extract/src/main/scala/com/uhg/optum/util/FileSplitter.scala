package com.uhg.optum.util

import org.apache.spark.sql._
import org.apache.spark.sql.types._
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.col
import java.util.Calendar
import java.text.SimpleDateFormat

import com.uhg.optum.common.DPOConstants._
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}

import java.io.File
import java.io.FileOutputStream
import java.io.PrintWriter
import scala.collection.mutable.ListBuffer

object FileSplitter {

  var fsConf = new Configuration()
  var fileSystem = FileSystem.get(fsConf)

  def main(args: Array[String]): Unit = {

    val inputFilePath = args(0) //"/datalake/uhclakedev/dataplatform/epde/d_data/OHBS/GROUP/OHBS_EPDE_GRP_20190630.TXT"
    val interval = args(1).toInt // 10000
    val outputPath = args(2) //"/datalake/uhclake/tst/developer/rmutreja/EPDE"
    val typeExtract = args(3) //"Full"
    val ecgLocation = args(4)
    val touchFileLocation = args(5)
    val touchFileName = args(6)
    val appendFlag = args(7)

    val spark = SparkSession.builder.appName("fileSplitter").getOrCreate

    val fileName = inputFilePath.split("/").last.split("[.]")(0)

    Logger.log.info(fileName)

    val inputFile = spark.read.option("header", "true").csv(inputFilePath)
    val header = inputFile.columns(0)

    val inputFileDF = spark.sqlContext.createDataFrame(inputFile.rdd.zipWithIndex.map { case (row, index) => Row.fromSeq(row.toSeq :+ index) }, StructType(inputFile.schema.fields :+ StructField("index", LongType, false)))

    val newNames = Seq("value", "index")
    val inputFileDFRenamed = inputFileDF.toDF(newNames: _*)
    val inputFileCount = inputFileDFRenamed.count()
    val loopCount = inputFileCount / interval
    var counter = 0
    var fileList : ListBuffer[String] = ListBuffer()

    while (counter <= loopCount) {

      val lowerBound = counter * interval
      var upperBound = lowerBound + interval

      if (counter == loopCount) {
        upperBound = lowerBound + (inputFileCount.toInt % interval)
      }

      val splitFileName = getSplitFileName(inputFilePath, typeExtract, lowerBound, upperBound)
      Logger.log.info(splitFileName)

      val finalDF = inputFileDFRenamed.filter(col("index") >= lowerBound && col("index") < upperBound).select(col("value"))

      val oldNAme = Seq(header)
      val finalDFRenamed = finalDF.toDF(oldNAme: _*)

      saveFileToMapRFS(finalDFRenamed, outputPath, splitFileName)
      fileList += splitFileName

      counter = counter + 1

    }

    createTouchFile(ecgLocation,outputPath,fileList.toList,touchFileLocation,touchFileName,appendFlag)

  }

  def createTouchFile(ecgLocation: String, outputPath: String, files: List[String],touchFileLocation: String, touchFileName: String, appendFlag: String): Unit = {

    val outLoc = "/mapr".concat(outputPath)
    //val files = new File(outLoc).list

    Logger.log.info(touchFileLocation + " " + touchFileName + " " + appendFlag)

    if (appendFlag == "Y") {
      val pw = new PrintWriter(new FileOutputStream(new File(touchFileLocation + "/" + touchFileName), true))
      for (file <- files) {
        pw.println("put " + outLoc+"/"+file)
      }
      pw.flush
      pw.close
    } else {
      val pw = new PrintWriter(new FileOutputStream(new File(touchFileLocation + "/" + touchFileName), false))
      pw.println("cd " + ecgLocation)
      for (file <- files) {
        pw.println("put " + outLoc+"/"+file)
      }
      pw.flush
      pw.close
    }
  }

  def getSplitFileName(inputFilePath: String, typeExtract: String, lowerBound: Int, upperBound: Int): String = {

    val cal = Calendar.getInstance
    val mon = new SimpleDateFormat("MMM").format(cal.getTime()).toUpperCase
    val date = new SimpleDateFormat("dd").format(cal.getTime()).toUpperCase
    val inputFilePathArray = inputFilePath.split("/")
    val segment = inputFilePathArray(inputFilePathArray.length - 2)
    val vendor = inputFilePathArray(inputFilePathArray.length - 3)

    vendor + "_" + typeExtract + "_" + segment + "_" + mon + date + "_" + lowerBound + "_TO_" + upperBound + ".txt"
  }

  def saveFileToMapRFS(finalDF: DataFrame, outFileLoc: String, outFileName: String): Unit = {
    Logger.log.info(".............Inside saveFileToMapRFS.............")

    rmPathIfExist(outFileLoc + "/" + outFileName)
    val outLoc = outFileLoc.replace("/mapr/", "/")
    val outLocTemp = outFileLoc.replace("/mapr/", "/") + "/" + outFileName + "_temp"
    mkdirs(outLocTemp)

    var savedFileName = ""

    finalDF.coalesce(1).write.option("header", "true").mode("overwrite").csv(outLocTemp)

    Logger.log.info("Saved in temp")

    savedFileName = fileSystem.globStatus(new Path(outLocTemp + "/p*"))(0).getPath.getName

    renamePath(outLocTemp + "/" + savedFileName, outLoc + "/" + outFileName)

    rmPathIfExist(outLocTemp)
  }

  def rmPathIfExist(path: String): Unit = {
    try {
      Logger.log.info("---Inside rmPathIfExist---" + path + "    " + fileSystem.getScheme)
      if (fileSystem.exists(new Path((path.replace("/mapr/", "/"))))) {
        // if (fileSystem.exists(new Path((path)))) {
        Logger.log.info(s" Deleted intermediate file/dir : " + path)
        fileSystem.delete(new Path(path.replace("/mapr/", "/")), true)
        //  fileSystem.deleteOnExit(new Path(path))
      } else {
        Logger.log.info(s" Path: $path doesn't exist, Not proceeding for removing.")
      }
    } catch {
      case e: Exception => Logger.log.info(" Exception at rmPathIfExist definition : " + e.getStackTrace.mkString("\n"))
        throw e
    }
  }

  def mkdirs(folderPath: String): Unit = {
    try {
      fileSystem.mkdirs(new Path(folderPath))
      Logger.log.info(s" Created Path : " + folderPath)
    } catch {
      case e: Exception => {
        Logger.log.info(" Exception at mkdirs definition : " + e.getStackTrace.toString)
        Logger.log.error("Error occured : " + e.getStackTrace.mkString("\n"))
      }
        throw e
    }
  }

  def renamePath(srcPath: String, destPath: String): Unit = {
    try {
      Logger.log.info(".............Inside renamePath...........")
      Logger.log.info(".........srcPath, destPath........." + srcPath + " " + destPath)
      if (fileSystem.exists(new Path(s"$srcPath"))) {
        Logger.log.info(s" Renaming/Move from ( $srcPath ) to ( $destPath )")
        var success = fileSystem.rename(new Path(srcPath), new Path(destPath))
        Logger.log.info(s" success flag--( $success )")
      } else {
        Logger.log.info(s" Path : $srcPath doesn't exist, Not proceeding for move/Rename .")
      }
    } catch {
      case e: Exception => Logger.log.info(" Exception at renamePath definition : " + e.getStackTrace.mkString("\n"))
        throw e
    }
  }


}