package com.uhg.optum.provider.extractors

import com.uhg.optum.common.DPOConstants
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDERK4InputJsonSchema.SegmentDetails
import com.uhg.optum.provider.output.OuptutGenerator
import com.uhg.optum.util.CommonUtil._
import com.uhg.optum.util.{EPDECommonUtil, FileSystemUtil, Logger}

import scala.util.Try

trait EPDERK4_NPI_SegExt extends OuptutGenerator{
  def genNPISeg(segDtls: SegmentDetails, glblVarLst:scala.collection.mutable.Map[String,String],SW_SKIP_NPI : String, outputFilePath : String)(implicit context: GlobalContext): String = {
    try{
    Logger.log.info("Inside npiSegGen")
    Logger.log.info("Initializing variables..")
    var Seg_Nm, Seg_Seq = ""
    var retStr = "N"
    /*
        var WS_ACTV_CD_1 = glblVarLst.get("WS_ACTV_CD_1")
        var WS_ACTV_CD_2 = glblVarLst.get("WS_ACTV_CD_2")
        var WS_UPDT_DT_1 = glblVarLst.get("WS_UPDT_DT_1") //PTA_LST_UPDT_DT
        var WS_UPDT_DT_2 = glblVarLst.get("WS_UPDT_DT_2") //ADR_LST_UPDT_DT
        var WS_PREV_RUN_DT_YMD = glblVarLst.get("WS_PREV_RUN_DT_YMD")*/
/*
    //TODO:: To be removed later
    var PRV_FNL_VIEW = context.sparkSession.read.format("parquet").load("/datalake/uhclakedev/dataplatform/epde/d_datafiles/OHPH/GROUP/PRV_FNL_VIEW_TEST5")
    PRV_FNL_VIEW.createOrReplaceTempView("PRV_FNL_VIEW")
    var df = context.sparkSession.sql("select * from PRV_FNL_VIEW where lnk_prov_id in (528719, 530799, 2022991)")
    df.createOrReplaceTempView("PRV_FNL_VIEW")*/


      if (segDtls.equals("") || segDtls == null) {
        Logger.log.info("No segment details present for NPI Segment")
      }
      if (!context.sparkSession.catalog.tableExists("PRV_FINAL_VIEW")) {
        Logger.log.info("The temporary view PRV_FINAL_VIEW from NPI segment is required for NPI segment")
      }
      if (SW_SKIP_NPI.equals("N")) {
        var SchemaNm = DPOConstants.SCHEMA
        Logger.log.info("SchemaNm: " + SchemaNm)
        if (segDtls.segName.equals("NPI")) {
          EPDECommonUtil.generateSegTables(segDtls.segTables,glblVarLst)
          Seg_Nm = segDtls.segName
          Seg_Seq = segDtls.segSeq
          Logger.log.info("Inside NPI")
          segDtls.segQueries.map { qryKey =>
            if (qryKey.name.equals("NPI_FNL_VIEW")) {
              Logger.log.info("Inside NPI_FNL_VIEW")
              val NPI_FNL_VIEW =executeQry(glblVarLst,qryKey)
              createOrReplaceTempViewFn(NPI_FNL_VIEW, qryKey.name)
              FileSystemUtil.saveFileToMapRFSNoRepartitionParquet(NPI_FNL_VIEW.dropDuplicates(),outputFilePath,qryKey.name,"",DPOConstants.PARQUET)
              //if(NPI_FNL_VIEW.count > 0){
                /*FileSystemUtil.saveFileToMapRFS(NPI_FNL_VIEW.dropDuplicates(),outputFilePath,qryKey.name,"",DPOConstants.PARQUET)*/
                retStr = "Y"
              //}
            }else{
              Logger.log.info("Inside else")
              val df = executeQry(glblVarLst, qryKey)
              createOrReplaceTempViewFn(df, qryKey.name)
            }
          }
        } else {
          retStr
        }
      } else {
        Logger.log.info("NPI Segment skipped...")
        retStr
      }
      retStr
    }
  catch {

    case e: Exception => {
      Logger.log.info(s"RK4 : EPDERK4_NPI_SegExt.genNPISeg() : "+e.getMessage)
      throw e
    }

  }
  }


}
