package com.uhg.optum.provider

import java.io.File


import com.uhg.optum.JobRunner.PEI

import com.uhg.optum.common.{BaseExtractor, BaseRepository, DPOConstants}
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.provider.snapshot.CommonSnapshotProvider
import com.uhg.optum.conf.ApplicationConfig._
import com.uhg.optum.protocols.EPDEInputJsonSchema.{EPDEInputExtractInfo, ExtractFileEntity}
import com.uhg.optum.provider.DefaultExtractProvider.ExtractOutput
import com.uhg.optum.provider.RawExtractProvider.RawExtractionFailed
import com.uhg.optum.provider.snapshot.CommonSnapshotProvider.CommonSnapshotFailed
import com.uhg.optum.util.{CommonUtil, Logger}

import scala.io.Source
import scala.util.{Failure, Success, Try}

object RawExtractProvider {

  class RawExtractionFailed(msg: String, th: Throwable) extends Exception(msg, th)

}

/**
  * Created by paror18 on 10/19/2018.
  * This class needs to be tested yet.
  */
class RawExtractProvider(implicit context: GlobalContext, pei: PEI) extends DefaultExtractProvider with CommonSnapshotProvider {

  //def extract(pei: PEI, jsonFile: Option[ExtractFileEntity], pitRowKey: String): ExtractOutput = {
  override def extract( jsonFile: Option[ExtractFileEntity], pitRowKey: String): ExtractOutput = {
    val pitTable = context.pitTable
    // val plcTable = context.plcTable
    val entityList=jsonFile.head.entityList.toUpperCase.split(";").toList
    //val entityList = pei.entitySet.toUpperCase.split(";").toList
    val peiRowKey = pitRowKey.split("-")(0)
    val pscRowKeyPart1=peiRowKey.split("_")(0)
    val inputPath = cmnSnapPath + File.separator + peiRowKey + "-Entity_List"
    val entityFileList = Source.fromFile(inputPath)("UTF-8").getLines.toList.filterNot(x => x.contains('#')) //TODO: Reading file from local again. Check issues

    if (!entityFileList.isEmpty) {
      entityFileList.map(entity => entity.split(DPOConstants.PIPE)(2).trim)
    }
    entityList.foreach { entity =>
      val rowKeyConfig = pscRowKeyPart1 + "-" + entity
      val checkCommonSnapshot="N"
      //TODO:if flag is no go in else( regenerate)
      if (entityFileList.contains(entity) && !(checkCommonSnapshot.equalsIgnoreCase("N"))) {
        Logger.log.info(s"Snapshot already exists for Entity: $entity. Proceeding to create Dataframe")
        val entityDF = getCommonSnapshotPerEntity(entity) //TODO: Can we rename it to something : createDataFrameForSnapshot
        // entityDF.createOrReplaceTempView(s"${entity}")
      } else {
        Logger.log.info(s"Calling for snapshot generation for entity: $entity")
        //val snapRes = getSnapshotExtractPerEntity(rowKeyConfig,entity,pei,pitRowKey)
        // snapRes match {
        /* case Success(result) =>
           pitTable.put(
             (pitRowKey, "exi", "fullLoadFlg", result.split(";")(0)), //TODO: Why is there a dropright case in else part in original code
             (pitRowKey, "exi", "rawRowDelim", result.split(";")(0)),
             (pitRowKey, "exi", "rawPartnFldr", result.split(";")(0)),
             (pitRowKey, "exi", "rawFileCnt", result.split(";")(0))
           )
         case Failure(ex) =>
           Failure(new RawExtractionFailed("Raw/Paquet file extraction process failed while creating snapshots", ex))*/
        //}

      }
    }


    val extractRes = super.extract(jsonFile, pitRowKey)
    //TODO: Correct this - This can go in job runner if this is common logic
    //    extractRes match {
    //      case Success(result) =>
    //        pitTable.put(
    //          (pitRowKey, "exi", "lastRunDt", CommonUtil.getCurrentTimeFormat),
    //          (pitRowKey, "exi", "provCompSts", "Success")
    //        )

    val lastProvRunDt = pitTable.getValueByRowKey(pitRowKey, "exi", "provStrTs") //TODO:Should we be getting try for every hbase operation
    // plcTable.put(peiRowKey, "plc", "lastRunDt", lastProvRunDt) //TODO: Should we plce the starttime of extraction process in global
    //TODO: Implement extractDuration method
    Logger.log.debug("Extraction process completed succesfully for Raw/Parquet")
    extractRes
    //TODO: Correct this
    //      case Failure(ex) =>
    //        Failure(new RawExtractionFailed("Exception while generating the extract for Raw/Parquet files", ex))
    //    }

    /*  //val extractRes = super.extract(pei,jsonFile, pitRowKey)
      val extractRes = super.extract(jsonFile, pitRowKey)
      /*extractRes match {
        case Success(result) =>
          pitTable.put(
            (pitRowKey, "exi", "lastRunDt", CommonUtil.getCurrentTimeFormat),
            (pitRowKey, "exi", "provCompSts", "Success")
          )
  */
          val lastProvRunDt = pitTable.getValueByRowKey(pitRowKey, "exi", "provStrTs") //TODO:Should we be getting try for every hbase operation
         // plcTable.put(peiRowKey, "plc", "lastRunDt", lastProvRunDt) //TODO: Should we plce the starttime of extraction process in global
          //TODO: Implement extractDuration method
          Logger.log.debug("Extraction process completed succesfully for Raw/Parquet")
          extractRes
        case Failure(ex) =>
          Failure(new RawExtractionFailed("Exception while generating the extract for Raw/Parquet files", ex))
      }*/


  }
  def extract(entityList:List[String],jsonFile: Option[ExtractFileEntity], pitRowKey: String,checkCommonSnapshot:String): String = {
    val pitTable = context.pitTable
    var retString = ""
    val peiRowKey = pitRowKey.split("-")(0)
    val pscRowKeyPart1 = peiRowKey.split("_")(0)
    val inputPath = cmnSnapPath + File.separator + peiRowKey + "-Entity_List"
    val entityFileList = Source.fromFile(inputPath)("UTF-8").getLines.toList.filterNot(x => x.contains('#')) //TODO: Reading file from local again. Check issues
    if (!entityFileList.isEmpty) {
      entityFileList.map(entity => entity.split(DPOConstants.PIPE)(2).trim)
    }
    entityList.foreach { entity =>
      val rowKeyConfig = pscRowKeyPart1 + "-" + entity
      val checkCommonSnapshot = "N"
      //TODO:if flag is no go in else( regenerate)
      if (entityFileList.contains(entity) && !(checkCommonSnapshot.equalsIgnoreCase("N"))) {
        Logger.log.info(s"RawExtractProvider: Snapshot already exists for Entity: $entity. Proceeding to create Dataframe")
        retString = getCommonSnapshotPerEntity(entity) //TODO: Can we rename it to something : createDataFrameForSnapshot
      } else {
        Logger.log.info(s"Calling for snapshot generation for entity: $entity")
        //retString = getSnapshotExtractPerEntity(rowKeyConfig, entity, pei, pitRowKey).get
        //retString = getSnapshotExtractPerEntity(rowKeyConfig, entity, pei, pitRowKey)

      }

    }

    retString
  }
}