package com.uhg.optum.provider.extractors

import com.uhg.optum.common.DPOConstants
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDERK4InputJsonSchema.SegmentDetails
import com.uhg.optum.provider.output.OuptutGenerator
import com.uhg.optum.util.CommonUtil.{createOrReplaceTempViewFn, executeQry}
import com.uhg.optum.util.{CommonUtil, EPDECommonUtil, Logger, FileSystemUtil}

trait EPDERK4_HRS_SegExt extends OuptutGenerator {
  def hrsSegGen(segDetails: SegmentDetails, outputFilePath: String, glblVarLst: collection.mutable.Map[String, String])(implicit context: GlobalContext): String = {
try{
    var df=context.sqlContext.emptyDataFrame
    var resStr = "N"

    EPDECommonUtil.generateSegTables(segDetails.segTables,glblVarLst)
    segDetails.segQueries.map { qryKey =>
      Logger.log.info("qryKey.name --> " + qryKey.name)
      if (qryKey.name.equals("HRS_FNL_VIEW")) {
        Logger.log.info("HRS_FNL_VIEW " + qryKey.name)
        var df = executeQry(glblVarLst, qryKey)
        var remDupDF = df.dropDuplicates()
        createOrReplaceTempViewFn(remDupDF, qryKey.name)
        FileSystemUtil.saveFileToMapRFSNoRepartitionParquet(remDupDF, outputFilePath, qryKey.name, "", DPOConstants.PARQUET)
        //if (remDupDF.count > 0) {
          /*FileSystemUtil.saveFileToMapRFS(remDupDF, outputFilePath, qryKey.name, "", DPOConstants.PARQUET)*/
          resStr="Y"
        //}
      }
      else{
        var df = executeQry(glblVarLst, qryKey)
        //var remDupDF = df.dropDuplicates()
        createOrReplaceTempViewFn(df, qryKey.name)
      }
    }


    resStr
}catch {

  case e: Exception => {
    Logger.log.info(s"RK4 : EPDERK4_HRS_SegExt.genHRSSeg() : "+e.getMessage)
    throw e
  }

}
  }
}