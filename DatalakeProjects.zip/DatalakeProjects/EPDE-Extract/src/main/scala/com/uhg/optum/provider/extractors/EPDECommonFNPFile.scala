package com.uhg.optum.provider.extractors

import com.uhg.optum.JobRunner.PEI
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.util.{EPDECommonUtil, Logger}
import org.apache.spark.sql.DataFrame


trait EPDECommonFNPFile {

  def common2200ExportProcess(dfInput:DataFrame, lastRunPlc: String, critInd: String, commQueries: Map[String, String], vendorCode: String)(implicit context: GlobalContext,pei:PEI): DataFrame = {
    //val commQueries = EPDECommonUtil.getCommonQueriesDetails(inputEntity).get.head.queries
    try {
      //var flag = ""
      var df11, df24, df25, df12, df13, df9_skip1, df9_skip2, df9_skip3 = context.sqlContext.emptyDataFrame
      Logger.log.info(s"RKP: common2200ExportProcess: Started common2200ExportProcess")
      if (critInd.equals("Y")) {
        // getting all prov_ids from various tables in case if crit_ind is Y
        df11 = EPDECommonUtil.getTempView(commQueries, "df11_query", "$vendor_cd", vendorCode, lastRunPlc)
        dfInput.createOrReplaceTempView("df2200_in")
        val df11_9 = EPDECommonUtil.getDataframe(commQueries, "df11_9_join", "$vendor_cd", vendorCode: String, lastRunPlc).get
        df11_9.createOrReplaceTempView("df11_9_join")
        //Logger.log.info(s"RKP: common2200ExportProcess: Query for TR24,TR25 merged")
        df24 = EPDECommonUtil.getTempView(commQueries, "df24_query", "$vendor_cd", vendorCode, lastRunPlc)
        val df24Cnt = df24.count
        if (df24Cnt > 0) {
          df9_skip1 = EPDECommonUtil.getTempView(commQueries, "df9_skip1", "$vendor_cd", vendorCode, lastRunPlc)
          Logger.log.info(s"RKP: common2200ExportProcess: Providers Skipped at TR11, TR24,TR25")
        } else {
          df9_skip1 = dfInput
          Logger.log.info(s"RKP: common2200ExportProcess: Providers Not Skipped at TR11, TR24, TR25")
        }
      } else {
        df9_skip1 = dfInput
        Logger.log.info(s"RKP: common2200ExportProcess: Providers Not Skipped at TR11, TR24, TR25")
      }
      df9_skip1.createOrReplaceTempView("df9_skip1")
      df9_skip2 = df9_skip1
      df12 = EPDECommonUtil.getTempView(commQueries, "df12_query", "$vendor_cd", vendorCode, lastRunPlc)
      if (df12.count() > 0) {
        df9_skip2 = EPDECommonUtil.getTempView(commQueries, "df9_skip2", "$vendor_cd", vendorCode, lastRunPlc)
        Logger.log.info(s"RKP: common2200ExportProcess: Providers Skipped at TR12")
      } else {
        df9_skip2.createOrReplaceTempView("df9_skip2")
        Logger.log.info(s"RKP: common2200ExportProcess: Providers Not Skipped at TR12")
      }
      df9_skip3 = df9_skip2
      // TR 13 to get all TINs for each PROV_ID
      df13 = EPDECommonUtil.getTempView(commQueries, "df13_query", "$vendor_cd", vendorCode, lastRunPlc)
      // Check if all above TINS also available for a particular PROV_Id in TR14 then skip that PROV_ID
      val df14 = EPDECommonUtil.getTempView(commQueries, "df14_query", "$vendor_cd", vendorCode, lastRunPlc)
      if (df14.count() > 0) {
        df9_skip3 = EPDECommonUtil.getTempView(commQueries, "df9_skip3", "$vendor_cd", vendorCode, lastRunPlc)
        Logger.log.info(s"RKP: common2200ExportProcess:Providers Skipped at TR13,TR14")
      }
      Logger.log.info(s"RKP: common2200ExportProcess: End common2200ExportProcess")
      df9_skip3
    }catch{
      case e: Exception => {
        Logger.log.error("RKP : EPDECommonFNPFile.common2200ExportProcess() "+e.getMessage )
        throw e
      }
    }
  }
}