package com.uhg.optum.conf

import com.typesafe.config.ConfigFactory

/**
  * Created by paror18 on 9/11/2018.
  */
object ApplicationConfig {

    //System.setProperty("config.resource", "application.local.conf")
    val conf = ConfigFactory.load()

    lazy val rootDir = conf.getString("provisioningApp.envConf.rootDir")
    lazy val peiTabName= conf.getString("provisioningApp.hbaseConf.peiTabName")
    lazy val pitTabName= conf.getString("provisioningApp.hbaseConf.pitTabName")
    lazy val pscTabName= conf.getString("provisioningApp.hbaseConf.pscTabName")
    lazy val plcTabName= conf.getString("provisioningApp.hbaseConf.plcTabName")
    lazy val entityMetaDataTabName= conf.getString("provisioningApp.envConf.entityMetaDataTabName")
    lazy val pitDatLocation= conf.getString("provisioningApp.envConf.pitDatLocation")
    lazy val peiDatLocation= conf.getString("provisioningApp.envConf.peiDatLocation")
    lazy val peDatArchiveLocation= conf.getString("provisioningApp.envConf.peDatArchiveLocation")
    lazy val securityfileLoc= conf.getString("provisioningApp.envConf.securityfileLoc")
    lazy val hbase_zookeeper_quorum= conf.getString("provisioningApp.hbaseConf.hbase_zookeeper_quorum")
    lazy val lakeEppTableName= conf.getString("provisioningApp.hbaseConf.lakeEppTableName")
    lazy val lakeEitTableName= conf.getString("provisioningApp.hbaseConf.lakeEitTableName")
    lazy val mountPath= conf.getString("provisioningApp.envConf.mountPath")
    lazy val workingDir= conf.getString("provisioningApp.envConf.workingDir")
    lazy val dataownr= conf.getString("provisioningApp.envConf.dataownr")
    lazy val mountPrefix = conf.getString("provisioningApp.envConf.mountPrefix")
    lazy val cmnSnapPath = conf.getAnyRef("provisioningApp.envConf.commonSnapPath")
    lazy val jsonPathPrefix = conf.getAnyRef("provisioningApp.envConf.jsonPathPrefix")
    lazy val metaUri = conf.getString("provisioningApp.envConf.metaUri")
    lazy val DSVConfigLocation = conf.getString("provisioningApp.envConf.DSVConfigLocation")
    lazy val peiFileName = conf.getString("provisioningApp.envConf.peiFileName")
    lazy val pscFileName = conf.getString("provisioningApp.envConf.pscFileName")
    lazy val plcFileName = conf.getString("provisioningApp.envConf.plcFileName")
    lazy val pitFileName = conf.getString("provisioningApp.envConf.pitFileName")
    lazy val eitTabName = conf.getString("provisioningApp.hbaseConf.eitTabName")
    lazy val allExtractsPitRowKeys = conf.getString("provisioningApp.envConf.allExtractsPitRowKeys")
    lazy val snapshotDir = conf.getString("provisioningApp.envConf.snapshotDir")


    lazy val inboxDir=conf.getString("provisioningApp.envConf.inboxDir")
    lazy val datafilesDir=conf.getString("provisioningApp.envConf.datafilesDir")
    lazy val dataDir = conf.getString("provisioningApp.envConf.dataDir")
    lazy val outboxDir = conf.getString("provisioningApp.envConf.outboxDir")
    lazy val archiveDir = conf.getString("provisioningApp.envConf.archiveDir")
    lazy val provider_par=conf.getString("provisioningApp.envConf.provider_par")
    lazy val contract_par=conf.getString("provisioningApp.envConf.contract_par")
    lazy val provDF=conf.getString("provisioningApp.envConf.provDF")
    lazy val contDF=conf.getString("provisioningApp.envConf.contDF")
    lazy val groupTypFrm=conf.getString("provisioningApp.envConf.groupTypFrm")
    lazy val physicianTypFrm=conf.getString("provisioningApp.envConf.physicianTypFrm")
    lazy val facilitiesTypFrm=conf.getString("provisioningApp.envConf.facilitiesTypFrm")
    lazy val schema=conf.getString("provisioningApp.envConf.schema")
    lazy val snapshotEntitiesFile=conf.getString("provisioningApp.envConf.snapshotEntitiesFile")
    lazy val snapshotEntitiesFile1=conf.getString("provisioningApp.envConf.snapshotEntitiesFile1")
    lazy val snapshotEntitiesFile2=conf.getString("provisioningApp.envConf.snapshotEntitiesFile2")
    lazy val snapshotEntitiesFile3=conf.getString("provisioningApp.envConf.snapshotEntitiesFile3")
    lazy val snapshotEntitiesFile4=conf.getString("provisioningApp.envConf.snapshotEntitiesFile4")
    lazy val snapshotEntitiesFile5=conf.getString("provisioningApp.envConf.snapshotEntitiesFile5")
    lazy val snapshotEntitiesFile6=conf.getString("provisioningApp.envConf.snapshotEntitiesFile6")
    lazy val snapshotEntitiesFile7=conf.getString("provisioningApp.envConf.snapshotEntitiesFile7")
    lazy val snapshotEntitiesFile8=conf.getString("provisioningApp.envConf.snapshotEntitiesFile8")
    lazy val snapshotEntitiesFile9=conf.getString("provisioningApp.envConf.snapshotEntitiesFile9")
    lazy val exportHbaseLocation=conf.getString("provisioningApp.envConf.exportHbaseLocation")
    lazy val ecgLocation=conf.getString("provisioningApp.envConf.ecgLocation")
    lazy val touchFileName=conf.getString("provisioningApp.envConf.touchFileName")
    lazy val touchFileECGLocation=conf.getString("provisioningApp.envConf.touchFileECGLocation")
    lazy val isTriggerJobType=conf.getString("provisioningApp.envConf.isTriggerJobType")

}
