package com.uhg.optum

import com.uhg.optum.common.DPOConstants
import com.uhg.optum.conf.ApplicationConfig
import com.uhg.optum.dao.{HbaseRepositoryManager, LocalRepositoryManager}
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.util.{FileSystemUtil, Logger}
import org.apache.hadoop.hbase.spark.HBaseContext
import org.apache.hadoop.hbase.TableName
import org.apache.hadoop.hbase.client.Scan
import org.apache.hadoop.hbase.filter.{Filter, FilterList, PrefixFilter}
import org.apache.hadoop.hbase.util.Bytes
import org.apache.spark.sql.SparkSession

object HbaseDataCapture {
  val peiHeader = "feedName"+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+"extractName"+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+"hdrDesc"+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+"hdrDateFormat"+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+"trlDesc"+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+"isJsonProp"+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+"jsonPropFileLoc"+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+"sqlQuery"+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+"transQuery"+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+"trgColumn"+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+"trgDataTypeLen"+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+"outFileName"+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+"outFileExt"+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+"outFileLoc"+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+"archLoc"+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+"isOutFileColDelim"+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+"outFileColDelim"+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+"isOutFileRowDelim"+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+"outFileRowDelim"+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+"isFixedWidth"+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+"srcCd"+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+"prtnrCd"+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+"entitySet"+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+"snapBuildType"+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+"consumingApp"+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+"inputFileName"+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+"inputFileLocation"
  val pscHeader ="feedName"+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+"extractName"+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+"entNm"+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+"prikeycols"+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+"dmlcol"+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+"activeflag"+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+"modtscol"+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+"fullLoadflg"
  val plcHeader = "feedName"+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+"extractName"+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+"lastRunDt"+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+"frequency"
  val envParam = "yarn"

  def main(args: Array[String]): Unit = {
    var filterName=""
   // val filterName=args(0).toUpperCase()
    if (args.length == 1) {
      filterName=args(0).toUpperCase()
    }else if((args.length >= 1)){
      Logger.log.info("===> Please Pass no argument or one argument that will act as prefix filter to extract records from hbase tables PEI,PSC,PLC<===")
      Logger.log.error("===> Since more than one arguments are passed <===")
      System.exit(1)
    }
    try {
      implicit val globalContext = if (envParam.equalsIgnoreCase("local")) {
        new GlobalContext("EPDE-OPTUM", DPOConstants.LOCAL) with LocalRepositoryManager
      } else {
        new GlobalContext("EPDE-OPTUM", DPOConstants.YARN) with HbaseRepositoryManager
      }

      getPEIDataIntoDSVFile(filterName)(globalContext)
      getPSCDataIntoDSVFile(filterName)(globalContext)
      getPLCDataIntoDSVFile(filterName)(globalContext)
      FileSystemUtil.rmPathIfExist(ApplicationConfig.exportHbaseLocation + "/temp")
      globalContext.sparkSession.stop()
    } catch {
    case e: Exception => {
      Logger.log.info(" Exception at occured in HbaseDataCapture : " + e.printStackTrace())
      Logger.log.error("Error occurred : " + e.getStackTrace.mkString("\n"))
    }
      throw e
  }
  }

  def  getPEIDataIntoDSVFile(filterName:String)(globalContext: GlobalContext): Unit = {
    val s = Seq(peiHeader)
    import globalContext.sparkSession.implicits._
    val headerDF = s.toDF
    var outFileName=DPOConstants.HBASE_PEI_FILE
    val scan = new Scan()
    if(!(filterName == null  || filterName.equalsIgnoreCase("") )){
    val filter = new PrefixFilter(Bytes.toBytes(s"${filterName}"))
    scan.setFilter(filterList(filter))
    outFileName=filterName+"_"+DPOConstants.HBASE_PEI_FILE
    }
    val peiVal = globalContext.hbaseContext.hbaseRDD(TableName.valueOf(ApplicationConfig.peiTabName), scan)
    val peiInfo = peiVal.map(tuple => {
      val result = tuple._2
      val row=Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("feedName")))+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("extractName")))+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("hdrDesc")))+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("hdrDateFormat")))+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("trlDesc")))+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("isJsonProp")))+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("jsonPropFileLoc")))+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("sqlQuery")))+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("transQuery")))+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("trgColumn")))+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("trgDataTypeLen")))+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("outFileName")))+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("outFileExt")))+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("outFileLoc")))+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("archLoc")))+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("isOutFileColDelim")))+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("outFileColDelim")))+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("isOutFileRowDelim")))+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("outFileRowDelim")))+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("isFixedWidth")))+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("srcCd")))+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("prtnrCd")))+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("entitySet")))+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("snapBuildType")))+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("consumingApp")))+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("inputFileName")))+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+Bytes.toString(result.getValue(Bytes.toBytes("pei"), Bytes.toBytes("inputFileLocation")))
      row
    })
    val peiData = headerDF.union(peiInfo.toDF)
    peiData.map(_.mkString).repartition(1).write.mode("overwrite").text(ApplicationConfig.exportHbaseLocation+"/temp/")
    FileSystemUtil.moveFile(ApplicationConfig.exportHbaseLocation+"/temp",ApplicationConfig.exportHbaseLocation+"/"+outFileName)(globalContext)

  }

  def getPSCDataIntoDSVFile(filterName:String)(globalContext: GlobalContext): Unit = {
    val s = Seq(pscHeader)
    import globalContext.sparkSession.implicits._
    val headerDF = s.toDF
    var outFileName=DPOConstants.HBASE_PSC_FILE
    val scan = new Scan()
    if(!(filterName == null  || filterName.trim.equalsIgnoreCase("") )){
      val filter = new PrefixFilter(Bytes.toBytes(s"${filterName}"))
      scan.setFilter(filterList(filter))
      outFileName=filterName+"_"+DPOConstants.HBASE_PSC_FILE
    }
    val pscVal = globalContext.hbaseContext.hbaseRDD(TableName.valueOf(ApplicationConfig.pscTabName), scan)
    val pscInfo = pscVal.map(tuple => {
      val result = tuple._2
      val row=Bytes.toString(result.getValue(Bytes.toBytes("psc"), Bytes.toBytes("feedName")))+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+Bytes.toString(result.getValue(Bytes.toBytes("psc"), Bytes.toBytes("extractName")))+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+Bytes.toString(result.getValue(Bytes.toBytes("psc"), Bytes.toBytes("entNm")))+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+Bytes.toString(result.getValue(Bytes.toBytes("psc"), Bytes.toBytes("prikeycols")))+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+Bytes.toString(result.getValue(Bytes.toBytes("psc"), Bytes.toBytes("dmlcol")))+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+Bytes.toString(result.getValue(Bytes.toBytes("psc"), Bytes.toBytes("activeflag")))+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+Bytes.toString(result.getValue(Bytes.toBytes("psc"), Bytes.toBytes("modtscol")))+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+Bytes.toString(result.getValue(Bytes.toBytes("psc"), Bytes.toBytes("fullLoadflg")))
      row
    })
    val pscData = headerDF.union(pscInfo.toDF)
    //FileSystemUtil.saveFileToMapRFSWithoutShuffle( pscData.map(_.mkString).toDF(),ApplicationConfig.exportHbaseLocation,outFileName,"",DPOConstants.TEXT)(globalContext)
   pscData.map(_.mkString).repartition(1).write.mode("overwrite").text(ApplicationConfig.exportHbaseLocation+"/temp/")
    FileSystemUtil.moveFile(ApplicationConfig.exportHbaseLocation+"/temp",ApplicationConfig.exportHbaseLocation+"/"+outFileName)(globalContext)

  }

  def getPLCDataIntoDSVFile(filterName:String)(globalContext: GlobalContext): Unit = {
    val s = Seq(plcHeader)
    import globalContext.sparkSession.implicits._
    val headerDF = s.toDF
    var outFileName=DPOConstants.HBASE_PLC_FILE
    val scan = new Scan()
    if(!(filterName == null  || filterName.equalsIgnoreCase("") )){
      val filter = new PrefixFilter(Bytes.toBytes(s"${filterName}"))
      scan.setFilter(filterList(filter))
      outFileName=filterName+"_"+DPOConstants.HBASE_PLC_FILE
    }
    val plcVal = globalContext.hbaseContext.hbaseRDD(TableName.valueOf(ApplicationConfig.plcTabName), scan)
    val plcInfo = plcVal.map(tuple => {
      val result = tuple._2
      val row=Bytes.toString(result.getValue(Bytes.toBytes("plc"), Bytes.toBytes("feedName")))+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+Bytes.toString(result.getValue(Bytes.toBytes("plc"), Bytes.toBytes("extractName")))+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+Bytes.toString(result.getValue(Bytes.toBytes("plc"), Bytes.toBytes("lastRunDt")))+DPOConstants.FIELD_DELIMITER_HBASE_TABLES+Bytes.toString(result.getValue(Bytes.toBytes("plc"), Bytes.toBytes("frequency")))
      row
    })
    val plcData = headerDF.union(plcInfo.toDF)
   // FileSystemUtil.saveFileToMapRFSWithoutShuffle(plcData.map(_.mkString).toDF(),ApplicationConfig.exportHbaseLocation,outFileName,"",DPOConstants.TEXT)(globalContext)
    plcData.map(_.mkString).repartition(1).write.mode("overwrite").text(ApplicationConfig.exportHbaseLocation+"/temp/")
    FileSystemUtil.moveFile(ApplicationConfig.exportHbaseLocation+"/temp",ApplicationConfig.exportHbaseLocation+"/"+outFileName)(globalContext)

  }
  /**
    *
    * @param filters
    * @return
    */
  def filterList(filters: Filter*) = new FilterList(FilterList.Operator.MUST_PASS_ALL, filters: _*)


}