package com.uhg.optum.protocols

import org.apache.hadoop.hbase.client.Result
import org.apache.hadoop.hbase.util.Bytes
import spray.json.{JsObject, JsString, JsValue, RootJsonFormat}
import spray.json._
import DefaultJsonProtocol._
import com.uhg.optum.JobRunner.PSC
import com.uhg.optum.common.{DAOModel, DPOConstants}
import com.uhg.optum.dao.{HbaseDAOModel, LocalDAOModel}

/**
  * Created by paror18 on 10/1/2018.
  */
object PSCProtocol {

  implicit object DAOModelToPSCDomain extends Converter[DAOModel, PSC] {
    override def convert(a: DAOModel): PSC = {
      if(a.isInstanceOf[LocalDAOModel]) {
        LocalModelToPSCDomain.convert(a.asInstanceOf[LocalDAOModel])
      } else
        HbaseModelToPSCDomain.convert(a.asInstanceOf[HbaseDAOModel])
    }
  }

  trait Converter[A <: DAOModel, B <: DomainModel] {
    def convert(a: A): B
  }

  implicit object LocalModelToPSCDomain extends Converter[LocalDAOModel, PSC] {
    import PSCJsonFormat._
    override def convert(a: LocalDAOModel): PSC = {
      a.jsObject match {
        case JsObject(value) =>
          value.get(a.colFm).get.convertTo[PSC]
      }
    }
  }

  implicit object HbaseModelToPSCDomain extends Converter[HbaseDAOModel, PSC] {
    override def convert(a: HbaseDAOModel): PSC = {
      val cfDataBytes = Bytes.toBytes(a.colFamily)
      val ext = (fieldName: String) => Bytes.toString(a.result.getValue(cfDataBytes, Bytes.toBytes(fieldName)))
      PSC(
        ext("feedName"), ext("extractName"), ext("entNm"), ext("prikeycols"), ext("dmlcol"),
        ext("activeflag"), ext("modtscol"), ext("fullLoadflg")
      )
    }
  }

  import scala.language.implicitConversions
  implicit def DAOModelToDomain[A <: DAOModel, B <: DomainModel](a : A)(implicit converter : Converter[A, B]) : B = converter.convert(a)

  implicit object PSCJsonFormat extends RootJsonFormat[PSC] {

    override def write(obj: PSC): JsValue = {
      JsObject("feedName" -> JsString(obj.feedName),
        "extractName" -> JsString(obj.extractName),
        "entNm" -> JsString(obj.entNm),
        "prikeycols" -> JsString(obj.prikeycols),
        "dmlcol" -> JsString(obj.dmlcol),
        "activeflag" -> JsString(obj.activeflag),
        "modtscol" -> JsString(obj.modtscol),
        "fullLoadflg" -> JsString(obj.fullLoadflg)
      )
    }

    override def read(value: JsValue): PSC = {
      val fields = value.asJsObject("Invalid Json").fields
      val ext = (fieldName :String) => fields.get(fieldName).get.convertTo[String]

      new PSC(ext("feedName"), ext("extractName"), ext("entNm"), ext("prikeycols"), ext("dmlcol"),
        ext("activeflag"), ext("modtscol"), ext("fullLoadflg")
      )
    }
  }

}
