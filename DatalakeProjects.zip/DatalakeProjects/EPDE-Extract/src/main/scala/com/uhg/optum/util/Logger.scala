package com.uhg.optum.util

import org.apache.log4j.Level

/**
  * Created by rkodur on 12/18/2017.
  */
object Logger {
  @transient lazy val log: org.apache.log4j.Logger = org.apache.log4j.LogManager.getLogger("Logger")
  //@transient lazy val log: org.apache.log4j.Logger = org.apache.log4j.LogManager.getLogger(getClass.getName)
  log.setLevel(Level.ALL)
}