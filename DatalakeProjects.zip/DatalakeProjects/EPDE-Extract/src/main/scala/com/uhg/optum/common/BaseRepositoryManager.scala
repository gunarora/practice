package com.uhg.optum.common

/**
  * Created by paror18 on 9/16/2018.
  */
trait BaseRepositoryManager {
  def getRepository(tableName: String): BaseRepository
  def closeRepository(repo: BaseRepository) : Unit
}
