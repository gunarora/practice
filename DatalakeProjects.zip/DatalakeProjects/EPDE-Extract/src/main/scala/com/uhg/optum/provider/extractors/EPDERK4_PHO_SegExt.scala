package com.uhg.optum.provider.extractors

import com.uhg.optum.provider.output.OuptutGenerator
import com.uhg.optum.common.DPOConstants
import com.uhg.optum.conf.ApplicationConfig.datafilesDir
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDERK4InputJsonSchema.{ExtractFileEntity, SegmentDetails}
import com.uhg.optum.provider.output.OuptutGenerator
import com.uhg.optum.util.CommonUtil.{add2Map, createOrReplaceTempViewFn, executeQry, occursCreation}
import com.uhg.optum.util.{CommonUtil, EPDECommonUtil, FileSystemUtil, Logger}
import org.apache.spark.sql.Row
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.sql.functions._

import scala.collection.mutable.ListBuffer

trait EPDERK4_PHO_SegExt extends OuptutGenerator {
  def phoSegGen(segDetails: SegmentDetails, outputFilePath: String, glblVarLst: collection.mutable.Map[String, String])(implicit context: GlobalContext): String = {

  /*  import scala.util.Random
    def myFunc: (String => String) = { r => {
      val A = Array("PR", "MAIL", "BILL")
      Random.shuffle(A.toList).head
    }

    }
*/
    var retStr = "N"
    /*
    val df =context.sparkSession.sql("SELECT PTA.PROV_ID as OUT_ADD_PROV_ID, PTP.TAX_ID_NBR as PTA_TAX_ID_NBR,PTP.TAX_ID_TYP_CD as PTA_TAX_ID_TYP_CD,PTA.ADR_TYP_CD as PTA_ADR_TYP_CD,PTA.ADR_ID as OUT_ADD_ADR_ID FROM  DF2_NDB_ODFR2TST.F5938DBE_PROV_TIN_ADR PTA,DF2_NDB_ODFR2TST.F5938DBE_PROV_TIN_PAY_AFFIL PTP,DF2_NDB_ODFR2TST.F5938DBE_ADR A,DF2_NDB_ODFR2TST.F5938DBE_PROV P WHERE PTA.PROV_ID       = P.PROV_ID AND PTA.PROV_ID       = PTP.PROV_ID AND  PTA.PROV_ID in (528719, 530799, 2022991) AND PTA.TAX_ID_NBR    = PTP.TAX_ID_NBR AND PTA.TAX_ID_TYP_CD = PTP.TAX_ID_TYP_CD AND PTA.ADR_TYP_CD   IN ('H','D','L','T') AND PTA.ADR_ID        =  A.ADR_ID AND ((unix_timestamp(PTP.CANC_DT,'yyyy-MM-dd')      = unix_timestamp('12/31/9999','MM/dd/yyyy')) OR (unix_timestamp(PTP.CANC_DT,'yyyy-MM-dd')     BETWEEN unix_timestamp('01/01/0001','MM/dd/yyyy') AND  unix_timestamp('12/31/9999','MM/dd/yyyy') AND unix_timestamp(PTP.LST_UPDT_DT,'yyyy-MM-dd') BETWEEN unix_timestamp('01/01/0001','MM/dd/yyyy') AND unix_timestamp('12/31/9999','MM/dd/yyyy'))) AND ((unix_timestamp(PTA.CANC_DT,'yyyy-MM-dd')  = unix_timestamp('12/31/9999','MM/dd/yyyy')) OR (unix_timestamp(PTA.CANC_DT,'yyyy-MM-dd')     BETWEEN unix_timestamp('01/01/0001','MM/dd/yyyy') AND  unix_timestamp('12/31/9999','MM/dd/yyyy') AND unix_timestamp(PTA.LST_UPDT_DT,'yyyy-MM-dd') BETWEEN unix_timestamp('01/03/2019','MM/dd/yyyy') AND unix_timestamp('12/31/9999','MM/dd/yyyy'))) AND PTP.TAX_ID_NBR NOT IN ( SELECT TAX_ID_NBR FROM  DF2_NDB_ODFR2TST.F5938DBE_DATA_VEND_CRIT_DTL WHERE DATA_VEND_FUNC_CD IN ('E' , 'B') AND  DATA_VEND_CD  =  'OPTUM' AND  CRIT_ID    =  10 AND  CRIT_COND_CD  = 'E' AND  ACTV_CD   = 'A' ) ORDER BY PTP.TAX_ID_NBR, PTA.ADR_TYP_CD ")

    val myUDF = udf(myFunc)
    val myDf=df.withColumn("OUT_ADD_TYP_CD",myUDF(df.col("PTA_TAX_ID_TYP_CD")))
    //myDf.createOrReplaceTempView("ADD_FNL_VIEW")
    val path=datafilesDir+"/"+glblVarLst("${WS_VENDR_CD}")+"/"+glblVarLst("provTypCd")+"/"
    Logger.log.info("path in the has for PRV_FNL_VIEW  "+path)
    generateOpFile(myDf, path, "ADD_FNL_VIEW")*/
    /* if(!context.sparkSession.catalog.tableExists("ADD_FNL_VIEW")){
      throw  new Exception ("The temporary view ADD_FNL_VIEW from ADD segment is reuired for PHO segment")
    }*/
try{
    var df=context.sqlContext.emptyDataFrame
    EPDECommonUtil.generateSegTables(segDetails.segTables, glblVarLst)
    //this method
    segDetails.segQueries.map { qryKey =>
      Logger.log.info("qryKey.name --> " + qryKey.name)
      if (qryKey.name.matches("PHO_FNL_VIEW")) {
        df = CommonUtil.executeQry(glblVarLst, qryKey)
        CommonUtil.createOrReplaceTempViewFn(df, qryKey.name)
        //if (df.count > 0) {
        //RPAD QUERY -> result -> write df res in file
        /*        val pspDf = CommonUtil.generateRpadQry(segDtls.segTarCol, segDtls.segTarLen, segDtls.segTolLen, qryKey.name)
              generateOpFile(pspDf, outputFilePath, segDtls.segSeq)*/

        //datafilesDir+"/"+glblVarLst("${WS_VENDR_CD}")+"/"+glblVarLst("provTypCd")+"/"
        FileSystemUtil.saveFileToMapRFS_noDropNoRepartitionParquet(df, outputFilePath, qryKey.name, "", DPOConstants.PARQUET)
        retStr = "Y"
        //}
      }
      else {
        df = CommonUtil.executeQry(glblVarLst, qryKey)
        CommonUtil.createOrReplaceTempViewFn(df, qryKey.name)
      }
    }



  /*  segDetails.segQueries.map { qryKey =>
      Logger.log.info("qryKey.name --> " + qryKey.name)
      if (qryKey.name.matches("ADR_TYP_VIEW")) {
        val tempView = qryKey.name
        var df = executeQry(glblVarLst, qryKey)


        createOrReplaceTempViewFn(df, qryKey.name)


      }
      else if (qryKey.name.matches("PHO_FNL_VIEW")) {
        val tempView = qryKey.name
        var df = executeQry(glblVarLst, qryKey)
        createOrReplaceTempViewFn(df, qryKey.name)
      //  if (df.count > 0) {
          //df.dropDuplicates()
          //RPAD QUERY -> result -> write df res in file
          //    val phoDf = CommonUtil.generateRpadQry(s.segTarCol,s.segTarLen,s.segTolLen,tempView )
          //Logger.log.info("PHO Final Query:"+phoQry)
          //val phoDf = context.sparkSession.sql(s"$phoQry")
          //listLnk.add()pho
          //list2=List(OUT_HAS_REC_TYP;OUT_HAS_PROV_ID;OUT_HAS_AFFIL_PROV_ID;OUT_HAS_EFF_DT;OUT_HAS_AFFIL_TYP_CD;OUT_HAS_CHG_IND)
          //val x = list2.toSeq
          //val df=phoDf.withColumn("pho", concat_ws("", x.map(c => col(c)): _*)).select("")
          //  val outputFilePath1=datafilesDir+"/"+glblVarLst("${WS_VENDR_CD}")+"/"+glblVarLst("provTypCd")+"/"
          //generateOpFile(df, outputFilePath, "PHO_FNL_VIEW")

        FileSystemUtil.saveFileToMapRFS(df.dropDuplicates(), outputFilePath, qryKey.name, "", DPOConstants.PARQUET)
          retStr = "Y"
        //}
      }



  }*/

  /*if(segDetails.segName.equals("PHO"))
    var qryStr = qryKey.query.replace("${WS_PREV_RUN_DT}", WS_PREV_RUN_DT)

  */
  retStr
}catch {

  case e: Exception => {
    Logger.log.info(s"RK4 : EPDERK4_PHO_SegExt.genPHOSeg() : "+e.getMessage)
    throw e
  }

}
}

}
