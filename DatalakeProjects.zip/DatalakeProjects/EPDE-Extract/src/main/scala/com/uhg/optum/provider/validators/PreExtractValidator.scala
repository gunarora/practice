package com.uhg.optum.provider.validators

import com.uhg.optum.JobRunner.PEI
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDEInputJsonSchema.{ExtractFileEntity, QueryDetail}
import com.uhg.optum.util.{EPDECommonUtil, Logger}
import org.apache.spark.sql.DataFrame

import scala.util.{Failure, Success, Try}

object PreExtractValidator {
  /**
    * This method does the validation of the vendor
    * based upon the input query and count provided by the query
    * @param queryMap
    * @param key
    * @param valueToBeChecked
    * @param vendorCode
    * @param context
    * @return
    */
  def validate(queryMap: Map[String, String], key: String, valueToBeChecked: String, vendorCode: String,lastRunPlc :String)(implicit context: GlobalContext,pei:PEI): Try[Boolean] = {
    Try {
      var retValue = true
      /*  val venCheckQuery = queryMap.get(key).head.toString
        val optiVenCheckQuery = EPDECommonUtil.optimiseQuery(venCheckQuery, vendorCode, valueToBeChecked)
        val df = EPDECommonUtil.getDataframeFromQuery(optiVenCheckQuery).get*/
      val df=EPDECommonUtil.getDataframe(queryMap,key,valueToBeChecked,vendorCode,lastRunPlc).get
      Logger.log.info(s"RKP: PreExtractValidator: Inside validate method")
      if (df.count == 0) {
        Logger.log.info(s"$key count = 0")
        retValue = false
      }
      Logger.log.info("RKP: PreExtractValidator: Return value after validate method: " + retValue)
      retValue
    }match {
      case Success(retValue) => Logger.log.info("RKP: PreEXcreactValidator: validate: Success")
        Success(retValue)
      case Failure(ex) => {
        Logger.log.info("RKP: PreEXcreactValidator: validate: " + ex.getMessage)
        Logger.log.error("Error occured : " + ex.getStackTrace.mkString("\n"))
        throw ex
      }
    }
  }


  /**
    * This method checks the fullFileIndicator based upon
    * vendor code and timing of the run
    * @param commQuery
    * @param vendorCode
    * @param currDay
    * @param currWeekOfMon
    * @param context
    * @return
    */
  def checkFullFileIndicator(commQuery: Map[String, String], vendorCode: String, currDay: Int, currWeekOfMon: Int,lastRunPlc:String)(implicit context: GlobalContext,pei:PEI): Try[String] = {
    Try {
      var fullFileInd = ""
      Logger.log.info("RKP: PreExtractValidator: checkFullFileIndicator")
      val df5 = EPDECommonUtil.getDataframe(commQuery, "df5_query", "$vendor_cd", vendorCode: String, lastRunPlc: String).get
      val df5Count = df5.count()
      if (df5Count == 1) {
        Logger.log.info("RKP: PreExtractValidator: checkFullFileIndicator: TR5 count: 1")
        fullFileInd = df5.head.apply(0).toString
        if ((fullFileInd.equals("W") && currDay > 5) || (fullFileInd.equals("M") && currDay > 5 && currWeekOfMon == 1) || (fullFileInd.equals("O")))
          fullFileInd = "F"
        else if (fullFileInd.equals("P"))
          fullFileInd = "P"
        else
          fullFileInd = "N"
      } else if (df5Count < 1) {
        Logger.log.info("RKP: PreExtractValidator: checkFullFileIndicator: TR5 count: 0")
        fullFileInd = "N"
      } else {
        fullFileInd = "V"
        Logger.log.info("RKP: PreExtractValidator: checkFullFileIndicator: TR5 count: More than 1")
      }
      fullFileInd
      //"V"
    } match {
      case Success(fullFileInd) => Logger.log.info("RKP: PreEXcreactValidator: checkFullFileIndicator: Success")
        Success(fullFileInd)
      case Failure(ex) => {
        Logger.log.info("RKP: PreExtractValidator: checkFullFileIndicator: " + ex.getMessage)
        throw ex
      }
    }
  }

  /**
    * This method checks criteria based upon the
    * vendor code
    * @param queryMap
    * @param key
    * @param valueToBeChecked
    * @param vendorCode
    * @param context
    * @return
    */
  def getCriteriaIndicator(queryMap: Map[String, String], key: String, valueToBeChecked: String, vendorCode: String,lastRunPlc:String)(implicit context: GlobalContext,pei:PEI): String = {
    try {
      var critInd = "N"
      Logger.log.info("RKP: PreExtractValidator: getCriteriaIndicator: TR8")
      val df = EPDECommonUtil.getDataframe(queryMap, key, valueToBeChecked, vendorCode, lastRunPlc).get
      val dfCnt=df.count
      Logger.log.info("RKP: PreExtractValidator: getCriteriaIndicator: TR8 Count: "+dfCnt )
      if (dfCnt >= 1) {
        critInd = "Y"
      }
      Logger.log.info("RKP: PreExtractValidator: getCriteriaIndicator: critInd: "+critInd )
      critInd
    }catch {
      case e: Exception => {
        Logger.log.error("RKP: PreExtractValidator: getCriteriaIndicator " + e.getMessage)
        throw e
      }
    }
  }

  /*def isActiveVendorHasEPDEFunc(vendorCode:String, inputEntity:ExtractFileEntity):Boolean={
    var retValue=true
    val commQuery=EPDECommonUtil.getCommonQueriesDetails(inputEntity).head.queries
    val venCheckQuery=commQuery.get("df2_query").head.toString
    val optiVenCheckQuery=EPDECommonUtil.optimiseQuery(venCheckQuery,vendorCode,"$vendor_cd")
    val df=EPDECommonUtil.getDataframeFromQuery(optiVenCheckQuery)
    if (df.count <= 0) {
      println("ACTIVE VENDOR CD WITH EPDE FUNCTION NOT FOUND ON DATA_VEND_FUNC TABLE, VENDOR = " + vendorCode)
      retValue=false
    }
    retValue
  }*/
}