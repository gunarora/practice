package com.uhg.optum.provider

import com.uhg.optum.JobRunner.PEI
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDEInputJsonSchema.ExtractFileEntity
import com.uhg.optum.provider.DefaultExtractProvider.ExtractOutput
import com.uhg.optum.provider.snapshot.PJSSnapshotProvider

import scala.util.Try

/**
  * Created by paror18 on 10/19/2018.
  */
class PJSExtractProvider(implicit  context: GlobalContext, pei: PEI) extends DefaultExtractProvider with PJSSnapshotProvider{

   override def extract(jsonFile: Option[ExtractFileEntity], pitRowKey: String): ExtractOutput = {
   getEntityMetaDataInfo()
    genPJSExtractPerEnt()

    val extractResult = super.extract(jsonFile, pitRowKey)
   // extractResult
    null


  }

}
