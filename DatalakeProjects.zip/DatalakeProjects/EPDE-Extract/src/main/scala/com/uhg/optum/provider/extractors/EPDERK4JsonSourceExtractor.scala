package com.uhg.optum.provider.extractors

import java.text.SimpleDateFormat
import java.util

import com.uhg.optum.conf.ApplicationConfig._
import com.uhg.optum.EPDERK4JobRunner
import com.uhg.optum.JobRunner.PEI
import com.uhg.optum.common.DPOConstants
import com.uhg.optum.conf.ApplicationConfig
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDERK4InputJsonSchema
import com.uhg.optum.protocols.EPDERK4InputJsonSchema.{ExtractFileEntity, Query, SegmentDetails}
import com.uhg.optum.util._
import org.apache.spark.sql.{DataFrame, Row}
import com.uhg.optum.util.CommonUtil._
import org.apache.spark.sql.types.{IntegerType, StringType, StructField, StructType}
import com.uhg.optum.provider.output.OuptutGenerator
import com.uhg.optum.util.EPDECommonUtil.getDataframeFromQuery
import com.uhg.optum.util.exceptions.{QueryFailureException, SegmentFailureException}
import org.apache.hadoop.fs.Path

import scala.collection.mutable
import scala.collection.mutable.{ArrayBuffer, HashMap, ListBuffer}
import scala.util.Try



trait EPDERK4JsonSourceExtractor extends OuptutGenerator with EPDERK4_HRS_SegExt with EPDERK4_AD1_SegExt with EPDERK4_COS_SegExt with EPDERK4_TCO_SegExt  with EPDERK4_PTI_SegExt with EPDERK4_COE_SegExt with EPDERK4_CDK_SegExt with EPDERK4_CON_SegExt with EPDERK4_CSP_SegExt with EPDERK4_CUL_SegExt with EPDERK4_ACT_SegExt with EPDERK4_ALT_SegExt with EPDERK4_TIN_SegExt with EPDERK4_PSP_SegExt with EPDERK4_PRV_SegExt with EPDERK4_ACO_SegExt with EPDERK4_SCO_SegExt with EPDERK4_ADD_SegExt with EPDERK4_HAS_SegExt with EPDERK4_PHO_SegExt with EPDERK4_LGS_SegExt with EPDERK4_PFA_SegExt with EPDERK4_NCE_SegExt with EPDERK4_HCA_SegExt with EPDERK4_NPI_SegExt with EPDERK4_LNG_SegExt with EPDERK4_PLI_SegExt with EPDERK4_PQI_SegExt{


  def generateExtractFromJson(inputEntity: ExtractFileEntity,peiRowKey:String,outputFilePath:String,vndrCd:String,provTypCd:String,lastRunPlc:String,varfeedName:String,peiExtractName:String)(implicit context: GlobalContext, pei: PEI): String = {
    try {
      Logger.log.info("===> Starting RK4Start Common <===")
      ///RK4Start
      var AMA_SPEC_TABLE_Cnt=0  // temp value
      var SW_SRCEXCL_CRIT ='N' // temp default value

      val WS_PREV_RUN_DT=getDateTimeFormat(lastRunPlc,"yyyy-MM-dd HH:mm:ss","yyyy-MM-dd")
      /*val WS_PREV_RUN_DT="2019-01-01" //TODO: From PLC*/
      val WS_CURRENT_DATE= getDateTimeFormatET("MM/dd/YYYY hh:mm a").substring(0,10)//(CURRENT DATE,USA)
      val WS_CURRENT_TIME=getDateTimeFormatET("YYYY-MM-dd HH.mm.ss").substring(11,19)//(CURRENT TIME,ISO)
      val WS_DB2_DATE=getDateTimeFormat(WS_PREV_RUN_DT,"yyyy-MM-dd","MM/dd/yyyy")
      val WS_PREV_RUN_DT_YMD = getDateTimeFormat(WS_PREV_RUN_DT,"yyyy-MM-dd","yyyyMMdd") //WS_PREV_RUN_DT in CCYYMMDD

      val WS_CANC_DT_1="01/01/0001"  // used in PSP ; genrated in
      val WS_CANC_DT_2="12/31/9999"  // used in PSP ; genrated in

      val WS_UPDT_DT_1= getDateTimeFormat(WS_PREV_RUN_DT,"yyyy-MM-dd","MM/dd/yyyy")  // used in PSP

      //val WS_UPDT_DT_1= "03/01/2019"
      // val WS_PREV_RUN_DT_YMD="20190301"
      //    var SchemaNm ="F5938DBE"

      val WS_UPDT_DT_2="12/31/9999"   // used in PSP
      val WS_ACTV_CD_1="A"  // used in ADD
      val WS_ACTV_CD_2="I"   // used in ADD
      //var WS_PROV_TYP_CD_1=""  // used in PSP ; generated in  PRV
      //var WS_PROV_TYP_CD_2=""   // used in PSP ;generated in  PRV


      var glblVarLst,varLst, emptyLst,tempLst  = collection.mutable.Map[String, String]()

      add2Map(glblVarLst,"${WS_CANC_DT_1}",WS_CANC_DT_1)
      add2Map(glblVarLst,"${WS_CANC_DT_2}",WS_CANC_DT_2)
      add2Map(glblVarLst,"${WS_UPDT_DT_1}",WS_UPDT_DT_1)
      add2Map(glblVarLst,"${WS_UPDT_DT_2}",WS_UPDT_DT_2)
      add2Map(glblVarLst,"${ACTUAL_VENDR_CD}",vndrCd)
      add2Map(glblVarLst,"${WS_VENDR_CD}",peiExtractName)
      add2Map(glblVarLst,"${WS_ACTV_CD_1}",WS_ACTV_CD_1)
      add2Map(glblVarLst,"${WS_ACTV_CD_2}",WS_ACTV_CD_2)
      add2Map(glblVarLst,"${WS_PREV_RUN_DT_YMD}",WS_PREV_RUN_DT_YMD)
      add2Map(glblVarLst,"${WS_CURRENT_DATE}",WS_CURRENT_DATE)
      add2Map(glblVarLst,"${WS_PREV_RUN_DT}",WS_PREV_RUN_DT)
      add2Map(glblVarLst,"provTypCd",provTypCd)
      //val SchemaNm=inputEntity.schemaNm
      val SchemaNm = schema
      add2Map(glblVarLst,"${SchemaNm}",SchemaNm)

      varLst=glblVarLst
      //var df_sco,df_tin = context.sqlContext.emptyDataFrame

      var tmpVwPath=workingDir+DPOConstants.SLASH+varfeedName+DPOConstants.SLASH+vndrCd+DPOConstants.SLASH+provTypCd+DPOConstants.SLASH
      add2Map(glblVarLst,"tmpVwPath",tmpVwPath)
      add2Map(glblVarLst,"outputFilePath",outputFilePath)


      var validSegNm=inputEntity.segmentList.split(";").to[ArrayBuffer]

      Logger.log.info("===> the super segment list is <=="+inputEntity.segmentList)
      Logger.log.info("===>schema name for "+inputEntity.programName +" is  ::: " +SchemaNm)

      var FinaltempPath=""

      inputEntity.segmentDetails.foreach{ segDtls=>

        if(segDtls.segName.contains("RK4Start")) {
          EPDECommonUtil.generateSegTables(segDtls.segTables,glblVarLst)
          segDtls.segQueries.foreach { qryKey =>
            //var df = context.sqlContext.emptyDataFrame
            // commenting below for using original instead of OCCURS table
            /*   if (qryKey.name.equals("AMA_SPEC_TABLE_CNT")) {
                 var df_ama = context.sqlContext.emptyDataFrame
                 df_ama=executeQry(varLst,qryKey)
                 var AMA_SPEC_TABLE_CNT =df_ama.select("AMA_SPEC_TABLE_CNT").collect()(0).getLong(0).toInt
                 Logger.log.info("INFO: original AMA_SPEC_TABLE_CNT is  "+AMA_SPEC_TABLE_CNT)
                 if(AMA_SPEC_TABLE_CNT >1000){
                   AMA_SPEC_TABLE_CNT=1000
                 }else{
                   AMA_SPEC_TABLE_CNT=AMA_SPEC_TABLE_CNT
                 }
                 Logger.log.info("INFO: considered AMA_SPEC_TABLE_CNT is  "+AMA_SPEC_TABLE_CNT)
                 //global variable
                 add2Map(glblVarLst,"AMA_SPEC_TABLE_Cnt",AMA_SPEC_TABLE_CNT.toString)
                 var occurStmnt = qryKey.occurStmnt.getOrElse("")
                 var occrNm=qryKey.occursNm.getOrElse("")
                 Logger.log.info(s"INFO: occurStmnt for $occrNm --> $occurStmnt")
                 var whrClause= occurStmnt.split("~")(3)
                 var tblNm= occurStmnt.split("~")(4).replace("${SchemaNm}",SchemaNm)
                 var occurFnlQryDF= occursCreation(occurStmnt,AMA_SPEC_TABLE_CNT,occrNm,SchemaNm,whrClause,tblNm)
                 FileSystemUtil.saveFileToMapRFS(occurFnlQryDF,glblVarLst.get("tmpVwPath").getOrElse(workingDir),occrNm,"",DPOConstants.PARQUET)
                 //println("occurStmnt " + occurStmnt)
                 createOrReplaceTempViewFn(occurFnlQryDF,occrNm)
               } else if (qryKey.name.equals("CTE1_SITEG_GRP_NUM")) {
                 var df_CTE1_SITEG = context.sqlContext.emptyDataFrame
                 df_CTE1_SITEG  =executeQry(varLst,qryKey)
                 var CTE1_SITEG_GRP_NUM =df_CTE1_SITEG.select("CNT").collect()(0).getLong(0).toInt
                 Logger.log.info("INFO: considered CTE1_SITEG_GRP_NUM is  "+CTE1_SITEG_GRP_NUM)
                 var occurStmnt = qryKey.occurStmnt.getOrElse("")
                 var occrNm=qryKey.occursNm.getOrElse("")
                 Logger.log.info(s"INFO: occurStmnt for $occrNm --> $occurStmnt")
                 var whrClause= occurStmnt.split("~")(3)
                 var tblNm= occurStmnt.split("~")(4).replace("${SchemaNm}",SchemaNm)
                 var occurFnlQryDF= occursCreation(occurStmnt,CTE1_SITEG_GRP_NUM,occrNm,SchemaNm,whrClause,tblNm)
                 FileSystemUtil.saveFileToMapRFS(occurFnlQryDF,glblVarLst.get("tmpVwPath").getOrElse(workingDir),occrNm,"",DPOConstants.PARQUET)
                 createOrReplaceTempViewFn(occurFnlQryDF,occrNm)
               }  else if (qryKey.name.equals("CTE1_MKT_CSR")) {
                 var df_CTE1_MKT = context.sqlContext.emptyDataFrame
                 //val qryStrTmp=qryKey.query.replace("${SchemaNm}",SchemaNm).replace("${WS_SQL_PROV_ID}",WS_SQL_PROV_ID).replace("${WS_VENDR_CD}",WS_VENDR_CD)
                 df_CTE1_MKT =executeQry(varLst,qryKey)
                 //context.sqlContext.sql(s"qryStrTmp")
                 createOrReplaceTempViewFn(df_CTE1_MKT,qryKey.name)
                 var CTE1_MKT_CSR =df_CTE1_MKT.select("CNT").collect()(0).getLong(0).toInt
                 var occurStmnt = qryKey.occurStmnt.getOrElse("")
                 var occrNm=qryKey.occursNm.getOrElse("")
                 Logger.log.info(s"INFO: occurStmnt for $occrNm --> $occurStmnt")
                 var whrClause= occurStmnt.split("~")(3)
                 var tblNm= occurStmnt.split("~")(4).replace("${SchemaNm}",SchemaNm)
                 var occurFnlQryDF=occursCreation(occurStmnt,CTE1_MKT_CSR,qryKey.occursNm.toString,SchemaNm,whrClause,tblNm)
                 FileSystemUtil.saveFileToMapRFS(occurFnlQryDF,glblVarLst.get("tmpVwPath").getOrElse(workingDir),occrNm,"",DPOConstants.PARQUET)
                 createOrReplaceTempViewFn(occurFnlQryDF,occrNm)
               }else if (qryKey.name.equals("CTE1_PRDCT_OFR_CSR")) {
                 var df_CTE1_PRDCT = context.sqlContext.emptyDataFrame
                 //val qryStrTmp=qryKey.query.replace("${SchemaNm}",SchemaNm).replace("${WS_SQL_PROV_ID}",WS_SQL_PROV_ID).replace("${WS_VENDR_CD}",WS_VENDR_CD)
                 df_CTE1_PRDCT = executeQry(varLst,qryKey)
                 createOrReplaceTempViewFn(df_CTE1_PRDCT,qryKey.name)
                 var CTE1_PRDCT_OFR_CSR =df_CTE1_PRDCT.select("CNT").collect()(0).getLong(0).toInt
                 var occurStmnt = qryKey.occurStmnt.getOrElse("")
                 var occrNm=qryKey.occursNm.getOrElse("")
                 Logger.log.info(s"INFO: occurStmnt for $occrNm --> $occurStmnt")
                 var whrClause= occurStmnt.split("~")(3)
                 var tblNm= occurStmnt.split("~")(4).replace("${SchemaNm}",SchemaNm)
                 var occurFnlQryDF=occursCreation(occurStmnt,CTE1_PRDCT_OFR_CSR,qryKey.occursNm.toString,SchemaNm,whrClause,tblNm)
                 //"SELECT MKT_NBR AS  LS_MKT_NBR  , MKT_NM AS  LS_MKT_NM   , CNT   FROM ${WS_SQL_PROV_ID}_${SchemaNm}_MKT, CTE1_MKT_CSR WHERE unix_timestamp(CANC_DT,yyyy-MM-dd) = unix_timestamp('9999-12-31',yyyy-MM-dd)  ORDER BY 1
                 //println("occurStmnt " + occurStmnt)
                 FileSystemUtil.saveFileToMapRFS(occurFnlQryDF,glblVarLst.get("tmpVwPath").getOrElse(workingDir),occrNm,"",DPOConstants.PARQUET)
                 createOrReplaceTempViewFn(occurFnlQryDF,occrNm)
               }
               else if (qryKey.name.equals("TBL_SOURCE_EXCLUSIONS_CNT")) {
                 var df_TBL_SRC_EXC = context.sqlContext.emptyDataFrame
                 df_TBL_SRC_EXC = executeQry(varLst,qryKey)
                 //context.sqlContext.sql(s"qryStrTmp")
                 //val qryStrTmp=qryKey.query.replace("${SchemaNm}",SchemaNm).replace("${WS_SQL_PROV_ID}",WS_SQL_PROV_ID).replace("${WS_VENDR_CD}",WS_VENDR_CD)
                 if (df_TBL_SRC_EXC.count() == 0) {
                   SW_SRCEXCL_CRIT = 'Y'  // global variable
                   add2Map(glblVarLst,"SW_SRCEXCL_CRIT","Y")
                 }else{
                   val qryStrTmp=qryKey.query.replace("${SchemaNm}",SchemaNm).replace("${WS_VENDR_CD}",vndrCd)
                   var TBL_SOURCE_EXCLUSIONS =df_TBL_SRC_EXC.select("CNT").collect()(0).getLong(0).toInt
                   var occurStmnt = qryKey.occurStmnt.getOrElse("")
                   var occrNm=qryKey.occursNm.getOrElse("")
                   Logger.log.info(s"INFO: occurStmnt for $occrNm --> $occurStmnt")
                   var whrClause= occurStmnt.split("~")(3)
                   var tblNm= occurStmnt.split("~")(4).replace("${SchemaNm}",SchemaNm).replace("${WS_VENDR_CD}",vndrCd)
                   TBL_SOURCE_EXCLUSIONS=50
                   var occurFnlQryDF=occursCreation(occurStmnt,TBL_SOURCE_EXCLUSIONS,qryKey.occursNm.toString,SchemaNm,whrClause,tblNm)
                   //                println("occurStmnt " + occurStmnt)
                   FileSystemUtil.saveFileToMapRFS(occurFnlQryDF,glblVarLst.get("tmpVwPath").getOrElse(workingDir),occrNm,"",DPOConstants.PARQUET)
                   createOrReplaceTempViewFn(occurFnlQryDF,occrNm)
                 }
               }
               else*/
            if (qryKey.name.equals("EPDE_SEG_EXC")) {
              var df_EPDE_SEG_EXC = context.sqlContext.emptyDataFrame
              df_EPDE_SEG_EXC = executeQry(varLst,qryKey)

              createOrReplaceTempViewFn(df_EPDE_SEG_EXC,qryKey.name)
              // FileSystemUtil.saveFileToMapRFS(df_EPDE_SEG_EXC,glblVarLst.get("tmpVwPath").getOrElse(workingDir),qryKey.name,"",DPOConstants.PARQUET)

              //var inValidSegNm =df_EPDE_SEG_EXC.collect.map(rec=> EPDE_SEG_EXC_CASE(rec.getAs[String]("WS_EPDE_SEG")).toString).to[ArrayBuffer]
              var inValidSegNm =df_EPDE_SEG_EXC.collect.map(rec=> rec.getAs[String]("WS_EPDE_SEG").toString).to[ArrayBuffer]
              //inValidSegNm = ArrayBuffer("PLI", "PFA", "TIN", "PTI", "TCO", "NCE", "ADD", "PHO", "ACT")
              Logger.log.info("INFO: invalid segement list for vendor :"+vndrCd+" is -->"+inValidSegNm)
              validSegNm --= inValidSegNm
              Logger.log.info("INFO: valid segement list for vendor :"+vndrCd+" is -->"+validSegNm)

            }
            else if (qryKey.name.equals("TBL_SOURCE_EXCLUSIONS_ORIG")) {
              Logger.log.info("INFO  : the Query name -- >"+qryKey.name)
              var df = context.sqlContext.emptyDataFrame
              df = executeQry(varLst, qryKey)
              FileSystemUtil.saveFileToMapRFSNoRepartitionParquet(df,glblVarLst.get("tmpVwPath").getOrElse(workingDir),qryKey.name,"",DPOConstants.PARQUET)
              createOrReplaceTempViewFn(df,qryKey.name)
            }
            else if (qryKey.name.equals("AMA_SPEC_TABLE_ORIG")) {
              Logger.log.info("INFO  : the Query name -- >"+qryKey.name)
              var df = context.sqlContext.emptyDataFrame
              df = executeQry(varLst, qryKey)
              FileSystemUtil.saveFileToMapRFSNoRepartitionParquet(df,glblVarLst.get("tmpVwPath").getOrElse(workingDir),qryKey.name,"",DPOConstants.PARQUET)
              createOrReplaceTempViewFn(df,qryKey.name)
            }
            else if (qryKey.name.equals("LS_SITEG_ARRAY_AREA_ORIG")) {
              Logger.log.info("INFO  : the Query name -- >"+qryKey.name)
              var df = context.sqlContext.emptyDataFrame
              df = executeQry(varLst, qryKey)
              FileSystemUtil.saveFileToMapRFSNoRepartitionParquet(df,glblVarLst.get("tmpVwPath").getOrElse(workingDir),qryKey.name,"",DPOConstants.PARQUET)
              createOrReplaceTempViewFn(df,qryKey.name)
            }
            else if (qryKey.name.equals("LS_MKT_ARRAY_AREA_ORIG")) {
              Logger.log.info("INFO  : the Query name -- >"+qryKey.name)
              var df = context.sqlContext.emptyDataFrame
              df = executeQry(varLst, qryKey)
              FileSystemUtil.saveFileToMapRFSNoRepartitionParquet(df,glblVarLst.get("tmpVwPath").getOrElse(workingDir),qryKey.name,"",DPOConstants.PARQUET)
              createOrReplaceTempViewFn(df,qryKey.name)
            }
            else if (qryKey.name.equals("LS_PRDCT_OFR_ARRAY_AREA_ORIG")) {
              Logger.log.info("INFO  : the Query name -- >"+qryKey.name)
              var df = context.sqlContext.emptyDataFrame
              df = executeQry(varLst, qryKey)
              FileSystemUtil.saveFileToMapRFSNoRepartitionParquet(df,glblVarLst.get("tmpVwPath").getOrElse(workingDir),qryKey.name,"",DPOConstants.PARQUET)
              createOrReplaceTempViewFn(df,qryKey.name)
            }
          }
        }


      }
      var jsonSegList = inputEntity.segmentDetails.map(a=>a.segName).to[ArrayBuffer]
      if (jsonSegList.size >= validSegNm.size)
      {
        if(validSegNm.forall(seg => jsonSegList.contains(seg)))
        {
          Logger.log.info("All Valid Segments are present in JSON")
          callSeg(validSegNm,inputEntity,outputFilePath,varLst,glblVarLst,provTypCd)
        }
        else{
          Logger.log.info("Same array size but some Segments are missing in JSON")
          throw SegmentFailureException("segment list  is invalid ; segments are missing in JSON")
        }
      }
      else
      {
        Logger.log.info("Some Segments are missing in JSON")
        throw SegmentFailureException("segment list  is invalid ; segments are missing in JSON")
      }

      Logger.log.info("inputEntity.segmentDetails.size --> "+inputEntity.segmentDetails.size)
      Logger.log.info("All segments created, Initialtin Hierarchial File Creation.")

      generateHierarchialFile(inputEntity, validSegNm, vndrCd, provTypCd,peiExtractName)


      FinaltempPath

    }catch {
      case c: SegmentFailureException => {
        Logger.log.info("RK4 : EPDERK4JsonSourceExtractor.generateExtractFromJson() "+c.getMessage)
        throw c
      }
      /* case q: QueryFailureException => {
         Logger.log.info("RK4 : EPDERK4JsonSourceExtractor.generateExtractFromJson() "+q.getMessage)
         throw q
       }
 */
      case e: Exception => {
        Logger.log.info("RK4 : EPDERK4JsonSourceExtractor.generateExtractFromJson() "+e.getMessage)
        throw e
      }

    }

  }

  /**
    *
    * @param vndrCd
    * @param context
    * @param pei
    * @return
    */

  def createTouchFiles(vndrCd: String)(implicit context: GlobalContext,pei: PEI): Unit ={

    Logger.log.info(s"create Touch File for ${vndrCd}")

    val vndrCode = pei.consumingApp
    Logger.log.info(s"select CRIT_TXT_VAL_1 FROM ${schema}_DATA_VEND_CRIT_DTL WHERE trim(DATA_VEND_CD)= '$vndrCode' AND trim(DATA_VEND_FUNC_CD) =  'E' AND CRIT_ID = 3 AND trim(ACTV_CD) = 'A' AND trim(CRIT_COND_CD) = 'I'")
    val dataDF = context.sqlContext.sql(s"select CRIT_TXT_VAL_1 FROM ${schema}_DATA_VEND_CRIT_DTL WHERE trim(DATA_VEND_CD)= '$vndrCode' AND trim(DATA_VEND_FUNC_CD) =  'E' AND CRIT_ID = 3 AND trim(ACTV_CD) = 'A' AND trim(CRIT_COND_CD) = 'I'")
    val crit_txt_val_1 = dataDF.first()(0).toString()

    Logger.log.info(s"Full file indicator ${crit_txt_val_1}")

    // Uncomment the condition once testing is done
    if(crit_txt_val_1=="O"||crit_txt_val_1=="P"){
      val venderCodePadded=vndrCd.padTo(5," ").mkString
      val touchFileBuilder = StringBuilder.newBuilder
      touchFileBuilder.append(s"${venderCodePadded}")
      touchFileBuilder.append(s"${crit_txt_val_1}")
      touchFileBuilder.append(s"    ${DPOConstants.NEWLINECHAR}")

      val touchFileContent = touchFileBuilder.mkString("")
      Logger.log.info(s"touchFileContent ${touchFileContent}")

      val extractFilePath = ApplicationConfig.dataDir + DPOConstants.SLASH + vndrCd + DPOConstants.SLASH

      FileSystemUtil.createHDFSFile(extractFilePath + ApplicationConfig.touchFileName, touchFileContent)
      Logger.log.info("SFTP created")
    }

  }

  def createZipFiles(vndrCd: String,provTypCd : String)(implicit context: GlobalContext,pei: PEI): String ={
    val zipFilePath = ApplicationConfig.outboxDir + vndrCd + DPOConstants.SLASH+provTypCd+DPOConstants.SLASH
    Logger.log.info(s"ZipFilePath :::: " + zipFilePath)
    val currentDate = CommonUtil.getCurrentDateTime("YYYYMMdd")

    Logger.log.info(s"Getting list of files " +ApplicationConfig.dataDir + vndrCd + DPOConstants.SLASH + DPOConstants.SLASH+provTypCd +DPOConstants.SLASH)

    val fileList = FileSystemUtil.getListOfFiles("/mapr/"+ApplicationConfig.dataDir + vndrCd + DPOConstants.SLASH + DPOConstants.SLASH+provTypCd +DPOConstants.SLASH)

    Logger.log.info(s"files "+fileList.mkString(","))

    val outFileName = fileList(0).getName
    val srcpath = ApplicationConfig.dataDir + vndrCd + DPOConstants.SLASH + DPOConstants.SLASH+provTypCd +DPOConstants.SLASH + outFileName

    FileSystemUtil.mkdirs(ApplicationConfig.outboxDir + vndrCd )
    FileSystemUtil.mkdirs(ApplicationConfig.outboxDir + vndrCd + DPOConstants.SLASH+provTypCd)

    // if(dateformattedOutFiles.contains(DPOConstants.PIPE)){

    var outFileLoc_Temp=""
    val outFileLoc = ApplicationConfig.dataDir + vndrCd + DPOConstants.SLASH  + provTypCd + DPOConstants.SLASH

    if(s"${vndrCd}".equalsIgnoreCase("OXHP")) /// since OXHP doesn't has facility file
    {
      outFileLoc_Temp= s"${ApplicationConfig.dataDir}${vndrCd}${DPOConstants.SLASH}${ApplicationConfig.physicianTypFrm}${DPOConstants.SLASH}${DPOConstants.SEMI_COLON}${ApplicationConfig.dataDir}${vndrCd}${DPOConstants.SLASH}${ApplicationConfig.groupTypFrm}${DPOConstants.SLASH}"
    }else {
      outFileLoc_Temp = s"${ApplicationConfig.dataDir}${vndrCd}${DPOConstants.SLASH}${ApplicationConfig.physicianTypFrm}${DPOConstants.SLASH}${DPOConstants.SEMI_COLON}${ApplicationConfig.dataDir}${vndrCd}${DPOConstants.SLASH}${ApplicationConfig.groupTypFrm}${DPOConstants.SLASH}${DPOConstants.SEMI_COLON}${ApplicationConfig.dataDir}${vndrCd}${DPOConstants.SLASH}${ApplicationConfig.facilitiesTypFrm}${DPOConstants.SLASH}"
    }

    Logger.log.info("INFO :::: inside create zip file  :: output temp path  "+outFileLoc_Temp)
    val peiOutFileLocs = outFileLoc_Temp.split(DPOConstants.SEMI_COLON)

    var zipFileName = ""

    peiOutFileLocs.zipWithIndex.foreach((peiFileLoc) => {
      if(peiFileLoc._1 == outFileLoc){
        val index = peiFileLoc._2
        zipFileName = pei.outFileName.split(DPOConstants.SEMI_COLON)(index.toInt)
        if(zipFileName.contains(DPOConstants.PIPE)) {
          zipFileName = zipFileName.split(DPOConstants.PIPE)(1)
        }
        zipFileName = if(zipFileName.contains("YYYYMMdd")) zipFileName.replace("YYYYMMdd", CommonUtil.getCurrentDateTime("YYYYMMdd")) else zipFileName
      }
    })

    Logger.log.info(s"INFO :::: inside create zip file  :: ZIP file name for ${vndrCd} ${zipFileName}")

    if(pei.outFileExt=="ZIP" || pei.outFileExt=="ZIPALL"){
      FileSystemUtil.zipFile("/mapr"+zipFilePath+zipFileName,"/mapr"+srcpath,outFileName)
      "/mapr" + zipFilePath + zipFileName
    }else{
      val destPath = zipFilePath + outFileName
      Logger.log.info(s"Copying file "+outFileName)
      FileSystemUtil.copyFSFile(srcpath,destPath)
      "/mapr"+destPath
    }
  }

  def createSftpFileForDestination(sftpFileDestinationList: List[String],vndrCd : String)(implicit context: GlobalContext, pei: PEI): Unit = {

    Logger.log.info(s"createSftpFileForDestination files " + sftpFileDestinationList.mkString(","))

    val sftpBuilder = StringBuilder.newBuilder
    sftpBuilder.append(s"cd ${ApplicationConfig.ecgLocation}${DPOConstants.NEWLINECHAR}")
    sftpFileDestinationList.foreach(line => sftpBuilder.append(s"put ${line}${DPOConstants.NEWLINECHAR}") )
    // sftpBuilder.append(s"put ${sftpFile}${DPOConstants.NEWLINECHAR}")

    val extractFilePath = ApplicationConfig.dataDir + DPOConstants.SLASH + vndrCd + DPOConstants.SLASH
    val metaContent = sftpBuilder.mkString("")
    FileSystemUtil.createHDFSFile(extractFilePath + "touch_" + vndrCd + "_SFTP", metaContent)
    Logger.log.info("createSftpFileForDestination created")

  }

  def createSftpFileForSource(vndrCd: String,sftpFile: String)(implicit context: GlobalContext, pei: PEI): Unit = {

    Logger.log.info(s"createSftpFileForSource files " + sftpFile)

    val sftpBuilder = StringBuilder.newBuilder
    sftpBuilder.append(s"cd ${ApplicationConfig.touchFileECGLocation}${DPOConstants.NEWLINECHAR}")
    sftpBuilder.append(s"put /mapr${sftpFile}${DPOConstants.NEWLINECHAR}")

    val extractFilePath = ApplicationConfig.dataDir + DPOConstants.SLASH + vndrCd + DPOConstants.SLASH
    val metaContent = sftpBuilder.mkString("")
    FileSystemUtil.createHDFSFile(extractFilePath + "trigger_" + vndrCd + "_SFTP", metaContent)
    Logger.log.info("createSftpFileForSource created")

  }

  def createMetaFile(vndrCd: String)(implicit context: GlobalContext,pei: PEI): String=
  {

    val outFileNames = if(pei.outFileExt=="ZIP" || pei.outFileExt=="ZIPALL" ) {
      val outFiles = pei.outFileName.split(DPOConstants.SEMI_COLON).map(outFileName => {
        outFileName.split(DPOConstants.PIPE)(0)
      })

      val updatedOutFiles = outFiles.map(outFile => {
        if(outFile.contains("YYYYMMdd")) {
          val currentDate = CommonUtil.getCurrentDateTime("YYYYMMdd")
          outFile.replace("YYYYMMdd", currentDate)
        }else outFile
      })
      updatedOutFiles.mkString(DPOConstants.SEMI_COLON)
    }else{
      if(pei.outFileName.contains("YYYYMMdd")) pei.outFileName.replace("YYYYMMdd",CommonUtil.getCurrentDateTime("YYYYMMdd")) else pei.outFileName
    }

    val zipFileNames = if(pei.outFileExt=="ZIP" || pei.outFileExt=="ZIPALL"){
      val outFileNames = pei.outFileName.split(DPOConstants.SEMI_COLON)
      val zipNames = outFileNames.map(outFileName => {
        outFileName.split(DPOConstants.PIPE)(1)
      })
      val updatedZipNames = zipNames.map(zipName => {
        if(zipName.contains("YYYYMMdd")) {
          val currentDate = CommonUtil.getCurrentDateTime("YYYYMMdd")
          zipName.replace("YYYYMMdd",currentDate)
        } else zipName
      })
      val strZipName = if(pei.outFileExt=="ZIP") updatedZipNames.mkString(DPOConstants.SEMI_COLON) else if(pei.outFileExt == "ZIPALL") updatedZipNames(0)
      strZipName
    }else{
      "NA"
    }
    //val updatedZipName = if (zipFileName.contains("$YYYYMMdd")) CommonUtil.replaceDate(zipFileName) else zipFileName

    val vndrCode = pei.consumingApp
    Logger.log.info(s"select CRIT_TXT_VAL_1 FROM ${schema}_DATA_VEND_CRIT_DTL WHERE trim(DATA_VEND_CD)= '$vndrCode' AND trim(DATA_VEND_FUNC_CD) =  'E' AND CRIT_ID = 3 AND trim(ACTV_CD) = 'A' AND trim(CRIT_COND_CD) = 'I'")
    val dataDF = context.sqlContext.sql(s"select CRIT_TXT_VAL_1 FROM ${schema}_DATA_VEND_CRIT_DTL WHERE trim(DATA_VEND_CD)= '$vndrCode' AND trim(DATA_VEND_FUNC_CD) =  'E' AND CRIT_ID = 3 AND trim(ACTV_CD) = 'A' AND trim(CRIT_COND_CD) = 'I'")

    val crit_txt_val_1 = dataDF.first()(0).toString()
    val extractFilePath = ApplicationConfig.dataDir + DPOConstants.SLASH + vndrCd + DPOConstants.SLASH
    Logger.log.info(s"extractFilePath :::: " + extractFilePath);

    val metaBuilder = StringBuilder.newBuilder
    metaBuilder.append(s"pitTabName=${ApplicationConfig.pitTabName}${DPOConstants.NEWLINECHAR}")
    //metaBuilder.append(s"pitRowKey=$pitRowKey${DPOConstants.NEWLINECHAR}")
    metaBuilder.append(s"extractFilePath=$extractFilePath${DPOConstants.NEWLINECHAR}")
    metaBuilder.append(s"extractFileName=${pei.consumingApp}${DPOConstants.NEWLINECHAR}")


    //metaBuilder.append(s"outFileLoc=${pei.outFileLoc}${DPOConstants.NEWLINECHAR}")
    if(s"${vndrCd}".equalsIgnoreCase("OXHP")) /// since OXHP doesn't has facility file
    {
      metaBuilder.append(s"outFileLoc=${ApplicationConfig.dataDir}${vndrCd}${DPOConstants.SLASH}${ApplicationConfig.physicianTypFrm}${DPOConstants.SLASH}${DPOConstants.SEMI_COLON}${ApplicationConfig.dataDir}${vndrCd}${DPOConstants.SLASH}${ApplicationConfig.groupTypFrm}${DPOConstants.SLASH}${DPOConstants.NEWLINECHAR}")
    }else {
      metaBuilder.append(s"outFileLoc=${ApplicationConfig.dataDir}${vndrCd}${DPOConstants.SLASH}${ApplicationConfig.physicianTypFrm}${DPOConstants.SLASH}${DPOConstants.SEMI_COLON}${ApplicationConfig.dataDir}${vndrCd}${DPOConstants.SLASH}${ApplicationConfig.groupTypFrm}${DPOConstants.SLASH}${DPOConstants.SEMI_COLON}${ApplicationConfig.dataDir}${vndrCd}${DPOConstants.SLASH}${ApplicationConfig.facilitiesTypFrm}${DPOConstants.SLASH}${DPOConstants.NEWLINECHAR}")
    }
    metaBuilder.append(s"outFileName=$outFileNames${DPOConstants.NEWLINECHAR}")
    metaBuilder.append(s"outFileExt=${pei.outFileExt}${DPOConstants.NEWLINECHAR}")
    //metaBuilder.append(s"archLoc=${pei.archLoc}${DPOConstants.NEWLINECHAR}")

    metaBuilder.append(s"archLoc=${ApplicationConfig.archiveDir}${DPOConstants.SLASH}extract${DPOConstants.NEWLINECHAR}")

    metaBuilder.append(s"peiTab=${ApplicationConfig.peiTabName}${DPOConstants.NEWLINECHAR}")
    metaBuilder.append(s"securityfileLoc=${ApplicationConfig.securityfileLoc}${DPOConstants.NEWLINECHAR}")
    metaBuilder.append(s"zipFileName=$zipFileNames${DPOConstants.NEWLINECHAR}")
    //metaBuilder.append(s"inputFileLocation=${pei.inputFileLocation}${DPOConstants.NEWLINECHAR}")
    metaBuilder.append(s"inputFileLocation=${ApplicationConfig.inboxDir}${DPOConstants.NEWLINECHAR}")
    metaBuilder.append(s"FullFileIndicator=${crit_txt_val_1}${DPOConstants.NEWLINECHAR}")

    val metaContent = metaBuilder.mkString("")
    FileSystemUtil.createHDFSFile(extractFilePath + DPOConstants.META_FILE_NAME, metaContent)
    Logger.log.info("MetaFile created")
    metaContent
  }



  /**
    *
    * @param entity
    * @param context
    */
  def generateHierarchialFile(entity: ExtractFileEntity, validSegNm: ArrayBuffer[String], vendorCd: String, provTypCd: String,peiExtractName:String)(implicit context: GlobalContext, pei: PEI): Unit = {
    try {
      val segmentData =  generaterPaddedSegmentsData(entity, validSegNm, vendorCd, provTypCd)
      val finalViewName = combineAllSegments(segmentData._1, segmentData._2,validSegNm)
      val lnkCols = segmentData._2
      val dataDF = context.sqlContext.sql(s"select * from $finalViewName")
      var outFileLoc_Temp=""
      val outFileLoc = ApplicationConfig.dataDir + vendorCd + DPOConstants.SLASH  + provTypCd + DPOConstants.SLASH

      Logger.log.info("INFO :::: inside hierarchy file creation "+outFileLoc)
      Logger.log.info("INFO :::: inside hierarchy file  :: output file name "+pei.outFileName)

      val hdrDF = generateHDRInfo(entity, lnkCols, dataDF, outFileLoc)
      hdrDF.createOrReplaceTempView(DPOConstants.HDR_DATA_VIEW)

      val hierarchialData = context.sqlContext.sql(s"SELECT * from $finalViewName UNION ALL SELECT * FROM ${DPOConstants.HDR_DATA_VIEW}")
      hierarchialData.createOrReplaceTempView(DPOConstants.VENDOR_FINAL_VIEW)

      val hierarchialOrderedData = context.sqlContext.sql(s"SELECT data from ${DPOConstants.VENDOR_FINAL_VIEW}  ORDER BY ${lnkCols.mkString(",")}  ")
      Logger.log.info("Final query:"+ s"SELECT * from ${DPOConstants.VENDOR_DATA_VIEW} ORDER BY ${lnkCols.mkString(",")}")
      hierarchialOrderedData.createOrReplaceTempView(DPOConstants.HIERARCHIAL_FILE_DF)
      if(s"${vendorCd}".equalsIgnoreCase("OXHP")) /// since OXHP doesn't has facility file
      {
        outFileLoc_Temp= s"${ApplicationConfig.dataDir}${vendorCd}${DPOConstants.SLASH}${ApplicationConfig.physicianTypFrm}${DPOConstants.SLASH}${DPOConstants.SEMI_COLON}${ApplicationConfig.dataDir}${vendorCd}${DPOConstants.SLASH}${ApplicationConfig.groupTypFrm}${DPOConstants.SLASH}"
      }else {
        outFileLoc_Temp = s"${ApplicationConfig.dataDir}${vendorCd}${DPOConstants.SLASH}${ApplicationConfig.physicianTypFrm}${DPOConstants.SLASH}${DPOConstants.SEMI_COLON}${ApplicationConfig.dataDir}${vendorCd}${DPOConstants.SLASH}${ApplicationConfig.groupTypFrm}${DPOConstants.SLASH}${DPOConstants.SEMI_COLON}${ApplicationConfig.dataDir}${vendorCd}${DPOConstants.SLASH}${ApplicationConfig.facilitiesTypFrm}${DPOConstants.SLASH}"
      }
      //val peiOutFileLocs = pei.outFileLoc.split(DPOConstants.SEMI_COLON)
      Logger.log.info("INFO :::: inside hierarchy file  :: output temp path  "+outFileLoc_Temp)
      val peiOutFileLocs = outFileLoc_Temp.split(DPOConstants.SEMI_COLON)

      var outFileName = ""

      peiOutFileLocs.zipWithIndex.foreach((peiFileLoc) => {
        if(peiFileLoc._1 == outFileLoc){
          val index = peiFileLoc._2
          outFileName = pei.outFileName.split(DPOConstants.SEMI_COLON)(index.toInt)
          if(outFileName.contains(DPOConstants.PIPE)) {
            outFileName = outFileName.split(DPOConstants.PIPE)(0)
          }
          outFileName = if(outFileName.contains("YYYYMMdd")) outFileName.replace("YYYYMMdd", CommonUtil.getCurrentDateTime("YYYYMMdd")) else outFileName
        }
      })
      Logger.log.info("INFO :::: inside hierarchy file creation: File name  "+ outFileName  +"<<<<< ")
      FileSystemUtil.saveFileToMapRFSWithoutShuffle(hierarchialOrderedData,outFileLoc,outFileName,"",DPOConstants.TEXT)
    } catch {
      case e: Exception => {
        Logger.log.info("RK4 : EPDERK4JsonSourceExtractor.generateHierarchialFile() " + e.getMessage)
        throw e
      }
    }
  }
  /**
    *
    * @param inputEntity
    * @param finalDF
    * @param outFileLoc
    * @param context
    * @return
    */
  def generateHDRInfo(inputEntity: ExtractFileEntity, lnkCols: Array[String],finalDF: DataFrame, outFileLoc: String)(implicit context: GlobalContext, pei: PEI): DataFrame = {
    try{
      val hdrCols = inputEntity.extractHdrCol.split(DPOConstants.SEMI_COLON).to[ArrayBuffer]
      val lnkColsArr = lnkCols.to[ArrayBuffer]
      val lnkColSchema = lnkColsArr.map(colName =>{
        if(colName.endsWith("_CD")) StructField(colName,StringType, true) else StructField(colName,IntegerType, true)
      } ).to[ArrayBuffer]

      val schema = hdrCols.map(colName => StructField(colName,StringType, true)).to[ArrayBuffer]
      schema ++= lnkColSchema

      val vendorCd = "UHC"
      val recTyp = "HDR"
      val prvCnt = context.sqlContext.sql("SELECT * FROM PRV_SEL_RKP_Prov where RNUM=1").count().toString
      //val prvCnt = "0"
      val hdrTs = CommonUtil.getCurrentDateTime(pei.hdrDateFormat)
      val totalCnt = finalDF.count().toString


      val lnkColsData = lnkColSchema.map(sch => {
        if(sch.dataType.equals(IntegerType) && sch.name.startsWith("LNK_")) 0 else "0"
      }).toSeq
      val hdrRec = Array(recTyp, vendorCd, prvCnt, hdrTs, totalCnt).toSeq
      val hdrData = hdrRec ++ lnkColsData

      import org.apache.spark.sql._
      val data = Row.fromSeq(hdrData)
      val hdrDF = context.sqlContext.createDataFrame(context.sparkContext.parallelize(Seq(data)),StructType(schema))
      hdrDF.createOrReplaceTempView(DPOConstants.HDR_DATA_VIEW)
      val hdrPaddedDF = genRPaddedDFForHierarchialFile(inputEntity.extractHdrCol, inputEntity.extractHdrLen, inputEntity.extractTolLen, hdrDF, DPOConstants.HDR_DATA_VIEW, DPOConstants.LPAD )
      hdrPaddedDF.createOrReplaceTempView(DPOConstants.HDR_FINAL_VIEW)
      hdrPaddedDF.show()

      hdrPaddedDF
    }catch {
      case e: Exception => {
        Logger.log.info("RK4 : EPDERK4JsonSourceExtractor.generateHDRInfo() "+e.getMessage)
        throw e
      }
    }

  }


  /**
    *
    * @param entity
    * @param vendorCd
    * @param context
    * @return
    */
  def generaterPaddedSegmentsData(entity: ExtractFileEntity, validSegNm: ArrayBuffer[String], vendorCd: String, provTypCd : String)(implicit context: GlobalContext): (Seq[String], Array[String]) = {
    try{
      var lnkCols = Array.empty[String]
      val segmentViews = entity.segmentDetails.map { seg => {
        val filePath = ApplicationConfig.workingDir+DPOConstants.SLASH +"segments"+DPOConstants.SLASH + vendorCd + DPOConstants.SLASH + provTypCd + DPOConstants.SLASH
        if (!validSegNm.contains(seg.segName)) {
          "NA"
        } else {
          val finalDF = context.sqlContext.read.parquet(filePath + seg.segName + "_FNL_VIEW")
          lnkCols = finalDF.columns.filter(_.startsWith("LNK_"))
          finalDF.persist(org.apache.spark.storage.StorageLevel.MEMORY_ONLY)
          finalDF.createOrReplaceTempView(seg.segName)
          val rpaddedDF = CommonUtil.genRPaddedDFForHierarchialFile(seg.segTarCol, seg.segTarLen, seg.segTolLen, finalDF, seg.segName, DPOConstants.RPAD)
          rpaddedDF.createOrReplaceTempView(seg.segName)
          seg.segName
        }
      }
      }
      (segmentViews, lnkCols)
    }catch {
      case e: Exception => {
        Logger.log.info("RK4 : EPDERK4JsonSourceExtractor.generaterPaddedSegmentsData() "+e.getMessage)
        throw e
      }
    }
  }

  /**
    *
    * @param segmentViews
    * @param lnkCols
    * @param context
    * @return
    */
  def combineAllSegments(segmentViews: Seq[String], lnkCols : Array[String],validSegNm: ArrayBuffer[String])(implicit context: GlobalContext):String ={
    try {
      val unionStringBuilder = StringBuilder.newBuilder
      var counter=1
      segmentViews.foreach { segmentView => {
        if (segmentView != "NA") {
          unionStringBuilder.append(s"SELECT ${lnkCols.mkString(",")}, data from ${segmentView}")
          if (counter<validSegNm.length) {
            unionStringBuilder.append(" UNION ALL ")
            counter+=1
          }
          Logger.log.info(s"INFO ::::::::::::::: ${validSegNm.length} and ${counter}")
        }
      }
      }

      Logger.log.info("Union String:"+unionStringBuilder.mkString)

      val unionDF = context.sqlContext.sql(unionStringBuilder.mkString)
      unionDF.persist(org.apache.spark.storage.StorageLevel.MEMORY_ONLY)
      unionDF.createOrReplaceTempView(DPOConstants.VENDOR_DATA_VIEW)
      DPOConstants.VENDOR_DATA_VIEW
    }
    catch
      {
        case e: Exception => {
          Logger.log.info("RK4 : EPDERK4JsonSourceExtractor.combineAllSegments :  Error Occured : "+e.getMessage )
          throw e
        }
      }
  }


  def callSeg(validSegNm: ArrayBuffer[String] ,inputEntity: ExtractFileEntity,outputFilePath:String,varLst:collection.mutable.Map[String, String], glblVarLst:collection.mutable.Map[String, String],provTypCd:String)(implicit context: GlobalContext): Unit = {
    var con_flag="N"
    try {
      if (validSegNm.contains("PRV")) {
        Logger.log.info("INFO::::PRV Extraction Called")
        inputEntity.segmentDetails.foreach{segDtls=>
          Logger.log.info("segDtls -->"+segDtls.segName)
          if(segDtls.segName.contains("PRV")){
            genPRVSeg(segDtls, varLst, glblVarLst,outputFilePath)
          }
        }
      }
      if (validSegNm.contains("ALT")) {
        Logger.log.info("INFO::::ALT Extraction Called")
        inputEntity.segmentDetails.foreach { segDtls =>
          Logger.log.info("segDtls -->" + segDtls.segName)
          if (segDtls.segName.contains("ALT")) {
            genALTSeg(segDtls, varLst, glblVarLst, outputFilePath)
          }
        }
      }
      if (validSegNm.contains("PSP")) {
        Logger.log.info("PSP Extraction Called")
        inputEntity.segmentDetails.foreach{segDtls=>
          if(segDtls.segName.contains("PSP")){
            genPSPSeg(segDtls, varLst, glblVarLst,outputFilePath)
          }
        }
      }

      if (validSegNm.contains("SCO")) {
        Logger.log.info("SCO Extraction Called")
        inputEntity.segmentDetails.foreach{segDtls=>
          if(segDtls.segName.contains("SCO")){
            genSCOSeg(segDtls, varLst, "N",outputFilePath)
          }
        }
      }
      if (validSegNm.contains("PQI")) {
        Logger.log.info("PQI Extraction Called")
        inputEntity.segmentDetails.foreach{segDtls=>
          if(segDtls.segName.contains("PQI")){
            pqiSegGen(segDtls, outputFilePath, varLst)
          }
        }
      }
      if (validSegNm.contains("HAS")) {
        Logger.log.info("HAS Extraction Called")
        inputEntity.segmentDetails.foreach{segDtls=>
          if(segDtls.segName.contains("HAS")){
            hasSegGen(segDtls, outputFilePath, varLst)
          }
        }
        //genHASSeg(segDtls, varLst, glblVarLst)
      }
      if (validSegNm.contains("PLI")) {
        Logger.log.info("PLI Extraction Called")
        inputEntity.segmentDetails.foreach { segDtls =>
          if (segDtls.segName.contains("PLI")) {
            pliSegGen(segDtls, varLst, outputFilePath)
          }
        }
      }
      if (validSegNm.contains("PFA")) {
        Logger.log.info("PFA Extraction Called")
        inputEntity.segmentDetails.foreach{segDtls=>
          if(segDtls.segName.contains("PFA")){
            genPFASeg(segDtls,varLst, glblVarLst, "N",outputFilePath)
          }
        }
      }
      if (validSegNm.contains("TIN")) {
        Logger.log.info("TIN Extraction Called")
        inputEntity.segmentDetails.foreach{segDtls=>
          if(segDtls.segName.contains("TIN")){
            genTINSeg(segDtls, varLst, glblVarLst,outputFilePath)
          }
        }
      }
      if (validSegNm.contains("CON")) {
        Logger.log.info("CON Extraction Called")
        con_flag="Y"
        inputEntity.segmentDetails.foreach{segDtls=>
          if(segDtls.segName.contains("CON")){
            genCONSeg(segDtls, varLst, glblVarLst,outputFilePath)
          }
        }
      }
      if (validSegNm.contains("PTI")) {
        Logger.log.info("PTI Extraction Called")
        inputEntity.segmentDetails.foreach{segDtls=>
          if(segDtls.segName.contains("PTI")){
            ptiSegGen(segDtls, outputFilePath, varLst)
          }
        }
        //genPTISeg(segDtls, varLst, glblVarLst)
        if (validSegNm.contains("TCO")) {
          Logger.log.info("TCO Extraction Called")
          inputEntity.segmentDetails.foreach{segDtls=>
            if(segDtls.segName.contains("TCO")){
              tcoSegGen(segDtls, outputFilePath, varLst)
            }
          }
          //genTCOSeg(segDtls, varLst, glblVarLst)
        }
      }
      if (validSegNm.contains("NCE")) {
        Logger.log.info("NCE Extraction Called")
        inputEntity.segmentDetails.foreach{segDtls=>
          if(segDtls.segName.contains("NCE")){
            genNCESeg(segDtls,varLst, "N",outputFilePath)
          }
        }
      }
      if (validSegNm.contains("ENT")) {
        Logger.log.info("ENT Extraction Called")
        //genENTSeg(segDtls, varLst, glblVarLst)
      }
      if (validSegNm.contains("ADD")) {
        Logger.log.info("ADD Extraction Called")
        inputEntity.segmentDetails.foreach{segDtls=>
          if(segDtls.segName.contains("ADD")){
            genADDSeg(segDtls,varLst, "N",outputFilePath)
          }
        }
      }
      if (validSegNm.contains("PHO")) {
        Logger.log.info("PHO Extraction Called")
        inputEntity.segmentDetails.foreach{segDtls=>
          if(segDtls.segName.contains("PHO")){
            phoSegGen(segDtls, outputFilePath, varLst)
          }
        }
        //genPHOSeg(segDtls, varLst, glblVarLst)
      }
      if (validSegNm.contains("ACT")) {
        Logger.log.info("INFO::::ACT Extraction Called")
        inputEntity.segmentDetails.foreach { segDtls =>
          Logger.log.info("segDtls -->" + segDtls.segName)
          if (segDtls.segName.contains("ACT")) {
            genACTSeg(segDtls, varLst, glblVarLst, outputFilePath)
          }
        }
      }
      if (validSegNm.contains("LGS")) {
        Logger.log.info("LGS Extraction Called")
        inputEntity.segmentDetails.foreach{segDtls=>
          if(segDtls.segName.contains("LGS")){
            lgsSegGen(segDtls, outputFilePath, varLst)
          }
        }
        //genLGSSeg(segDtls, varLst, glblVarLst)
      }

      if (validSegNm.contains("LNG")) {
        Logger.log.info("LNG Extraction Called")
        inputEntity.segmentDetails.foreach { segDtls =>
          if (segDtls.segName.contains("LNG")) {
            lngSegGen(segDtls, varLst, outputFilePath)
          }
        }
      }

      if (validSegNm.contains("HRS")) {
        Logger.log.info("HRS Extraction Called")
        inputEntity.segmentDetails.foreach{segDtls=>
          Logger.log.info("segDtls --> "+segDtls.segName)
          if(segDtls.segName.contains("HRS")) {
            hrsSegGen(segDtls,outputFilePath,varLst)
          }
        }
      }
      if (validSegNm.contains("HCA")) {
        Logger.log.info("HCA Extraction Called")
        inputEntity.segmentDetails.foreach { segDtls =>
          if (segDtls.segName.contains("HCA")) {
            genHCASeg(segDtls, varLst, "N", outputFilePath)
          }
        }
      }
      /*    if (validSegNm.contains("HRS")) {
            Logger.log.info("HRS Extraction Called")
            inputEntity.segmentDetails.foreach{segDtls=>
              Logger.log.info("segDtls --> "+segDtls.segName)
              if(segDtls.segName.contains("HRS")) {
                hrsSegGen(segDtls,outputFilePath,varLst)
              }
            }
          }*/
      /*if (validSegNm.contains("HCA")) {
        Logger.log.info("HCA Extraction Called")
        inputEntity.segmentDetails.foreach{segDtls=>
          if(segDtls.segName.contains("HCA")){
            genHCASeg(segDtls,varLst, "N",outputFilePath)
          }
        }
      }*/
      if (validSegNm.contains("ACO")) {
        Logger.log.info("ACO Extraction Called")
        inputEntity.segmentDetails.foreach{segDtls=>
          if(segDtls.segName.contains("ACO")){
            genACOSeg(segDtls,varLst, "N",outputFilePath)
          }
        }
      }
      if (validSegNm.contains("AD1")) {
        Logger.log.info("AD1 Extraction Called")
        inputEntity.segmentDetails.foreach{segDtls=>
          if(segDtls.segName.contains("AD1")){
            ad1SegGen(segDtls, outputFilePath, varLst)
          }
        }
        //genAD1Seg(segDtls, varLst, glblVarLst)
      }
      //}
      /*if (validSegNm.contains("CON")) {
        Logger.log.info("CON Extraction Called")
        inputEntity.segmentDetails.foreach{segDtls=>
          if(segDtls.segName.contains("AD1")){
            genCONSeg(segDtls, varLst, glblVarLst, outputFilePath)
          }
        }
      }*/

      if (validSegNm.contains("CDK")) {
        Logger.log.info("CDK Extraction Called")
        inputEntity.segmentDetails.foreach{segDtls=>
          if(segDtls.segName.contains("CDK")){
            genCDKSeg(segDtls, varLst, glblVarLst,outputFilePath,con_flag)
          }
        }
      }
      if (validSegNm.contains("CSP")) {
        Logger.log.info("INFO::::CSP Extraction Called")
        inputEntity.segmentDetails.foreach{segDtls=>
          Logger.log.info("segDtls -->"+segDtls.segName)
          if(segDtls.segName.contains("CSP")){
            genCSPSeg(segDtls, varLst, glblVarLst,outputFilePath)
          }
        }
      }
      if (validSegNm.contains("COS")) {
        Logger.log.info("COS Extraction Called")
        inputEntity.segmentDetails.foreach{segDtls=>
          Logger.log.info("segDtls -->"+segDtls.segName)
          if(segDtls.segName.contains("COS")){
            cosSegGen(segDtls, outputFilePath, varLst)
          }
        }
        //genCOSSeg(segDtls, varLst, glblVarLst)
      }

      if (validSegNm.contains("CUL")) {
        Logger.log.info("CUL Extraction Called")
        inputEntity.segmentDetails.foreach{segDtls=>
          Logger.log.info("segDtls --> "+segDtls.segName)
          if(segDtls.segName.contains("CUL")) {
            culSegGen(segDtls,outputFilePath,varLst)
          }
        }
      }
      if (validSegNm.contains("NPI")) {
        Logger.log.info("NPI Extraction Called")
        inputEntity.segmentDetails.foreach{segDtls=>
          if(segDtls.segName.contains("NPI")){
            genNPISeg(segDtls,varLst, "N",outputFilePath)
          }
        }
      }
      if (validSegNm.contains("COE")) {
        Logger.log.info("COE Extraction Called")
        inputEntity.segmentDetails.foreach{segDtls=>
          if(segDtls.segName.contains("COE")){
            genCOESeg(segDtls, varLst, glblVarLst,outputFilePath,provTypCd)
          }
        }
      }
    }
    catch {

      case e: Exception => {
        Logger.log.info(s"RK4 : EPDERK4JsonSourceExtractor.callSeg() : "+e.getMessage)
        throw e
      }

    }
  }
  // checking for prov_id exclusion by the following logic with WS_PROV_TYP_CD_1 = 'P'
  /*
  def PRV_5000_SPEC_EXCLUSIONS_prc(segQueries:EPDERK4InputJsonSchema.Queries,WS_VENDR_CD:String,SchemaNm:String,WS_SQL_PROV_ID:String,OccurIndx:Int)(implicit context: GlobalContext):Boolean={
  var indx=OccurIndx.toString
  var resFlg=false
  try{
  segQueries.map { qryKey =>
  if (qryKey.name.equals("PRV_17_DATA_VEND_CRIT_DTL")) {
  var df= context.sqlContext.emptyDataFrame
  val qryStr = qryKey.query.replace("${SchemaNm}", SchemaNm).replace("${WS_SQL_PROV_ID}", WS_SQL_PROV_ID).replace("${WS_VENDR_CD}", WS_VENDR_CD).replace("${i}",indx)
  Logger.log.info(s"the Query for ${qryKey.name} is $qryStr")
      df = context.sqlContext.sql(s"$qryStr")
  // checking for Prov_id exclusion ; if present then true i.e. prov_id excluded
  if(df.count()>0){
    resFlg= true
  }
  else{
    resFlg= false
  }
  }
  }} catch {
  case e: Exception => {
  Logger.log.info("ERROR : DB2 ERROR ON DATA_VEND_CRIT_DTL SQLCODE = "+e.getMessage)
  }
  }
  resFlg
  }
  // checking for prov_id exclusion by the following logic with WS_PROV_TYP_CD_1 <> 'P'
  def PRV_5010_ORG_EXCLUSIONS_prc(segQueries:EPDERK4InputJsonSchema.Queries,WS_VENDR_CD:String,SchemaNm:String,WS_SQL_PROV_ID:String,OccurIndx:Int)(implicit context: GlobalContext):Boolean={
  var indx=OccurIndx.toString
  var resFlg=false
  try{
  segQueries.map { qryKey =>
  if (qryKey.name.equals("PRV_18_DATA_VEND_CRIT_DTL")) {
  var df= context.sqlContext.emptyDataFrame
  val qryStr = qryKey.query.replace("${SchemaNm}", SchemaNm).replace("${WS_SQL_PROV_ID}", WS_SQL_PROV_ID).replace("${WS_VENDR_CD}", WS_VENDR_CD).replace("${i}",indx)
  Logger.log.info(s"the Query for ${qryKey.name} is $qryStr")
  df = context.sqlContext.sql(s"$qryStr")
  // checking for Prov_id exclusion ; if present then true i.e. prov_id excluded
  if(df.count()>0){
    resFlg= true
  }
  else{
    resFlg= false
  }
  }
  }} catch {
  case e: Exception => {
  Logger.log.info("ERROR : DB2 ERROR ON DATA_VEND_CRIT_DTL SQLCODE = "+e.getMessage)
  }
  }
  resFlg
  }
  */
  /*
  def prv_2100_label(segQueries:EPDERK4InputJsonSchema.Queries,WS_VENDR_CD:String,SchemaNm:String,WS_SQL_PROV_ID:String,WS_ACTV_CD_1:String,WS_ACTV_CD_2:String,WS_UPDT_DT_1:String,WS_UPDT_DT_2:String,WS_CANC_DT_1:String,WS_CANC_DT_2:String)(implicit context: GlobalContext)={
  val OUT_PRV_RECORD=""
  var SW_DEGCD_EOF="Y"
  val WS_FETCH_COUNT=0
  val PDG_DEG_CD=""
  val PDG_PRI_CD=""
  var PDG_LST_UPDT_DT=""
  var PCR_LST_UPDT_DT=""
  var PTA_LST_UPDT_DT=""
  var PRV_14_PTA_Flg=true
  segQueries.map { qryKey =>
  if (qryKey.name.equals("PRV_TBL_DEG_CD_OCCURS")) {
  Logger.log.info(s"2222-FETCH-DEG label starts")
  var PRV_TBL_DEG_CD_OCCURSDF= context.sqlContext.emptyDataFrame
  //OCCURS 2 times
  val qryStr = qryKey.query.replace("${SchemaNm}", SchemaNm).replace("${WS_SQL_PROV_ID}", WS_SQL_PROV_ID).replace("${WS_ACTV_CD_1}", WS_ACTV_CD_1).replace("${WS_ACTV_CD_2}", WS_ACTV_CD_2).replace("${WS_UPDT_DT_1}", WS_UPDT_DT_1).replace("${WS_UPDT_DT_2}", WS_UPDT_DT_2)
  Logger.log.info(s"the Query for ${qryKey.name} is $qryStr")
  //    df = context.sqlContext.sql(s"$qryStr")
  if(PRV_TBL_DEG_CD_OCCURSDF.count()<1)
  {
    SW_DEGCD_EOF="Y"
    PDG_LST_UPDT_DT="01/01/0001" // no usage in final Query
  }
  else{
    SW_DEGCD_EOF="N"
    var occurStmnt = qryKey.occurStmnt.toString
    var whrClause= occurStmnt.split("~")(4)
    var tblNm= occurStmnt.split("~")(3).replace("${SchemaNm}", SchemaNm).replace("${WS_SQL_PROV_ID}", WS_SQL_PROV_ID).replace("${WS_ACTV_CD_1}", WS_ACTV_CD_1).replace("${WS_ACTV_CD_2}", WS_ACTV_CD_2).replace("${WS_UPDT_DT_1}", WS_UPDT_DT_1).replace("${WS_UPDT_DT_2}", WS_UPDT_DT_2)
    var TBL_SOURCE_EXCLUSIONS =PRV_TBL_DEG_CD_OCCURSDF.select("CNT").collect()(0).getLong(0).toInt
    occursCreation(occurStmnt,50,qryKey.occursNm.toString,WS_SQL_PROV_ID,SchemaNm,whrClause,tblNm)
    println("occurStmnt " + occurStmnt)
  }
  Logger.log.info(s"2222-FETCH-DEG label ends")
  }else
  //      if(nxtSentenceFlg==(true)){
  if (qryKey.name.equals("PRV_DCLPROV_CRDNTL_STS_1")) {
  var df= context.sqlContext.emptyDataFrame
  val qryStr = qryKey.query.replace("${SchemaNm}", SchemaNm).replace("${WS_SQL_PROV_ID}", WS_SQL_PROV_ID).replace("${WS_ACTV_CD_1}", WS_ACTV_CD_1).replace("${WS_ACTV_CD_2}", WS_ACTV_CD_2).replace("${WS_UPDT_DT_1}", WS_UPDT_DT_1).replace("${WS_UPDT_DT_2}", WS_UPDT_DT_2)
  Logger.log.info(s"the Query for ${qryKey.name} is $qryStr")
  //    df = context.sqlContext.sql(s"$qryStr")
  createOrReplaceTempViewFn(df,qryKey.name)
  }else if (qryKey.name.equals("PRV_DCLPROV_CRDNTL_STS")) {
  Logger.log.info(s"12 A_B")
  var df= context.sqlContext.emptyDataFrame
  val qryStr = qryKey.query.replace("${SchemaNm}", SchemaNm).replace("${WS_SQL_PROV_ID}", WS_SQL_PROV_ID).replace("${WS_ACTV_CD_1}", WS_ACTV_CD_1).replace("${WS_ACTV_CD_2}", WS_ACTV_CD_2).replace("${WS_UPDT_DT_1}", WS_UPDT_DT_1).replace("${WS_UPDT_DT_2}", WS_UPDT_DT_2)
  Logger.log.info(s"the Query for ${qryKey.name} is $qryStr")
  //    df = context.sqlContext.sql(s"$qryStr")
  createOrReplaceTempViewFn(df,qryKey.name)
  if(df.count()<1)
  {
    PCR_LST_UPDT_DT="01/01/0001"  // no usage in final Query
  }
  }
  else if (qryKey.name.equals("PRV_13_PTA")) {
  var df= context.sqlContext.emptyDataFrame
  val qryStr = qryKey.query.replace("${SchemaNm}", SchemaNm).replace("${WS_SQL_PROV_ID}", WS_SQL_PROV_ID).replace("${WS_CANC_DT_1}", WS_CANC_DT_1).replace("${WS_CANC_DT_2}", WS_CANC_DT_2).replace("${WS_UPDT_DT_1}", WS_UPDT_DT_1).replace("${WS_UPDT_DT_2}", WS_UPDT_DT_2)
  Logger.log.info(s"the Query for ${qryKey.name} is $qryStr")
  //    df = context.sqlContext.sql(s"$qryStr")
  createOrReplaceTempViewFn(df,qryKey.name)
  var resOne=df.take(1)
  resOne.map { rec =>
    var prv13PtaObj = PRV_13_PTA(rec.getAs[String]("PTA_PROV_ID"),rec.getAs[String]("PTA_MDCD_ID"), rec.getAs[String]("PTA_MDCD_LOC_CD"), rec.getAs[String]("PTA_LST_UPDT_DT"))
    if(prv13PtaObj.PTA_MDCD_ID.equalsIgnoreCase("")){
      Logger.log.info(s"proceeding to next line")
    }else{
      //              if(WS_VENDR_CD.equalsIgnoreCase("OHPH")) {
      prv_2400_label(segQueries, SchemaNm, WS_SQL_PROV_ID,WS_VENDR_CD)
      PRV_14_PTA_Flg=false
      //}
    }
  }
  } else  if (qryKey.name.equals("PRV_14_PTA")) {
  if(PRV_14_PTA_Flg) {
    var df = context.sqlContext.emptyDataFrame
    val qryStr = qryKey.query.replace("${SchemaNm}", SchemaNm).replace("${WS_SQL_PROV_ID}", WS_SQL_PROV_ID).replace("${WS_CANC_DT_1}", WS_CANC_DT_1).replace("${WS_CANC_DT_2}", WS_CANC_DT_2).replace("${WS_UPDT_DT_1}", WS_UPDT_DT_1).replace("${WS_UPDT_DT_2}", WS_UPDT_DT_2)
    Logger.log.info(s"the Query for ${qryKey.name} is $qryStr")
    //    df = context.sqlContext.sql(s"$qryStr")
    createOrReplaceTempViewFn(df, qryKey.name)
    if (df.count() < 0) {
      PTA_LST_UPDT_DT = "01/01/0001"
    } else {
      PTA_LST_UPDT_DT = "value from query"
    }
    prv_2400_label(segQueries, SchemaNm, WS_SQL_PROV_ID,WS_VENDR_CD)
  }
  }
  else {
  Logger.log.info(s"inside others")
  var df = context.sqlContext.emptyDataFrame
  //   df = executeQry(qryKey, SchemaNm, WS_SQL_PROV_ID)
  }
  //}
  }
  }
  def prv_2400_label(segQueries:EPDERK4InputJsonSchema.Queries,SchemaNm:String,WS_SQL_PROV_ID:String,WS_VENDR_CD:String)(implicit context: GlobalContext)={
  var PTA_LST_UPDT_DT=""
  segQueries.map { qryKey =>
  var df= context.sqlContext.emptyDataFrame
  if (qryKey.name.equals("PRV_75_VREL")) {
  if(WS_VENDR_CD.equalsIgnoreCase("OHPH")) {
    val qryStr = qryKey.query.replace("${SchemaNm}", SchemaNm).replace("${WS_SQL_PROV_ID}", WS_SQL_PROV_ID)
    Logger.log.info(s"the Query for ${qryKey.name} is $qryStr")
    //    df = context.sqlContext.sql(s"$qryStr")
  }
  /*HANDLED IN FINal query
  if (df.count()<0) {
    //OUT_PRV_VEND_KEY =""
    }else{
    //OUT_PRV_VEND_KEY ="value from query"
  }*/


  }
  createOrReplaceTempViewFn(df,qryKey.name)
  }
  }

  def prv_5020_FAC_PROCESS(segQueries:EPDERK4InputJsonSchema.Queries,SchemaNm:String,WS_SQL_PROV_ID:String,PRO_ORG_TYP_CD:String,DVD_DATA_VEND_CD:String)(implicit context: GlobalContext):Boolean={
  var retunFlg:Boolean= false
  segQueries.map { qryKey =>
  if (qryKey.name.equals("FAC_EXCL_CURSOR")){
  var df= context.sqlContext.emptyDataFrame
  val qryStr=qryKey.query.replace("${SchemaNm}",SchemaNm).replace("${WS_SQL_PROV_ID}",WS_SQL_PROV_ID).replace("${PRO_ORG_TYP_CD}",PRO_ORG_TYP_CD)
  Logger.log.info(s"the Query for ${qryKey.name} is $qryStr")
  //    df = context.sqlContext.sql(s"$qryStr")
  createOrReplaceTempViewFn(df,qryKey.name)
  }
  else if (qryKey.name.equals("PRV_9_DATA_VEND_CRIT_DTL")){
  var df= context.sqlContext.emptyDataFrame
  val qryStr=qryKey.query.replace("${SchemaNm}",SchemaNm).replace("${WS_SQL_PROV_ID}",WS_SQL_PROV_ID).replace("${DVD_DATA_VEND_CD}",DVD_DATA_VEND_CD)
  //    df = context.sqlContext.sql(s"$qryStr")
  createOrReplaceTempViewFn(df,qryKey.name)
  if(df.count()<0){
    retunFlg=true
  }else{
    retunFlg=false
  }

  }

  }
  retunFlg
  }
  */


  /*
    def hasSegGen(inputEntity: ExtractFileEntity)(implicit context: GlobalContext) = {
    }
    /*def phoSegGen(segDetails:SegmentDetails,PTA_ADR_TYP_CD:String)(implicit context:GlobalContext):String={
      null
    }*/

  */

  /*def ADD_PROV_TIN_ADR_LIM_tmp_prc(segQueries:EPDERK4InputJsonSchema.Queries,ADD_PROV_TIN_ADR_LIM:String,WS_SQL_PROV_ID:String,PTA_ADR_ID:String)(implicit context:GlobalContext):Unit={
    var df= context.sqlContext.emptyDataFrame
    Logger.log.info("Inside ADD_PROV_TIN_ADR_LIM_tmp_prc")
    segQueries.map { qryKey =>
      if (qryKey.name.equals("ADD_76_57_58")){
        Logger.log.info("Inside ADD_76_57_58")
        var qryStr = qryKey.query.replace("${ADD_PROV_TIN_ADR_LIM}", ADD_PROV_TIN_ADR_LIM).replace("${WS_SQL_PROV_ID}", WS_SQL_PROV_ID).replace("${PTA_ADR_ID}", PTA_ADR_ID)
        df = context.sqlContext.sql(s"$qryStr")
        createOrReplaceTempViewFn(df, qryKey.name)
        Logger.log.info("ADD_76_57_58 df.count" + df.count)
      }
    }
  }
  def ADD_58_PROV_TIN_ADR_LIM_prc(segQueries:EPDERK4InputJsonSchema.Queries,SchemaNm:String,WS_SQL_PROV_ID:String,tinObj:TIN_SEG,WS_ADR_TYP_CD_1:String,WS_ADR_TYP_CD_2:String,WS_LST_UPDT_DT2:String,WS_LST_UPDT_DT1:String,WS_ACTV_CD_1:String,WS_ACTV_CD_2:String)(implicit context:GlobalContext):Unit={
    Logger.log.info("Inside ADD_58_PROV_TIN_ADR_LIM_prc")
    var df= context.sqlContext.emptyDataFrame
    segQueries.map { qryKey =>
      if (qryKey.name.equals("ADD_58_PROV_TIN_ADR_LIM")){
        Logger.log.info("Inside ADD_58_PROV_TIN_ADR_LIM" )
        var qryStr = qryKey.query.replace("${SchemaNm}", SchemaNm).replace("${WS_SQL_PROV_ID}", WS_SQL_PROV_ID)
          .replace("${PTA_ADR_ID}", tinObj.TR28_PTA_ADR_ID).replace("${PTP_TAX_ID_NBR}", tinObj.TR28_PTP_TAX_ID_NBR).replace("${PTP_TAX_ID_TYP_CD}", tinObj.TR28_PTP_TAX_ID_TYP_CD)
          .replace("${WS_ADR_TYP_CD_1}", WS_ADR_TYP_CD_1).replace("${WS_ADR_TYP_CD_2}", WS_ADR_TYP_CD_2).replace("${WS_ACTV_CD_1}",WS_ACTV_CD_1 )
          .replace("${WS_ACTV_CD_2}", WS_ACTV_CD_2).replace("${WS_UPDT_DT_1}", WS_LST_UPDT_DT1).replace("${WS_UPDT_DT_2}", WS_LST_UPDT_DT2)
        df = context.sqlContext.sql(s"$qryStr")
        createOrReplaceTempViewFn(df, qryKey.name)
        Logger.log.info("ADD_58_PROV_TIN_ADR_LIM df.count" + df.count)
        ADD_PROV_TIN_ADR_LIM_tmp_prc(segQueries,qryKey.name,WS_SQL_PROV_ID,tinObj.TR28_PTA_ADR_ID)
        Logger.log.info("Go to END 4210-GET-ADR-LIM ; EXECUTING JOIN WITH tr76 AND tr58")
      }
    }
  }*/

  /* def pspSegGen(inputEntity:ExtractFileEntity,segDtls:SegmentDetails,SW_SKIP_PSP : String, SchemaNm: String,WS_SQL_PROV_ID:String,WS_UPDT_DT_2:String,WS_UPDT_DT_1:String,WS_ACTV_CD_1:String,WS_ACTV_CD_2:String,WS_PREV_RUN_DT_YMD:String,AMA_SPEC_TABLE_Cnt:Int,SW_SKIP_SCO:String,WS_PROV_TYP_CD_1:String,WS_PROV_TYP_CD_2:String,WS_CANC_DT_1:String,WS_CANC_DT_2:String,WS_DB2_DATE: String, WS_VENDR_CD:String,outputFilePath:String)(implicit context: GlobalContext): String = {
     val Seg_Nm = segDtls.segName
     val Seg_Seq = segDtls.segSeq
    var WS_PSP_SPCL_TYP_CD=""    // ???
    var SW_SPCL_EOF="N"
    var WS_LAST_SPCL_TYP_CD="" //  ???
    var PSP_SW_SKIP_PROV="N"
    var DONE_SW="N"
    //          var VS_AMA_SPCL_TYP_CD=""
    var finalQryNm="PSP_FINAL_QRY_1"
    var pspStr,tempStr,tempPath=""
    var resFlg = true // means we will skip the provider id
    //executing the PSP SQL Queries
    segDtls.segQueries.map{qryKey=>
      // this is the first PSP Query which may produce multiple records
      if (qryKey.name.equals("PSP_16_SPCL_CUR")) {
        try{
          var df_PSP_16 = context.sqlContext.emptyDataFrame
          val qryStr = qryKey.query.replace("${SchemaNm}", SchemaNm).replace("${WS_SQL_PROV_ID}", WS_SQL_PROV_ID).replace("${WS_CANC_DT_1}", WS_CANC_DT_1).replace("${WS_CANC_DT_2}", WS_CANC_DT_2).replace("${WS_UPDT_DT_1}", WS_UPDT_DT_1).replace("${WS_UPDT_DT_2}", WS_UPDT_DT_2)
          df_PSP_16 = context.sqlContext.sql(s"$qryStr")
          createOrReplaceTempViewFn(df_PSP_16, qryKey.name)
          if(df_PSP_16.count()==1){
            df_PSP_16.collect.map{rec =>
              // Iterating over the output of the  PSP_16_SPCL_CUR and craeting instance of the PSP_16_SPCL_CUR case class
              val PSP_16_SPCL_CUR_Obj= PSP_16_SPCL_CUR(rec.getAs[String]("PSP_PROV_ID"),rec.getAs[String]("PSP_SPCL_TYP_CD"),rec.getAs[String]("PSP_SPCL_BD_CERT_CD"),rec.getAs[String]("PSP_SPCL_BD_CERT_DT"),rec.getAs[String]("PSP_SPCL_BD_EXPIR_DT"),rec.getAs[String]("PSP_RCERT_EFF_DT"),rec.getAs[String]("PSP_CRED_VERF_ORG_ID"),rec.getAs[String]("PSP_PRI_CD"),rec.getAs[String]("PSP_DIR_IND"),rec.getAs[String]("PSP_LST_UPDT_DT"),rec.getAs[String]("PSP_PRAC_SPCL_IND"),rec.getAs[String]("PSP_SPCL_SRC_CD"),rec.getAs[String]("PSP_SPCL_BD_EXAM_DT"),rec.getAs[String]("PSP_RES_IND"),rec.getAs[String]("PSP_CANC_DT"))
              WS_PSP_SPCL_TYP_CD=PSP_16_SPCL_CUR_Obj.PSP_SPCL_TYP_CD
              if(WS_PSP_SPCL_TYP_CD.equalsIgnoreCase(WS_LAST_SPCL_TYP_CD)){ // logic confirmation ???
                SW_SPCL_EOF="Y"
              }else {
                var i = 0
                // for every occurs instance of table AMA_SPEC_TABLE (created in RK4Start) we will execute the following logic till 1000 or AMA_SPEC_TABLE count
                for (i <- 1 to AMA_SPEC_TABLE_Cnt) {
                  var df_ama = context.sqlContext.emptyDataFrame
                  var AMA_SPEC_ENTRY_qry = s"SELECT 'Y' AS DONE_SW FROM AMA_SPEC_TABLE AMA,PSP_16_SPCL_CUR PSP WHERE AMA.AS_SPCL_TYP_${i} = PSP.PSP_SPCL_TYP_CD AND ( AMA.AS_PROV_TYP_${i} = '${WS_PROV_TYP_CD_1}' OR AMA.AS_PROV_TYP_${i} = s'${WS_PROV_TYP_CD_2}')"
                  df_ama = context.sqlContext.sql(s"$qryStr")
                  if (df_ama.count() > 0) {
                    // checking for prov_id exclusion by the following logic
                    if (WS_PROV_TYP_CD_1.equalsIgnoreCase("P")) {
                      //resFlg = PRV_5000_SPEC_EXCLUSIONS_prc(segDtls.segQueries, WS_VENDR_CD, SchemaNm, WS_SQL_PROV_ID, i)
                      resFlg=true
                    } else {
                      //resFlg = PRV_5010_ORG_EXCLUSIONS_prc(segDtls.segQueries, WS_VENDR_CD, SchemaNm, WS_SQL_PROV_ID, i)
                      resFlg=true
                    }
                  }
                  // if resFlg is true then skip the prov_id
                  if (resFlg) {
                    PSP_SW_SKIP_PROV = "Y"
                    DONE_SW="Y"
                  } else {
                    PSP_SW_SKIP_PROV = "N"
                  }
                }
              }
            }
          }else{
            SW_SPCL_EOF="Y"
            PSP_SW_SKIP_PROV = "N"
          }
        } catch {
          case e: Exception => {
            Logger.log.info("ERROR : PSP Segment :DB2 ERROR ON PSP_16_SPCL_CUR "+WS_SQL_PROV_ID)
          }
        }
      }  /*else if(qryKey.name.equals("PSP_SPCL_TMP")){
      if(SW_SKIP_PROV.equalsIgnoreCase("N")){
        var df = context.sqlContext.emptyDataFrame
        val qryStr = qryKey.query.replace("${SchemaNm}", SchemaNm).replace("${WS_SQL_PROV_ID}", WS_SQL_PROV_ID)
        //    df = context.sqlContext.sql(s"$qryStr")
        //   createOrReplaceTempViewFn(df, qryKey.name)
      }
    }*/
      else if(qryKey.name.equals("PSP_19_STC_PSP")){
        // will execute the following only whe prov_id is not skipped from PSP_16 logic

        if(PSP_SW_SKIP_PROV.equalsIgnoreCase("N")){
          var df_19 = context.sqlContext.emptyDataFrame
          try{
            val qryStr = qryKey.query.replace("${SchemaNm}", SchemaNm).replace("${WS_SQL_PROV_ID}", WS_SQL_PROV_ID)
            df_19 = context.sqlContext.sql(s"$qryStr")
            createOrReplaceTempViewFn(df_19, qryKey.name)
            //Final Query will have OUT_STC_SPCL_CATGY_CD as space if  there were multiple values
            if(df_19.count()<1){
              Logger.log.info("Final Query will have OUT_STC_SPCL_CATGY_CD as space since there were multiple values ")
              finalQryNm="PSP_FINAL_QRY_2"
            }else{
              Logger.log.info("Final Query will have OUT_STC_SPCL_CATGY_CD as present in 19_STC_PSP  since there was single  value ")
              finalQryNm="PSP_FINAL_QRY_1"
            }
          } catch {
            case e: Exception => {
              Logger.log.info("ERROR : PSP Segment :DB2 ERROR ON SELECT CONTR "+WS_SQL_PROV_ID +" ::" +e.getMessage)
            }
          }
        }
      }else if(qryKey.name.equals(finalQryNm)){
        // will execute the following only whe prov_id is not skipped from PSP_16 logic
        try {
          if (PSP_SW_SKIP_PROV.equalsIgnoreCase("N")) {
            var df_final = context.sqlContext.emptyDataFrame
            val qryStr = qryKey.query.replace("${SchemaNm}", SchemaNm).replace("${WS_SQL_PROV_ID}", WS_SQL_PROV_ID).replace("${WS_PREV_RUN_DT_YMD}", WS_PREV_RUN_DT_YMD)
            df_final = context.sqlContext.sql(s"$qryStr")
            createOrReplaceTempViewFn(df_final, qryKey.name)
          }
        } catch {
          case e: Exception => {
            Logger.log.info("ERROR : PSP Segment :DB2 ERROR ON Final Query ::"+finalQryNm+" ::  "+WS_SQL_PROV_ID +" ::" +e.getMessage)
          }
        }
      }


    }

    //rppading code


    var df_psp = context.sqlContext.emptyDataFrame
    var finalStr=""

    /*import context.sparkSession.sqlContext.implicits._
    val df: DataFrame = Seq((1, "a", "foo1", 3.0),(2,"b","foo2",4.0),(3,"c","foo3",5.0)).toDF("c1","c2","c3","c4")
    df.persist(org.apache.spark.storage.StorageLevel.MEMORY_ONLY)
    df.createOrReplaceTempView("DATA_VEND_MSTR")
    context.sqlContext.sql("select * from DATA_VEND_MSTR").show()*/


    var df_1 = context.sqlContext.sql("select \"PSP \" as OUT_PSP_REC_TYP, \"108\" as OUT_PSP_PROV_ID, \"3\" as OUT_PSP_SPCL_TYP_CD, \"4\" as OUT_PSP_BD_CERT_CD, \"5\" as OUT_PSP_BD_CD_1, \"6\" as OUT_PSP_BD_CD_9, \"7\" as OUT_PSP_BD_CERT_DT, \"8\" as OUT_PSP_BD_EXPIR_DT, \"9\" as OUT_PSP_RCERT_EFF_DT, \"10\" as OUT_PSP_PRI_CD, \"11\" as OUT_PSP_DIR_IND, \"12\" as OUT_PSP_CHG_IND, \"13\" as OUT_STC_SPCL_CATGY_CD, \"14\" as OUT_PSP_PRAC_SPCL_IND, \"15\" as OUT_PSP_SPCL_SRC_CD, \"ABC\" as OUT_PSP_CRED_VERF_ORG_ID, \"9999-12-31\" as OUT_PSP_SPCL_BD_EXAM_DT, \"Y\" as OUT_PSP_RES_IND, \"9999-12-31\" as OUT_PSP_CANC_DT from F5938DBE_SPCL_TYP_CATGY ").limit(1)

    var df_2 = context.sqlContext.sql("select \"PSP \" as OUT_PSP_REC_TYP, \"108\" as OUT_PSP_PROV_ID, \"10\" as OUT_PSP_SPCL_TYP_CD, \"41\" as OUT_PSP_BD_CERT_CD, \"5\" as OUT_PSP_BD_CD_1, \"6\" as OUT_PSP_BD_CD_9, \"7\" as OUT_PSP_BD_CERT_DT, \"8\" as OUT_PSP_BD_EXPIR_DT, \"90\" as OUT_PSP_RCERT_EFF_DT, \"10\" as OUT_PSP_PRI_CD, \"11\" as OUT_PSP_DIR_IND, \"12\" as OUT_PSP_CHG_IND, \"13\" as OUT_STC_SPCL_CATGY_CD, \"14\" as OUT_PSP_PRAC_SPCL_IND, \"15\" as OUT_PSP_SPCL_SRC_CD, \"XYZ\" as OUT_PSP_CRED_VERF_ORG_ID, \"9999-12-31\" as OUT_PSP_SPCL_BD_EXAM_DT, \"N\" as OUT_PSP_RES_IND, \"9999-12-31\" as OUT_PSP_CANC_DT from F5938DBE_SPCL_TYP_CATGY ").limit(1)
    df_psp = df_1.union(df_2)

    Logger.log.info("--df_psp.count--> " + df_psp.count)
    Logger.log.info("---Inside df_psp------")
    df_psp.show()

    /*
          +---------------+---------------+-------------------+------------------+---------------+---------------+------------------+-------------------+--------------------+--------------+---------------+---------------+---------------------+---------------------+-------------------+------------------------+-----------------------+---------------+---------------+
          |OUT_PSP_REC_TYP|OUT_PSP_PROV_ID|OUT_PSP_SPCL_TYP_CD|OUT_PSP_BD_CERT_CD|OUT_PSP_BD_CD_1|OUT_PSP_BD_CD_9|OUT_PSP_BD_CERT_DT|OUT_PSP_BD_EXPIR_DT|OUT_PSP_RCERT_EFF_DT|OUT_PSP_PRI_CD|OUT_PSP_DIR_IND|OUT_PSP_CHG_IND|OUT_STC_SPCL_CATGY_CD|OUT_PSP_PRAC_SPCL_IND|OUT_PSP_SPCL_SRC_CD|OUT_PSP_CRED_VERF_ORG_ID|OUT_PSP_SPCL_BD_EXAM_DT|OUT_PSP_RES_IND|OUT_PSP_CANC_DT|
          +---------------+---------------+-------------------+------------------+---------------+---------------+------------------+-------------------+--------------------+--------------+---------------+---------------+---------------------+---------------------+-------------------+------------------------+-----------------------+---------------+---------------+
          |           PSP |              2|                  3|                 4|              5|              6|                 7|                  8|                   9|            10|             11|             12|                   13|                   14|                 15|                      16|                     17|             18|             19|
          |           PSP |              2|                  3|                 4|              5|              6|                 7|                  8|                   9|            10|             11|             12|                   13|                   14|                 15|                      16|                     17|             18|             19|
            +---------------+---------------+-------------------+------------------+---------------+---------------+------------------+-------------------+--------------------+--------------+---------------+---------------+---------------------+---------------------+-------------------+------------------------+-----------------------+---------------+---------------+
    */

    //  val SchemaNm = inputEntity.schemaNm

    var str = ""
    df_psp.rdd.collect.map{rec =>

      val pspObj = PSP_SEG(rec.getAs[String]("OUT_PSP_REC_TYP"), rec.getAs[String]("OUT_PSP_PROV_ID"), rec.getAs[String]("OUT_PSP_SPCL_TYP_CD"), rec.getAs[String]("OUT_PSP_BD_CERT_CD"), rec.getAs[String]("OUT_PSP_BD_CD_1"), rec.getAs[String]("OUT_PSP_BD_CD_9"), rec.getAs[String]("OUT_PSP_BD_CERT_DT"), rec.getAs[String]("OUT_PSP_BD_EXPIR_DT"),
        rec.getAs[String]("OUT_PSP_RCERT_EFF_DT"), rec.getAs[String]("OUT_PSP_PRI_CD"), rec.getAs[String]("OUT_PSP_DIR_IND"), rec.getAs[String]("OUT_PSP_CHG_IND"),
        rec.getAs[String]("OUT_STC_SPCL_CATGY_CD"), rec.getAs[String]("OUT_PSP_PRAC_SPCL_IND"), rec.getAs[String]("OUT_PSP_SPCL_SRC_CD"), rec.getAs[String]("OUT_PSP_CRED_VERF_ORG_ID"), rec.getAs[String]("OUT_PSP_SPCL_BD_EXAM_DT"), rec.getAs[String]("OUT_PSP_RES_IND"), rec.getAs[String]("OUT_PSP_CANC_DT"))
/*
      str = scoSegGen(inputEntity ,pspObj, SW_SKIP_SCO, SchemaNm,WS_SQL_PROV_ID,WS_DB2_DATE,WS_UPDT_DT_1,WS_PREV_RUN_DT_YMD).get
      Logger.log.info("-----Returned SCO String-----" +str)
      pspStr = pspObj.OUT_PSP_REC_TYP + DPOConstants.TABDELIM + pspObj.OUT_PSP_PROV_ID + DPOConstants.TABDELIM + pspObj.OUT_PSP_SPCL_TYP_CD + DPOConstants.TABDELIM + pspObj.OUT_PSP_BD_CERT_CD + DPOConstants.TABDELIM + pspObj.OUT_PSP_CANC_DT + DPOConstants.TABDELIM + pspObj.OUT_PSP_REC_TYP + DPOConstants.TABDELIM + pspObj.OUT_PSP_PROV_ID + DPOConstants.TABDELIM + pspObj.OUT_PSP_SPCL_TYP_CD + DPOConstants.TABDELIM + pspObj.OUT_PSP_BD_CERT_CD + DPOConstants.TABDELIM + pspObj.OUT_PSP_CANC_DT
      tempStr = tempStr + DPOConstants.NEWLINECHAR + pspStr + DPOConstants.NEWLINECHAR +  str
      tempStr += DPOConstants.NEWLINECHAR
      Logger.log.info("tempStr --> " + tempStr)*/
    }
    Logger.log.info("Seg_Nm --> " +Seg_Nm)
    Logger.log.info("Seg_Seq --> " +Seg_Seq)

    tempPath = generateEPDEOpFile(tempStr, outputFilePath, Seg_Nm, Seg_Seq )

    tempPath

   }*/
  /* def addSegGen(inputEntity: ExtractFileEntity, tinObj: TIN_SEG,SW_SKIP_ADD : String, SchemaNm: String,WS_SQL_PROV_ID:String,WS_UPDT_DT_2:String,WS_UPDT_DT_1:String,WS_ACTV_CD_1:String,WS_ACTV_CD_2:String,WS_PREV_RUN_DT_YMD:String, outputFilePath : String)(implicit context: GlobalContext): String = {
     //def addSegGen(inputEntity: ExtractFileEntity)(implicit context: GlobalContext) ={
    Logger.log.info("Inside addSegGen")
    Logger.log.info("Initializing variables..")
    var addStr,str,tempStr,tempPath = ""
    var SW_SKIP_ACO = "N"
    val PTA_ADR_TYP_CD          = tinObj.TR28_PTA_ADR_TYP_CD
    val WS_SQL_PROV_IDTmp       = "108" //WS_SQL_PROV_ID ip arg
    val PTA_ADR_ID              = tinObj.TR28_PTA_ADR_ID
    var PTA_BIL_ADR_ID          = tinObj.TR28_PTA_BIL_ADR_ID//OUT_ADD_BIL_ADR_ID_9.
    var ADR_ADR_LN_1_TXT        = tinObj.TR28_ADR_ADR_LN_1_TXT //OUT_ADD_STREET.
    var ADR_CTY_NM              = tinObj.TR28_ADR_CTY_NM //OUT_ADD_CITY.
    var ADR_ST_CD               = tinObj.TR28_ADR_ST_CD //OUT_ADD_ST.
    var ADR_ZIP_CD              = tinObj.TR28_ADR_ZIP_CD //OUT_ADD_ZIP_CD.
    var ADR_ZIP_PLS_4_CD        = tinObj.TR28_ADR_ZIP_PLS_4_CD //OUT_ADD_ZIP_PLS_4_CD.
    var ADR_CNTY_NM             = tinObj.TR28_ADR_CNTY_NM //OUT_ADD_CNTY_NM.
    var ADR_HNCP_ACSBL_IND      = tinObj.TR28_ADR_HNCP_ACSBL_IND //OUT_ADD_HNCP_ACSBL_IND.
    var PTA_ORIG_EFF_DT         = tinObj.TR28_PTA_ORIG_EFF_DT //OUT_ADD_ORIG_EFF_DT.
    var ADR_ADR_STR_OVRIDE_IND  = tinObj.TR28_ADR_ADR_STR_OVRIDE_IND //OUT_ADD_ADR_STR_OVRIDE_IND.
    var PTA_CORSP_ADR_IND       = tinObj.TR28_PTA_CORSP_ADR_IND //OUT_ADD_CORSP_ADR_IND.
    var PTA_ADR_CARE_NM         = tinObj.TR28_PTA_ADR_CARE_NM //OUT_ADD_ADR_CARE_NM.
    var PTA_INTRL_RTE_NBR       = tinObj.TR28_PTA_INTRL_RTE_NBR //OUT_ADD_INTRL_RTE_NBR.
    var PTA_EFF_DT              = tinObj.TR28_PTA_EFF_DT //OUT_ADD_EFF_DT.
    var PTA_CANC_DT             = tinObj.TR28_PTA_CANC_DT //OUT_ADD_CANC_DT.
    var PTA_MDCD_ID             = tinObj.TR28_PTA_MDCD_ID //OUT_ADD_MDCD_ID.
    var PTA_MDCD_LOC_CD         = tinObj.TR28_PTA_MDCD_LOC_CD //OUT_ADD_MDCD_LOC_CD.
    var PTA_EPD_ADDR_SEQ        = tinObj.TR28_PTA_EPD_ADDR_SEQ //OUT_ADD_ADR_SEQ_NBR.
    var PTP_TAX_ID_NBR          = tinObj.TR28_PTP_TAX_ID_NBR //WS-TAX-ID-NBR-9
    var PTP_TAX_ID_TYP_CD       = tinObj.TR28_PTP_TAX_ID_TYP_CD  //OUT-TIN-TAX-ID-TYP-CD
    var PTL_LST_UPDT_DT=""  // no usage found ???
    var WS_LST_UPDT_DT1 = tinObj.TR28_PTA_LST_UPDT_DT
    var WS_LST_UPDT_DT2 = tinObj.TR28_ADR_LST_UPDT_DT
    var PTA_DIR_IND=tinObj.TR28_PTA_DIR_IND
    var PTA_PRI_CD = tinObj.TR28_PTA_PRI_CD
    var PTA_TOPS_TIN_SUFX_CD=tinObj.TR28_PTA_TOPS_TIN_SUFX_CD
    var PTA_TOPS_TIN_PRFX_CD=tinObj.TR28_PTA_TOPS_TIN_PRFX_CD
    val SW_MAIL_ADR_TYP = "N"
    // SW_MAIL_ADR_TYP = "N"
    var WS_ADR_TYP_CD_1 = PTA_ADR_TYP_CD
    var WS_ADR_TYP_CD_2 = PTA_ADR_TYP_CD
    var df_76,df_58,df_57,df_add = context.sparkSession.emptyDataFrame
    var Seg_Nm,Seg_Seq = ""
    //if(PTA_ADR_TYP_CD.equals("L") || PTA_ADR_TYP_CD.equals("D")) {
    //Process 4250-GET-ZIP-LAT-LONG
    //Execute TR '76 ZIP'
    //Check skip flag for ADD
    if(SW_SKIP_ADD.equals("N")) {
      inputEntity.segmentDetails.map { segDtls =>
        val SchemaNm = inputEntity.schemaNm
        // Logger.log.info(".........Schema Name......." + SchemaNm)
        if (segDtls.segName.contains("ADD")) {
          Seg_Nm = segDtls.segName
          Seg_Seq = segDtls.segSeq
          Logger.log.info("Inside ADD")
          //Iterate over all the segment keys one by one
          segDtls.segQueries.map { qryKey =>
            if (qryKey.name.matches("ADD_76_ZIP")) {
              try {
                Logger.log.info("Inside ADD_76_ZIP")
                var qryStr = qryKey.query.replace("${SchemaNm}", SchemaNm).replace("${WS_SQL_PROV_ID}", WS_SQL_PROV_ID).
                  replace("${ADR_ZIP_CD}", ADR_ZIP_CD).replace("${PTA_CANC_DT}", PTA_CANC_DT).replace("${PTA_ADR_TYP_CD}",PTA_ADR_TYP_CD)
                df_76 = context.sqlContext.sql(s"$qryStr")
                createOrReplaceTempViewFn(df_76, qryKey.name)
                Logger.log.info("ADD_76_ZIP Query --> " + qryStr)
                Logger.log.info("df_76.count --> " + df_76.count)
              } catch {
                case e: Exception => {
                  Logger.log.info("'DB2 ERROR ON SELECT ADD_76_ZIP SQLCODE'")
                }
              }
            } else if (qryKey.name.matches("ADD_57_PROV_TIN_ADR_LIM")) {
              try {
                Logger.log.info("-- Inside ADD_57_PROV_TIN_ADR_LIM --")
                var qryStr = qryKey.query.replace("${SchemaNm}", SchemaNm).replace("${WS_SQL_PROV_ID}", WS_SQL_PROV_ID)
                  .replace("${PTA_ADR_ID}", PTA_ADR_ID).replace("${PTP_TAX_ID_NBR}", PTP_TAX_ID_NBR)/*.replace("${PTP_TAX_ID_TYP_CD}", PTP_TAX_ID_TYP_CD)
          .replace("${WS_ADR_TYP_CD_1}", WS_ADR_TYP_CD_1).replace("${WS_ADR_TYP_CD_2}", WS_ADR_TYP_CD_2).replace("${WS_ACTV_CD_1}", WS_ACTV_CD_1)
          .replace("${WS_ACTV_CD_2}", WS_ACTV_CD_2).replace("${WS_UPDT_DT_1}", WS_UPDT_DT_1).replace("${WS_UPDT_DT_2}", WS_UPDT_DT_2)*/
                Logger.log.info("ADD_57_PROV_TIN_ADR_LIM Query --> " + qryStr)
                df_57 = context.sqlContext.sql(s"$qryStr")
                createOrReplaceTempViewFn(df_57, qryKey.name)
                Logger.log.info("df_57.count --> " + df_57.count)
                if (df_57.count() >= 1) {
                  //Calling an intermediate procedure to join
                  ADD_PROV_TIN_ADR_LIM_tmp_prc(segDtls.segQueries, qryKey.name, WS_SQL_PROV_ID, PTA_ADR_ID)
                  Logger.log.info("Go to END 4210-GET-ADR-LIM ; EXECUTING JOIN WITH tr76 AND tr57")
                } else {
                  if (PTA_ADR_TYP_CD.equals("T")) {
                    /*  PTL_LST_UPDT_DT = "01/01/0001"
                //GO TO END 4210-GET-ADR-LIM
                *HANDLED IN QUERY
                */
                  } else if (PTA_ADR_TYP_CD.equals("L")) {
                    WS_ADR_TYP_CD_1 = "L"
                    WS_ADR_TYP_CD_2 = "D"
                  } else {
                    WS_ADR_TYP_CD_1 = "H"
                    WS_ADR_TYP_CD_2 = "D"
                  }

                   ADD_58_PROV_TIN_ADR_LIM_prc(segDtls.segQueries, SchemaNm: String, WS_SQL_PROV_ID: String, tinObj, WS_ADR_TYP_CD_1, WS_ADR_TYP_CD_2, WS_UPDT_DT_1, WS_UPDT_DT_2, WS_ACTV_CD_1, WS_ACTV_CD_2)

                   /* if (df_58.count >= 1) {
                 //Next Sentence
                 // PTL_LST_UPDT_DT from resultset
               } else if (df_58.count() == 0) {
                 PTL_LST_UPDT_DT = "01/01/0001"
               }
             HANDLED IN QUERY
             */
                 }
               } catch {
                 case e: Exception => {
                   Logger.log.info("'DB2 ERROR ON SELECT PROV_TIN_ADR_LIM SQLCODE'")
                 }

                   System.exit(0)
               }

             } else if (qryKey.name.matches("ADD_FINAL_QRY")) {
               Logger.log.info("Inside ADD_FINAL_QRY")
               var qryStr = qryKey.query.replace("${PTA_CANC_DT}", PTA_CANC_DT).replace("${WS_SQL_PROV_ID}", WS_SQL_PROV_ID).replace("${PTA_ADR_ID}", PTA_ADR_ID)
                 .replace("${ADR_ADR_LN_1_TXT}", ADR_ADR_LN_1_TXT).replace("${ADR_CTY_NM}", ADR_CTY_NM).replace("${ADR_ST_CD}", ADR_ST_CD).replace("${ADR_ZIP_CD}", ADR_ZIP_CD)
                 .replace("${ADR_ZIP_PLS_4_CD}", ADR_ZIP_PLS_4_CD)
                 .replace("${ADR_CNTY_NM}", ADR_CNTY_NM).replace("${ADR_HNCP_ACSBL_IND}", ADR_HNCP_ACSBL_IND).replace("${PTA_ADR_TYP_CD}", PTA_ADR_TYP_CD)
                 .replace("${PTA_DIR_IND}", PTA_DIR_IND).replace("${PTA_PRI_CD}", PTA_PRI_CD).replace("${PTA_BIL_ADR_ID}", PTA_BIL_ADR_ID)
                 .replace("${PTA_LST_UPDT_DT}", WS_LST_UPDT_DT1).replace("${WS_PREV_RUN_DT_YMD}", WS_PREV_RUN_DT_YMD).replace("${ADR_LST_UPDT_DT}", WS_LST_UPDT_DT2)
                 .replace("${PTA_TOPS_TIN_SUFX_CD}", PTA_TOPS_TIN_SUFX_CD).replace("${PTA_TOPS_TIN_PRFX_CD}", PTA_TOPS_TIN_PRFX_CD).replace("${PTA_ORIG_EFF_DT}", PTA_ORIG_EFF_DT)
                 .replace("${ADR_ADR_STR_OVRIDE_IND}", ADR_ADR_STR_OVRIDE_IND).replace("${PTA_CORSP_ADR_IND}", PTA_CORSP_ADR_IND).replace("${PTA_ADR_CARE_NM}", PTA_ADR_CARE_NM)
                 .replace("${PTA_INTRL_RTE_NBR}", PTA_INTRL_RTE_NBR).replace("${PTA_EFF_DT}", PTA_EFF_DT).replace("${PTA_CANC_DT}", PTA_CANC_DT)
                 .replace("${PTA_MDCD_ID}", PTA_MDCD_ID).replace("${PTA_MDCD_LOC_CD}", PTA_MDCD_LOC_CD).replace("${PTA_EPD_ADDR_SEQ}", PTA_EPD_ADDR_SEQ)
               df_add = context.sqlContext.sql(s"$qryStr")
               createOrReplaceTempViewFn(df_add, qryKey.name)
               Logger.log.info("ADD_FINAL_QRY df.count" + df_add.count)
               if (df_add.count > 0) {
                 Logger.log.info("Inside df_add.count > 0")
                 //  addStr = df_add.collect.map(x => x.mkString(DPOConstants.TABDELIM)).mkString(DPOConstants.NEWLINECHAR)
                 df_add.rdd.collect().map{
                   rec =>
                     val addObj = ADD_SEG(rec.getAs[String]("OUT_ADD_REC_TYP"),rec.getAs[String]("OUT_ADD_PROV_ID"),rec.getAs[String]("OUT_ADD_ADR_ID_3"),
                       rec.getAs[String]("OUT_ADD_ADR_ID_9"),rec.getAs[String]("OUT_ADD_STREET"),rec.getAs[String]("OUT_ADD_CITY"),rec.getAs[String]("OUT_ADD_ST"),
                       rec.getAs[String]("OUT_ADD_ZIP_CD"),rec.getAs[String]("OUT_ADD_ZIP_PLS_4_CD"),rec.getAs[String]("OUT_ADD_CNTY_NM"),rec.getAs[String]("OUT_ADD_HNCP_ACSBL_IND"),
                       rec.getAs[String]("OUT_PTNT_BEGN_AGE_NBR"),rec.getAs[String]("OUT_PTNT_END_AGE_NBR"),rec.getAs[String]("OUT_ADD_TYP_CD"),rec.getAs[String]("OUT_ADD_DIR_IND"),
                       rec.getAs[String]("OUT_ADD_PRI_CD"),rec.getAs[String]("OUT_ADD_BIL_ADR_ID_3"),rec.getAs[String]("OUT_ADD_BIL_ADR_ID_9"),rec.getAs[String]("OUT_ADD_CHG_IND"),
                       rec.getAs[String]("OUT_ADD_TIN_SUFX_CD"),rec.getAs[String]("OUT_ADD_TIN_PRFX_CD"),rec.getAs[String]("OUT_ADD_ORIG_EFF_DT"),rec.getAs[String]("OUT_ADD_ADR_STR_OVRIDE_IND"),
                       rec.getAs[String]("OUT_ADD_CORSP_ADR_IND"),rec.getAs[String]("OUT_ADD_ADR_CARE_NM"),rec.getAs[String]("OUT_ADD_INTRL_RTE_NBR"),rec.getAs[String]("OUT_ADD_EFF_DT"),
                       rec.getAs[String]("OUT_ADD_CANC_DT"),rec.getAs[String]("OUT_ADD_MDCD_ID"),rec.getAs[String]("OUT_ADD_MDCD_LOC_CD"),rec.getAs[String]("OUT_ADD_ADR_SEQ_NBR"),
                       rec.getAs[String]("OUT_ADD_ADR_LATITUDE"),rec.getAs[String]("OUT_ADD_ADR_LONGITUD"),rec.getAs[String]("PTL_LST_UPDT_DT"))

                    str = acoSegGen(inputEntity ,/*tinObj,addObj,*/SW_SKIP_ACO/*,WS_SQL_PROV_ID*/, WS_PREV_RUN_DT_YMD, outputFilePath).get

                    Logger.log.info("-----Returned ACO String-----" +str)
                    addStr = addObj.OUT_ADD_REC_TYP + DPOConstants.TABDELIM + addObj.OUT_ADD_PROV_ID + DPOConstants.TABDELIM + addObj.OUT_ADD_ADR_ID_3 + DPOConstants.TABDELIM + addObj.OUT_ADD_ADR_ID_9 + DPOConstants.TABDELIM + addObj.OUT_ADD_CITY + DPOConstants.TABDELIM + addObj.OUT_ADD_DIR_IND + DPOConstants.TABDELIM + addObj.OUT_ADD_CITY + DPOConstants.TABDELIM + addObj.OUT_ADD_ADR_ID_3 + DPOConstants.TABDELIM + addObj.OUT_ADD_ADR_ID_9 + DPOConstants.TABDELIM + addObj.OUT_ADD_CITY + DPOConstants.TABDELIM + addObj.OUT_ADD_DIR_IND + DPOConstants.TABDELIM + addObj.OUT_ADD_CITY
                    Logger.log.info("-- addStr -- " + addStr)
                    tempStr = tempStr + DPOConstants.NEWLINECHAR + addStr + DPOConstants.NEWLINECHAR +  str
                    tempStr += DPOConstants.NEWLINECHAR

                }
              }
              Logger.log.info("-- tempStr -- " + tempStr)
            }

          }

          tempStr.dropRight(1)
          Logger.log.info("Seg_Nm --> " +Seg_Nm)
          Logger.log.info("Seg_Seq --> " +Seg_Seq)

          tempPath = generateEPDEOpFile(tempStr, outputFilePath, Seg_Nm, Seg_Seq )
          Logger.log.info("ACO temp path -->" + tempPath)
          tempPath

        }
      }
    }

    addStr += DPOConstants.NEWLINECHAR
    Logger.log.info("Sco str --> " + addStr)
    addStr
  }*/

}
