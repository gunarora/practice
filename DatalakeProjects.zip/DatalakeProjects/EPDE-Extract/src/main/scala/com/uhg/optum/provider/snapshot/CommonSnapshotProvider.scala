package com.uhg.optum.provider.snapshot

import java.io.{File, FileWriter}

import com.uhg.optum.JobRunner._
import com.uhg.optum.common.DPOConstants
import com.uhg.optum.conf.ApplicationConfig
import com.uhg.optum.conf.ApplicationConfig.{snapshotDir, workingDir}
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.util.{CommonUtil, FileSystemUtil, Logger, SparkUtil}
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.hadoop.hbase.{CellUtil, TableName}
import org.apache.hadoop.hbase.client.{Get, Result}
import org.apache.hadoop.hbase.filter.CompareFilter.CompareOp
import org.apache.hadoop.hbase.filter.{Filter, FilterList, PrefixFilter, SingleColumnValueFilter}
import org.apache.hadoop.hbase.util.Bytes
import org.apache.spark.SparkContext
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{col, concat_ws, lit, row_number}
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{DataFrame, Row, SaveMode}

import scala.collection.mutable.ListBuffer
import scala.io.Source
import scala.util.{Failure, Success, Try}


object CommonSnapshotProvider {

  class CommonSnapshotFailed(msg: String, th: Throwable) extends Exception(msg, th)

}

/**
  * Created by paror18 on 10/18/2018.
  */
trait CommonSnapshotProvider extends RawSnapshotProvider with ParquetSnapshotProvider{
  var fsConf = new Configuration()
  var fileSystem = FileSystem.get(fsConf)

  /**
    *
    * @param entity
    * @param context
    * @return
    */
  def getCommonSnapshotPerEntity(entity: String)(implicit context: GlobalContext): String = {
    Logger.log.info("CommonSnapshotProvider: in getCommonSnapshotPerEntity ==========")
    Logger.log.info("CommonSnapshotProvider: Directory to read Parquet file--"+workingDir + "/"+snapshotDir+"/" + entity)
    val entityDF = context.sqlContext.read.parquet(workingDir +"/"+ snapshotDir +"/"+ entity)
    //Logger.log.info(entity + s" count from common snapshot: " + entityDF.count())
    entityDF.createOrReplaceTempView(s"${entity}")
    "Y"
  }


  /**
    *
    * @param rowKeyConfig
    * @param entity
    * @param pei
    * @param pitRowKey
    * @param context
    * @return
    */
  def getSnapshotExtractPerEntity(rowKeyConfig: String, entity: String, pei: PEI, pitRowKey: String,eitFlag:String)(implicit context: GlobalContext): String = {
    //println("in getSnapshotExtractPerEntity=================")
    val pscTable = context.pscTable
    val plcTable = context.plcTable
    var peiFullLoadFlg = " "
    var pitRawRowDelim = " "
    var pitRawPartnFlr = " "
    var pitRawFileCnt = " "

    Logger.log.info(s" Scanning PSC for rowKeyConfig provided:$rowKeyConfig")
    import com.uhg.optum.protocols.PSCProtocol._
    val psc : PSC = pscTable.getWithFilter(rowKeyConfig, "psc", new CustomFilter("psc", "activeflag", CompareOperations.EQUAL, "Y")).get
    println("psc==========PK============="+psc.prikeycols.split(";"))
    val primaryKeys = psc.prikeycols.split(";")
    val dmlCol = psc.dmlcol
    val modTsCol = psc.modtscol
    val fullLoadFlg = psc.fullLoadflg
    val incEndTs = CommonUtil.getCurrentTimeFormat //TODO check with Priya
    val plcRowKey = rowKeyConfig.split("-")(0) + "-" + pei.consumingApp
    Logger.log.info(s"plc row key : $plcRowKey")
    Logger.log.info(s" Primary Key Columns for $entity : ${psc.prikeycols.mkString}")
    val lastRunDt = plcTable.getValueByRowKey(plcRowKey, "plc", "lastRunDt")

    val lstrundateFlg = getLstRunDtFlag(lastRunDt, fullLoadFlg, entity)
    Logger.log.info(s" last run date Flag : $lstrundateFlg")
    // if lstrundateFlg true then Incremental will run
    if (lstrundateFlg) {
      peiFullLoadFlg = entity + "-N"
    } else {
      peiFullLoadFlg = entity + "-Y"
    }

    //  val lstrundateFlg = if(lastRunDt.isEmpty) false else if(psc.fullLoadflg.equalsIgnoreCase("Y")) false else true
    //TODO: Log the full load logger based on the value of lstRundateFlag
    //   Logger.log.info(s" last run date Flag : $lstrundateFlg")
    //  val peiFullLoadFlg = if(lstrundateFlg) entity+"-N" else entity+"-Y"
    var result: String = eitLakeTabScanMod(pei: PEI, eitFlag, entity, lstrundateFlg, lastRunDt, incEndTs, pitRowKey, ApplicationConfig.lakeEitTableName)
    Logger.log.info(s"result retrieved from eitTabScan :: " + result)

    val resultFlg = result.split(';')(0)
    pitRawRowDelim = pitRawRowDelim + result.split(';')(1).dropRight(1)
    pitRawPartnFlr = pitRawPartnFlr + result.split(';')(2).dropRight(1)
    pitRawFileCnt = pitRawFileCnt + result.split(';')(3).dropRight(1)


    val ptnrCd = s"${pei.prtnrCd.toUpperCase()}"
    val src = s"${pei.srcCd.toUpperCase()}"
    val entName = s"${entity.toUpperCase()}"
    Logger.log.info(s" Working Directory path for Incremental extract: $workingDir")

    val sqlContext = context.sparkSession.sqlContext

    if (resultFlg.equalsIgnoreCase("true")) {
      try {
        Logger.log.info(s" Captured Incremental Extract for ${entName}")
        Logger.log.info(s" Merging Schema for $entName from $workingDir/$entName")
        Logger.log.info(s" checking existence of working directory")
        val merDir = workingDir + "/" + entName
        SparkUtil.mkdirs(merDir)
        val mergeDF = sqlContext.read.option("mergeSchema", true).parquet(s"$workingDir/$entName").persist(org.apache.spark.api.java.StorageLevels.MEMORY_AND_DISK_SER)
        Logger.log.info(s" Merge Schema Record Count for $entName :" + mergeDF.count)

        try {
          //snpCfgScan.unpersist()
          val userWindow = Window.partitionBy(concat_ws("-", primaryKeys.map(c => col(c)): _*), lit("")).orderBy(col(s"$modTsCol").desc)
          val dedupDF = mergeDF.withColumn("rank", row_number().over(userWindow)).where(col("rank") === 1).drop("rank")
          Logger.log.info(s"Schema: " + dedupDF.printSchema() + s"Count::" + dedupDF.count())
          /*val noCdcFlg=dedupDF.filter(dedupDF("CDC_FLAG") =!= 'D'
          ).persist(org.apache.spark.api.java.StorageLevels.MEMORY_AND_DISK_SER)*/
          dedupDF.createOrReplaceTempView("dedupDf")
          val noCdcFlg = sqlContext.sql(s"select * from dedupDf where cdc_flag != 'D'")
          val dedupCnt = noCdcFlg.count()
          Logger.log.info(s"Number of Records Extracted for $entName  with Dedup Logic:" + dedupCnt)
          //noCdcFlg.createOrReplaceTempView(s"${entName}")





          val snapDir = workingDir + "/snapshot/" + entName
          mkdirs(snapDir)

          noCdcFlg.write.mode(SaveMode.Overwrite).parquet(snapDir)
          ///VS TEMP starts
          noCdcFlg.createOrReplaceTempView(entName)
          Logger.log.info(s"==========> temp view made for "+entName)
          /// VS TEMP ends
          Logger.log.info(s"==========> Delete raw data after snapshot generated for $entName <===========")
          rmPathIfExist(merDir)
          Logger.log.info(s"==========> Directory $merDir removed <===========")
          Logger.log.info(s"==========> Snapshot creation completed for ${entName} <===========")
          noCdcFlg.unpersist()
          dedupDF.unpersist()
          //TODO: save this dataframe as parquet
          /*Logger.log.info( s" Updating lastRnTs as ${incEndTs} in PSC HTable for EntNm:$entName" )
        hbasePSCPut( rowKeyConfig, "psc", "lastRunDt", incEndTs )*/ dedupDF.unpersist()

        } catch {
          case e: Exception => Logger.log.info(s">>>>> Exception at Main Loading MergeSchema/SqlStatement for $entName <<<<<" :+ e.getMessage)
            //removing intermediate parquet data
            SparkUtil.rmPathIfExist(workingDir + "/" + entName)
            // hbasePITEndStage("Fail", pitRowKey)
            throw e
        }


      } catch {
        case e: Exception => Logger.log.info(s">>>>> Exception at Main Loading Merge Parquet Schema/SqlStatement for $entName <<<<<" :+ e.getMessage)
          //removing intermediate parquet data
          SparkUtil.rmPathIfExist(workingDir + "/" + entName)
          // hbasePITEndStage("Fail", pitRowKey)
          throw e
      }


    } else {
      Logger.log.info(s" Since there are No Changes reflected for the $entName in a given time range, hence ending the workflow  ")

      peiFullLoadFlg = entName + "-ERROR"
      pitRawRowDelim = entName + "-ERROR"
      pitRawPartnFlr = entName + "-ERROR"
      pitRawFileCnt = entName + "-0"
      //hbasePITEndStage("Fail", pitRowKey)
      Logger.log.info(s" Updating lastRnTs as ${incEndTs} in PLC HTable for EntNm:$entName")
      plcTable.put(plcRowKey, "plc", "lastRunDt", incEndTs)
      //hbasePitPut(plcTab, plcRowKey, "plc", "lastRunDt", incEndTs)
      // hbasePSCPut(snapConfigTab, rowKeyConfig, "psc", "lastRunDt", incEndTs)
    }

    peiFullLoadFlg + ";" + pitRawRowDelim + ";" + pitRawPartnFlr + ";" + pitRawFileCnt

  }
  def getSnapshotExtractPerEntity(rowKeyConfig: String, entity: String, pei: PEI, pitRowKey: String)(implicit context: GlobalContext): String = {
    //println("in getSnapshotExtractPerEntity=================")
    val pscTable = context.pscTable
    val plcTable = context.plcTable
    var peiFullLoadFlg = " "
    var pitRawRowDelim = " "
    var pitRawPartnFlr = " "
    var pitRawFileCnt = " "

    Logger.log.info(s" Scanning PSC for rowKeyConfig provided:$rowKeyConfig")
    import com.uhg.optum.protocols.PSCProtocol._
    val psc : PSC = pscTable.getWithFilter(rowKeyConfig, "psc", new CustomFilter("psc", "activeflag", CompareOperations.EQUAL, "Y")).get
    println("psc==========PK============="+psc.prikeycols.split(";"))
    val primaryKeys = psc.prikeycols.split(";")
    val dmlCol = psc.dmlcol
    val modTsCol = psc.modtscol
    val fullLoadFlg = psc.fullLoadflg
    val incEndTs = CommonUtil.getCurrentTimeFormat //TODO check with Priya
    val plcRowKey = rowKeyConfig.split("-")(0) + "-" + pei.consumingApp
    Logger.log.info(s"plc row key : $plcRowKey")
    Logger.log.info(s" Primary Key Columns for $entity : ${psc.prikeycols.mkString}")
    val lastRunDt = plcTable.getValueByRowKey(plcRowKey, "plc", "lastRunDt")

    val lstrundateFlg = getLstRunDtFlag(lastRunDt, fullLoadFlg, entity)
    Logger.log.info(s" last run date Flag : $lstrundateFlg")
    // if lstrundateFlg true then Incremental will run
    if (lstrundateFlg) {
      peiFullLoadFlg = entity + "-N"
    } else {
      peiFullLoadFlg = entity + "-Y"
    }

    //  val lstrundateFlg = if(lastRunDt.isEmpty) false else if(psc.fullLoadflg.equalsIgnoreCase("Y")) false else true
    //TODO: Log the full load logger based on the value of lstRundateFlag
    //   Logger.log.info(s" last run date Flag : $lstrundateFlg")
    //  val peiFullLoadFlg = if(lstrundateFlg) entity+"-N" else entity+"-Y"
    var result: String = eitLakeTabScanMod(pei: PEI, "Y", entity, lstrundateFlg, lastRunDt, incEndTs, pitRowKey, ApplicationConfig.lakeEitTableName)
    Logger.log.info(s"result retrieved from eitTabScan :: " + result)

    val resultFlg = result.split(';')(0)
    pitRawRowDelim = pitRawRowDelim + result.split(';')(1).dropRight(1)
    pitRawPartnFlr = pitRawPartnFlr + result.split(';')(2).dropRight(1)
    pitRawFileCnt = pitRawFileCnt + result.split(';')(3).dropRight(1)


    val ptnrCd = s"${pei.prtnrCd.toUpperCase()}"
    val src = s"${pei.srcCd.toUpperCase()}"
    val entName = s"${entity.toUpperCase()}"
    Logger.log.info(s" Working Directory path for Incremental extract: $workingDir")

    val sqlContext = context.sparkSession.sqlContext

    if (resultFlg.equalsIgnoreCase("true")) {
      try {
        Logger.log.info(s" Captured Incremental Extract for ${entName}")
        Logger.log.info(s" Merging Schema for $entName from $workingDir/$entName")
        Logger.log.info(s" checking existence of working directory")
        val merDir = workingDir + "/" + entName
        SparkUtil.mkdirs(merDir)
        val mergeDF = sqlContext.read.option("mergeSchema", true).parquet(s"$workingDir/$entName").persist(org.apache.spark.api.java.StorageLevels.MEMORY_AND_DISK_SER)
        Logger.log.info(s" Merge Schema Record Count for $entName :" + mergeDF.count)

        try {
          //snpCfgScan.unpersist()
          val userWindow = Window.partitionBy(concat_ws("-", primaryKeys.map(c => col(c)): _*), lit("")).orderBy(col(s"$modTsCol").desc)
          val dedupDF = mergeDF.withColumn("rank", row_number().over(userWindow)).where(col("rank") === 1).drop("rank")
          Logger.log.info(s"Schema: " + dedupDF.printSchema() + s"Count::" + dedupDF.count())
          /*val noCdcFlg=dedupDF.filter(dedupDF("CDC_FLAG") =!= 'D'
          ).persist(org.apache.spark.api.java.StorageLevels.MEMORY_AND_DISK_SER)*/
          dedupDF.createOrReplaceTempView("dedupDf")
          val noCdcFlg = sqlContext.sql(s"select * from dedupDf where cdc_flag != 'D'")
          val dedupCnt = noCdcFlg.count()
          Logger.log.info(s"Number of Records Extracted for $entName  with Dedup Logic:" + dedupCnt)
          noCdcFlg.createOrReplaceTempView(s"${entName}")





          val snapDir = workingDir +"/"+ snapshotDir +"/"+ entName
          mkdirs(snapDir)

          noCdcFlg.write.mode(SaveMode.Overwrite).parquet(snapDir)
          Logger.log.info(s"==========> Delete raw data after snapshot generated for $entName <===========")
          rmPathIfExist(merDir)
          Logger.log.info(s"==========> Directory $merDir removed <===========")
          Logger.log.info(s"==========> Snapshot creation completed for ${entName} <===========")

          //TODO: save this dataframe as parquet
          /*Logger.log.info( s" Updating lastRnTs as ${incEndTs} in PSC HTable for EntNm:$entName" )
        hbasePSCPut( rowKeyConfig, "psc", "lastRunDt", incEndTs )*/ dedupDF.unpersist()

        } catch {
          case e: Exception => Logger.log.info(s">>>>> Exception at Main Loading MergeSchema/SqlStatement for $entName <<<<<" :+ e.getMessage)
            //removing intermediate parquet data
            SparkUtil.rmPathIfExist(workingDir + "/" + entName)
            // hbasePITEndStage("Fail", pitRowKey)
            throw e
        }


      } catch {
        case e: Exception => Logger.log.info(s">>>>> Exception at Main Loading Merge Parquet Schema/SqlStatement for $entName <<<<<" :+ e.getMessage)
          //removing intermediate parquet data
          SparkUtil.rmPathIfExist(workingDir + "/" + entName)
          // hbasePITEndStage("Fail", pitRowKey)
          throw e
      }


    } else {
      Logger.log.info(s" Since there are No Changes reflected for the $entName in a given time range, hence ending the workflow  ")

      peiFullLoadFlg = entName + "-ERROR"
      pitRawRowDelim = entName + "-ERROR"
      pitRawPartnFlr = entName + "-ERROR"
      pitRawFileCnt = entName + "-0"
      //hbasePITEndStage("Fail", pitRowKey)
      Logger.log.info(s" Updating lastRnTs as ${incEndTs} in PLC HTable for EntNm:$entName")
      plcTable.put(plcRowKey, "plc", "lastRunDt", incEndTs)
      //hbasePitPut(plcTab, plcRowKey, "plc", "lastRunDt", incEndTs)
      // hbasePSCPut(snapConfigTab, rowKeyConfig, "psc", "lastRunDt", incEndTs)
    }

    peiFullLoadFlg + ";" + pitRawRowDelim + ";" + pitRawPartnFlr + ";" + pitRawFileCnt

  }
  /**
    *
    * @param pei
    * @param EXTRACT_EIT_FLG
    * @param entNm
    * @param lstrundateFlg
    * @param incStTime
    * @param incEndTs
    * @param pitRowKey
    * @param eitTable
    * @param globalContext
    * @return
    */
  def eitLakeTabScanMod(pei: PEI, EXTRACT_EIT_FLG: String, entNm: String, lstrundateFlg: Boolean, incStTime: String, incEndTs: String, pitRowKey: String, eitTable: String)(implicit globalContext: GlobalContext): String = {
    try {
      Logger.log.info(s"INSIDE eitLakeTabScanMod def ")
      //val eitTable = globalContext.lakeEitTableName
      val ptnr = s"${pei.prtnrCd}".toUpperCase
      val src = s"${pei.srcCd}".toUpperCase
      //val incEndTs=CommonUtil.getCurrentTimeFormat
      //val mountPath = globalContext.mountPath
      val raw_path = s"maprfs://${ApplicationConfig.mountPath}/${ptnr.toLowerCase}/raw/standard_access/${src.toLowerCase}/data/"
      val entName = s"${entNm}".toUpperCase
      Logger.log.info(s" Retrieving Files for $entName from Raw: $raw_path")
      Logger.log.info(s" Processing Entity:${entName} with patnrCd:${ptnr} srcCd:${src}")
      var startTime = ""
      if (incStTime.isEmpty) {
        Logger.log.info(s" Incremental start time($incStTime) is empty , so overriding startTime with incEndTm to  $incEndTs")
        startTime = s"$incEndTs"
      } else {
        Logger.log.info(s" Incremental start time($incStTime) is not empty , so overriding startTime with incStTime  $incEndTs")
        startTime = s"$incStTime"
      }
      val endTime = s"$incEndTs"
      Logger.log.info(s" Endtime : $incEndTs ")
      Logger.log.info(s" startTime : $startTime ")
      Logger.log.info(s" Capturing if any Changes reflected for $entName from $startTime to $endTime")
      val rowKey = s"${ptnr}-${src}-${entName}"
      val sppRowKey = s"${ptnr}-${src}"
      var pitRawPartnFlr = ""
      var pitRawRowDelim = ""
      var pitRawFileCnt = ""
      var refEitTblFlg = "N"
      var resFlg = "false"
      var retStr=""
      //start for parquet
      if (pei.snapBuildType.equalsIgnoreCase("parquet")) {

        Logger.log.info(s" starting EIT scan for Parquet files")
        Logger.log.info(s"EXTRACT_EIT_FLG value is $EXTRACT_EIT_FLG")
        if (EXTRACT_EIT_FLG.equalsIgnoreCase("N")){
          try {
            Logger.log.info(s"Since EXTRACT_EIT_FLG value is $EXTRACT_EIT_FLG then reading from HbaseEit.txt file ; refEitTblFlg : $refEitTblFlg")
            var filename=s"/mapr/${workingDir}/EIT/HbaseEit.txt"
            var fileNmChk=new File(filename).exists()
            if(fileNmChk) {


              Logger.log.info(s"Scanning HbaseEit file ;fileNmChk : $fileNmChk")
              val lines = Source.fromFile(filename).getLines.toList
              var splitLine = lines.map(x => x.split('|'))
              var eitFileList: List[String] = null
              if (lstrundateFlg) {
                eitFileList = splitLine.filter(x => x(2) == entName && x(2) > startTime).map(x => s"${raw_path}${entNm}/${x(1)}").distinct
                Logger.log.info(s" Number of Entries Captured for $entName from EIT SCAN b/w $startTime and $endTime :" + eitFileList.size)
              } else {
                eitFileList = splitLine.filter(x => x(2) == entName).map(x => s"${raw_path}${entNm}/${x(1)}").distinct
                Logger.log.info(s" Number of Entries Captured for $entName from EIT SCAN full load :" + eitFileList.size)
              }

              if (eitFileList.size > 0) {
                //val eitFileList = eitInfo.map(x => (x._1, x._2)).collect.toList.map(x => ( s"${raw_path}${entNm}/${x._2}")).distinct
                //val eitRawFileList = eitFileList.filter(x => filterRawFileExist(x))
                val eitRawFileListNtEmp = eitFileList.filter(x =>
                  if(ApplicationConfig.isTriggerJobType.equalsIgnoreCase(DPOConstants.K8S) || ApplicationConfig.isTriggerJobType.equalsIgnoreCase(DPOConstants.KUBERNETES)){
                  FileSystemUtil.isNotEmptyDirMaprfs(x)}
                else{

                  isDirNotEmpty(x)})

                Logger.log.info(s" Number of PARQUET Files exist in Raw for $entName from EIT SCAN  :" + eitRawFileListNtEmp.length)
                Logger.log.info(s" List of PARQUET Files from Raw : ${eitRawFileListNtEmp.mkString}")
                val eitRdd = globalContext.sparkContext.parallelize(eitRawFileListNtEmp)

                eitRdd.collect.map(x => saveToDataFrameP("PARQUET", workingDir, x, entName))

                pitRawRowDelim = "NA|"
                pitRawPartnFlr = "NA|"
                pitRawFileCnt = "NA|"
                refEitTblFlg = "N"

                resFlg = "true"



              } else {
                refEitTblFlg = "Y"
                Logger.log.info(s" Since, No Changes Captured for $entName in the HbaseEIT File from $startTime to $endTime,")
                pitRawRowDelim = "0|"
                pitRawPartnFlr = "0|"
                pitRawFileCnt = "0|"
                resFlg = "false"
              }
            }
            else{
              refEitTblFlg = "Y"
              Logger.log.info(s" Since HbaseEIT file  not present at $filename, proceeding towards reading the EIT Hbase Table")
              pitRawRowDelim = "0|"
              pitRawPartnFlr = "0|"
              pitRawFileCnt = "0|"
              resFlg = "false"

            }
          }
          catch {
            case e: Exception => Logger.log.info(s" Exception while Reading HbaseEit.txt file for $entNm" :+ e.getStackTrace.mkString)
              // hbasePITEndStage( "Fail", pitRowKey)
              pitRawRowDelim="ERROR|"
              pitRawPartnFlr="ERROR|"
              pitRawFileCnt="ERROR|"
              resFlg="false"
              throw e
          }
        }
        else{
          refEitTblFlg="Y"
          Logger.log.info(s"Since EXTRACT_EIT_FLG value is $EXTRACT_EIT_FLG then proceeding towards scanning EIT Table ; refEitTblFlg : $refEitTblFlg")
          pitRawRowDelim="0|"
          pitRawPartnFlr="0|"
          pitRawFileCnt="0|"
          resFlg="false"

        }
        if(refEitTblFlg.equalsIgnoreCase("Y")) {
          try {

            Logger.log.info(s" Since refEitTblFlg is $refEitTblFlg then scanning the EIT Hbase Table $eitTable")
            import org.apache.hadoop.hbase.client.Scan
            val scan = new Scan()
            val filter = new PrefixFilter(Bytes.toBytes(s"${ptnr}-${src}-${entName}-"))
            val filter1 = new SingleColumnValueFilter(Bytes.toBytes("exi"), Bytes.toBytes("ingProcLogSts"), CompareOp.EQUAL, Bytes.toBytes("Success")); //val filter2 = new SingleColumnValueFilter(Bytes.toBytes("fi"), Bytes.toBytes("iscustrowdelim"), CompareOp.EQUAL, Bytes.toBytes("No"));
            import org.apache.hadoop.hbase.filter.CompareFilter.CompareOp
            scan.setCaching(10000)
            scan.setCacheBlocks(false)
            filter1.setFilterIfMissing(true)
            scan.setFilter(filterList(filter1, filter))
            if (lstrundateFlg) {
              scan.setTimeRange(CommonUtil.getTimestamp(startTime), CommonUtil.getTimestamp(endTime))
            }

            val eitVal = globalContext.hbaseContext.hbaseRDD(TableName.valueOf(eitTable), scan).cache
            Logger.log.info(s" DL eitVal count : ${eitVal.count()} ")
            val eitInfo = eitVal.map(tuple => {
              val result = tuple._2
              //(Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("schmVer"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("ingstdFileNm"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("entprtnfldr"))))
              (Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("schmVer"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("entprtnfldr"))))
            })


            if (lstrundateFlg) {
              Logger.log.info(s" Number of Entries Captured for $entName from EIT SCAN b/w $startTime and $endTime :" + eitVal.count())
            } else {
              Logger.log.info(s" Number of Entries Captured for $entName from EIT SCAN full load :" + eitVal.count())
            }

            if (!eitInfo.isEmpty) {
              Logger.log.info(s" eitInfo: $eitInfo")
              val eitFileList = eitInfo.map(x => (x._1, x._2)).collect.toList.map(x => (s"${raw_path}${entNm}/${x._2}")).distinct
              Logger.log.info(s" eitFileList: $eitFileList")
              //val eitRawFileList = eitFileList.filter(x => filterRawFileExist(x))
              val eitRawFileListNtEmp = eitFileList.filter(x =>
                if(ApplicationConfig.isTriggerJobType.equalsIgnoreCase(DPOConstants.K8S) || ApplicationConfig.isTriggerJobType.equalsIgnoreCase(DPOConstants.KUBERNETES)){
                  FileSystemUtil.isNotEmptyDirMaprfs(x)}
                else{

                  isDirNotEmpty(x)})

              Logger.log.info(s" Number of PARQUET Files exist in Raw for $entName from EIT SCAN b/w $startTime and $endTime :" + eitRawFileListNtEmp.length)
              Logger.log.info(s" List of PARQUET Files from Raw : ${eitRawFileListNtEmp.mkString}")
              val eitRdd = globalContext.sparkContext.parallelize(eitRawFileListNtEmp)

              eitRdd.collect.map(x => saveToDataFrameP("PARQUET", workingDir, x, entName))
              eitVal.unpersist()

              pitRawRowDelim="NA|"
              pitRawPartnFlr="NA|"
              pitRawFileCnt="NA|"
              resFlg="true"

              //"true;" + entName + "-" + pitRawRowDelim + ";" + entName + "-" + pitRawPartnFlr + ";" + entName + "-" + pitRawFileCnt;


            } else {
              Logger.log.info(s" Since, No Changes Captured for $entName in scanning EIT hbase table/ Hbase EIT File from $startTime to $endTime,No DataSets Generated")
              pitRawRowDelim="ERROR|"
              pitRawPartnFlr="ERROR|"
              pitRawFileCnt="ERROR|"
              resFlg="false"
              //"false;" + entName + "-ERROR|;" + entName + "-ERROR|;" + entName + "-ERROR|";
            }

          }  catch {
            case e: Exception => Logger.log.info(s" Exception while Scanning EIT Hbase Table for $entNm" :+ e.getStackTrace.mkString)
              //hbasePITEndStage( "Fail", pitRowKey)
              pitRawRowDelim="ERROR|"
              pitRawPartnFlr="ERROR|"
              pitRawFileCnt="ERROR|"
              resFlg="false"
              //"false;"+entName+"-ERROR|;"+entName+"-ERROR|;"+entName+"-ERROR|";
              throw e
          }

        }

        retStr=  resFlg+";"+entName+"-"+pitRawRowDelim+";"+entName+"-"+pitRawPartnFlr+";"+entName+"-"+pitRawFileCnt;
      }

      retStr
      //End for parquet

    }
    catch {
      case e: Exception => Logger.log.info(s" Exception while Scanning Files from DL EIT for $entNm from eitTabScan" :+ e.getStackTrace.mkString)
        //hbasePITEndStage("Fail", pitRowKey)
        throw e
    }

  }


  /**
    *
    * @param filters
    * @return
    */
  def filterList(filters: Filter*) = new FilterList(FilterList.Operator.MUST_PASS_ALL, filters: _*)

  /**
    * This method is for checking if the directory
    * exists or not for the given path.
    * @param filePath
    * @param context
    * @return
    */
  def isDirNotEmpty(filePath: String)(implicit context: GlobalContext): Boolean = {
    var resFlg = false
    val filePathT = filePath.replace("maprfs://", "/mapr/")
    val file = new File(filePathT)
    /*if(file.isDirectory()){*/
    if (context.fs.exists(new Path(s"$filePath"))) {
      if (file.list().length > 0) {
        Logger.log.info(s" Directory is not empty! " + filePathT);
        resFlg = true
      } else {
        resFlg = false
        Logger.log.info(s" Directory is  empty! " + filePathT);
      }
    } else {
      resFlg = false
      Logger.log.info(s" Directory path not present! " + filePathT);

    }
    /*}else{
      resFlg=false
      Logger.log.info(s" Not a Directory  " +filePathT);
    }*/
    resFlg
  }

  /**
    *
    * @param schmVer
    * @param workingDir
    * @param fileList
    * @param entNm
    * @param context
    */
  def saveToDataFrameP(schmVer: String, workingDir: String, fileList: String, entNm: String)(implicit context: GlobalContext): Unit = {
    var resCnt = "0"
    try {
      Logger.log.info(s" FileList in  saveDFversionTablesParquet for entity $entNm of partition Folder $schmVer is $fileList")

      val fileLstTkn = fileList.split(",").map(x => context.sparkSession.read.parquet(x))
      val df = fileLstTkn.reduce(_.union(_))
      resCnt = df.count().toString
      Logger.log.info(s" count for  entity $entNm of partition folder is " + resCnt)

      df.write.mode(SaveMode.Append).parquet(s"$workingDir/${entNm.toUpperCase()}")
    } catch {
      case e: Exception => Logger.log.info(" Exception at saveDFversionTablesParquet" :+ e.getMessage)
        throw e
    }

  }


  /**
    *
    * @param jobStatusTmp
    * @param pitRowKey
    * @param context
    */
  def hbasePITEndStage(jobStatusTmp: String, pitRowKey: String)(implicit context: GlobalContext): Unit = {
    val jobStatus = jobStatusTmp.toLowerCase;
    val provEndTs = CommonUtil.getCurrentTimeFormat
    if (jobStatus.equalsIgnoreCase("fail")) {
      //Find the duration
      //Logger.log.info(s"===================> for pitTableName  : " + pitTabName);
      val provStartTime = context.pitTable.getValueByRowKey(pitRowKey, "exi", "provStrTs")
      //val provStartTime = CustomFunctions.getHtableValByRowKey(pitTabName, pitRowKey, "exi", "provStrTs")
      val duration = CommonUtil.getDuration(provEndTs, provStartTime)
      Logger.log.info(s"===================> duration : " + duration);

      context.pitTable.put(pitRowKey, "exi", "provDur", duration)
      Logger.log.info(s" Updating PIT table for the column : provDur as $duration , cf : exi, RowKey : $pitRowKey ")
      context.pitTable.put(pitRowKey, "exi", "provEndTs", provEndTs)
      Logger.log.info(s" Updating PIT table for the column : provEndTs as ${CommonUtil.getCurrentTimeFormat} , cf : exi, RowKey : $pitRowKey ")
    }
    else {
      context.pitTable.put(pitRowKey, "exi", "lastRunDt", provEndTs)
    }
    context.pitTable.put(pitRowKey, "exi", "provCompSts", jobStatus)
    Logger.log.info(s" Updating PIT table for the column : provCompSts as $jobStatus , cf : exi, RowKey : $pitRowKey ")

    Logger.log.info(s"==============> Ending Provisioning extract PIT table with status as $jobStatus<==============")

    context.sparkContext.stop()

  }

  /** Purpose : Def to get the schema versions from Datalake EPP htable
    * input : LakeEPP RowKey i.e sourceCode, partnerCode, entityName
    * output: Returns LakeEPP RowKey respective Schemaversions RDD */
  /* def getEppLakeTabSchma(eppTab: String, patnrCd: String, srcCd: String, entNm: String)(implicit context: GlobalContext): org.apache.spark.rdd.RDD[(String, String)] = {
     try {
       //val eppTableName = "/datalake/uhclake/prd/p_mtables/entity_partner_profile"
       //   val eppTab = globalContext.lakeEppTableName
       Logger.log.info(s" Scanning EPP HBase Table $eppTab for Entity: $entNm")
       val rdd = context.sparkContext.parallelize(Array(Bytes.toBytes(s"${patnrCd}-${srcCd}-${entNm}")))
       val getRdd = context.hbaseContext.bulkGet[Array[Byte], List[(String, String)]](TableName.valueOf(eppTab), 2, rdd, record => {
         val get = new Get(record)
         get.setMaxVersions(99)
       }, (result: Result) => {
         val it = result.listCells().iterator()
         var schver = new ListBuffer[String]()
         var schm = new ListBuffer[String]()
         while (it.hasNext) {
           val cell = it.next()
           val q = Bytes.toString(CellUtil.cloneQualifier(cell))
           if (q.equals("schmVer")) schver += Bytes.toString(CellUtil.cloneValue(cell)) else if (q.equals("schm")) schm += Bytes.toString(CellUtil.cloneValue(cell))
         }
         (schver zip schm).toList
       })
       getRdd.flatMap(x => x)
     } catch {
       case e: Exception => Logger.log.info(" Exception at saveDFVersionTables" :+ e.getMessage)
         throw e
     }
   }
 */

  /*def filterRawFileExist(filePath: String)(implicit context: GlobalContext): Boolean = {
    context.fs.exists(new Path(s"$filePath"))
  }*/

  /** Purpose : Def to save the EPP Htable schema versions results into spark dataframe with parquet file format
    * input : schemaVersion(s), schema, filesList, entityName, sparkConfiguration
    * output: DF should be created and saves resultant versions in the form of parquet */
  /*def saveToDataFrame(workingDir: String, schmVer: String, schm: String, fileList: String, entNm: String, sparkConfig: SparkContext)(implicit context: GlobalContext): Unit = {
    try {
      val jsonFile = schm.split("(?<=\\}),(?=\\{)")
      val jsonRddSchm = context.sparkContext.parallelize(jsonFile)
      val jsonRdd = context.sparkSession.sqlContext.read.json(jsonRddSchm).rdd.map(x => (x(1).toString)).collect.toList
      val fields = jsonRdd.map(fieldName => StructField(fieldName, StringType, nullable = true))
      val schema = StructType(fields) //
      val loadFiles = sparkConfig.textFile(fileList).map(_.split("\u0001", -1)).map(x => Row(x: _*))
      val verDf = context.sparkSession.sqlContext.createDataFrame(loadFiles, schema)
      //val workingDir = globalContext.workingDir
      verDf.write.mode(SaveMode.Append).parquet(s"$workingDir/${entNm.toUpperCase()}")
    } catch {
      case e: Exception => Logger.log.info(" Exception at saveDFversionTables" :+ e.getMessage)
        throw e
    }
  }
*/



  def getLstRunDtFlag(lstrundate: String, fullLoadFlg: String, entity: String): Boolean = {
    var lstrundateFlg = false
    Logger.log.info(s" Given fullLoadFlg value : $fullLoadFlg")

    // if lastRunDate is empty , then consider this load as Full load and make lastRunDateFlag as False,
    // else check the given  fullLoadFlag value is Yes then consider this load as Full load and make lastRunDateFlag as False,
    // else consider this load as Incremental load and make lastRunDateFlag as True
    if (lstrundate.isEmpty) {
      Logger.log.info(s" performing full load runtime snapshot for the entity ${entity}")
      lstrundateFlg = false
    } else {
      if (fullLoadFlg.equalsIgnoreCase("Y")) {
        Logger.log.info(s" performing full load runtime snapshot for the entity ${entity}")
        lstrundateFlg = false
      } else {
        Logger.log.info(s" performing Incremental load runtime snapshot for the entity ${entity} with last rundate as ${lstrundate}")
        lstrundateFlg = true
      }
    }
    lstrundateFlg
  }




  /** Purpose : Def to create folder(s)/directories in MapR FileSystem
    * input : path of the folder
    * output: Given folder path should be created in FileSystem */
  def mkdirs (folderPath: String): Unit = {
    try {
      Logger.log.info(s" Created Path : " + folderPath)
      fileSystem.mkdirs(new Path(folderPath))

    } catch {
      case e: Exception => Logger.log.info(" Exception at mkdirs definition" :+ e.getStackTrace.toString)
        throw e
    }
  }




  /*def getSnapshotCommonPerEntity (snapBuildType:String,pKeys:String,lakeEitTableName: String, mountPath: String, workingDir: String, lakeEppTableName: String,entity: String, prtnrCd: String, srcCd: String,dmlCol:String,modTsCol:String): Unit = {

    try {
      val primaryKeys: Array[String] = pKeys.split(";")
      Logger.log.info(s" Primary Key Columns for $entity : ${pKeys}")
      // Get LakeEIT scanned rowKey entity
      var result: Boolean=false
      //result = eitLakeTabScanCommonSnap(snapBuildType,lakeEitTableName, mountPath, lakeEppTableName, workingDir, prtnrCd, srcCd, entity)
      result = eitLakeTabScanCommonSnapMod(snapBuildType,lakeEitTableName, mountPath, lakeEppTableName, workingDir, prtnrCd, srcCd, entity)
      val ptnrCd = s"${prtnrCd.toUpperCase()}"
      val src = s"${srcCd.toUpperCase()}"
      val entName = s"${entity.toUpperCase()}"
      Logger.log.info(s" Working Directory path for Incremental extract: $workingDir")

      //if LakeEIT scanned rowKey entity is empty then end the workflow with Success Status , else continue to save the raw snapshot merged files into a dataframe as entity name
      if (result) {
        try {
          Logger.log.info(s" Captured Incremental Extract for ${entName}")
          Logger.log.info(s" Merging Schema for $entName from $workingDir/$entName")
          Logger.log.info(s" checking existence of working directory")
          val merDir = workingDir + "/" + entName
          mkdirs(merDir)
          val mergeDF = sqlContext.read.option("mergeSchema", true).parquet(s"$workingDir/$entName").persist(org.apache.spark.api.java.StorageLevels.MEMORY_AND_DISK_SER)
          //Temp// Logger.log.info(s" Merge Schema Record Count for $entName :" + mergeDF.count)

          try {
            val userWindow = Window.partitionBy(concat_ws("-", primaryKeys.map(c => col(c)): _*), lit("")).orderBy(col(s"$modTsCol").desc)
            val dedupDF = mergeDF.withColumn("rank", row_number().over(userWindow)).where(col("rank") === 1).drop("rank")
            // val noCdcFlg=dedupDF.toDF.filter(dedupDF("CDC_FLAG") =!= 'D').persist(org.apache.spark.api.java.StorageLevels.MEMORY_AND_DISK_SER)
            dedupDF.createOrReplaceTempView(s"dedupDf")
            val noCdcFlg=sqlContext.sql(s"select * from dedupDf where trim(${dmlCol}) != 'D'")
            val snapDir = workingDir + "/snapshot/" + entName
            mkdirs(snapDir)
            //dedupDF.createOrReplaceGlobalTempView(s"${entName}")
            noCdcFlg.write.mode(SaveMode.Overwrite).parquet(snapDir)
            Logger.log.info(s"==========> Delete raw data after snapshot generated for $entName <===========")
            rmPathIfExist(merDir)
            Logger.log.info(s"==========> Directory $merDir removed <===========")
            Logger.log.info(s"==========> Snapshot creation completed for ${entName} <===========")
          } catch {
            case e: Exception => Logger.log.info(s">>>>> Exception at Main Loading MergeSchema/SqlStatement for $entName <<<<<" :+ e.getMessage)
              //removing intermediate parquet data
              rmPathIfExist(workingDir + "/" + entName)
              rmPathIfExist(workingDir + "/snapshot/" + entName)
              //hbasePITEndStage(pitTab, "Fail", pitRowKey)
              throw e
          }


        } catch {
          case e: Exception => Logger.log.info(s">>>>> Exception at Main Loading Merge Parquet Schema/SqlStatement for $entName <<<<<" :+ e.getMessage)
            //removing intermediate parquet data
            rmPathIfExist(workingDir + "/" + entName)
            throw e
        }
      } else {
        Logger.log.info(s" Since there are No Changes reflected for the $entName in a given time range, hence ending the workflow  ")
      }
    } catch {
      case e: Exception => Logger.log.info(" Exception at DataLake Snapshot Scan , Failed due to " :+ e.getMessage)
        throw e

    }
  }

*/



  /** Purpose : Def to remove hadoop directory if exists
    * input : hadoopDirectoryPath
    * output: Returns Boolean value as 0 if the file is exists else 1 for not exists */
  //Fix : not used anywhere, later we can use this instead of commandline commands
  def rmPathIfExist (path: String): Unit = {
    try {

      if (fileSystem.exists(new Path(path))) {
        Logger.log.info(s" Deleted intermediate file/dir : " + path)
        fileSystem.delete(new Path(path.replace("/mapr/", "/")), true)
        //fileSystem.deleteOnExit(new Path(path))
      } else {
        Logger.log.info(s" Path: $path doesn't exist, Not proceeding for removing.")
      }
    } catch {
      case e: Exception => Logger.log.info(" Exception at rmPathIfExist definition" :+ e.getStackTrace.toString)
        throw e
    }
  }

  def getParquetFilesPerEntity(rowKeyConfig: String, entity: String, pei: PEI, pitRowKey: String)(implicit context: GlobalContext): String = {
    //println("in getSnapshotExtractPerEntity=================")
    val pscTable = context.pscTable
    val plcTable = context.plcTable
    var peiFullLoadFlg = " "
    var pitRawRowDelim = " "
    var pitRawPartnFlr = " "
    var pitRawFileCnt = " "

    Logger.log.info(s" Scanning PSC for rowKeyConfig provided:$rowKeyConfig")
    import com.uhg.optum.protocols.PSCProtocol._
    val psc : PSC = pscTable.getWithFilter(rowKeyConfig, "psc", new CustomFilter("psc", "activeflag", CompareOperations.EQUAL, "Y")).get
    println("psc==========PK============="+psc.prikeycols.split(";"))
    val primaryKeys = psc.prikeycols.split(";")
    val dmlCol = psc.dmlcol
    val modTsCol = psc.modtscol
    val fullLoadFlg = psc.fullLoadflg
    val incEndTs = CommonUtil.getCurrentTimeFormat //TODO check with Priya
    val plcRowKey = rowKeyConfig.split("-")(0) + "-" + pei.consumingApp
    Logger.log.info(s"plc row key : $plcRowKey")
    Logger.log.info(s" Primary Key Columns for $entity : ${psc.prikeycols.mkString}")
    val lastRunDt = plcTable.getValueByRowKey(plcRowKey, "plc", "lastRunDt")

    val lstrundateFlg = getLstRunDtFlag(lastRunDt, fullLoadFlg, entity)
    Logger.log.info(s" last run date Flag : $lstrundateFlg")
    // if lstrundateFlg true then Incremental will run
    if (lstrundateFlg) {
      peiFullLoadFlg = entity + "-N"
    } else {
      peiFullLoadFlg = entity + "-Y"
    }

    //  val lstrundateFlg = if(lastRunDt.isEmpty) false else if(psc.fullLoadflg.equalsIgnoreCase("Y")) false else true
    //TODO: Log the full load logger based on the value of lstRundateFlag
    //   Logger.log.info(s" last run date Flag : $lstrundateFlg")
    //  val peiFullLoadFlg = if(lstrundateFlg) entity+"-N" else entity+"-Y"
    val result = eitLakeTabScanMod1(pei: PEI, "Y", entity, lstrundateFlg, lastRunDt, incEndTs, pitRowKey, ApplicationConfig.lakeEitTableName)
    Logger.log.info(s"result retrieved from eitTabScan :: " + result)
    //result.map(x => saveToDataFrameP1("PARQUET", workingDir, x, entity))
    /* val resultFlg = result.split(';')(0)
     pitRawRowDelim = pitRawRowDelim + result.split(';')(1).dropRight(1)
     pitRawPartnFlr = pitRawPartnFlr + result.split(';')(2).dropRight(1)
     pitRawFileCnt = pitRawFileCnt + result.split(';')(3).dropRight(1)

     val ptnrCd = s"${pei.prtnrCd.toUpperCase()}"
     val src = s"${pei.srcCd.toUpperCase()}"
     val entName = s"${entity.toUpperCase()}"
     Logger.log.info(s" Working Directory path for Incremental extract: $workingDir")

     val sqlContext = context.sparkSession.sqlContext*/

    /* if (resultFlg.equalsIgnoreCase("true")) {
       try {
         Logger.log.info(s" Captured Incremental Extract for ${entName}")
         Logger.log.info(s" Merging Schema for $entName from $workingDir/$entName")
         Logger.log.info(s" checking existence of working directory")
         val merDir = workingDir + "/" + entName
         SparkUtil.mkdirs(merDir)
         val mergeDF = sqlContext.read.option("mergeSchema", true).parquet(s"$workingDir/$entName").persist(org.apache.spark.api.java.StorageLevels.MEMORY_AND_DISK_SER)
         Logger.log.info(s" Merge Schema Record Count for $entName :" + mergeDF.count)

       /*  try {
           //snpCfgScan.unpersist()
           val userWindow = Window.partitionBy(concat_ws("-", primaryKeys.map(c => col(c)): _*), lit("")).orderBy(col(s"$modTsCol").desc)
           val dedupDF = mergeDF.withColumn("rank", row_number().over(userWindow)).where(col("rank") === 1).drop("rank")
           Logger.log.info(s"Schema: " + dedupDF.printSchema() + s"Count::" + dedupDF.count())
           /*val noCdcFlg=dedupDF.filter(dedupDF("CDC_FLAG") =!= 'D'
           ).persist(org.apache.spark.api.java.StorageLevels.MEMORY_AND_DISK_SER)*/
           dedupDF.createOrReplaceTempView("dedupDf")
           val noCdcFlg = sqlContext.sql(s"select * from dedupDf where cdc_flag != 'D'")
           val dedupCnt = noCdcFlg.count()
           Logger.log.info(s"Number of Records Extracted for $entName  with Dedup Logic:" + dedupCnt)
           noCdcFlg.createOrReplaceTempView(s"${entName}")





           val snapDir = workingDir + "/snapshot/" + entName
           mkdirs(snapDir)

           noCdcFlg.write.mode(SaveMode.Overwrite).parquet(snapDir)
           Logger.log.info(s"==========> Delete raw data after snapshot generated for $entName <===========")
           rmPathIfExist(merDir)
           Logger.log.info(s"==========> Directory $merDir removed <===========")
           Logger.log.info(s"==========> Snapshot creation completed for ${entName} <===========")

           //TODO: save this dataframe as parquet
           /*Logger.log.info( s" Updating lastRnTs as ${incEndTs} in PSC HTable for EntNm:$entName" )
         hbasePSCPut( rowKeyConfig, "psc", "lastRunDt", incEndTs )*/ dedupDF.unpersist()

         } catch {
           case e: Exception => Logger.log.info(s">>>>> Exception at Main Loading MergeSchema/SqlStatement for $entName <<<<<" :+ e.getMessage)
             //removing intermediate parquet data
             SparkUtil.rmPathIfExist(workingDir + "/" + entName)
             // hbasePITEndStage("Fail", pitRowKey)
             throw e
         }
 */

       } catch {
         case e: Exception => Logger.log.info(s">>>>> Exception at Main Loading Merge Parquet Schema/SqlStatement for $entName <<<<<" :+ e.getMessage)
           //removing intermediate parquet data
           SparkUtil.rmPathIfExist(workingDir + "/" + entName)
           // hbasePITEndStage("Fail", pitRowKey)
           throw e
       }


     } else {
       Logger.log.info(s" Since there are No Changes reflected for the $entName in a given time range, hence ending the workflow  ")

       peiFullLoadFlg = entName + "-ERROR"
       pitRawRowDelim = entName + "-ERROR"
       pitRawPartnFlr = entName + "-ERROR"
       pitRawFileCnt = entName + "-0"
       //hbasePITEndStage("Fail", pitRowKey)
       Logger.log.info(s" Updating lastRnTs as ${incEndTs} in PLC HTable for EntNm:$entName")
       plcTable.put(plcRowKey, "plc", "lastRunDt", incEndTs)
       //hbasePitPut(plcTab, plcRowKey, "plc", "lastRunDt", incEndTs)
       // hbasePSCPut(snapConfigTab, rowKeyConfig, "psc", "lastRunDt", incEndTs)
     }*/

    peiFullLoadFlg + ";" + pitRawRowDelim + ";" + pitRawPartnFlr + ";" + pitRawFileCnt

  }

  def eitLakeTabScanMod1(pei: PEI, EXTRACT_EIT_FLG: String, entNm: String, lstrundateFlg: Boolean, incStTime: String, incEndTs: String, pitRowKey: String, eitTable: String)(implicit globalContext: GlobalContext): Boolean = {
    try {
      Logger.log.info(s"INSIDE eitLakeTabScanMod def ")
      //val eitTable = globalContext.lakeEitTableName
      val ptnr = s"${pei.prtnrCd}".toUpperCase
      val src = s"${pei.srcCd}".toUpperCase
      //val incEndTs=CommonUtil.getCurrentTimeFormat
      //val mountPath = globalContext.mountPath
      val raw_path = s"maprfs://${ApplicationConfig.mountPath}/${ptnr.toLowerCase}/raw/standard_access/${src.toLowerCase}/data/"
      val entName = s"${entNm}".toUpperCase
      Logger.log.info(s" Retrieving Files for $entName from Raw: $raw_path")
      Logger.log.info(s" Processing Entity:${entName} with patnrCd:${ptnr} srcCd:${src}")
      var startTime = ""
      if (incStTime.isEmpty) {
        Logger.log.info(s" Incremental start time($incStTime) is empty , so overriding startTime with incEndTm to  $incEndTs")
        startTime = s"$incEndTs"
      } else {
        Logger.log.info(s" Incremental start time($incStTime) is not empty , so overriding startTime with incStTime  $incEndTs")
        startTime = s"$incStTime"
      }
      val endTime = s"$incEndTs"
      Logger.log.info(s" Endtime : $incEndTs ")
      Logger.log.info(s" startTime : $startTime ")
      Logger.log.info(s" Capturing if any Changes reflected for $entName from $startTime to $endTime")
      val rowKey = s"${ptnr}-${src}-${entName}"
      val sppRowKey = s"${ptnr}-${src}"
      var pitRawPartnFlr = ""
      var pitRawRowDelim = ""
      var pitRawFileCnt = ""
      var refEitTblFlg = "N"
      var resFlg = false
      var retStr=""
      var retList=List[String]()
      //start for parquet


      Logger.log.info(s" starting EIT scan for Parquet files")
      Logger.log.info(s"EXTRACT_EIT_FLG value is $EXTRACT_EIT_FLG")


      try {

        Logger.log.info(s" Since refEitTblFlg is $refEitTblFlg then scanning the EIT Hbase Table $eitTable")
        import org.apache.hadoop.hbase.client.Scan
        val scan = new Scan()
        val filter = new PrefixFilter(Bytes.toBytes(s"${ptnr}-${src}-${entName}-"))
        val filter1 = new SingleColumnValueFilter(Bytes.toBytes("exi"), Bytes.toBytes("ingProcLogSts"), CompareOp.EQUAL, Bytes.toBytes("Success")); //val filter2 = new SingleColumnValueFilter(Bytes.toBytes("fi"), Bytes.toBytes("iscustrowdelim"), CompareOp.EQUAL, Bytes.toBytes("No"));
        import org.apache.hadoop.hbase.filter.CompareFilter.CompareOp
        scan.setCaching(10000)
        scan.setCacheBlocks(false)
        filter1.setFilterIfMissing(true)
        scan.setFilter(filterList(filter1, filter))
        if (lstrundateFlg) {
          scan.setTimeRange(CommonUtil.getTimestamp(startTime), CommonUtil.getTimestamp(endTime))
        }

        val eitVal = globalContext.hbaseContext.hbaseRDD(TableName.valueOf(eitTable), scan).cache
        Logger.log.info(s" DL eitVal count : ${eitVal.count()} ")
        val eitInfo = eitVal.map(tuple => {
          val result = tuple._2
          //(Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("schmVer"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("ingstdFileNm"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("entprtnfldr"))))
          (Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("schmVer"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("entprtnfldr"))))
        })


        if (lstrundateFlg) {
          Logger.log.info(s" Number of Entries Captured for $entName from EIT SCAN b/w $startTime and $endTime :" + eitVal.count())
        } else {
          Logger.log.info(s" Number of Entries Captured for $entName from EIT SCAN full load :" + eitVal.count())
        }

        if (!eitInfo.isEmpty) {
          Logger.log.info(s" eitInfo: $eitInfo")
          val eitFileList = eitInfo.map(x => (x._1, x._2)).collect.toList.map(x => (s"${raw_path}${entNm}/${x._2}")).distinct
          Logger.log.info(s" eitFileList: $eitFileList")
          //val eitRawFileList = eitFileList.filter(x => filterRawFileExist(x))
          val eitRawFileListNtEmp = eitFileList.filter(x =>
            if(ApplicationConfig.isTriggerJobType.equalsIgnoreCase(DPOConstants.K8S) || ApplicationConfig.isTriggerJobType.equalsIgnoreCase(DPOConstants.KUBERNETES)){
              FileSystemUtil.isNotEmptyDirMaprfs(x)}
          else{
            isDirNotEmpty(x)})
          retList = eitRawFileListNtEmp
          retList.foreach(println)


          Logger.log.info(s" Number of PARQUET Files exist in Raw for $entName from EIT SCAN b/w $startTime and $endTime :" + eitRawFileListNtEmp.length)
          Logger.log.info(s" List of PARQUET Files from Raw : ${eitRawFileListNtEmp.mkString}")
          val eitRdd = globalContext.sparkContext.parallelize(eitRawFileListNtEmp)
          eitRdd.collect.map(x => saveToDataFrameP1("PARQUET", workingDir, x, entName))
          eitVal.unpersist()
          resFlg=true
          /*eitRdd.collect.map(x => saveToDataFrameP1("PARQUET", workingDir, x, entName))
          eitVal.unpersist()

          pitRawRowDelim="NA|"
          pitRawPartnFlr="NA|"
          pitRawFileCnt="NA|"
          resFlg="true"

          //"true;" + entName + "-" + pitRawRowDelim + ";" + entName + "-" + pitRawPartnFlr + ";" + entName + "-" + pitRawFileCnt;


        } else {
          Logger.log.info(s" Since, No Changes Captured for $entName in scanning EIT hbase table/ Hbase EIT File from $startTime to $endTime,No DataSets Generated")
          pitRawRowDelim="ERROR|"
          pitRawPartnFlr="ERROR|"
          pitRawFileCnt="ERROR|"
          resFlg="false"
          //"false;" + entName + "-ERROR|;" + entName + "-ERROR|;" + entName + "-ERROR|";
        }*/

        }
      }  catch {
        case e: Exception => Logger.log.info(s" Exception while Scanning EIT Hbase Table for $entNm" :+ e.getStackTrace.mkString)
          hbasePITEndStage( "Fail", pitRowKey)

          resFlg=false
          //"false;"+entName+"-ERROR|;"+entName+"-ERROR|;"+entName+"-ERROR|";
          throw e
      }



      // retStr=  resFlg+";"+entName+"-"+pitRawRowDelim+";"+entName+"-"+pitRawPartnFlr+";"+entName+"-"+pitRawFileCnt;
      resFlg

      // retStr
      //End for parquet

    }
    catch {
      case e: Exception => Logger.log.info(s" Exception while Scanning Files from DL EIT for $entNm from eitTabScan" :+ e.getStackTrace.mkString)
        //hbasePITEndStage("Fail", pitRowKey)
        throw e
    }

  }





  def saveToDataFrameP1(schmVer : String, workingDir: String, fileList: String, entNm : String)(implicit context: GlobalContext): Unit = {
    var resCnt = "0"
    try {
      Logger.log.info(s" FileList in  saveDFversionTablesParquet for entity $entNm of partition Folder $schmVer is $fileList")

      val fileLstTkn = fileList.split(",").map(x => context.sparkSession.read.parquet(x))
      val df = fileLstTkn.reduce(_.union(_))
      resCnt = df.count().toString
      Logger.log.info(s" count for  entity $entNm of partition folder is " + resCnt)

      df.write.mode(SaveMode.Append).parquet(s"$workingDir/${entNm.toUpperCase()}")
    } catch {
      case e: Exception => Logger.log.info(" Exception at saveDFversionTablesParquet" :+ e.getMessage)
        throw e
    }

  }

































  // def getCommonSnapshotPerEntity(entity: String): DataFrame = ???

  /*def getSnapshotExtractPerEntity(rowKeyConfig: String, entity: String)(implicit context: GlobalContext): Try[String] = {
    val pscTable = context.pscTable
    val plcTable = context.plcTable
    Try {
      Logger.log.info(s" Scanning PSC for rowKeyConfig provided:$rowKeyConfig")
      import com.uhg.optum.protocols.PSCProtocol._
      val psc = pscTable.getWithFilter[PSC](rowKeyConfig, "psc", new CustomFilter("psc", "activeflag", CompareOperations.EQUAL, "Y")) match {
        case Success(instance) =>
          instance match {
            case Some(pscInstance) =>
              pscInstance
            case None =>
              Logger.log.info("Snapshot config(PSC) PrimaryKeys / CDC Timestamp not found, Please Check PSC HTable")
            //hbasePITEndStage(pitTab, "Fail", pitRowKey)
          }
        case Failure(ex) =>
          Failure(new PSCInstanceEmpty(s"Exception while retriving Pk's from Snapshot Config Tab for $rowKeyConfig", ex))
      }
      val plcRowKey = rowKeyConfig.split("-")(0) + "-" + rowKeyConfig.split("-")(1)
      var lastRunDt = "" //TODO: Find a better way to do this
      // Logger.log.info(s" Primary Key Columns for $entity : ${psc.prikeycols.mkString}")
      plcTable.getValueByRowKey(plcRowKey, "plc", "lastRunDt") match {
        case Success(plcColValue) =>
          lastRunDt = plcColValue
          Logger.log.info(s" last run date From PLC : $lastRunDt")
          Success()
        case Failure(ex) =>
          Failure(new ValueNotFound("Exception while fetching the value of lastRunDt from PLC Table ", ex))
      }
      //  val lstrundateFlg = if(lastRunDt.isEmpty) false else if(psc.fullLoadflg.equalsIgnoreCase("Y")) false else true
      //TODO: Log the full load logger based on the value of lstRundateFlag
      //   Logger.log.info(s" last run date Flag : $lstrundateFlg")
      //  val peiFullLoadFlg = if(lstrundateFlg) entity+"-N" else entity+"-Y"
      val peiFullLoadFlg = ""
      //    // Get LakeEIT scanned rowKey entity
      //    var result: Boolean=false
      //result = eitLakeTabScan(snapBuildType,lakeEitTableName, mountPath, lakeEppTableName, workingDir, prtnrCd, srcCd, entity, lstrundateFlg, lstrundate, incEndTs, pitRowKey, pitTab)
      //            val ptnrCd = s"${prtnrCd.toUpperCase()}"
      //            val src = s"${srcCd.toUpperCase()}"
      //            val entName = s"${entity.toUpperCase()}"
      //            Logger.log.info(s" Working Directory path for Incremental extract: $workingDir")
      //
      //            //if LakeEIT scanned rowKey entity is empty then end the workflow with Success Status , else continue to save the raw snapshot merged files into a dataframe as entity name
      //            if (result) {
      //              try {
      //                Logger.log.info(s" Captured Incremental Extract for ${entName}")
      //                Logger.log.info(s" Merging Schema for $entName from $workingDir/$entName")
      //                Logger.log.info(s" checking existence of working directory")
      //                val merDir = workingDir + "/" + entName
      //                mkdirs(merDir)
      //                val mergeDF = sqlContext.read.option("mergeSchema", true).parquet(s"$workingDir/$entName").persist(org.apache.spark.api.java.StorageLevels.MEMORY_AND_DISK_SER)
      //                Logger.log.info(s" Merge Schema Record Count for $entName :" + mergeDF.count)
      //
      //                try {
      //                  snpCfgScan.unpersist()
      //                  val userWindow = Window.partitionBy(concat_ws("-", primaryKeys.map(c => col(c)): _*), lit("")).orderBy(col(s"$modTsCol").desc)
      //                  val dedupDF = mergeDF.withColumn("rank", row_number().over(userWindow)).where(col("rank") === 1 && dmlCol != "D").drop("rank").persist(org.apache.spark.api.java.StorageLevels.MEMORY_AND_DISK_SER)
      //                  val dedupCnt = dedupDF.count()
      //                  Logger.log.info(s"Number of Records Extracted for $entName  with Dedup Logic:" + dedupCnt)
      //                  dedupDF.createOrReplaceTempView(s"${entName}")
      //
      //                  /*Logger.log.info( s" Updating lastRnTs as ${incEndTs} in PSC HTable for EntNm:$entName" )
      //                hbasePSCPut( rowKeyConfig, "psc", "lastRunDt", incEndTs )*/ dedupDF.unpersist()
      //
      //                } catch {
      //                  case e: Exception => {
      //                    Logger.log.info(s">>>>> Exception at Main Loading MergeSchema/SqlStatement for $entName <<<<< : " + e.getMessage)
      //                    Logger.log.error("Error occured : " + e.getStackTrace.mkString("\n"))
      //                  }
      //                    //removing intermediate parquet data
      //                    rmPathIfExist(workingDir + "/" + entName)
      //                    hbasePITEndStage(pitTab, "Fail", pitRowKey)
      //                    throw e
      //                }
      //
      //
      //              } catch {
      //                case e: Exception => {
      //                  Logger.log.info(s">>>>> Exception at Main Loading Merge Parquet Schema/SqlStatement for $entName <<<<< : " + e.getMessage)
      //                  Logger.log.error("Error occured : " + e.getStackTrace.mkString("\n"))
      //                }
      //                  //removing intermediate parquet data
      //                  rmPathIfExist(workingDir + "/" + entName)
      //                  hbasePITEndStage(pitTab, "Fail", pitRowKey)
      //                  throw e
      //              }
      //
      //
      //            } else {
      //              Logger.log.info(s" Since there are No Changes reflected for the $entName in a given time range, hence ending the workflow  ")
      //              hbasePITEndStage(pitTab, "Success", pitRowKey)
      //              Logger.log.info(s" Updating lastRnTs as ${incEndTs} in PLC HTable for EntNm:$entName")
      //              hbasePitPut(plcTab, plcRowKey, "plc", "lastRunDt", incEndTs)
      //              // hbasePSCPut(snapConfigTab, rowKeyConfig, "psc", "lastRunDt", incEndTs)
      //
      //            }
      //          }

      //          catch {
      //            case e: Exception => {
      //              Logger.log.info(" Exception at DataLake Snapshot Scan , Failed due to : " + e.getMessage)
      //              Logger.log.error("Error occured : " + e.getStackTrace.mkString("\n"))
      //            }
      //              hbasePITEndStage(pitTab, "Fail", pitRowKey)
      //              throw e
      //
      //          }
      peiFullLoadFlg
    }
  }*/
}