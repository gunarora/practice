package com.uhg.optum.provider.extractors

import com.uhg.optum.common.DPOConstants
import com.uhg.optum.conf.ApplicationConfig.{datafilesDir, workingDir}
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDERK4InputJsonSchema.SegmentDetails
import com.uhg.optum.util.{CommonUtil, EPDECommonUtil, FileSystemUtil, Logger}

trait EPDERK4_LGS_SegExt {


  def lgsSegGen(segDetails: SegmentDetails, outputFilePath: String, glblVarLst: collection.mutable.Map[String, String])(implicit context: GlobalContext): String = {
try{
    var df=context.sqlContext.emptyDataFrame
    var resStr = "N"
    EPDECommonUtil.generateSegTables(segDetails.segTables, glblVarLst)
    segDetails.segQueries.map { qryKey =>
      Logger.log.info("qryKey.name --> " + qryKey.name)
      if (qryKey.name.matches("LGS_FNL_VIEW")) {
        df = CommonUtil.executeQry(glblVarLst, qryKey)
        CommonUtil.createOrReplaceTempViewFn(df, qryKey.name)
        //if (df.count > 0) {
          //RPAD QUERY -> result -> write df res in file
          /*        val pspDf = CommonUtil.generateRpadQry(segDtls.segTarCol, segDtls.segTarLen, segDtls.segTolLen, qryKey.name)
                generateOpFile(pspDf, outputFilePath, segDtls.segSeq)*/

          //datafilesDir+"/"+glblVarLst("${WS_VENDR_CD}")+"/"+glblVarLst("provTypCd")+"/"
          FileSystemUtil.saveFileToMapRFSNoRepartitionParquet(df, outputFilePath, qryKey.name, "", DPOConstants.PARQUET)
          resStr = "Y"
        //}
      }
      else {
        df = CommonUtil.executeQry(glblVarLst, qryKey)
        CommonUtil.createOrReplaceTempViewFn(df, qryKey.name)
      //  FileSystemUtil.saveFileToMapRFS(df,glblVarLst.get("tmpVwPath").getOrElse(workingDir),qryKey.name,"",DPOConstants.PARQUET)
      }
    }
    resStr
}catch {

  case e: Exception => {
    Logger.log.info(s"RK4 : EPDERK4_LGS_SegExt.genLGSSeg() : "+e.getMessage)
    throw e
  }

}
  }
}
