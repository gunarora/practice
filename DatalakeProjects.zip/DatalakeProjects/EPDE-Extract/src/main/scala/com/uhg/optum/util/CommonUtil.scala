package com.uhg.optum.util
import org.apache.hadoop.hbase.client.{Get, HTable, Result, _}
import java.io.{BufferedReader, File, FileOutputStream, FileReader}
import java.util.{Calendar, Date, Properties, TimeZone}
import java.text.SimpleDateFormat
import java.time.format.DateTimeFormatter
import java.time._

import com.uhg.optum.common.DPOConstants._
import com.uhg.optum.JobRunner.{DPOException, PEI}
import com.uhg.optum.common.DPOConstants
import com.uhg.optum.common.DPOConstants.HEADER_VIEW
import com.uhg.optum.executors.GlobalContext
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.sql.{DataFrame, Row, SaveMode}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{col, concat_ws, lit, row_number}
import com.uhg.optum.protocols.EPDERK4InputJsonSchema.{ExtractFileEntity, Query}
import org.apache.hadoop.hbase.{CellUtil, TableName}
import org.apache.hadoop.hbase.client.{HTable, Scan}
import org.apache.hadoop.hbase.filter.CompareFilter.CompareOp
import org.apache.hadoop.hbase.filter._
import org.apache.hadoop.hbase.util.Bytes
import org.apache.spark.{SparkContext, sql}
import org.apache.spark.sql.types.{StringType, StructField, StructType}

import scala.collection.mutable.ListBuffer
import scala.io.Source
import scala.util.{Failure, Success, Try}
import java.time.format.DateTimeFormatter

import com.uhg.optum.conf.ApplicationConfig
import com.uhg.optum.conf.ApplicationConfig.{snapshotDir, workingDir}
import com.uhg.optum.util.exceptions.{InsufficientArgsException, QueryFailureException}
import org.apache.spark
/**
  * Created by paror18 on 9/11/2018.
  */
object CommonUtil {

  def createParquetFromMap(dfsMap:scala.collection.mutable.Map[String,DataFrame], outLoc : String)(implicit context : GlobalContext): Try[Unit] ={
    Logger.log.info("---------Inside createParquetFromMap----")
    Try {
      if (dfsMap.isEmpty || dfsMap == null) {
        Logger.log.info("No info for the parquet files to be created present")
      }

      if(outLoc.isEmpty || outLoc == "" || outLoc == null){
        Logger.log.info("No info for the outLoc present")
      }

      for ((k, v) <- dfsMap) {
        var outType = k.split("_")(0)
        var outfilePath = outLoc + DPOConstants.SLASH + outType.toUpperCase
        mkdirs(outfilePath)
        Logger.log.info(s"INFO: the outfilelocation is $outfilePath")
        var outFileNm = k.split("_")(1)
        FileSystemUtil.saveFileToMapRFSNoRepartitionParquet(v, outfilePath, outFileNm, "", DPOConstants.PARQUET)
        //   v.repartition(1).write.mode(SaveMode.Append).format("parquet").save(outLoc + DPOConstants.SLASH + k)
      }
    }
  }

  def saveAsParquetFn(dirPath: String,fldrNm: String,rePartNm:Int,saveDf:DataFrame)(implicit context: GlobalContext): Unit = {
    var parPath=s"$dirPath/${fldrNm.toUpperCase()}"
    mkdirs(parPath)
    //df.write.mode(SaveMode.Append).parquet(s"$workingDir/${entNm.toUpperCase()}")
    //saveDf.repartition(rePartNm).write.mode(SaveMode.Overwrite).parquet(s"$parPath/txtTry.txt")
    saveDf.repartition(rePartNm).write.mode("overwrite").format("parquet").save(s"$parPath")
  }

  /*  def occursCreation_Shell(occurStmnt: String,occursCnt: Int,occrsNm:String,SchemaNm:String,whrClause:String,tblNm:String): org.apache.spark.sql.Dataset[org.apache.spark.sql.Row] = {
    println("occurStmnt-- > "+occurStmnt )
    var occurSelDecode ,occurSelRnum,occurSelPrt1,occurSelPrt2,occurFnlQry,selClauseRnum= ""
    var selCol,selOrig,selAlias=Array[String]()
    var prtClause,occurGrpPrt3=""
    // <selClause>~<selPrtClause>~<orderByClause>~<tblNm>~<whrClause>
    var selClause = occurStmnt.split("~")(0)
    if (selClause.trim.equals("")) {
      println("No select clause ")
      selClause=""
      prtClause = "1"
    } else {
      selCol = selClause.split(",")
      selOrig = selCol.map(x => x.split("AS")(0).trim)
      selAlias = selCol.map(x => x.split("AS")(1).trim)
      prtClause = selOrig.mkString(",")
      selClause = selClause + ","
    }
    println("selClause -->" + selClause)
    println("prtClause -->" + prtClause)
    occurGrpPrt3 = selAlias.mkString(",")
    println("occurGrpPrt3 -->" + occurGrpPrt3)
    if (occurGrpPrt3.isEmpty) {
      occurGrpPrt3 = ""
    } else {
      selClauseRnum = occurGrpPrt3 + ","
      occurGrpPrt3 = "GROUP BY " + occurGrpPrt3
    }
    var selPrtClause = occurStmnt.split("~")(1)
    println("selPrtClause -->" + selPrtClause)
    var selPrtCol = selPrtClause.split(",")
    var occurPrtSel = selPrtCol.map(x => x.split(" AS ")(1).trim)
    var orderByClause = occurStmnt.split("~")(2)
    println("orderByClause -->" + orderByClause)
    var whrClauseTmp = whrClause
    if (whrClauseTmp.trim.equals("")) {
      println("No WHERE clause ")
    } else {
      whrClauseTmp = "WHERE " + whrClauseTmp
    }
    var rnumCreate = s"SELECT ${selClause} ${selPrtClause} , ROW_NUMBER() OVER (PARTITION BY ${prtClause} ORDER BY ${orderByClause} ) AS RNUM FROM ${tblNm}  ${whrClauseTmp} "
    println("rnumCreate --> " + rnumCreate)
    var rnumCreateDF = spark.sqlContext.emptyDataFrame
    rnumCreateDF = spark.sqlContext.sql(s"${rnumCreate}")
    var tblNmRnum = "RNumTbl"
    rnumCreateDF.show()
    rnumCreateDF.createOrReplaceTempView(tblNmRnum)
    for (i <- 1 to occursCnt) {
      for (selPrt <- occurPrtSel) {
        val selPrtTrim = selPrt.trim()
        occurSelDecode = occurSelDecode + s"MAX(decode(encode(COALESCE(${selPrtTrim}_${i},''), 'utf-8') , 'utf-8')) AS ${selPrtTrim}_${i} ,"
        occurSelRnum = occurSelRnum + s"CASE WHEN RNUM=${i} THEN COALESCE(${selPrtTrim},'') END AS ${selPrtTrim}_${i} ,"
      }
      occurSelPrt1 = s" SELECT ${selClauseRnum} ${occurSelDecode.dropRight(1)} FROM "
      occurSelPrt2 = s" (SELECT ${selClauseRnum} ${occurSelRnum.dropRight(1)} FROM ${tblNmRnum})"
      println(s"${i}--> " + occurSelPrt1)
      println(s"${i} -->" + occurSelPrt2)
      /*occurSelPrt1 =s" SELECT  ${occurSelDecode.dropRight(1)} FROM "
    occurSelPrt2 =s" (SELECT ${occurSelRnum.dropRight(1)} FROM ${tblNmRnum})"*/
      //Logger.log.info(occurSelPrt1)
      //Logger.log.info(occurSelPrt2)
    }
    println("occurSelPrt1 --> "+occurSelPrt1)
    println("occurSelPrt2 --> "+occurSelPrt2)
    if (occurGrpPrt3.equals("")) {
      occurFnlQry = occurSelPrt1 + occurSelPrt2
    } else {
      occurFnlQry = occurSelPrt1 + occurSelPrt2 + occurGrpPrt3
    }
    println("occurFnlQry --> "+occurFnlQry)

    //var occurFnlQryDF = spark.sqlContext.emptyDataFrame
    var occurFnlQryDF = spark.sqlContext.sql(s"$occurFnlQry")
    occurFnlQryDF.show()
    occurFnlQryDF
  }*/

  /** Purpose : Def to handle occurs statement where in count is passed as input
    * input : occurStmnt;occursCnt;occrsNm;WS_SQL_PROV_ID;SchemaNm
    * output: DF should be created with Occurs logic*/
  def occursCreation(occurStmnt: String,occursCnt: Int,occrsNm:String,SchemaNm:String,whrClause:String,tblNm:String)(implicit context: GlobalContext): DataFrame = {
    Logger.log.info("INFO : Inside occursCreation() for "+occrsNm)
    var occurSelDecode ,occurSelRnum,occurSelPrt1,occurSelPrt2,occurFnlQry,selClauseRnum= ""
    var selCol,selOrig,selAlias=Array[String]()
    var prtClause,occurGrpPrt3=""
    // <selClause>~<selPrtClause>~<orderByClause>~<tblNm>~<whrClause>

    var selClause= occurStmnt.split("~")(0)
    Logger.log.info("INFO : Inside occursCreation() selClause -->" + selClause)
    if (selClause.trim.equals("")) {
      Logger.log.info("INFO : No select clause ")
      selClause=""
      prtClause = "1"
    } else {
      selCol = selClause.split(",")
      selOrig = selCol.map(x => x.split("AS")(0).trim)
      selAlias = selCol.map(x => x.split("AS")(1).trim)
      prtClause = selOrig.mkString(",")
      selClause = selClause + ","
      occurGrpPrt3=selAlias.mkString(",")
    }


    /*selCol=selClause.split(",")
    selOrig=selCol.map(x=> x.split("AS")(0).trim)
    selAlias=selCol.map(x=> x.split("AS")(1).trim)

    prtClause=selOrig.mkString(",")*/


    if(occurGrpPrt3.isEmpty) {
      occurGrpPrt3=""
    }else{
      selClauseRnum=occurGrpPrt3+","
      occurGrpPrt3=" GROUP BY "+occurGrpPrt3
    }
    Logger.log.info("INFO : Inside occursCreation() occurGrpPrt3 -->" + occurGrpPrt3)

    var selPrtClause= occurStmnt.split("~")(1)
    Logger.log.info("INFO : Inside occursCreation() selPrtClause -->" + selPrtClause)

    var selPrtCol=selPrtClause.split(",")
    var occurPrtSel =selPrtCol.map(x=> x.split(" AS ")(1).trim)


    var orderByClause= occurStmnt.split("~")(2)
    Logger.log.info("INFO : Inside occursCreation() orderByClause -->" + orderByClause)

    var whrClauseTmp=whrClause
    Logger.log.info("INFO : Inside occursCreation() whrClauseTmp -->" + whrClauseTmp)

    if (whrClauseTmp.trim.equals("")){
      Logger.log.info("INFO :No WHERE clause ")
    } else{
      whrClauseTmp="WHERE "+whrClauseTmp
    }

    var rnumCreate=s"SELECT ${selClause} ${selPrtClause} , ROW_NUMBER() OVER (PARTITION BY ${prtClause} ORDER BY ${orderByClause} ) AS RNUM FROM ${tblNm}  ${whrClauseTmp} "
    Logger.log.info("INFO : Inside occursCreation(), RNUM creation Query --> "+rnumCreate)
    var rnumCreateDF = context.sqlContext.emptyDataFrame
    rnumCreateDF= context.sqlContext.sql(s"$rnumCreate")
    var tblNmRnum="RNumTbl"
    createOrReplaceTempViewFn(rnumCreateDF,tblNmRnum)

    for (i <- 1 to occursCnt){

      for(selPrt <- occurPrtSel){
        val selPrtTrim=selPrt.trim()
        occurSelDecode=occurSelDecode+s"MAX(decode(encode(COALESCE(${selPrtTrim}_${i},''), 'utf-8') , 'utf-8')) AS ${selPrtTrim}_${i} ,"
        occurSelRnum=occurSelRnum+s"CASE WHEN RNUM=${i} THEN COALESCE(${selPrtTrim},'') END AS ${selPrtTrim}_${i} ,"
      }
      occurSelPrt1 =s" SELECT ${selClauseRnum} ${occurSelDecode.dropRight(1)} FROM "
      occurSelPrt2 =s" (SELECT ${selClauseRnum} ${occurSelRnum.dropRight(1)} FROM ${tblNmRnum})"
      /*occurSelPrt1 =s" SELECT  ${occurSelDecode.dropRight(1)} FROM "
      occurSelPrt2 =s" (SELECT ${occurSelRnum.dropRight(1)} FROM ${tblNmRnum})"*/
      //Logger.log.info(occurSelPrt1)
      //Logger.log.info(occurSelPrt2)
    }
    //Logger.log.info("Inside occursCreation(), first part of OCCURS --> "+occurSelPrt1)
    //Logger.log.info("Inside occursCreation(),second part of OCCURS --> "+occurSelPrt2)

    //if (selClause.trim.equals("")){println("No select clause ") }else{ occurGrpPrt3=" GROUP BY "+selClause }

    if (occurGrpPrt3.equals("")) {
      occurFnlQry = occurSelPrt1+ occurSelPrt2
    } else{
      occurFnlQry = occurSelPrt1+ occurSelPrt2+occurGrpPrt3
    }

    //Logger.log.info(" INFO :Inside occursCreation(), Final OCCURS Query --> "+occurFnlQry)

    var occurFnlQryDF = context.sqlContext.emptyDataFrame
    occurFnlQryDF= context.sqlContext.sql(s"$occurFnlQry")
    //createOrReplaceTempViewFn(occurFnlQryDF,occrsNm)
    occurFnlQryDF
  }
  /*
    def amaSpecTblLoop_Shell(AMA_SPEC_TABLE_Cnt:Int):String= {
      var skipPrvLst = "'"
      //var skipPrv= scala.collection.mutable.Set[String]()

      for (i <- 1 to AMA_SPEC_TABLE_Cnt) {
        var df_ama_17 = spark.sqlContext.emptyDataFrame
        var df_ama_18 = spark.sqlContext.emptyDataFrame
        // var AMA_SPEC_ENTRY_qry = s"SELECT 'Y' AS DONE_SW FROM AMA_SPEC_TABLE AMA,PRV_10_PSP PSP WHERE AMA.AS_SPCL_TYP_${i} = PSP.PSP_SPCL_TYP_CD AND ( AMA.AS_PROV_TYP_${i} = WS_PROV_TYP_CD_1 OR AMA.AS_PROV_TYP_${i} = WS_PROV_TYP_CD_2)"
        var AMA_SPEC_ENTRY_qry_17 = s"SELECT PSP.PRO_PROV_ID as PRO_PROV_ID FROM AMA_SPEC_TABLE AMA inner join PRV_17_DVC_DTL PSP ON AMA.AS_SPCL_TYP_${i} = PSP.PSP_SPCL_TYP_CD "
        println("AMA_SPEC_ENTRY_qry_17 --> "+AMA_SPEC_ENTRY_qry_17)
        var AMA_SPEC_ENTRY_qry_18 = s"SELECT PSP.PRO_PROV_ID as PRO_PROV_ID FROM AMA_SPEC_TABLE AMA INNER JOIN PRV_18_DVC_DTL PSP ON AMA.AS_SPCL_TYP_${i} = PSP.PSP_SPCL_TYP_CD"
        println("AMA_SPEC_ENTRY_qry_18 --> "+AMA_SPEC_ENTRY_qry_18)
        df_ama_17 = spark.sqlContext.sql(s"$AMA_SPEC_ENTRY_qry_17")
        var cnt17=df_ama_17.count
        println(" 17th count for "+i+" is "+cnt17)
        df_ama_18 = spark.sqlContext.sql(s"$AMA_SPEC_ENTRY_qry_18")
        var cnt18=df_ama_18.count
        println(" 18th count for "+i+" is "+cnt18)
        /*if(cnt17>0) {
          df_ama_17.collect.map(x => skipPrv += x.toString())
        }
        if(cnt18>0) {
          df_ama_18.collect.map(x => skipPrv += x.toString())
        }*/

        skipPrvLst += df_ama_17.collect.map(x => x.mkString("")).mkString("','")

        skipPrvLst += df_ama_18.collect.map(x => x.mkString("")).mkString("','")

        if(skipPrvLst.equals("'")) {
          skipPrvLst=""
          }
        else{
          skipPrvLst+="'"
        }
      }
      println("final skip list --> "+skipPrvLst)
      skipPrvLst
    }*/

  /** Purpose : Def to handle 5010-SPEC-EXCLUSIONS and 5000-SPEC-EXCLUSIONS based on AMA_SPEC_TABLE_Cnt retrived in RK4 Start
    * input :  AMA_SPEC_TABLE_Cnt retrived in RK4 Start
    * output: String containing list of prov_ids to be skipped*/

  def amaSpecTblLoop(AMA_SPEC_TABLE_Cnt:Int)(implicit context: GlobalContext):String= {
    var skipPrvLst = "'"
    Logger.log.info("INFO: INSIDE amaSpecTblLoop, AMA_SPEC_TABLE_Cnt IS "+AMA_SPEC_TABLE_Cnt)
    //  var skipPrv= scala.collection.mutable.Set[String]()

    for (i <- 1 to AMA_SPEC_TABLE_Cnt) {
      var df_ama_17 = context.sqlContext.emptyDataFrame
      var df_ama_18 = context.sqlContext.emptyDataFrame
      // var AMA_SPEC_ENTRY_qry = s"SELECT 'Y' AS DONE_SW FROM AMA_SPEC_TABLE AMA,PRV_10_PSP PSP WHERE AMA.AS_SPCL_TYP_${i} = PSP.PSP_SPCL_TYP_CD AND ( AMA.AS_PROV_TYP_${i} = WS_PROV_TYP_CD_1 OR AMA.AS_PROV_TYP_${i} = WS_PROV_TYP_CD_2)"
      var AMA_SPEC_ENTRY_qry_17 = s"SELECT PSP.PRO_PROV_ID as PRO_PROV_ID FROM AMA_SPEC_TABLE AMA INNER JOIN PSP_17_DVC_DTL PSP ON AMA.AS_SPCL_TYP_${i} = PSP.PSP_SPCL_TYP_CD WHERE ( AMA.AS_PROV_TYP_${i} = PSP.WS_PROV_TYP_CD_1 OR AMA.AS_PROV_TYP_${i} = PSP.WS_PROV_TYP_CD_2)"
      var AMA_SPEC_ENTRY_qry_18 = s"SELECT PSP.PRO_PROV_ID as PRO_PROV_ID FROM AMA_SPEC_TABLE AMA INNER JOIN PSP_18_DVC_DTL PSP ON AMA.AS_SPCL_TYP_${i} = PSP.PSP_SPCL_TYP_CD WHERE ( AMA.AS_PROV_TYP_${i} = PSP.WS_PROV_TYP_CD_1 OR AMA.AS_PROV_TYP_${i} = PSP.WS_PROV_TYP_CD_2)"
      Logger.log.info(s"INFO: INSIDE amaSpecTblLoop,$AMA_SPEC_ENTRY_qry_17")

      df_ama_17 = context.sqlContext.sql(s"$AMA_SPEC_ENTRY_qry_17")
      Logger.log.info(s"INFO: INSIDE amaSpecTblLoop,$AMA_SPEC_ENTRY_qry_18")
      df_ama_18 = context.sqlContext.sql(s"$AMA_SPEC_ENTRY_qry_18")
      /*df_ama_17.collect.map(x=> skipPrv+=x.toString())
      df_ama_18.collect.map(x=> skipPrv+=x.toString())*/
      skipPrvLst += df_ama_17.collect.map(x => x.mkString("")).mkString("','")

      skipPrvLst += df_ama_18.collect.map(x => x.mkString("")).mkString("','")

      //:TODO  duplicacy removal
      // true means no prov_ids to be skipped found
      /*      if(skipPrvLst.equals("'")) {
              skipPrvLst=""
            }
            else{
              skipPrvLst+="'"
            }*/
      skipPrvLst+="'"
      /* var df_amaJoin = context.sqlContext.emptyDataFrame
       var AMA_SPEC_ENTRY_qry= s"SELECT PSP.PRO_PROV_ID as PRO_PROV_ID,'SKIP' AS SKPFLG FROM AMA_SPEC_TABLE AMA,${joinTBL} PSP WHERE AMA.AS_SPCL_TYP_${i} = PSP.PSP_SPCL_TYP_CD AND ( AMA.AS_PROV_TYP_${i} = PSP.WS_PROV_TYP_CD_1 OR AMA.AS_PROV_TYP_${i} = PSP.WS_PROV_TYP_CD_2)"
       df_amaJoin = context.sqlContext.sql(s"AMA_SPEC_ENTRY_qry")
       createOrReplaceTempViewFn(df_amaJoin,tblNm)
 */
    }
    Logger.log.info("INFO:Final AMASPECLOOP list "+skipPrvLst)
    skipPrvLst
  }

  /** Purpose : Def to create temp view
    * input : dataframe to e registered, tempview name
    * output: the data frame will be registered with the given tempview name*/
  def createOrReplaceTempViewFn(df:DataFrame,tblNm:String)(implicit context: GlobalContext) = {
    try {
      if (tblNm == null || tblNm.isEmpty) {
        Logger.log.info("in if condition of the createOrReplaceTempViewFn")
        throw new InsufficientArgsException("Cannot execute createOrReplaceTempView as table name is empty or NULL")
      }
      // Logger.log.info(s"the Count for ${tblNm} is " + df.count())
      df.createOrReplaceTempView(tblNm)
      Logger.log.info("df registered...")
    } catch {
      case c : InsufficientArgsException => {
        Logger.log.info("RK4 :  CommonUtil.createOrReplaceTempViewFn() " + c.getMessage)
        throw c
      }
      case e: Exception => {
        Logger.log.info("RK4 : CommonUtil.createOrReplaceTempViewFn() " + e.getMessage)
        throw e
      }
    }
  }

  /** Purpose : Def to replace the variables in the query, check the Query and execute it
    * input : varlist (in form of key-value pair mutable map), qryKey containing the name and the query
    * output: the data frame will be registered with the given tempview name*/
  def executeQry(prmVarLst:collection.mutable.Map[String, String],qryKey:Query)(implicit context: GlobalContext):sql.DataFrame = {
    var df = context.sqlContext.emptyDataFrame
    try {
      var qryStr=qryKey.query
      if (qryStr == null || qryStr.isEmpty || !qryStr.trim.toUpperCase.startsWith("SELECT")) {
        Logger.log.info(s"INFO :in if condition of the executeQry; query.Exception thrown --> "+qryKey.query)
        throw new QueryFailureException("ERROR : Cannot make DF as Query is empty or NULL or does not start with select "+qryKey.name)
      }else {

        if (prmVarLst.isEmpty) {
          Logger.log.info(s"INFO :variable replace list is empty")
        }else {
          for ((k, v) <- prmVarLst) {
            Logger.log.info(s"INFO : the key ${k}  and Value ${v} will be replaced for  ${qryKey.name}")
            qryStr = qryStr.replace(k, v)
          }
        }
        //val qryStr=qryKey.query.replace("${SchemaNm}",SchemaNm).replace("${WS_SQL_PROV_ID}",WS_SQL_PROV_ID)
        Logger.log.info(s"INFO: the Query for ${qryKey.name} is $qryStr")
        df = context.sparkSession.sql(s"$qryStr")
        df.persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)
      }
    }catch {
      case c : QueryFailureException => {
        Logger.log.info("RK4 :  CommonUtil.executeQry() " + c.getMessage)
        throw c
      }
      case e: Exception => {
        Logger.log.info("RK4 : CommonUtil.executeQry() " + e.getMessage)

        throw e
      }
    }
    df
  }

  /** Purpose : Def to add key value pair to the input mutable map.
    * input : mutable map, Key, value
    * output: Key Value pair are added to the inputed map*/

  def add2Map(mapVar:scala.collection.mutable.Map[String,String],k:String,v:String):Unit={
    //Logger.log.info("INFO : adding key "+k+" and  value "+v+" to a mutable map ")
    mapVar+=(k->v)
  }

  /** Purpose : Def to get current Date time in given format as per ET TimesZone
    * input : datetime Format USA ="MM/dd/YYYY hh:mm a" and ISO = "yyyy-MM-dd HH:mm:ss"
    * output: Datetime in imput  format*/

  def getDateTimeFormatET(dateFormat:String):String={
    try {
      /*val timestampFormat = new SimpleDateFormat(dateFormat)
      timestampFormat.setTimeZone(TimeZone.getTimeZone("ET"))

      timestampFormat.format(Calendar.getInstance().getTime)*/

      val defaultZoneId: ZoneId = ZoneId.systemDefault
      //System.out.println(defaultZoneId)

      Logger.log.info("Deafult Syetem ZoneId"+defaultZoneId)

      val etZoneId: ZoneId = ZoneId.of("America/New_York") // ET TimeZone

      //val globalFormat: DateTimeFormatter = DateTimeFormatter.ofPattern("MM/dd/yyyy 'at' hh:mma z")

      val etFormat: DateTimeFormatter = DateTimeFormatter.ofPattern(dateFormat)

      val currentDateTime = LocalDateTime.now

      val currentDefaultTime = currentDateTime.atZone(defaultZoneId)
      // System.out.println(currentDefaultTime)
      Logger.log.info("tranformed Current  Date Time"+ currentDefaultTime)

      val currentETime = currentDefaultTime.withZoneSameInstant(etZoneId) //ET Time
      ///System.out.println(globalFormat.format(currentISTime))

      val resDT=etFormat.format(currentETime)
      //System.out.println(resDT)
      Logger.log.info("tranformed ET Date Time "+resDT)
      resDT

    }  catch {
      case e: Exception => Logger.log.info(" Exception while getting current date/time in getDateTimeFormatET" :+ e.getMessage)
        "0"
    }

  }
  /** Purpose : Def to get given Date time in given format
    * input : datetime Format USA ="MM/dd/YYYY hh:mm a" and ISO =
    * output: Datetime in input  format*/

  def getDateTimeFormat(dateString:String,ipDateFormat:String,opDateFormat:String):String={
    try {
      val opDtFormat = new SimpleDateFormat(opDateFormat)
      val ipDtFormat = new SimpleDateFormat(ipDateFormat)
      opDtFormat.setTimeZone(TimeZone.getTimeZone("ET"))
      val convDate = ipDtFormat.parse(ipDtFormat.format(ipDtFormat.parse(dateString)))
      opDtFormat.format(convDate)

    }  catch {
      case e: Exception => Logger.log.info(" Exception while getting current date/time in getDateTimeFormat" :+ e.getMessage)
        "0"
    }

  }




  def getCommonSnapshotPerEntity(entity: String)(implicit context: GlobalContext): String = {
    println("CommonUtil: in getCommonSnapshotPerEntity ==========")
    if(entity.trim.equalsIgnoreCase(""))
    {Logger.log.info("INFO: entity name is empty")}
    else{
      Logger.log.info("CommonUtil: Directory to read Parquet file--"+workingDir + "/"+snapshotDir+"/" + entity)
      val entityDF = context.sqlContext.read.parquet(workingDir + "/"+snapshotDir+"/" + entity)
      //Logger.log.info(entity + s" count from common snapshot: " + entityDF.count())
      entityDF.createOrReplaceTempView(s"${entity}")
    }

    "Y"
  }
  /*private var fsConf = new Configuration()
  private var fileSystem = FileSystem.get(fsConf)*/

  def createCommonSnapshot(inputScoSegElement: String)(implicit context: GlobalContext): Unit = {
    println("............Inside createCommonSnapshot().............")


    //check feed name, here using -> "MCAD_Reporting-TOPS"
    val feedNm = "MCAD_Reporting"
    val snapBuildType = readFeedBasedProperties("common_snapshot", feedNm, s"COMMON_SNAP_BUILD_TYPE", "conf/dev")
    println(snapBuildType)
    val entityArr: Array[String] = inputScoSegElement.mkString("").split('|')
    println("pkeys--" + entityArr(3).trim)
    val prtnrCd = entityArr(0).trim
    val srcCd = entityArr(1).trim
    val ent = entityArr(2).trim
    val pKeys = entityArr(3).trim
    val env = "conf/dev"

    val lakeEppTableName = readProperties(s"lakeEppTableName", env)
    val lakeEitTableName = readProperties(s"lakeEitTableName", env)
    val mountPath = readProperties(s"mountPath", env)
    val workingDir = readProperties(s"workingDir", env)
    val dmlCol = readFeedBasedProperties("common_snapshot", feedNm, s"DML_COL", env)
    val modTsCol = readFeedBasedProperties("common_snapshot", feedNm, s"MOD_TS_COL", env)
    getSnapshotCommonPerEntity(snapBuildType, pKeys, lakeEitTableName, mountPath, workingDir, lakeEppTableName, ent, prtnrCd, srcCd, dmlCol, modTsCol)
  }
  /*added to check directory is empty or not */
  def isNotEmptyDir(filePath: String)(implicit context: GlobalContext): Boolean = {
    var resFlg=false
    val filePathT=filePath.replace("maprfs://","/mapr/")
    var file= new File(filePathT)
    /*if(file.isDirectory()){*/


    if (context.fs.exists(new Path(s"$filePath"))){
      if(file.list().length>0){
        Logger.log.info(s" Directory is not empty! " +filePathT);
        resFlg=true
      }else{
        resFlg=false
        Logger.log.info(s" Directory is  empty! " +filePathT);
      }
    }else
    {
      resFlg=false
      Logger.log.info(s" Directory path not present! " +filePathT);

    }
    /*}else{
      resFlg=false
      Logger.log.info(s" Not a Directory  " +filePathT);
    }*/
    resFlg}




  def readProperties(input: String, enviParam: String): String = {
    val prop = new Properties()
    val path = "/prov_" + enviParam + ".properties"
    val in = this.getClass.getResourceAsStream(path)
    prop.load(in)
    val value = prop.getProperty(s"$input")
    // println( value )
    value
  }

  def readFeedBasedProperties(dirNm: String, feedName: String, input: String, envParam: String): String = {
    val prop = new Properties()
    val path = "/" + dirNm + "/" + feedName + "_" + envParam + ".properties"
    val in = this.getClass.getResourceAsStream(path)
    prop.load(in)
    val value = prop.getProperty(s"$input")
    value
  }
  // added for Datalake parquet files handling - STARTS- 27/5/2018 - vshrest1 //
  /** Purpose : Def to parquet fileList into spark dataframe with parquet file format version wise
    * input : schemaVersion(s), workingDir, filesList, entityName
    * output: DF should be created and saves resultant versions in the form of parquet */

  def saveToDataFrameP(schmVer: String,workingDir: String,fileList: String, entNm: String)(implicit context: GlobalContext): Unit = {
    var resCnt="0"
    try {
      Logger.log.info(s" FileList in  saveDFversionTablesParquet for entity $entNm of partition Folder $schmVer is $fileList" )

      val fileLstTkn=fileList.split(",").map(x=>context.sparkSession.read.parquet(x))
      val df = fileLstTkn.reduce(_.union(_))
      resCnt=df.count().toString
      Logger.log.info(s" count for  entity $entNm of partition folder is "+resCnt )

      df.write.mode(SaveMode.Append).parquet(s"$workingDir/${entNm.toUpperCase()}")
    } catch {
      case e: Exception => Logger.log.info(" Exception at saveDFversionTablesParquet" :+ e.getMessage)
        throw e
    }

  }
  /** Purpose : Def to check  hadoop file path
    * input : hadoopFilePath
    * output: Returns Boolean value as 0 if the file is exists else 1 for not exists */
  def filterRawFileExist (filePath: String)(implicit context: GlobalContext): Boolean = {
    context.fs.exists(new Path(s"$filePath"))
  }

  /** Purpose : Def to get the schema versions from Datalake EPP htable
    * input : LakeEPP RowKey i.e sourceCode, partnerCode, entityName
    * output: Returns LakeEPP RowKey respective Schemaversions RDD */
  def getEppLakeTabSchma (eppTab: String, patnrCd: String, srcCd: String, entNm: String)(implicit context: GlobalContext): org.apache.spark.rdd.RDD[(String, String)] = {
    try {
      //val eppTableName = "/datalake/uhclake/prd/p_mtables/entity_partner_profile"
      //   val eppTab = globalContext.lakeEppTableName
      Logger.log.info(s" Scanning EPP HBase Table $eppTab for Entity: $entNm")
      val rdd = context.sparkContext.parallelize(Array(Bytes.toBytes(s"${patnrCd}-${srcCd}-${entNm}")))
      val getRdd = context.hbaseContext.bulkGet[Array[Byte], List[(String, String)]](TableName.valueOf(eppTab), 2, rdd, record => {
        val get = new Get(record)
        get.setMaxVersions(99)
      }, (result: Result) => {
        val it = result.listCells().iterator()
        var schver = new ListBuffer[String]()
        var schm = new ListBuffer[String]()
        while (it.hasNext) {
          val cell = it.next()
          val q = Bytes.toString(CellUtil.cloneQualifier(cell))
          if (q.equals("schmVer")) schver += Bytes.toString(CellUtil.cloneValue(cell)) else if (q.equals("schm")) schm += Bytes.toString(CellUtil.cloneValue(cell))
        }
        (schver zip schm).toList
      })
      getRdd.flatMap(x => x)
    } catch {
      case e: Exception => Logger.log.info(" Exception at saveDFversionTables" :+ e.getMessage)
        throw e
    }
  }


  /** Purpose : Def to read from the  DataLake EIT file data based on entity name
    * input : Lake EIT RowKey i.e. partnerCode, sourceCode, entityName , lastRunDateFlag, incrementalStartTime,incrementalEndTime, application PIT rowKey
    * output: Returns boolean value, if Lake EIT RowKey respective data found then 0 else 1 */
  def eitLakeTabScanMod (EXTRACT_EIT_FLG:String,snapBuildType:String,eitTable: String, mountPath: String, eppTable: String, workingDir: String, patnrCd: String, srcCd: String, entNm: String, lstrundateFlg: Boolean, incStTime: String, incEndTs: String, pitRowKey: String)(implicit context: GlobalContext): String = {
    try {
      Logger.log.info(s"INSIDE eitLakeTabScanMod def ")
      //val eitTable = globalContext.lakeEitTableName
      val ptnr = s"${patnrCd}".toUpperCase
      val src = s"${srcCd}".toUpperCase
      //val mountPath = globalContext.mountPath
      val raw_path = s"maprfs://$mountPath/${ptnr.toLowerCase}/raw/standard_access/${src.toLowerCase}/data/"
      val entName = s"${entNm}".toUpperCase
      Logger.log.info(s" Retrieving Files for $entName from Raw: $raw_path")
      Logger.log.info(s" Processing Entity:${entName} with patnrCd:${ptnr} srcCd:${src}")
      var startTime = ""
      if (incStTime.isEmpty) {
        Logger.log.info(s" Incremental start time($incStTime) is empty , so overriding startTime with incEndTm to  $incEndTs")
        startTime = s"$incEndTs"
      } else {
        Logger.log.info(s" Incremental start time($incStTime) is not empty , so overriding startTime with incStTime  $incEndTs")
        startTime = s"$incStTime"
      }

      val endTime = s"$incEndTs"
      Logger.log.info(s" Endtime : $incEndTs ")
      Logger.log.info(s" startTime : $startTime ")
      Logger.log.info(s" Capturing if any Changes reflected for $entName from $startTime to $endTime")
      val rowKey = s"${ptnr}-${src}-${entName}"
      val sppRowKey = s"${ptnr}-${src}"
      var pitRawPartnFlr=""
      var pitRawRowDelim=""
      var pitRawFileCnt=""
      var refEitTblFlg="N"
      var resFlg="false"


      if (snapBuildType.equalsIgnoreCase("parquet")) {

        Logger.log.info(s" starting EIT scan for Parquet files")
        Logger.log.info(s"EXTRACT_EIT_FLG value is $EXTRACT_EIT_FLG")
        if (EXTRACT_EIT_FLG.equalsIgnoreCase("N")){
          try {
            Logger.log.info(s"Since EXTRACT_EIT_FLG value is $EXTRACT_EIT_FLG then reading from HbaseEit.txt file ; refEitTblFlg : $refEitTblFlg")
            var filename=s"/mapr/${workingDir}/EIT/HbaseEit.txt"
            var fileNmChk=new File(filename).exists()
            if(fileNmChk) {


              Logger.log.info(s"Scanning HbaseEit file ;fileNmChk : $fileNmChk")
              val lines = Source.fromFile(filename).getLines.toList
              var splitLine = lines.map(x => x.split('|'))
              var eitFileList: List[String] = null
              if (lstrundateFlg) {
                eitFileList = splitLine.filter(x => x(2) == entName && x(2) > startTime).map(x => s"${raw_path}${entNm}/${x(1)}").distinct
                Logger.log.info(s" Number of Entries Captured for $entName from EIT SCAN b/w $startTime and $endTime :" + eitFileList.size)
              } else {
                eitFileList = splitLine.filter(x => x(2) == entName).map(x => s"${raw_path}${entNm}/${x(1)}").distinct
                Logger.log.info(s" Number of Entries Captured for $entName from EIT SCAN full load :" + eitFileList.size)
              }

              if (eitFileList.size > 0) {
                //val eitFileList = eitInfo.map(x => (x._1, x._2)).collect.toList.map(x => ( s"${raw_path}${entNm}/${x._2}")).distinct
                //val eitRawFileList = eitFileList.filter(x => filterRawFileExist(x))
                val eitRawFileListNtEmp = eitFileList.filter(x => if(ApplicationConfig.isTriggerJobType.equalsIgnoreCase(DPOConstants.K8S) || ApplicationConfig.isTriggerJobType.equalsIgnoreCase(DPOConstants.KUBERNETES)){
                  FileSystemUtil.isNotEmptyDirMaprfs(x)}
                else{

                  isNotEmptyDir(x)})

                Logger.log.info(s" Number of PARQUET Files exist in Raw for $entName from EIT SCAN  :" + eitRawFileListNtEmp.length)
                Logger.log.info(s" List of PARQUET Files from Raw : ${eitRawFileListNtEmp.mkString}")
                val eitRdd = context.sparkContext.parallelize(eitRawFileListNtEmp)

                eitRdd.collect.map(x => saveToDataFrameP("PARQUET", workingDir, x, entName))

                pitRawRowDelim = "NA|"
                pitRawPartnFlr = "NA|"
                pitRawFileCnt = "NA|"
                refEitTblFlg = "N"

                resFlg = "true"
              } else {
                refEitTblFlg = "Y"
                Logger.log.info(s" Since, No Changes Captured for $entName in the HbaseEIT File from $startTime to $endTime,")
                pitRawRowDelim = "0|"
                pitRawPartnFlr = "0|"
                pitRawFileCnt = "0|"
                resFlg = "false"
              }
            }
            else{
              refEitTblFlg = "Y"
              Logger.log.info(s" Since HbaseEIT file  not present at $filename, proceeding towards reading the EIT Hbase Table")
              pitRawRowDelim = "0|"
              pitRawPartnFlr = "0|"
              pitRawFileCnt = "0|"
              resFlg = "false"

            }
          }
          catch {
            case e: Exception => Logger.log.info(s" Exception while Reading HbaseEit.txt file for $entNm" :+ e.getStackTrace.mkString)
              pitRawRowDelim="ERROR|"
              pitRawPartnFlr="ERROR|"
              pitRawFileCnt="ERROR|"
              resFlg="false"
              throw e
          }
        }
        else{
          refEitTblFlg="Y"
          Logger.log.info(s"Since EXTRACT_EIT_FLG value is $EXTRACT_EIT_FLG then proceeding towards scanning EIT Table ; refEitTblFlg : $refEitTblFlg")
          pitRawRowDelim="0|"
          pitRawPartnFlr="0|"
          pitRawFileCnt="0|"
          resFlg="false"

        }
        if(refEitTblFlg.equalsIgnoreCase("Y")) {
          try {

            Logger.log.info(s" Since refEitTblFlg is $refEitTblFlg then scanning the EIT Hbase Table $eitTable")
            import org.apache.hadoop.hbase.client.Scan
            val scan = new Scan()
            val filter = new PrefixFilter(Bytes.toBytes(s"${ptnr}-${src}-${entName}-"))
            val filter1 = new SingleColumnValueFilter(Bytes.toBytes("exi"), Bytes.toBytes("ingProcLogSts"), CompareOp.EQUAL, Bytes.toBytes("Success")); //val filter2 = new SingleColumnValueFilter(Bytes.toBytes("fi"), Bytes.toBytes("iscustrowdelim"), CompareOp.EQUAL, Bytes.toBytes("No"));
            import org.apache.hadoop.hbase.filter.CompareFilter.CompareOp
            scan.setCaching(10000)
            scan.setCacheBlocks(false)
            filter1.setFilterIfMissing(true)
            scan.setFilter(filterList(filter1, filter))
            if (lstrundateFlg) {
              scan.setTimeRange(getTimestamp(startTime), getTimestamp(endTime))
            }

            val eitVal = context.hbaseContext.hbaseRDD(TableName.valueOf(eitTable), scan).cache
            Logger.log.info(s" DL eitVal count : ${eitVal.count()} ")
            val eitInfo = eitVal.map(tuple => {
              val result = tuple._2
              //(Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("schmVer"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("ingstdFileNm"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("entprtnfldr"))))
              (Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("schmVer"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("entprtnfldr"))))
            })


            if (lstrundateFlg) {
              Logger.log.info(s" Number of Entries Captured for $entName from EIT SCAN b/w $startTime and $endTime :" + eitVal.count())
            } else {
              Logger.log.info(s" Number of Entries Captured for $entName from EIT SCAN full load :" + eitVal.count())
            }

            if (!eitInfo.isEmpty) {
              Logger.log.info(s" eitInfo: $eitInfo")
              val eitFileList = eitInfo.map(x => (x._1, x._2)).collect.toList.map(x => (s"${raw_path}${entNm}/${x._2}")).distinct
              Logger.log.info(s" eitFileList: $eitFileList")
              //val eitRawFileList = eitFileList.filter(x => filterRawFileExist(x))
              val eitRawFileListNtEmp = eitFileList.filter(x =>
                if(ApplicationConfig.isTriggerJobType.equalsIgnoreCase(DPOConstants.K8S) || ApplicationConfig.isTriggerJobType.equalsIgnoreCase(DPOConstants.KUBERNETES)){
                  FileSystemUtil.isNotEmptyDirMaprfs(x)}
                else{

                  isNotEmptyDir(x)})

              Logger.log.info(s" Number of PARQUET Files exist in Raw for $entName from EIT SCAN b/w $startTime and $endTime :" + eitRawFileListNtEmp.length)
              Logger.log.info(s" List of PARQUET Files from Raw : ${eitRawFileListNtEmp.mkString}")
              val eitRdd = context.sparkContext.parallelize(eitRawFileListNtEmp)

              eitRdd.collect.map(x => saveToDataFrameP("PARQUET", workingDir, x, entName))
              eitVal.unpersist()

              pitRawRowDelim="NA|"
              pitRawPartnFlr="NA|"
              pitRawFileCnt="NA|"
              resFlg="true"

              //"true;" + entName + "-" + pitRawRowDelim + ";" + entName + "-" + pitRawPartnFlr + ";" + entName + "-" + pitRawFileCnt;


            } else {
              Logger.log.info(s" Since, No Changes Captured for $entName in scanning EIT hbase table/ Hbase EIT File from $startTime to $endTime,No DataSets Generated")
              pitRawRowDelim="ERROR|"
              pitRawPartnFlr="ERROR|"
              pitRawFileCnt="ERROR|"
              resFlg="false"
              //"false;" + entName + "-ERROR|;" + entName + "-ERROR|;" + entName + "-ERROR|";
            }

          }  catch {
            case e: Exception => Logger.log.info(s" Exception while Scanning EIT Hbase Table for $entNm" :+ e.getStackTrace.mkString)
              pitRawRowDelim="ERROR|"
              pitRawPartnFlr="ERROR|"
              pitRawFileCnt="ERROR|"
              resFlg="false"
              //"false;"+entName+"-ERROR|;"+entName+"-ERROR|;"+entName+"-ERROR|";
              throw e
          }

        }

        resFlg+";"+entName+"-"+pitRawRowDelim+";"+entName+"-"+pitRawPartnFlr+";"+entName+"-"+pitRawFileCnt;
      }else{
        Logger.log.info(s" starting EIT scan for dat files")
        var rsltFlg1=false
        var rsltFlg2=false

        try {
          import org.apache.hadoop.hbase.client.Scan
          val eppRdd: org.apache.spark.rdd.RDD[(String, String)] = getEppLakeTabSchma(eppTable, ptnr, src, entName).cache
          Logger.log.info(s" scanning EIT for isCustRowlim as No for dat files")
          val scan_N = new Scan()
          val filter_N = new PrefixFilter(Bytes.toBytes(s"${ptnr}-${src}-${entName}-"))
          val filter1_N = new SingleColumnValueFilter(Bytes.toBytes("exi"), Bytes.toBytes("ingProcLogSts"), CompareOp.EQUAL, Bytes.toBytes("Success"));
          val filter2_N = new SingleColumnValueFilter(Bytes.toBytes("fi"), Bytes.toBytes("iscustrowdelim"), CompareOp.EQUAL, Bytes.toBytes("No"));
          scan_N.setCaching(10000)
          scan_N.setCacheBlocks(false)
          filter1_N.setFilterIfMissing(true)
          filter2_N.setFilterIfMissing(true)
          scan_N.setFilter(filterList(filter1_N, filter_N,filter2_N))

          if (lstrundateFlg) {
            scan_N.setTimeRange(getTimestamp(startTime), getTimestamp(endTime))
          }

          val eitVal_N = context.hbaseContext.hbaseRDD(TableName.valueOf(eitTable), scan_N).cache
          Logger.log.info(s" DL eitVal count with isCustRowlim as No is  : ${eitVal_N.count()} ")

          if(eitVal_N.count()>0){
            val eitInfo = eitVal_N.map(tuple => {
              val result = tuple._2
              (Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("schmVer"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("srcFileNm"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("entprtnfldr"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("iscustrowdelim"))))
            })
            val isCustDelim = eitInfo.map(kv => {
              kv._4
            }).first.toString

            Logger.log.info(s" Processing ${entName} Files with Delimiter: \\n as isCustDelim is ${isCustDelim}")
            if (lstrundateFlg) {
              Logger.log.info(s" Number of Entries Captured for $entName from EIT SCAN b/w $startTime and $endTime :" + eitVal_N.count())
            } else {
              Logger.log.info(s" Number of Entries Captured for $entName from EIT SCAN full load :" + eitVal_N.count())
            }
            if (!eitInfo.isEmpty) {
              //  val eitFileList: List[(String, String)] = eitInfo.collect.toList.map(x => (x, s"${raw_path}${entName}/${entName}.v${x}//*"))
              //val eitFileList = eitInfo.map(x => (x._1,x._3, x._2)).collect.toList.map(x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._2}/${x._3}"))

              val eitFileListT = eitInfo.map(x => (x._1,x._3, x._2)).collect.toList
              val eitFileList = eitFileListT.map(x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._2}/${x._3}"))


              val eitRawFileList = eitFileList.filter(x => filterRawFileExist(x._2))
              Logger.log.info(s" Number of Files exist in Raw with \\n record delim for $entName from EIT SCAN b/w $startTime and $endTime :" + eitRawFileList.length)

              val eitPartnFlr=eitFileListT.map(x=> (x._2,1))
              val eitPartnFlrCnt= context.sparkContext.parallelize(eitPartnFlr).reduceByKey(_+_).collect().mkString("~")
              pitRawFileCnt=pitRawFileCnt+"\n-"+eitRawFileList.length+"|"
              pitRawRowDelim=pitRawRowDelim+"\n|"
              pitRawPartnFlr=pitRawPartnFlr+"\n-"+eitPartnFlrCnt+"|"

              Logger.log.info(s" List of Files from Raw with \\n record delim: ${eitRawFileList.mkString}")
              val eitRdd = context.sparkContext.parallelize(eitRawFileList)
              val eitFileRdd = eitRdd.groupByKey.mapValues(_.mkString(","))
              //  val eppRdd: org.apache.spark.rdd.RDD[(String, String)] = getEppLakeTabSchma(eppTable, ptnr, src, entName).cache
              Logger.log.info(s" Number of Schema Versions for ${entName} retrieved from EPP HBase Table:" + eppRdd.count())
              val sparkConfig = context.sparkContext
              eppRdd.join(eitFileRdd).collect.foreach { case (schmVer, (schm, fileList)) => saveToDataFrame(workingDir, schmVer, schm, fileList, entName, sparkConfig)
              }
              eitVal_N.unpersist()
              //  eppRdd.unpersist()
              rsltFlg1=true
            } else {
              Logger.log.info(s" Since, No Changes Captured for $entName from $startTime to $endTime, datasets will not be generated")
              rsltFlg1=false
            }
          }
          else
          {
            Logger.log.info(s" since DL eitVal count with isCustRowlim as No is  : ${eitVal_N.count()} , skipping the process")
            rsltFlg1=false
          }


          Logger.log.info(s" scanning EIT for isCustRowlim as Yes for dat files")
          val scan_Y = new Scan()
          val filter_Y = new PrefixFilter(Bytes.toBytes(s"${ptnr}-${src}-${entName}-"))
          val filter1_Y = new SingleColumnValueFilter(Bytes.toBytes("exi"), Bytes.toBytes("ingProcLogSts"), CompareOp.EQUAL, Bytes.toBytes("Success"));
          val filter2_Y = new SingleColumnValueFilter(Bytes.toBytes("fi"), Bytes.toBytes("iscustrowdelim"), CompareOp.EQUAL, Bytes.toBytes("Yes"));
          scan_Y.setCaching(10000)
          scan_Y.setCacheBlocks(false)
          filter1_Y.setFilterIfMissing(true)
          filter2_Y.setFilterIfMissing(true)
          scan_Y.setFilter(filterList(filter1_Y, filter_Y,filter2_Y))

          if (lstrundateFlg) {
            scan_Y.setTimeRange(getTimestamp(startTime), getTimestamp(endTime))
          }

          val eitVal_Y = context.hbaseContext.hbaseRDD(TableName.valueOf(eitTable), scan_Y).cache
          Logger.log.info(s" DL eitVal count with isCustRowlim as Yes is  : ${eitVal_Y.count()} ")
          if(eitVal_Y.count()>0){

            val eitInfo = eitVal_Y.map(tuple => {
              val result = tuple._2
              (Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("schmVer"))), Bytes.toHex(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("rowdelim"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("entprtnfldr"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("srcFileNm"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("iscustrowdelim"))))
            })
            //     (Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("schmVer"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("srcFileNm"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("entprtnfldr"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("iscustrowdelim"))))

            Logger.log.info(s" Processing ${entName} Files with Row Delimiter: \\u0002 & \\u0002\\u000A")
            val isCustDelim = eitInfo.map(kv => {
              kv._5
            }).first.toString

            Logger.log.info(s" Processing ${entName} Files with Delimiter:\\u0002 OR  \\u0002\\u000A  isCustDelim is ${isCustDelim}")

            if (lstrundateFlg) {
              Logger.log.info(s" Number of Entries Captured for $entName from EIT SCAN b/w $startTime and $endTime :" + eitVal_Y.count())
            } else {
              Logger.log.info(s" Number of Entries Captured for $entName from EIT SCAN full load :" + eitVal_Y.count())
            }
            if (!eitInfo.isEmpty()) {

              //val rwDelimLst: List[(String,String)] = eitInfo.map(x => (x._1,x._2, x._3, x._4)).collect.toList.map(x => (x._2,"1"))
              //val rddRwDelim = globalContext.spark.parallelize(rwDelimLst)
              //val rddRwDelimLst = rddRwDelim.groupByKey.mapValues(_.mkString(","))

              //val eppRdd: org.apache.spark.rdd.RDD[(String, String)] = getEppLakeTabSchma(eppTable, ptnr, src, entName).cache
              // val rsltFlg2=rddRwDelimLst.collect.map(x => genExtDelim(x._1,eppRdd, eitInfo,entNm,raw_path,workingDir,startTime, endTime))

              ///val eitFileListCtlB: List[(String, String)] = eitInfo.filter(x => x._2 == "2" || x._2 == "5c7530303032").map(x => (x._1, x._3, x._4)).collect.toList.map(x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._2}/${x._3}"))

              //PITEntry//val eitFileListCtlB: List[(String, String)] = eitInfo.filter(x =>  x._2 == "5c7530303032").map(x => (x._1, x._3, x._4)).collect.toList.map(x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._2}/${x._3}"))

              //val eitFileListCtlBT = eitInfo.filter(x =>  x._2 == "5c7530303032").map(x => (x._1, x._3, x._4)).collect.toList
              val eitFileListCtlBT = eitInfo.filter(x => x._2 == "2" || x._2 == "5c7530303032").map(x => (x._1, x._3, x._4)).collect.toList
              val eitFileListCtlB= eitFileListCtlBT.map(x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._2}/${x._3}"))

              Logger.log.info(s" CustomRowDelim :List of Files from Raw with \\u0002 record delim: ${eitFileListCtlB.mkString}")
              //val eitFileListCtlB: List[(String, String)] = eitInfo.filter( x => x._2 == "2" || x._2 == "5c7530303032" ).map( x => (x._1, x._4, x._3) ).collect.toList.map( x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._4}/${x._3}") )
              val eitRawFileListCtlB = eitFileListCtlB.filter(x => filterRawFileExist(x._2))
              Logger.log.info(s" CustomRowDelim :ACTUAL Number of Files exist in Raw with \\u0002 record delim for $entName from EIT SCAN b/w $startTime and $endTime :" + eitRawFileListCtlB.length)
              Logger.log.info(s" CustomRowDelim :List of Files from Raw with \\u0002 record delim: ${eitRawFileListCtlB.mkString}")

              if(eitRawFileListCtlB.length>0){

                val eitPartnFlrCtlB=eitFileListCtlBT.map(x=> (x._2,1))
                val eitPartnFlrCtlBCnt= context.sparkContext.parallelize(eitPartnFlrCtlB).reduceByKey(_+_).collect().mkString("~")
                pitRawFileCnt=pitRawFileCnt+"CtlB-"+eitRawFileListCtlB.length+"|"
                pitRawRowDelim=pitRawRowDelim+"CtlB|"
                pitRawPartnFlr=pitRawPartnFlr+"CtlB-"+eitPartnFlrCtlBCnt+"|"

                val rddCtlB = context.sparkContext.parallelize(eitRawFileListCtlB)
                val eitFileRddCtlB = rddCtlB.groupByKey.mapValues(_.mkString(","))
                //            val eppRdd: org.apache.spark.rdd.RDD[(String, String)] = getEppLakeTabSchma(eppTable, ptnr, src, entName).cache
                Logger.log.info(s" CustomRowDelim :Number of Schema Versions for ${entName} retrieved from EPP HBase Table:" + eppRdd.count())
                val sparkConfigCtlB = context.sparkContext
                sparkConfigCtlB.hadoopConfiguration.set("textinputformat.record.delimiter", "\u0002")
                eppRdd.join(eitFileRddCtlB).collect.foreach { case (schmVer, (schm, fileList)) => saveToDataFrame(workingDir, schmVer, schm, fileList, entName, sparkConfigCtlB)
                }
              }
              else
              {
                Logger.log.info(s" Skipping the process as ACTUAL Number of Files exist in Raw with \\u0002 record delim is :" + eitRawFileListCtlB.length)
              }


              //val eitFileListCtlBNL: List[(String, String)] = eitInfo.filter(x => x._2 == "25c6e" || x._2 == "20a" || x._2 == "5c75303030325c6e").map(x => (x._1, x._3, x._4)).collect.toList.map(x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._2}/${x._3}"))
              //PitEntry// val eitFileListCtlBNL: List[(String, String)] = eitInfo.filter(x => x._2 == "5c75303030325c6e").map(x => (x._1, x._3, x._4)).collect.toList.map(x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._2}/${x._3}"))
              //val eitFileListCtlBNLT = eitInfo.filter(x => x._2 == "5c75303030325c6e").map(x => (x._1, x._3, x._4)).collect.toList
              val eitFileListCtlBNLT = eitInfo.filter(x => x._2 == "25c6e" || x._2 == "20a" || x._2 == "5c75303030325c6e").map(x => (x._1, x._3, x._4)).collect.toList
              val eitFileListCtlBNL=eitFileListCtlBNLT.map(x => (x._1, s"${raw_path}${entNm}/${entNm}.v${x._1}/${x._2}/${x._3}"))

              Logger.log.info(s" CustomRowDelim :Number of Files exist in Raw with \\u0002\\u000A record delim for $entName from EIT SCAN b/w $startTime and $endTime :" + eitFileListCtlBNL.length)

              val eitRawFileListCtlBNL = eitFileListCtlBNL.filter(x => filterRawFileExist(x._2))
              Logger.log.info(s" CustomRowDelim :Number of ACTUAL Files exist in Raw with \\u0002\\u000A record delim for $entName from EIT SCAN b/w $startTime and $endTime :" + eitRawFileListCtlBNL.length)
              Logger.log.info(s" CustomRowDelim :List of ACTUAL Files from Raw with \\u0002\\u000A record delim: ${eitRawFileListCtlBNL.mkString}")
              if(eitRawFileListCtlBNL.length>0){

                val eitPartnFlrCtlBNL=eitFileListCtlBNLT.map(x=> (x._2,1))
                val eitPartnFlrCtlBNLCnt= context.sparkContext.parallelize(eitPartnFlrCtlBNL).reduceByKey(_+_).collect().mkString("~")
                pitRawFileCnt=pitRawFileCnt+"CtlB\n-"+eitRawFileListCtlBNL.length+"|"
                pitRawRowDelim=pitRawRowDelim+"CtlB\n|"
                pitRawPartnFlr=pitRawPartnFlr+"CtlB\n-"+eitPartnFlrCtlBNLCnt+"|"

                val rddCtlBNL = context.sparkContext.parallelize(eitRawFileListCtlBNL)
                val eitFileRddCtlBNL = rddCtlBNL.groupByKey.mapValues(_.mkString(","))
                val sparkConfigCtlBNL = context.sparkContext
                sparkConfigCtlBNL.hadoopConfiguration.set("textinputformat.record.delimiter", "\u0002\u000A")
                eppRdd.join(eitFileRddCtlBNL).collect.foreach { case (schmVer, (schm, fileList)) => saveToDataFrame(workingDir, schmVer, schm, fileList, entName, sparkConfigCtlBNL)
                  //eppRdd.unpersist()
                }

              }
              else
              {
                Logger.log.info(s" Skipping the process as ACTUAL Number of Files exist in Raw with \\u0002\\u000A  record delim is :" + eitRawFileListCtlBNL.length)
              }


              eitVal_Y.unpersist()
              rsltFlg2=true

            }
            else {
              Logger.log.info(s" Number of Files Captured for $entName from EIT SCAN b/w $startTime and $endTime :" + 0)
              Logger.log.info(s" Since, No Changes Captured for $entName from $startTime to $endTime,datasets will not be generated")
              rsltFlg2=false
            }

          }
          else {
            Logger.log.info(s" since DL eitVal count with isCustRowlim as Yes is  : ${eitVal_Y.count()} , skipping the process")
            rsltFlg2=false

          }
          eppRdd.unpersist()

          var res="false;;;"
          if(rsltFlg2==true || rsltFlg1 == true)
          {
            /*            hbasePitPut(pitTab, pitRowKey, "fi", "rawRowDelim", pitRawRowDelim.dropRight(1))
                        hbasePitPut(pitTab, pitRowKey, "fi", "rawPartnFldr", pitRawPartnFlr.dropRight(1))
                        hbasePitPut(pitTab, pitRowKey, "fi", "rawFileCnt", pitRawFileCnt.dropRight(1))*/

            res="true;"+entName+"-"+pitRawRowDelim+";"+entName+"-"+pitRawPartnFlr+";"+entName+"-"+pitRawFileCnt;
          }
          else
          {
            /*            hbasePitPut(pitTab, pitRowKey, "fi", "rawRowDelim", "")
                        hbasePitPut(pitTab, pitRowKey, "fi", "rawPartnFldr", "")
                        hbasePitPut(pitTab, pitRowKey, "fi", "rawFileCnt", "0")*/
            res="false;"+entName+"- ;"+entName+"- ;"+entName+"-0";

          }
          res
        } catch {
          case e: Exception => Logger.log.info(s" Exception while Scanning Files from DL EIT for $entNm" :+ e.getStackTrace.mkString)

            throw e
        }
      }
    } catch {
      case e: Exception => Logger.log.info(s" Exception while Scanning Files from DL EIT for $entNm from eitTabScan" :+ e.getStackTrace.mkString)
        throw e
    }

  }
  /** Purpose : Def to save the EPP Htable schema versions results into spark dataframe with parquet file format
    * input : schemaVersion(s), schema, filesList, entityName, sparkConfiguration
    * output: DF should be created and saves resultant versions in the form of parquet */
  def saveToDataFrame (workingDir: String, schmVer: String, schm: String, fileList: String, entNm: String, sparkConfig: SparkContext)(implicit context: GlobalContext): Unit = {
    try {
      val jsonFile = schm.split("(?<=\\}),(?=\\{)")
      val jsonRddSchm = context.sparkContext.parallelize(jsonFile)
      val jsonRdd = context.sqlContext.read.json(jsonRddSchm).rdd.map(x => (x(1).toString)).collect.toList
      val fields = jsonRdd.map(fieldName => StructField(fieldName, StringType, nullable = true))
      val schema = StructType(fields) //
      val loadFiles = sparkConfig.textFile(fileList).map(_.split("\u0001", -1)).map(x => Row(x: _*))
      val verDf = context.sqlContext.createDataFrame(loadFiles, schema)
      //val workingDir = globalContext.workingDir
      verDf.write.mode(SaveMode.Append).parquet(s"$workingDir/${entNm.toUpperCase()}")
    } catch {
      case e: Exception => Logger.log.info(" Exception at saveDFversionTables" :+ e.getMessage)
        throw e
    }
  }

  def getSnapshotCommonPerEntity(snapBuildType: String, pKeys: String, lakeEitTableName: String, mountPath: String, workingDir: String, lakeEppTableName: String, entity: String, prtnrCd: String, srcCd: String, dmlCol: String, modTsCol: String)(implicit context: GlobalContext): Unit = {

    try {
      val primaryKeys: Array[String] = pKeys.split(";")
      Logger.log.info(s" Primary Key Columns for $entity : ${pKeys}")
      // Get LakeEIT scanned rowKey entity
      var result=""
      //confirm flag EXTRACT_EIT_FLG value
      var EXTRACT_EIT_FLG = "Y"
      var lstrundateFlg = false
      //confirm lstrundate,incEndTs,pitRowKey,pitTab
      var lstrundate = ""
      var incEndTs = ""
      var pitRowKey = ""
      var pitTab = ""
      var pitRawRowDelim = ""
      var pitRawPartnFlr = ""
      var pitRawFileCnt = ""


      result = eitLakeTabScanMod(EXTRACT_EIT_FLG, snapBuildType, lakeEitTableName, mountPath, lakeEppTableName, workingDir, prtnrCd, srcCd, entity, lstrundateFlg, lstrundate, incEndTs, pitRowKey)
      //result:String = eitLakeTabScanMod(EXTRACT_EIT_FLG,snapBuildType,lakeEitTableName, mountPath, lakeEppTableName, workingDir, prtnrCd, srcCd, entity, lstrundateFlg, lstrundate, incEndTs, pitRowKey)
      val ptnrCd = s"${prtnrCd.toUpperCase()}"
      val src = s"${srcCd.toUpperCase()}"
      val entName = s"${entity.toUpperCase()}"
      Logger.log.info(s" Working Directory path for Incremental extract: $workingDir")
      Logger.log.info(s"result retrieved from eitTabScan :: " +result)

      val resultFlg= result.split(';')(0)
      pitRawRowDelim=pitRawRowDelim+result.split(';')(1).dropRight(1)
      pitRawPartnFlr=pitRawPartnFlr+result.split(';')(2).dropRight(1)
      pitRawFileCnt=pitRawFileCnt+result.split(';')(3).dropRight(1)

      //if LakeEIT scanned rowKey entity is empty then end the workflow with Success Status , else continue to save the raw snapshot merged files into a dataframe as entity name
      if (resultFlg.equalsIgnoreCase("true")) {
        try {
          Logger.log.info(s" Captured Incremental Extract for ${entName}")
          Logger.log.info(s" Merging Schema for $entName from $workingDir/$entName")
          Logger.log.info(s" checking existence of working directory")
          val merDir = workingDir + "/" + entName
          mkdirs(merDir)
          val mergeDF = context.sqlContext.read.option("mergeSchema", true).parquet(s"$workingDir/$entName").persist(org.apache.spark.api.java.StorageLevels.MEMORY_AND_DISK_SER)
          //Temp// Logger.log.info(s" Merge Schema Record Count for $entName :" + mergeDF.count)

          try {
            val userWindow = Window.partitionBy(concat_ws("-", primaryKeys.map(c => col(c)): _*), lit("")).orderBy(col(s"$modTsCol").desc)
            val dedupDF = mergeDF.withColumn("rank", row_number().over(userWindow)).where(col("rank") === 1).drop("rank")
            // val noCdcFlg=dedupDF.toDF.filter(dedupDF("CDC_FLAG") =!= 'D').persist(org.apache.spark.api.java.StorageLevels.MEMORY_AND_DISK_SER)
            dedupDF.createOrReplaceTempView(s"dedupDf")
            val noCdcFlg=context.sqlContext.sql(s"select * from dedupDf where trim(${dmlCol}) != 'D'")
            val snapDir = workingDir + "/"+snapshotDir+"/" + entName
            mkdirs(snapDir)
            noCdcFlg.createOrReplaceTempView(s"${entName}")
            noCdcFlg.write.mode(SaveMode.Overwrite).parquet(snapDir)
            Logger.log.info(s"==========> Delete raw data after snapshot generated for $entName <===========")
            // rmPathIfExist(merDir)
            Logger.log.info(s"==========> Directory $merDir removed <===========")
            Logger.log.info(s"==========> Snapshot creation completed for ${entName} <===========")
          } catch {
            case e: Exception => Logger.log.info(s">>>>> Exception at Main Loading MergeSchema/SqlStatement for $entName <<<<<" :+ e.getMessage)
              //removing intermediate parquet data
              rmPathIfExist(workingDir + "/" + entName)
              rmPathIfExist(workingDir + "/"+snapshotDir+"/" + entName)
              //hbasePITEndStage(pitTab, "Fail", pitRowKey)
              throw e
          }


        } catch {
          case e: Exception => Logger.log.info(s">>>>> Exception at Main Loading Merge Parquet Schema/SqlStatement for $entName <<<<<" :+ e.getMessage)
            //removing intermediate parquet data
            rmPathIfExist(workingDir + "/" + entName)
            throw e
        }
      } else {
        Logger.log.info(s" Since there are No Changes reflected for the $entName in a given time range, hence ending the workflow  ")
      }
    } catch {
      case e: Exception => Logger.log.info(" Exception at DataLake Snapshot Scan , Failed due to " :+ e.getMessage)
        throw e

    }

  }

  def rmPathIfExist (path: String): Unit = {
    try { var fsConf = new Configuration()
    var fileSystem = FileSystem.get(fsConf)
    if (fileSystem.exists(new Path(path))) {
      Logger.log.info(s" Deleted intermediate file/dir : " + path)
      fileSystem.delete(new Path(path.replace("/mapr/", "/")), true)
      //fileSystem.deleteOnExit(new Path(path))
    } else {
      Logger.log.info(s" Path: $path doesn't exist, Not proceeding for removing.")
    }

    } catch {
      case e: Exception => Logger.log.info(" Exception at rmPathIfExist definition" :+ e.getStackTrace.toString)
        throw e
    }
  }

  def mkdirs (folderPath: String): Unit = {
    try { var fsConf = new Configuration()
    var fileSystem = FileSystem.get(fsConf)
    Logger.log.info(s" Created Path : " + folderPath)
    fileSystem.mkdirs(new Path(folderPath))


    } catch {
      case e: Exception => Logger.log.info(" Exception at mkdirs definition" :+ e.getStackTrace.toString)
        throw e
    }
  }


  def getPkTs (rowKeyConfig: String, snapConfigTab: String)(implicit context: GlobalContext):org.apache.spark.rdd.RDD[(String, String, String, String, String, String, String, String)] = {
    try {
      // val snapConfigTab = globalContext.pscTabName
      Logger.log.info(s" Snapshot Config table : $snapConfigTab")
      val scanner = new Scan()
      scanner.setCaching(1000)
      scanner.setCacheBlocks(false)
      val filter1 = new RowFilter(CompareOp.EQUAL, new BinaryComparator(Bytes.toBytes(s"$rowKeyConfig")))
      val filter2 = new SingleColumnValueFilter(Bytes.toBytes("psc"), Bytes.toBytes("activeflag"), CompareOp.EQUAL, Bytes.toBytes("Y"));
      scanner.setFilter(filterList(filter1, filter2))

      val snapInfo = context.hbaseContext.hbaseRDD(TableName.valueOf(snapConfigTab), scanner)
      Logger.log.info(s" SnapConfigTab Filter count : ${snapInfo.count()} ")
      val snapRDD = snapInfo.map(tuple => {
        val result = tuple._2
        (
          Bytes.toString(result.getValue(Bytes.toBytes("psc"), Bytes.toBytes("feedName"))),
          Bytes.toString(result.getValue(Bytes.toBytes("psc"), Bytes.toBytes("extractName"))),
          Bytes.toString(result.getValue(Bytes.toBytes("psc"), Bytes.toBytes("entNm"))),
          Bytes.toString(result.getValue(Bytes.toBytes("psc"), Bytes.toBytes("prikeycols"))),
          Bytes.toString(result.getValue(Bytes.toBytes("psc"), Bytes.toBytes("dmlcol"))),
          Bytes.toString(result.getValue(Bytes.toBytes("psc"), Bytes.toBytes("activeflag"))),
          Bytes.toString(result.getValue(Bytes.toBytes("psc"), Bytes.toBytes("modtscol"))),
          Bytes.toString(result.getValue(Bytes.toBytes("psc"), Bytes.toBytes("fullLoadflg"))))

      })

      snapRDD
    } catch {
      case e: Exception => Logger.log.error(s" Exception while retriving Pk's from Snapshot Config Tab for $rowKeyConfig" :+ e.getMessage)
        throw e
    }
  }



  def filterList (filters: Filter*) = new FilterList(FilterList.Operator.MUST_PASS_ALL, filters: _*)


  /*def createOrReplaceTempViewFn(df:DataFrame,tblNm:String)(implicit context: GlobalContext) = {
    Logger.log.info(s"the Count for ${tblNm} is "+df.count())
    //var res=df.createOrReplaceTempView(tblNm)


  }
*/


  //Purpose : Def to get current time in a specific format
  def getCurrentTimeFormat: String = getCurrentDateTime("yyyy-MM-dd HH:mm:ss")

  //Purpose : Def to get current time in a specific format
  def getCurrentTsFormat: String = getCurrentDateTime("yyyyMMddHHmmssSS").substring(0, 16)

  /** Purpose : Def to get current date/time in a specified format
    * input : dateField
    * output: Returns DateField as specified format */
  def getCurrentDateTime (dateTimeFormat: String): String = {
    try {
      val dateFormat = new SimpleDateFormat(dateTimeFormat)
      val cal = Calendar.getInstance()
      dateFormat.format(cal.getTime)
    }catch{
      case e: Exception => {
        Logger.log.info("RK4 :  CommonUtil.getCurrentDateTime() "+e.getMessage )
        throw e
      }
    }
  }



  //Purpose : Def to get current date in a specific format
  def getCurrentDateFormat: String = getCurrentDateTime("yyyy-MM-dd")


  /** Purpose : Def to get current date/time in a specified format
    * input : dateField
    * output: Returns DateField as specified format */
  def getTimestamp (DateFormat: String): Long = {
    try {
      val timestampformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
      timestampformat.parse(DateFormat).getTime
    } catch {
      case e: Exception => Logger.log.info(" Exception while getting current date/time : " + e.getMessage)
        0
    }
  }

  /** Purpose : Def to get the duration in  seconds
    * input : two dates
    * output: returns duration */
  def getDuration (endDate: String, startDate: String): String = {
    val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")
    val startDatefrmt = LocalDateTime.parse(startDate, formatter)
    val endDatefrmt = LocalDateTime.parse(endDate, formatter)
    //val zoneId = ZoneId.systemDefault
    val zoneId = ZoneId.ofOffset("UTC", ZoneOffset.ofHours(0))
    (endDatefrmt.atZone(zoneId).toEpochSecond() - startDatefrmt.atZone(zoneId).toEpochSecond()).toString
    //println(newDate.toEpochDay() - oldDate.toEpochDay())
  }

  def readFileFs()={

  }

  def updatePITFailedStatus() = ???

  /**
    *This method fetches the last run date from PLC
    *
    * @param plcRowKey
    * @param context
    * @return
    */
  def fetchPLCLastRunDt(plcRowKey: String)(implicit context: GlobalContext): String = {
    //val plcRowKey = pei.feedName + "_" + pei.consumingApp
    val lastRunDt = context.plcTable.getValueByRowKey(plcRowKey, "plc", "lastRunDt")
    lastRunDt
  }
  /**
    *This method update the last run date from PLC
    *
    * @param plcRowKey
    * @param context
    * @return
    */
  def updatePLCLastRunDt(plcRowKey: String,lastRunDt: String)(implicit context: GlobalContext): Unit = {
    //val plcRowKey = pei.feedName + "_" + pei.consumingApp
    context.plcTable.put(plcRowKey, "plc", "lastRunDt",lastRunDt)
  }
  def generatePDF(inputFilePath:String,outputFilePath: String ): Unit = {
    import com.itextpdf.text._
    import com.itextpdf.text.pdf.PdfWriter
    var inputFile = inputFilePath
    if (!inputFile.contains("/mapr/")) {
      inputFile = inputFile.replace("/datalake/", "/mapr/datalake/")
    }
    var outputFile = outputFilePath
    if (!outputFile.contains("/mapr/")) {
      outputFile = outputFile.replace("/datalake/", "/mapr/datalake/")
    }
    val pdfDoc = new Document(PageSize.A4)
    PdfWriter.getInstance(pdfDoc, new FileOutputStream(outputFile)).setPdfVersion(PdfWriter.PDF_VERSION_1_7)
    val one = new Rectangle(1850, 700)
    pdfDoc.setPageSize(one)
    pdfDoc.setMargins(1, 1, 1, 1)
    pdfDoc.open()
    val myfont = new Font
    myfont.setStyle(Font.NORMAL)
    //myfont.setSize(11)
    pdfDoc.add(new Paragraph("\n"))
    Logger.log.info("=============> Reading the Input File <=============")
    val br = new BufferedReader(new FileReader(inputFile))
    var strLine: String = null
    while ( {
      strLine = br.readLine; strLine != null
    }) {
      val para = new Paragraph(strLine + "\n", myfont)
      para.setAlignment(Element.ALIGN_LEFT)
      pdfDoc.add(para)
      //pdfDoc.add(new Paragraph("\n"))
    }
    pdfDoc.close()
    br.close()
    Logger.log.info("=============> Converted the Input file into PDF <=============")
  }

  /**
    *
    * @param fileName
    * @return
    */
  def replaceDate(fileName: String): String ={
    val dtFormat = CommonUtil.getCurrentDateTime("yyyyMMdd")
    fileName.replace("$YYYYMMDD",dtFormat)
  }

  /**
    *
    * @param filePath
    * @param fileName
    * @param context
    * @return
    */
  def assignSeqNumFromFile(filePath: String, fileName: String)(implicit context: GlobalContext): String = {
    var prevGen = context.sparkContext.textFile(filePath).collect()(0).toInt
    var nextGen = "%04d".format(prevGen + 1)

    val updatedFileName = fileName.replace("$NUM", nextGen)
    FileSystemUtil.createHDFSFile(filePath, nextGen)

    updatedFileName
  }

  /**
    *
    * @param fileName
    * @return
    *
    * This method is replacing the date and time from the Header Description of a provision if HDR is true.
    * For the Header Description, a table/view is created which is used to fetch the timestamp.
    * The logic is being used in PE and quite specific to it.
    *
    */
  //TODO : Need to be make it generic
  def replaceDateAndTime(fileName:String, isHdr: Boolean)(implicit context: GlobalContext) : String = {
    Logger.log.info(s"Handling date format if the file name having  YYYYMMDD-HHMMSS")
    if(isHdr){
      //Logic given below is specific to PE
      var datetime = context.sqlContext.sql(s"select * from ${HEADER_VIEW}").head.getString(0).split('.')(0).split('|')(1).split('_')(1)
      fileName.replace("YYYYMMDD-HHMMSS",datetime)
    } else {
      // This logic has never been used in any extract till now.
      val dtFormat = CommonUtil.getCurrentDateTime("yyyyMMdd-HHmmss")
      fileName.replace("YYYYMMDD-HHMMSS", dtFormat)
    }
  }


  /**
    *
    * @param provTempLoc
    * @param outFileNameWithoutPDFExt
    * @param outFileName
    * @return
    */
  def createPDFFile(provTempLoc: String, outFileNameWithoutPDFExt: String, outFileName: String): String ={
    CommonUtil.generatePDF(provTempLoc+ SLASH +outFileNameWithoutPDFExt,provTempLoc+ SLASH +outFileName)
    FileSystemUtil.rmPathIfExist(provTempLoc+ SLASH +outFileNameWithoutPDFExt)
    outFileName
  }

  /**
    *
    * @param segTarCols
    * @param segTarLen
    * @param segLen
    * @param finalDF
    * @param finalViewName
    * @param context
    * @return
    */
  def genRPaddedDFForHierarchialFile(segTarCols: String, segTarLen: String, segLen: String, finalDF : DataFrame, finalViewName: String, typeOfPadding: String)(implicit context: GlobalContext): DataFrame = {
    try {
      val targetCols = segTarCols.split(";")
      val targetColLengths = segTarLen.split(";")
      val lnkCols = finalDF.columns.filter(_.startsWith("LNK_"))

      if (targetCols.length != targetColLengths.length) {
        Logger.log.info(s"Number of target columns do not match with number of target Data Type lengths provided for $finalViewName, hence ending the workflow with Failed status")
        throw new DPOException("Number of target columns do not match with the number of target Data Type lengths provided")
      }

      import org.apache.spark.sql.functions.rpad
      val sqlString = if(typeOfPadding==DPOConstants.LPAD){
        targetCols.zip(targetColLengths).map { (colMeta) => s"$typeOfPadding(COALESCE(${colMeta._1},''),${colMeta._2},'0') AS ${colMeta._1}" }.mkString(",")
        //targetCols.zip(targetColLengths).map { (colMeta) => s"$typeOfPadding(${colMeta._1},${colMeta._2},'0') AS ${colMeta._1}" }.mkString(",")
      }else{
        targetCols.zip(targetColLengths).map { (colMeta) => s"$typeOfPadding(COALESCE(${colMeta._1},''),${colMeta._2},' ') AS ${colMeta._1}" }.mkString(",")
        //targetCols.zip(targetColLengths).map { (colMeta) => s"$typeOfPadding(${colMeta._1},${colMeta._2},' ') AS ${colMeta._1}" }.mkString(",")
      }



      val rpadQuery = s"SELECT ${lnkCols.mkString(",")}, ${sqlString} FROM $finalViewName" //lnkCols,rpadded cols
      Logger.log.info(" Constructed sql String is: " + rpadQuery)

      val rpaddedDF = context.sqlContext.sql(rpadQuery)
      val dataCols = targetCols.toSeq
      val dfResults = rpaddedDF.withColumn("data",concat_ws("",targetCols.map(c => col(c)): _*)) //lnkCols, rpadded cols, data
      dfResults.createOrReplaceTempView("concatDF")

      val allCols = s"${lnkCols.mkString(",")},RPAD(data,${segLen.toInt},' ') AS data "
      val transformedDF = context.sqlContext.sql(s"SELECT $allCols from concatDF")
      transformedDF
    }
    catch {
      case e: Exception => {
        Logger.log.info("RK4 : EPDERK4JsonSourceExtractor.genRPaddedDFForHierarchialFile() "+e.getMessage)
        throw e
      }
    }
  }

  /**
    *
    * @param tarCols
    * @param tarLen
    * @param totLen
    * @param viewName
    * @param context
    * @return
    */
  def generatePaddedDF(tarCols: String, tarLen: String, totLen: String, viewName : String, typeOfPadding: String)(implicit context: GlobalContext): DataFrame ={
    var finalQry = StringBuilder.newBuilder
    var tempStr = StringBuilder.newBuilder

    val targetCols = tarCols.split(";")
    val targetColLengths = tarLen.split(";")
    var lenSum = 0

    if (targetCols.length != targetColLengths.length) {
      Logger.log.info(s"Number of target columns do not match with number of target Data Type lengths provided for $viewName, hence ending the workflow with Failed status")
      throw new DPOException("Number of target columns do not match with the number of target Data Type lengths provided")
    }

    import org.apache.spark.sql.functions.rpad
    val sqlString = targetCols.zip(targetColLengths).map { (colMeta) => s"$typeOfPadding(${colMeta._1},${colMeta._2},'0') AS ${colMeta._1}" }.mkString(",")

    val rpadQuery = s"SELECT ${sqlString} FROM $viewName"
    Logger.log.info(" Constructed sql String is: " + rpadQuery)

    var rpaddedDF = context.sqlContext.sql(rpadQuery)
    val dfResults = rpaddedDF.withColumn("data",concat_ws("",targetCols.map(c => col(c)): _*)).select("data")

    import org.apache.spark.sql.functions.rpad
    val dfFinal = dfResults.select(rpad(dfResults.col("data"),totLen.toInt," ").as("data"))

    dfFinal.show(false)
    dfFinal
  }

}
