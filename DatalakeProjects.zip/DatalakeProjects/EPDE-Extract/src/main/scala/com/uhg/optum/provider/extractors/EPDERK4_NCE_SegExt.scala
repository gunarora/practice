package com.uhg.optum.provider.extractors

import com.uhg.optum.common.DPOConstants
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDERK4InputJsonSchema.SegmentDetails
import com.uhg.optum.provider.output.OuptutGenerator
import com.uhg.optum.util.CommonUtil._
import com.uhg.optum.util.{EPDECommonUtil, FileSystemUtil, Logger}

import scala.util.{Failure, Success, Try}

trait EPDERK4_NCE_SegExt extends OuptutGenerator{

  def genNCESeg(segDtls: SegmentDetails,glblVarLst:collection.mutable.Map[String, String],SW_SKIP_NCE : String, outputFilePath: String)(implicit context: GlobalContext): Try[String] = {
    Logger.log.info("Inside nceSegGen...")
    Logger.log.info("Initializing variables...")

    /*    var tinQry = "SELECT PTA.PROV_ID as PROV_ID, PTP.TAX_ID_NBR as TAX_ID_NBR,PTA.ADR_TYP_CD as ADR_TYP_CD,PTA.ADR_ID as ADR_ID,from_unixtime(unix_timestamp(PTA.LST_UPDT_DT,'yyyy-MM-dd'), 'MM/dd/yyyy') AS LST_UPDT_DT, A.ZIP_CD AS ZIP_CD, PTA.DIR_IND AS DIR_IND, PTA.PRI_CD AS PRI_CD, PTA.TOPS_TIN_SUFX_CD AS TOPS_TIN_SUFX_CD ,PTA.TOPS_TIN_PRFX_CD AS TOPS_TIN_PRFX_CD, from_unixtime(unix_timestamp(PTA.ORIG_EFF_DT,'yyyy-MM-dd'), 'MM/dd/yyyy') as ORIG_EFF_DT, A.ADR_STR_OVRIDE_IND as ADR_STR_OVRIDE_IND,PTA.CORSP_ADR_IND as CORSP_ADR_IND, PTA.ADR_CARE_NM as ADR_CARE_NM, PTA.INTRL_RTE_NBR as INTRL_RTE_NBR,PTA.BIL_ADR_ID as BIL_ADR_ID, from_unixtime(unix_timestamp(PTA.EFF_DT,'yyyy-MM-dd'), 'MM/dd/yyyy')  as EFF_DT, PTA.MDCD_ID as MDCD_ID, PTA.MDCD_LOC_CD as MDCD_LOC_CD, PTA.EPD_ADDR_SEQ as EPD_ADDR_SEQ, PTA.TAX_ID_TYP_CD AS TAX_ID_TYP_CD,A.ADR_LN_1_TXT ADR_LN_1_TXT,A.CTY_NM CTY_NM, A.ST_CD ST_CD,A.ZIP_PLS_4_CD ZIP_PLS_4_CD,A.CNTY_NM CNTY_NM, A.HNCP_ACSBL_IND HNCP_ACSBL_IND,from_unixtime(unix_timestamp(PTA.CANC_DT,'yyyy-MM-dd'), 'MM/dd/yyyy') as CANC_DT,from_unixtime(unix_timestamp(A.LST_UPDT_DT,'yyyy-MM-dd'), 'MM/dd/yyyy') AS ADR_LST_UPDT_DT FROM  DF2_NDB_ODFR2TST.F5938DBE_PROV_TIN_ADR PTA,DF2_NDB_ODFR2TST.F5938DBE_PROV_TIN_PAY_AFFIL PTP,DF2_NDB_ODFR2TST.F5938DBE_ADR A,DF2_NDB_ODFR2TST.F5938DBE_PROV P WHERE PTA.PROV_ID = P.PROV_ID AND PTA.PROV_ID = PTP.PROV_ID AND PTA.TAX_ID_NBR = PTP.TAX_ID_NBR AND PTA.TAX_ID_TYP_CD = PTP.TAX_ID_TYP_CD AND PTA.ADR_TYP_CD IN ('H','D','L','T') AND PTA.ADR_ID =  A.ADR_ID and PTA.PROV_ID in (528719, 530799, 2022991) ORDER BY PTP.TAX_ID_NBR, PTA.ADR_TYP_CD limit 1000"

        var df_tin = context.sqlContext.sql(tinQry)
        df_tin.createOrReplaceTempView("TIN_FNL_VIEW")
        Logger.log.info("---Registered TIN_FNL_VIEW ----")*/

   //TODO::To be removed this declaration
/*    var WS_PREV_RUN_DT_YMD = glblVarLst.get("WS_PREV_RUN_DT_YMD").
    var SchemaNm= glblVarLst.get("SchemaNm")*/
    //   var WS_PREV_RUN_DT_YMD = glblVarLst.get("WS_PREV_RUN_DT_YMD")

    //  var df = context.sqlContext.emptyDataFrame
    var retStr = "N"
    Try {
      if(segDtls.equals("") || segDtls == null){
        Logger.log.info("No segment details present for ACE Segment")
      }
      if(!context.sparkSession.catalog.tableExists("TIN_FNL_VIEW")){
        Logger.log.info("The temporary view TIN_FNL_VIEW from TIN segment is required for NCE segment")
      }

      if (SW_SKIP_NCE.equals("N")) {

        if (segDtls.segName.equals("NCE")) {
          var segNm = segDtls.segName
          var seg_Seq = segDtls.segSeq
          Logger.log.info("Inside NCE")
          EPDECommonUtil.generateSegTables(segDtls.segTables,glblVarLst)
          //Iterate over all the segment keys one by one
          segDtls.segQueries.map { qryKey =>
            if (qryKey.name.matches("NCE_56_CUR")) {
              Logger.log.info("--Inside NCE_56_CUR--")
             // var qryStr = qryKey.query.replace("${SchemaNm}", SchemaNm)
              //val NCE_56_CUR = context.sqlContext.sql(s"$qryStr")
              val NCE_56_CUR =executeQry(glblVarLst,qryKey)
              createOrReplaceTempViewFn(NCE_56_CUR,qryKey.name)
            }
            else if (qryKey.name.matches("NCE_FNL_VIEW")) {
              /*var qryStr = qryKey.query.replace("${SchemaNm}", SchemaNm).replace("${WS_PREV_RUN_DT_YMD}",WS_PREV_RUN_DT_YMD)
              val NCE_FNL_VIEW =  context.sqlContext.sql(s"$qryStr")*/
              val NCE_FNL_VIEW =executeQry(glblVarLst,qryKey)
          createOrReplaceTempViewFn(NCE_FNL_VIEW,qryKey.name)
              FileSystemUtil.saveFileToMapRFSNoRepartitionParquet(NCE_FNL_VIEW.dropDuplicates(),outputFilePath,qryKey.name,"",DPOConstants.PARQUET)
          //if(NCE_FNL_VIEW.count > 0){
            /*FileSystemUtil.saveFileToMapRFS(NCE_FNL_VIEW.dropDuplicates(),outputFilePath,qryKey.name,"",DPOConstants.PARQUET)*/
            retStr = "Y"
          //}
        }
        else{
          Logger.log.info("No query key matches NCE_56_CUR ")
        }
      }
        }else{
          retStr
        }

      } else {
        Logger.log.info("NCE Segment skipped...")
        retStr
      }
      retStr
    }    match {
      case Success(retStr) => {
        Logger.log.info("RK4 : EPDERK4_NCE_SegExt.genNCESeg(): Success")
        Success(retStr)
      }
      case Failure(ex) => {
        Logger.log.info(s"RK4 : EPDERK4_NCE_SegExt.genNCESeg() : " + ex.getMessage)
        throw ex
      }
    }
  }


}
