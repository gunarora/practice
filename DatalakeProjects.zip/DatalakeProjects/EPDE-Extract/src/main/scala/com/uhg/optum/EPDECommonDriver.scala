package com.uhg.optum

import com.uhg.optum.common.DPOConstants
import com.uhg.optum.dao.{HbaseRepositoryManager, LocalRepositoryManager}
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.util.CommonUtil.readProperties
import com.uhg.optum.util.{CommonUtil, Logger}
import com.uhg.optum.conf.ApplicationConfig.inboxDir

/**
  * Description : Program to generate the extract based on PEI, PSC,PLC configurations with snapBudType raw / snapshot / pjs (with source as File for CHY)
  */
object EPDECommonDriver {
  def main(args: Array[String]): Unit = {
    try {

      Logger.log.info("=============> Starting EPDE Common Extract WorkFlow <=============")
      /*    if (args.length != 3) {
            Logger.log.info("===> Please Pass feedName-vendorName Environment thriftServerUrl \" EPDE-OPTUM  dev/tst/prod thrift://dbsls0306.uhc.com:11018\" for Provisioning extract <===")
            Logger.log.error("===> Since No args(FeedName-ExtractName,Environment)  is Passed ending Provisioning extract <===")
            System.exit(1)
          }
    */

      val vndrCd = args(0).toUpperCase()
      val provContr = "provider"
      val peiRowKey = "EPDE-"+vndrCd
      val envParam=args(1).trim
      Logger.log.info("peiRowKey: " + peiRowKey)
      val env = args(2).trim
      val metaURI = args(3).trim
      //val metaURI = "thrift://dbsls0306.uhc.com:11018"

//      val inputParquetFilePath = "/datalake/uhclake/tst/t_inbound/uhg/ndb/inbound/VS/"
      val inboxPath=inboxDir //take from application.config
      Logger.log.info(s"INFO : inboxPath is $inboxPath")

      implicit val globalContext = if(envParam.equalsIgnoreCase("local")) {
        new GlobalContext(peiRowKey,DPOConstants.LOCAL) with LocalRepositoryManager
      } else {
        new GlobalContext(peiRowKey,DPOConstants.YARN) with HbaseRepositoryManager
      }
      // val jobRunner = new EPDEJobRunner(peiRowKey)
      val commonJobRunner = new EPDECommonJobRunner(peiRowKey, env, inboxPath, vndrCd)
      commonJobRunner.start()
      globalContext.sparkSession.stop()

    } catch {
      case e: Exception => {
        Logger.log.error(" Exception at <def Main> from EPDECommonDriver Object : " + e.printStackTrace())
        Logger.log.error("Error occured : " + e.getStackTrace.mkString("\n"))
        System.exit(4)
      }
        throw e
    }
  }

}
