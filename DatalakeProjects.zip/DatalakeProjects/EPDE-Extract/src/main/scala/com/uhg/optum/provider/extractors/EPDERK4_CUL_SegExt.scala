package com.uhg.optum.provider.extractors

import com.uhg.optum.common.DPOConstants
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDERK4InputJsonSchema.SegmentDetails
import com.uhg.optum.provider.output.OuptutGenerator
import com.uhg.optum.util.CommonUtil.{createOrReplaceTempViewFn, executeQry}
import com.uhg.optum.util.{CommonUtil, EPDECommonUtil, Logger, FileSystemUtil}

trait EPDERK4_CUL_SegExt extends OuptutGenerator {
  def culSegGen(segDetails: SegmentDetails, outputFilePath: String, glblVarLst: collection.mutable.Map[String, String])(implicit context: GlobalContext): String = {
try{
    var df=context.sqlContext.emptyDataFrame
    var resStr = "N"

    EPDECommonUtil.generateSegTables(segDetails.segTables,glblVarLst)
    segDetails.segQueries.map { qryKey =>
      Logger.log.info("qryKey.name --> " + qryKey.name)
      if (qryKey.name.equals("CUL_FNL_VIEW")) {
        df = executeQry(glblVarLst, qryKey)
        Logger.log.info("CUL_FNL_VIEW " + qryKey.name)
        val remDupDF = df.dropDuplicates()
        createOrReplaceTempViewFn(remDupDF, qryKey.name)
        FileSystemUtil.saveFileToMapRFSNoRepartitionParquet(remDupDF, outputFilePath, qryKey.name, "", DPOConstants.PARQUET)
        //if (remDupDF.count > 0) {
        /*  FileSystemUtil.saveFileToMapRFS(remDupDF, outputFilePath, qryKey.name, "", DPOConstants.PARQUET)*/
          resStr="Y"
        //}
      }
      else{
        df = executeQry(glblVarLst, qryKey)
        val remDupDF = df.dropDuplicates()
        createOrReplaceTempViewFn(remDupDF, qryKey.name)
      }
    }


    resStr
}catch {

  case e: Exception => {
    Logger.log.info(s"RK4 : EPDERK4_CUL_SegExt.genCULSeg() : "+e.getMessage)
    throw e
  }

}
  }
}