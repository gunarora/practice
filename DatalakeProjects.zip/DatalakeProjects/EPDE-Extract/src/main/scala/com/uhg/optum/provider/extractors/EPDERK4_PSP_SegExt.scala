package com.uhg.optum.provider.extractors

import com.uhg.optum.common.DPOConstants
import com.uhg.optum.conf.ApplicationConfig.workingDir
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDERK4InputJsonSchema.SegmentDetails
import com.uhg.optum.provider.output.OuptutGenerator
import com.uhg.optum.util.CommonUtil.{add2Map, amaSpecTblLoop, createOrReplaceTempViewFn, executeQry}
import com.uhg.optum.util.{CommonUtil, EPDECommonUtil, FileSystemUtil, Logger}

trait EPDERK4_PSP_SegExt extends OuptutGenerator{
  def genPSPSeg(segDtls: SegmentDetails,varLst:collection.mutable.Map[String, String],glblVarLst:collection.mutable.Map[String, String],outputFilePath:String)(implicit context: GlobalContext): String = {
    try{
    var resStr="N"
    /*var AMA_SPEC_TABLE_Cnt=glblVarLst.get("AMA_SPEC_TABLE_Cnt").mkString.toInt
    var SchemaNm=glblVarLst.get("SchemaNm").mkString
    Logger.log.info("INFO: AMA_SPEC_TABLE count is "+AMA_SPEC_TABLE_Cnt)
    var occurFnlQryDF = context.sqlContext.emptyDataFrame*/

    var emptyLst  = collection.mutable.Map[String, String]()
    var df = context.sqlContext.emptyDataFrame
    if(segDtls == null || segDtls.equals("")){
      throw new Exception("No segment details present for PSP Segment")
    }
    Logger.log.info("PSP")
    EPDECommonUtil.generateSegTables(segDtls.segTables,glblVarLst)
    segDtls.segQueries.map { qryKey =>
      /*    //fetches TR# 16 SPCL  with PRV segment output
       if (qryKey.name.equals("PSP_16_SPCL_RCRDS")) {
            df = executeQry(varLst, qryKey)
            createOrReplaceTempViewFn(df, qryKey.name)
          }    //fetches details  with PRV segment output which doesn't fulfills TR# 16 SPCL
       else if (qryKey.name.equals("PSP_16_SPCL_NORCRDS")) {
            df = executeQry(varLst, qryKey)
            createOrReplaceTempViewFn(df, qryKey.name)
          }
          // fetches EXCLUSION prov_id which fulfills the criteria of  #TR 17 #5000-SPEC-EXCLUSIONS
          else if (qryKey.name.equals("PSP_17_DVC_DTL")) {
            var AMA_SPEC_ENTRY_qry_17 = context.sqlContext.emptyDataFrame
            AMA_SPEC_ENTRY_qry_17 = executeQry(varLst,qryKey)
            // AMA_SPEC_ENTRY_qry_17 = executeQry(qryKey, SchemaNm, WS_VENDR_CD)
            createOrReplaceTempViewFn(AMA_SPEC_ENTRY_qry_17, qryKey.name)
          }
          // fetches EXCLUSION OF  prov_id which fulfills the criteria of  #TR 18 # 5010-SPEC-EXCLUSIONS
          else if (qryKey.name.equals("PSP_18_DVC_DTL")) {
            var AMA_SPEC_ENTRY_qry_18 = context.sqlContext.emptyDataFrame
            AMA_SPEC_ENTRY_qry_18 = executeQry(varLst,qryKey)
            // AMA_SPEC_ENTRY_qry_18 = executeQry(qryKey, SchemaNm, WS_VENDR_CD)
            createOrReplaceTempViewFn(AMA_SPEC_ENTRY_qry_18, qryKey.name)
          }
          //excludes the prov-id fetched in PRV_17_DVC_DTL and PRV_18_DVC_DTL based on filter for AMA_SPEC_TABLE
          else if (qryKey.name.equals("PSP_AMA_17_18")) {
      var skipPrvLst=amaSpecTblLoop(AMA_SPEC_TABLE_Cnt)
      tempLst.clear()
      tempLst=varLst
      add2Map(tempLst,"${skipPrvLst}",skipPrvLst)
      df=executeQry(tempLst,qryKey)
      // df = executeQry(qryKey,skipPrvLst)
      createOrReplaceTempViewFn(df, qryKey.name)
    }
         // union PSP_16_SPCL_NORCRDS and PSP_AMA_17_18
          else if (qryKey.name.equals("PSP_3050_FRMT")) {
            df = executeQry(varLst, qryKey)
            createOrReplaceTempViewFn(df, qryKey.name)
          }
         // calculates the count of the TR#19  to handle SQLCODE +0 nd consider only single records
          else if (qryKey.name.equals("PSP_19_STC_PSP_CNT")) {
            df = executeQry(varLst, qryKey)
            createOrReplaceTempViewFn(df, qryKey.name)
          }
          // fetches records with count=1 in PSP_19_STC_PSP_CNT and satisfies TR# 19 STC_PSP
          else if (qryKey.name.equals("PSP_19_STC_PSP_SNGLE")) {
          df = executeQry(varLst, qryKey)
          createOrReplaceTempViewFn(df, qryKey.name)
          }
    //  output of PSP  segemnt along with link columns
    else */if (qryKey.name.equals("PSP_FNL_VIEW")) {
      val df = executeQry(varLst, qryKey).dropDuplicates()
      createOrReplaceTempViewFn(df, qryKey.name)
      /// df.show()
      FileSystemUtil.saveFileToMapRFSNoRepartitionParquet(df,outputFilePath,qryKey.name,"",DPOConstants.PARQUET)
      //if (df.count > 0) {
        //RPAD QUERY -> result -> write df res in file
        /*     val pspDf = CommonUtil.generateRpadQry(segDtls.segTarCol, segDtls.segTarLen, segDtls.segTolLen, qryKey.name)
                generateOpFile(pspDf, outputFilePath, segDtls.segSeq)
        pspDf.show()*/
        /*val pspDf = CommonUtil.generateRpadQry(segDtls.segTarCol, segDtls.segTarLen, segDtls.segTolLen, qryKey.name)
        generateOpFile(pspDf, outputFilePath, qryKey.name+"rpad")*/
        //FileSystemUtil.saveFileToMapRFS(pspDf,outputFilePath,qryKey.name,"",DPOConstants.CSV)
        /*FileSystemUtil.saveFileToMapRFS(df,outputFilePath,qryKey.name,"",DPOConstants.PARQUET)*/
        resStr="Y"

      //}
    }
    else{
      df = executeQry(varLst, qryKey)
      createOrReplaceTempViewFn(df, qryKey.name)
      /// df.show()
      /// FileSystemUtil.saveFileToMapRFS(df,glblVarLst.get("tmpVwPath").getOrElse(workingDir),qryKey.name,"",DPOConstants.PARQUET)
    }
    }
    resStr
  }catch {

    case e: Exception => {
      Logger.log.info(s"RK4 : EPDERK4_PSP_SegExt.genPSPSeg() : "+e.getMessage)
      throw e
    }

  }
  }

}
