package com.uhg.optum

import com.uhg.optum.dao.{HbaseRepositoryManager, LocalRepositoryManager}
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.util.{CommonUtil, Logger}
import com.uhg.optum.EPDERK4JobRunner._
import com.uhg.optum.common.DPOConstants
import com.uhg.optum.util.exceptions.InsufficientArgsException

object EPDERK4Driver {

  def main(args: Array[String]): Unit = {
    try {

      Logger.log.info("=============> Starting EPDE RK4 WorkFlow <=============")
      /*if (args.length != 4) {
        Logger.log.info("===> Please Pass provider id ; vendorCode ; env ; metaURI for  starting EPDE RK4 process <===")
        Logger.log.error("===> Since No args(provider id ; vendorCode ; env ; metaURI) for  starting EPDE RK4 process <===")
        System.exit(1)
      }*/

      /*   val provId = "108"
         Logger.log.info("=============> Starting EPDE RK4 WorkFlow <============= 1")
         val vndrCd = "OHPH"
         val PROVIN_UPDT_TYP_CD= ""
         val env = "dev"
         val metaURI = "thrift://dbsls0306.uhc.com:11018"
         val provContr = "provider"*/


      //val vndrCd = args(0).
      if (args.length != 8) {
        Logger.log.info("===> Please Pass  env; varfeedName; varextractName; envParam; peiRowKey; refreshFlag; eitFlag for  starting EPDE RK4 process <===")

        //System.exit(1)
        throw InsufficientArgsException("Insufficient arguments")
      }else {

        val env = args(0).toLowerCase()
        val varfeedName = args(1)
        val varextractName = args(2)
        val envParam = args(3).toLowerCase
        val peiRowKey = args(4).toUpperCase
        //val provTypCd = args(5).toUpperCase
        //      val provTypCd = "GROUP".toUpperCase()
        val vndrCd = peiRowKey.split('-')(1)
        val refreshFlag = args(5).toUpperCase
        val eitFlag = args(6).toUpperCase
        val provTypCd= args(7).toUpperCase
        Logger.log.info(s"=============> Starting EPDE RK4 WorkFlow <============= $vndrCd ")

        Logger.log.info(s"INFO : input arguments env :: $env")
        Logger.log.info(s"INFO : input arguments varfeedName :: $varfeedName")
        Logger.log.info(s"INFO : input arguments varextractName :: $varextractName")
        Logger.log.info(s"INFO : input arguments envParam :: $envParam")
        Logger.log.info(s"INFO : input arguments peiRowKey :: $peiRowKey")
        Logger.log.info(s"INFO : input arguments refreshFlag :: $refreshFlag")
        Logger.log.info(s"INFO : input arguments eitFlag :: $eitFlag")
        Logger.log.info(s"INFO : input arguments provTypCd :: $provTypCd")



        /*      val env = "dev".toLowerCase()
            val varfeedName="EPDE_Extraction"
            val varextractName="F5938RK4"
            val envParam="yarn"*/
        //val peiRowKey="EPDE-"+vndrCd


        /*      val refreshFlag="N"
            val eitFlag="N"*/
        //  val metaURI = "thrift://dbsls0306.uhc.com:11018"

        implicit val globalContext = if (envParam.equalsIgnoreCase("local")) {
          new GlobalContext(peiRowKey, DPOConstants.LOCAL) with LocalRepositoryManager
        } else {
          new GlobalContext(peiRowKey, DPOConstants.YARN) with HbaseRepositoryManager
        }




        /*implicit val globalContext = new GlobalContext("EPDE-OHPH","yarn") with HbaseRepositoryManager*/
        //TODO: Handle it from properties

        Logger.log.info("Context created and calling JobRunner")
        val ePDERK4JobRunner = new EPDERK4JobRunner(peiRowKey, env, vndrCd, refreshFlag, eitFlag, varfeedName, varextractName,provTypCd)
        ePDERK4JobRunner.start()
        globalContext.sparkSession.stop()
      }

    } catch {
      case c : InsufficientArgsException => {
        Logger.log.error("RK4 : EPDERK4Driver : "+c.getMessage)
        Logger.log.error("RK4 : EPDERK4Driver: Error occurred : " + c.getStackTrace.mkString("\n"))
        System.exit(3)
        throw c
      }
      case e: Exception => {
        Logger.log.error("RK4 : EPDERK4Driver :  Error Occured : "+e.getMessage )
        Logger.log.error("RK4 : EPDERK4Driver: Error occurred : " + e.getStackTrace.mkString("\n"))
        System.exit(4)
        throw e
      }
    }
  }

}







































/*
package com.uhg.optum

import com.uhg.optum.dao.{HbaseRepositoryManager, LocalRepositoryManager}
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.util.{CommonUtil, Logger}
import com.uhg.optum.EPDERK4JobRunner._

object EPDERK4Driver {

  def main(args: Array[String]): Unit = {
    try {

      Logger.log.info("=============> Starting EPDE RK4 WorkFlow <=============")
      /*if (args.length != 4) {
        Logger.log.info("===> Please Pass provider id ; vendorCode ; env ; metaURI for  starting EPDE RK4 process <===")
        Logger.log.error("===> Since No args(provider id ; vendorCode ; env ; metaURI) for  starting EPDE RK4 process <===")
        System.exit(1)
      }*/
      Logger.log.info("=============> Starting EPDE RK4 WorkFlow <============= 1")
      val provId = "108"
      Logger.log.info("=============> Starting EPDE RK4 WorkFlow <============= 1")
      val vndrCd = "OHPH"
      val PROVIN_UPDT_TYP_CD= ""
      val env = "dev"
      val metaURI = "thrift://dbsls0306.uhc.com:11018"
      val provContr = "provider"



      /*
            val provId = args(0).trim
            val vndrCd = args(1).trim
            val env = args(2).trim.toLowerCase
            val metaURI = args(3).trim
            val provContr = args(4).trim
      */
//TODO: Constanst in DPO yarn and local
      val arg1=provId+"-"+vndrCd+"-"+provContr
      implicit val globalContext = new GlobalContext("EPDE-OHPH","yarn") with HbaseRepositoryManager
      //TODO: Handle it from properties

      Logger.log.info("=============> Starting EPDE RK4 WorkFlow <============= 2")
      val ePDERK4JobRunner = new EPDERK4JobRunner("EPDE-OHPH",env,"N","Y")
      ePDERK4JobRunner.start()

    } catch {
      case e: Exception => {
        Logger.log.info(" Exception at <def Main> from PEMain 2Object : " + e.printStackTrace())
        Logger.log.error("Error occured : " + e.getStackTrace.mkString("\n"))
      }
        throw e
    }
  }

}

*/
