package com.uhg.optum.util


import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.util.SparkUtil.fileSystem
import org.apache.commons.lang.StringUtils
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions.{col, regexp_replace}
import org.apache.spark.sql.{DataFrame, Row, SQLContext, SparkSession}
import org.apache.spark.sql.types.{StringType, StructField, StructType}

/**
  * Created by paror18 on 10/1/2018.
  */
object SparkUtil {
  val fsConf = new Configuration()
  val fileSystem = FileSystem.get(fsConf)
  def createDFSchema(inputCols: String, delimiter: Option[String]): StructType = {
    delimiter match {
      case Some(dlm) => StructType(inputCols.split(dlm).map(fieldName => StructField(fieldName, StringType, true)))
      case None => StructType(List(StructField(inputCols, StringType, true)))
    }

  }

  def createDFFromRDD(rdd: RDD[String], delimiter: String, inputSchema: StructType, sqlContext: SQLContext): DataFrame = {
    import sqlContext.implicits._ // Fix this import
    val arrayRDD = rdd.map(_.split(delimiter))
    val dataDF = sqlContext.createDataFrame(arrayRDD.map(row => Row(row: _*)), inputSchema)
    dataDF
  }

  def saveDFToMapR(diffRec: DataFrame, outFileLoc: String): Unit = {
    try {
      Logger.log.info(s" saveDFToMapR initiated with input arguments -> diffRec : $diffRec , outFileLoc : $outFileLoc ")
      val outLoc = outFileLoc.replace("/mapr/", "/")
      mkdirs(outLoc)
      Logger.log.info(s" OutputLocation is : ${outLoc}  ")
      diffRec.repartition(1).write.mode("overwrite").csv(outLoc)
    } catch {
      case e: Exception => {
        Logger.log.info(" Exception at saveDFOutputToMapR definition : " + e.getMessage)
        Logger.log.error("Error occured : " + e.getStackTrace.mkString("\n"))
      }
        throw e
    }
  }

  def deleteDir(path: String): Unit = {
    try {
      if (fileSystem.exists(new Path(path))) {
        fileSystem.delete(new Path(path), true)
      }
    }
    catch {
      case exception: Exception => {
        Logger.log.info(" Exception at delete definition : " + exception.getMessage)
        Logger.log.error("Error occured : " + exception.getStackTrace.mkString("\n"))
      }
        throw exception
    }
  }

  def saveDFAsDelFileToMapR(diffRec: DataFrame, outFileLoc: String, delimiter: String): Unit = {
    try {
      val outLoc = outFileLoc.replace("/mapr/", "/")
      deleteDir(outLoc)
      diffRec.repartition(1).write.option("delimiter", delimiter).csv(outLoc)
    }
    catch {
      case exception: Exception => {
        Logger.log.info(" Exception at saveDFAsDelFileToMapR definition : " + exception.getMessage)
        Logger.log.error("Error occured : " + exception.getStackTrace.mkString("\n"))
      }
        throw exception
    }
  }

  def mkdirs(folderPath: String): Unit = {
    try {
      fileSystem.mkdirs(new Path(folderPath))
      Logger.log.info(s" Created Path : " + folderPath)
    } catch {
      case exception: Exception => {
        Logger.log.info(" Exception at mkdirs definition : " + exception.getStackTrace.toString)
        Logger.log.error("Error occured : " + exception.getStackTrace.mkString("\n"))
      }
        throw exception
    }
  }

  def createDFFromDelimitedFile(sparkSession: SparkSession, delimiter: String, filePath: String): DataFrame = {
    try {
      sparkSession.read.format("csv").option("delimiter", delimiter).load(filePath)
    }
    catch {
      case exception: Exception => {
        Logger.log.info(" Exception at createDFFromDelimitedFile definition : " + exception.getStackTrace.toString)
        Logger.log.error("Error occured : " + exception.getStackTrace.mkString("\n"))
      }
        throw exception
    }

  }

  def removeAllSpecialCharsFromDF(dataFrame: DataFrame): DataFrame = {
    try {
      dataFrame.columns.foldLeft(dataFrame) { (memoDF, colName) =>
        memoDF.withColumn(
          colName,
          regexp_replace(col(colName), "[^a-zA-Z0-9.:-\\\\ ]", "")
        )
      }
    } catch {
      case exception: Exception => {
        Logger.log.info(" Exception at removeAllSpecialCharsFromDF definition : " + exception.getStackTrace.toString)
        Logger.log.error("Error occured : " + exception.getStackTrace.mkString("\n"))
      }
        throw exception
    }
  }
  /** Purpose : Def to remove hadoop directory if exists
    * input : hadoopDirectoryPath
    * output: Returns Boolean value as 0 if the file is exists else 1 for not exists */
  //Fix : not used anywhere, later we can use this instead of commandline commands
  def rmPathIfExist (path: String): Unit = {
    try {
      if (fileSystem.exists(new Path(path))) {
        fileSystem.delete(new Path(path.replace("/mapr/", "/")), true)
        Logger.log.info(s" Deleted intermediate file/dir : " + path)
        //fileSystem.deleteOnExit(new Path(path))
      } else {
        Logger.log.info(s" Path: $path doesn't exist, Not proceeding for removing.")
      }
    } catch {
      case e: Exception => Logger.log.info(" Exception at rmPathIfExist definition" :+ e.getStackTrace.toString)
        throw e
    }
  }/**
    *
    * @param rdd
    * @return
    */
  def removeUnPrintableCharFromRDD(rdd: RDD[Row]): RDD[Row] = {
    rdd.map{ rec =>
      val recStr = rec.mkString("~^~").filter(c => StringUtils.isAsciiPrintable(c.toString))
      val row: Array[String] = recStr.split("\\~\\^\\~", -1)
      Row.fromSeq(row.toSeq)
    }
  }
  /**
    *  This method creates the dataframe with data and schema
    * @param row
    * @param colNames
    * @return
    */
  def createDataFrameFromData(row: Row, colNames:Seq[String])(implicit context: GlobalContext): DataFrame = {
    import org.apache.spark.sql._
    val data = Seq(row)
    //This method assumes all cols are of stringtype and nullable is true. If any other type is required, an overloaded method can be created.
    val schema = colNames.map(colName => StructField(colName,StringType, true)).toList
    Logger.log.info(s" colNames in createDataFrameFromData: " + colNames)
    context.sqlContext.createDataFrame(context.sparkContext.parallelize(data),StructType(schema))
  }

  /**
    *
    * @param colNames
    * @return
    */
  def createDFSchemaFromCols(colNames: Seq[String]): StructType = {
    val structFields = colNames.map(colName =>  StructField(colName,StringType, true)).toList
    StructType(structFields)

  }
  /**
    *
    * @param inputParquetPath
    * @return
    */
  def createDataFrameFromParquet(inputParquetPath : String)(implicit context: GlobalContext): DataFrame ={
    println("--Inside createDataFrameFromParquet--")
    println("--inputParquetPath--" + inputParquetPath)
    val parquetFileDF = context.sparkSession.read.parquet(inputParquetPath)
    println("==========")
    parquetFileDF
  }



}
