package com.uhg.optum.protocols

import com.uhg.optum.protocols.EPDECommonInputJsonSchema._
import spray.json._

object EPDECommonInputJsonSchema {

  type Queries = Seq[Query]
  case class Query(name: String, query: String)
  case class FeedDetails (
                           feedName: String,
                           extraction: Seq[ExtractFileEntity]
                         )

  case class ExtractFileEntity(
                                programName: String,
                                segmentList: String,
                                schemaNm: String,
                                segmentDetails: Seq[SegmentDetails]
                              )
  case class SegmentDetails(
                             segName: String,
                             segSeq: String,
                             segTarCol: String,
                             segTarLen: String,
                             segTolLen: String,
                             segTables: String,
                             segQueries: Queries
                           )

  case class EPDECommonInputExtractInfo(items: Array[FeedDetails]) extends IndexedSeq[FeedDetails] {
    def apply(index: Int) = items(index)
    def length = items.length
  }

}

object EPDECommonInputProtocol extends DefaultJsonProtocol {

  implicit val query = jsonFormat2(Query)
  implicit val segmentDetails = jsonFormat7(SegmentDetails)
  implicit val extract = jsonFormat4(ExtractFileEntity)
  implicit val feed = jsonFormat2(FeedDetails)

  implicit object EPDECommonInputExtractInfoJsonFormat extends RootJsonFormat[EPDECommonInputExtractInfo] {
    def read(value: JsValue) = EPDECommonInputExtractInfo(value.convertTo[Array[FeedDetails]])
    def write(f: EPDECommonInputExtractInfo) = JsArray(f.toJson)
  }
}

