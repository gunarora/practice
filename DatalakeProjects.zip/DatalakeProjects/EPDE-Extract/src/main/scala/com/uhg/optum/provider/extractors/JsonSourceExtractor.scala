package com.uhg.optum.provider.extractors

import com.uhg.optum.JobRunner.PEI
import com.uhg.optum.common.DPOConstants
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDEInputJsonSchema.{ExtractDetail, ExtractFileEntity, Queries, Query}
import com.uhg.optum.provider.output.OuptutGenerator
import com.uhg.optum.util.{CommonUtil, Logger}
import org.apache.spark.sql.DataFrame

import scala.util.{Failure, Success, Try}

/**
  * Created by paror18 on 10/19/2018.
  */
trait JsonSourceExtractor extends OuptutGenerator {

  /**
    *
    * This method takes the json file and  generates the final extract after transformation
    * with the execution of all queries in json.
    * @param inputEntity
    * @param pitRowKey
    * @param context
    * @param pei
    * @return
    */
  def generateExtractFromJson(inputEntity: ExtractFileEntity, provNo: Int, pitRowKey: String)(implicit context: GlobalContext, pei: PEI): DataFrame = {
    //TODO : Handle the Stepnumber Functionality
    var step = context.sqlContext.sql("select 1 as num")
    step.createOrReplaceTempView("stepnumber")
    val commonExtract = generateCommonExtract(inputEntity.commonQueries)
    val extractDetail =  inputEntity.extractDetails(provNo-1)
    val provExtract = generateProvExtract(extractDetail,inputEntity.isSchemaChange.equalsIgnoreCase("Yes"), pitRowKey)
    provExtract
  }

  /**
    * This method takes executes the common queries and returns the final DF of common queries
    * @param pei
    * @param context
    * @return
    */
  def generateCommonExtract(commonQueries: Option[Queries])(implicit context: GlobalContext, pei: PEI): Option[DataFrame] = {
    val isCommonFlg = if (pei.outFileName.split('|')(0).equalsIgnoreCase("Y")) Some() else None
    isCommonFlg.map { _ =>
      val commonDF = commonQueries.get.map { cq =>
        createDataFrameFromQuery(cq)
      }
      commonDF.last
    }
  }


  /**
    * This method assigns the value of last run date either from PLC or current date
    * @param pei
    * @param query
    * @param context
    * @return
    */
  private def assignLastRunDate(pei: PEI, query: String)(implicit context: GlobalContext): String = {
    val lastRunDt = fetchPLCLastRunDt(pei)
    if (lastRunDt.isEmpty) query.replace("$LAST_RUN_DATE", CommonUtil.getCurrentDateFormat) else query.replace("$LAST_RUN_DATE", lastRunDt)
  }

  /**
    *This method fetches the last run date from PLC
    *
    * @param pei
    * @param context
    * @return
    */
  private def fetchPLCLastRunDt(pei: PEI)(implicit context: GlobalContext): String = {
    val plcRowKey = pei.feedName + DPOConstants.HYPHEN + pei.extractName
    val lastRunDt = context.plcTable.getValueByRowKey(plcRowKey, "plc", "lastRunDt")
    lastRunDt
  }


  /**
    * This method creates extract for one particular provision
    *
    * @param extractDetail
    * @param isSchemaChange
    * @param pitRowKey
    * @param context
    * @param pei
    * @return
    */
  def generateProvExtract(extractDetail: ExtractDetail,
                          isSchemaChange: Boolean,
                          pitRowKey: String)(implicit context: GlobalContext, pei: PEI): DataFrame = {

    val finalDFInfo = generateQueriesForProv(extractDetail.provDataQueries)

    val trgColumn = if (isSchemaChange) extractDetail.provTrgColumn else pei.trgColumn
    val trgColumnLen = if (isSchemaChange) extractDetail.provTrgDataTypeLen else pei.trgDataTypeLen
    val transformedDF = generateTransformedExtract(trgColumn, trgColumnLen, finalDFInfo._1, pitRowKey)

    transformedDF
  }

  /**
    *
    * This method executes the queries of one single provision
    * and returns the DF and DF view for that particular provision.
    *
    * @param provDataQueries
    * @param context
    * @return
    */

  def generateQueriesForProv(provDataQueries: Queries)(implicit context: GlobalContext, pei: PEI): (String, DataFrame) = {

    val queryFilterExprssion = (q: String) => q.toLowerCase.startsWith("select") || q.toLowerCase.contains("cache")
    val totalSqlQueries = provDataQueries.count(q => queryFilterExprssion(q.query))
    Logger.log.info(s" totalSqlQueries : " + totalSqlQueries)

    val provDFs = provDataQueries.map { pq =>
      createDataFrameFromQuery(pq)
    }
    provDataQueries.last.name -> provDFs.last
  }

  /**
    * This method is used to create dataframe and view from query.
    * @param queryObj
    * @return
    */
  def createDataFrameFromQuery(queryObj: Query)(implicit pei: PEI, context: GlobalContext): DataFrame = {
    var transformedQuery = queryObj.query
    if (transformedQuery.contains("$LAST_RUN_DATE")) {
      transformedQuery = assignLastRunDate(pei, queryObj.query)
    }
    val singleQueryDF = context.sqlContext.sql(transformedQuery)
    Logger.log.info(s" Dataframe created successfully for : " + queryObj.name)
    singleQueryDF.persist(org.apache.spark.storage.StorageLevel.MEMORY_ONLY)
    Logger.log.info(s" Dataframe CACHED successfully for : " + queryObj.name)
    singleQueryDF.createOrReplaceTempView(queryObj.name)
    Logger.log.info(s" Able to Create Temporary View as  " + queryObj.name)
    val queryRecCount = singleQueryDF.count()
    Logger.log.info(" count for the query is   : " + "for entity " + queryObj.name + " is " + queryRecCount)
    singleQueryDF
  }

}
