package com.uhg.optum.provider.extractors

import com.uhg.optum.common.DPOConstants
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDERK4InputJsonSchema.SegmentDetails
import com.uhg.optum.provider.output.OuptutGenerator
import com.uhg.optum.util.CommonUtil._
import com.uhg.optum.util.{EPDECommonUtil, FileSystemUtil, Logger}

trait EPDERK4_COE_SegExt extends OuptutGenerator{
  def genCOESeg(segDetails:SegmentDetails,glblVarLst:collection.mutable.Map[String, String],varLst:collection.mutable.Map[String, String],segLocation:String,provTypCd:String)(implicit context: GlobalContext): String = {
    try{
    var df_COE = context.sqlContext.emptyDataFrame
    var rs="N"
    Logger.log.info("Segment COE Creation Start")
    //df_PRV = context.sqlContext.read.parquet(segLocation + "/PRV")
    val sparkSession = context.sparkSession
    import sparkSession.implicits._
    /*val df_PRV= Seq(
      ("6519517", "P"),
      ("6515920", "P"),
      ("6515913","P")
    ).toDF("OUT_PRV_PROV_ID", "OUT_PRV_TYP_CD")*/

  //  if (df_PRV.count() != 0) {
      if (segDetails.segName.equals("COE")) {
        //Segment query execution in sequence
        EPDECommonUtil.generateSegTables(segDetails.segTables,glblVarLst)
        //df_PRV.createOrReplaceTempView("PRV_FNL_VIEW")

        segDetails.segQueries.foreach { qryKey =>
          Logger.log.info("qryKey.name --> " + qryKey.name)
          df_COE = executeQry(glblVarLst, qryKey)
          //createOrReplaceTempViewFn(df_COE, qryKey.name)
          if(qryKey.name.equals("COE_PRE_VIEW_PHY") && provTypCd.equalsIgnoreCase("PHYSICIAN")) {
            Logger.log.info("COE gen for Physician")
            createOrReplaceTempViewFn(df_COE, "COE_PREVIEW")
          } else if(qryKey.name.equals("COE_PRE_VIEW_FAC") && !provTypCd.equalsIgnoreCase("PHYSICIAN")){
            createOrReplaceTempViewFn(df_COE, "COE_PREVIEW")
            Logger.log.info("COE gen for Facility")
          } else{
            createOrReplaceTempViewFn(df_COE, qryKey.name)
          }

        }
  //      val segLocation1="/datalake/uhclakedev/dataplatform/epde/d_datafiles/OHPH/GROUP/"
        FileSystemUtil.saveFileToMapRFSNoRepartitionParquet(df_COE.dropDuplicates(),segLocation,"COE_FNL_VIEW","",DPOConstants.PARQUET)
        rs="Y"
        // Segment file generation
        /*if (df_COE.count() > 0) {
          //FileSystemUtil.saveFileToMapRFS(df_COE.dropDuplicates(),segLocation,"COE_FNL_VIEW","",DPOConstants.PARQUET)
/*          val tinDf = generateRpadQry(segDetails.segTarCol, segDetails.segTarLen, segDetails.segTolLen, "COE_FNL_VIEW")
          Logger.log.info("COE RPAD Query")
          tinDf.show()
          Logger.log.info("...Inside COE -> outputFilePath, seg_Seq..." + segLocation + " " + segDetails.segSeq)
          FileSystemUtil.saveFileToMapRFS(tinDf.dropDuplicates(),segLocation,"COE_FNL_VIEW_TXT","",DPOConstants.TEXT)*/
          //generateOpFile(tinDf, segLocation, "TIN_FNL_VIEW_TXT")
          rs="Y"
        } else {
          Logger.log.info("ERROR FETCHING COE")
          rs="N"
        }*/
      }
    /*}else{
      Logger.log.error(s"PRV dataframe Should not be Empty")
      throw new Exception("Exception thrown")
    }*/
   /* val coeCount = df_COE.count()
    Logger.log.info(s"COE segment count:$coeCount")*/
    rs
    }catch {

      case e: Exception => {
        Logger.log.info(s"RK4 : EPDERK4_COE_SegExt.genCOESeg() : "+e.getMessage)
        throw e
      }

    }
  }
}
