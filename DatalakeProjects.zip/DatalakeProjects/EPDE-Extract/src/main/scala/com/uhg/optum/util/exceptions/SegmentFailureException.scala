package com.uhg.optum.util.exceptions

final case class SegmentFailureException (private val message: String = "",
                                          private val cause: Throwable = None.orNull)
  extends Exception(message, cause)