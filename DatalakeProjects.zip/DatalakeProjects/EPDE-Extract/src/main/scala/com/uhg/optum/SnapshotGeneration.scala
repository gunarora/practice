package com.uhg.optum

import com.uhg.optum.JobRunner.{PEI, PEIInstanceEmpty, SnapshotFileName}
import com.uhg.optum.common.DPOConstants
import com.uhg.optum.conf.ApplicationConfig
import com.uhg.optum.conf.ApplicationConfig._
import com.uhg.optum.dao.{HbaseRepositoryManager, LocalRepositoryManager}
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.provider.RawExtractProvider
import com.uhg.optum.util.{FileSystemUtil, Logger}

import scala.collection.mutable.ListBuffer
import scala.util.{Failure, Success}

object SnapshotGeneration {
  implicit var pei: PEI = _

  def main(args: Array[String]): Unit = {
    var tableName=""
    val failedSnaplist=ListBuffer[String]()

    try {
      if (args.length != 4) {
        Logger.log.error("Parameter Missing: refresh flag needs to be passed as either 'Y' or 'N'  ")
        throw new Exception("Parameter Missing: refresh flag needs to be passed as either 'Y' or 'N' ")

      }
      Logger.log.info("=========================================================")
      Logger.log.info("=============> START : Snapshot Generation <==============")
      val refreshFlag = args(0).toUpperCase()
      val envParam = args(1)
      val peiRowKey = "EPDE-OPTUM"
      val snapFileName = args(2)
      val eitFlag = args(3)
      var retFlag = ""
      implicit val globalContext = if (envParam.equalsIgnoreCase("local")) {
        new GlobalContext(peiRowKey, DPOConstants.LOCAL) with LocalRepositoryManager
      } else {
        new GlobalContext(peiRowKey, DPOConstants.YARN) with HbaseRepositoryManager
      }
      val peTable = globalContext.peTable
      import com.uhg.optum.protocols.PEIProtocol._
      peTable.get(peiRowKey, "pei") match {
        case Success(instance) =>
          this.pei = instance
          Success()
        case Failure(ex) =>
          Failure(new PEIInstanceEmpty("Exception while getting the columns info from PEI Table", ex))
      }

      var entitiesStream = this.getClass.getResourceAsStream(snapshotEntitiesFile)

      if("EPDE_1_Entity_List".equalsIgnoreCase(snapFileName)){
         entitiesStream = this.getClass.getResourceAsStream(snapshotEntitiesFile1)
      } else if("EPDE_2_Entity_List".equalsIgnoreCase(snapFileName)){
         entitiesStream = this.getClass.getResourceAsStream(snapshotEntitiesFile2)
      } else if("EPDE_3_Entity_List".equalsIgnoreCase(snapFileName)){
         entitiesStream = this.getClass.getResourceAsStream(snapshotEntitiesFile3)
      } else if("EPDE_4_Entity_List".equalsIgnoreCase(snapFileName)){
         entitiesStream = this.getClass.getResourceAsStream(snapshotEntitiesFile4)
      } else if("EPDE_5_Entity_List".equalsIgnoreCase(snapFileName)){
         entitiesStream = this.getClass.getResourceAsStream(snapshotEntitiesFile5)
      } else if("EPDE_6_Entity_List".equalsIgnoreCase(snapFileName)){
         entitiesStream = this.getClass.getResourceAsStream(snapshotEntitiesFile6)
      } else if("EPDE_7_Entity_List".equalsIgnoreCase(snapFileName)){
         entitiesStream = this.getClass.getResourceAsStream(snapshotEntitiesFile7)
      } else if("EPDE_8_Entity_List".equalsIgnoreCase(snapFileName)){
         entitiesStream = this.getClass.getResourceAsStream(snapshotEntitiesFile8)
      } else if("EPDE_9_Entity_List".equalsIgnoreCase(snapFileName)){
         entitiesStream = this.getClass.getResourceAsStream(snapshotEntitiesFile9)
      }


      val entitiesList = scala.io.Source.fromInputStream(entitiesStream).getLines.toList
      val pitRowKey = s"EPDE_Snapshot_Generation-${java.util.UUID.randomUUID.toString}"

      entitiesList.foreach { entity =>
         tableName = schema + "_" + entity
        val rowKeyConfig = peiRowKey.split("-")(0) + "-" + tableName
        if (ApplicationConfig.isTriggerJobType.equalsIgnoreCase(DPOConstants.BDPAAS) && (!FileSystemUtil.isNonEmptyDir(mountPrefix + "/" + workingDir + "/" + snapshotDir + "/" + tableName)) || refreshFlag.trim().equals("Y")) {
          val rawExtractProvider = new RawExtractProvider()(globalContext, pei)
          Logger.log.info(s"Calling for snapshot generation for entity: $tableName")
          retFlag = rawExtractProvider.getSnapshotExtractPerEntity(rowKeyConfig, tableName, pei, pitRowKey, eitFlag)
        }else if ((ApplicationConfig.isTriggerJobType.equalsIgnoreCase(DPOConstants.KUBERNETES) || ApplicationConfig.isTriggerJobType.equalsIgnoreCase(DPOConstants.K8S) ) && (!FileSystemUtil.isNotEmptyDirMaprfs(  "maprfs:///" + workingDir + "/" + snapshotDir + "/" + tableName)) || refreshFlag.trim().equals("Y")) {
        val rawExtractProvider = new RawExtractProvider()(globalContext, pei)
        Logger.log.info(s"Calling for snapshot generation for entity: $tableName")
        retFlag = rawExtractProvider.getSnapshotExtractPerEntity(rowKeyConfig, tableName, pei, pitRowKey, eitFlag)
      }
      }
      Logger.log.info("=========================================================")
      if(failedSnaplist.size>0){
      Logger.log.info("ERROR : There are "+failedSnaplist.size+" entities for which snapshot build failed at runtime.Please find below : ")
      failedSnaplist.foreach((table:String)=>{Logger.log.info(table)})   }
      Logger.log.info("=============> END : Snapshot Generation <==============")
      globalContext.sparkSession.stop()
    } catch {
      case e: Exception => {
        Logger.log.error(" Exception at <def Main> from SnapshotGeneration Object : " + e.printStackTrace())
        Logger.log.error("ERROR : Snapshot generation failed for entity - " +  tableName+" due to "+e.getMessage+("\n"))
        Logger.log.error("Error occurred : " + e.getStackTrace.mkString("\n"))
        if(!tableName.trim.isEmpty()){
        FileSystemUtil.rmPathIfExist(mountPrefix + "/" + workingDir + "/" + snapshotDir + "/" + tableName)
        failedSnaplist+=tableName}
        System.exit(4)
      }
       // throw e
    }
  }

}
