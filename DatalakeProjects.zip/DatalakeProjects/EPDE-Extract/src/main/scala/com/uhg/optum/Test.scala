package com.uhg.optum

import com.uhg.optum.protocols.EPDERK4InputJsonSchema.ExtractFileEntity

object Test {
  def generateLpadRpadQry(): String ={
    var finalQry = ""
    var tempStr = ""
    var tabNm = "ABC"
    var whrClause = "col = '12'"
    //   inputEntity.segmentDetails.map{
    //      s=> if(s.segName.equals(segNm)){
                var segTarCols = "TBL_EX_LST_UPDT_TYP_CD;TBL_EX_OFC_CD;TBL_EX_USER_ID"
                var segTarLen = "1;3;3"
                var columns = segTarCols.split(";").toList
                var lengths = segTarLen.split(";").toList
           for(i <- 0 to columns.size-1){
            tempStr = tempStr + "RPAD(" + columns(i) + "," + lengths(i) + "," + "''),"
      }
    println("Before dropRight " + tempStr)
    tempStr = tempStr.substring(0,tempStr.length-1)
    println("After dropRight " + tempStr)
    //  }
  //  }
    finalQry = "SELECT " + tempStr + " FROM " + tabNm + " WHERE " + whrClause
    println(finalQry)
    finalQry
  }

  def main(args: Array[String]): Unit = {
    generateLpadRpadQry()
  }

}
