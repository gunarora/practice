package com.uhg.optum

import java.io.File

import com.mapr.db.spark
import com.uhg.optum.EPDERK4JobRunner._
import com.uhg.optum.common._
import com.uhg.optum.util.CommonUtil.{createCommonSnapshot, createOrReplaceTempViewFn, getDateTimeFormatET}
import com.uhg.optum.conf.ApplicationConfig._
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDERK4InputJsonSchema.{EPDERK4InputExtractInfo, ExtractFileEntity}
import com.uhg.optum.provider.{DefaultExtractProvider, EPDERK4ExtractProvider, PJSExtractProvider, RawExtractProvider}
import com.uhg.optum.util.{CommonUtil, EPDECommonUtil, Logger}
import spray.json._
import com.mapr.db.spark._
import com.uhg.optum.JobRunner.{PEI, PEIInstanceEmpty}
import com.uhg.optum.conf.ApplicationConfig
import com.uhg.optum.util.SparkUtil.createDataFrameFromParquet
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.types.{IntegerType, StringType, StructField, StructType}
import org.apache.spark.sql.Row

import scala.collection.mutable.{ArrayBuffer, HashMap, ListBuffer}
import org.apache.spark.rdd.RDD

import scala.io.Source
import scala.util.{Failure, Success, Try}
import org.apache.spark.sql.functions._

object EPDERK4JobRunner {
  /*case class PEI(feedName: String,
                extractName: String,
                hdrDesc: String,
                hdrDateFormat: String,
                trlDesc: String,
                isJsonProp: String,
                jsonPropFileLoc: String,
                sqlQuery: String,
                transQuery: String,
                trgColumn: String,
                trgDataTypeLen: String,
                outFileName: String,
                outFileExt: String,
                outFileLoc: String,
                archLoc: String,
                isOutFileColDelim: String,
                outFileColDelim: String,
                isFixedWidth: String,
                srcCd: String,
                prtnrCd: String,
                entitySet: String,
                snapBuildType: String,
                isOutFileRowDelim: String,
                outFileRowDelim: String,
                consumingApp: String,
                inputFileName: String,
                inputFileLocation: String,
                inputLandingLocation: String)*/

  case class PSC(
                  feedName: String,
                  extractName: String,
                  entNm: String,
                  prikeycols: String,
                  dmlcol: String,
                  activeflag: String,
                  modtscol: String,
                  fullLoadflg: String
                )

  case class CustomFilter(
                           colFm: String,
                           colValue: String,
                           compareOp: CompareOperations.Value,
                           valueToBeCompared: String
                         )

  object CompareOperations extends Enumeration{
    val LESS, LESS_OR_EQUAL , EQUAL, NOT_EQUAL, GREATER_OR_EQUAL, GREATER, NO_OP = Value
  }

  case class trlHdrSchema(desc: String)

  class PEIInstanceEmpty(msg: String, th: Throwable) extends Exception(msg, th)
  class PSCInstanceEmpty(msg: String, th: Throwable) extends Exception(msg, th)
  class ValueNotFound(msg: String, th: Throwable) extends Exception(msg,th)


}

/**
  * Created by paror18 on 9/11/2018.
  */
//class EPDERK4JobRunner(peiRowKey: String, env : String,refreshFlag:String,eitFlag:String)(implicit val globalContext: GlobalContext) extends Job {
class EPDERK4JobRunner(peiRowKey: String, env : String,vndrCd:String,refreshFlag:String,eitFlag:String,varfeedName:String,varextractName:String,provTypCd:String)(implicit val globalContext: GlobalContext) extends Job {
  val peTable = globalContext.peTable
  val pscTable = globalContext.pscTable
  val pitTable = globalContext.pitTable
  val plcTable = globalContext.plcTable

  implicit var pei: PEI = _

  override def jobName: String = peiRowKey


  override def preStart()(implicit context: GlobalContext): Try[Unit] = { super.preStart()(context)
    Logger.log.info(s" Scanning PEI HBase Table $peiTabName for ROWKEY :  ${peiRowKey} ")
    import com.uhg.optum.protocols.PEIProtocol._
    peTable.get(peiRowKey,"pei") match {
      case Success(instance) =>
        this.pei = instance
        Success()
      case Failure(ex) => {
        Failure(new PEIInstanceEmpty("Exception while getting the columns info from PEI Table", ex))
        Logger.log.info("RK4 : EPDERK4JobRunner.preStart : "+ex.getMessage)
        throw ex
      }
    }
  }

  /* override def preStart()(implicit globalContext: GlobalContext): Try[Unit] = {
     Try {
       println("..............Inside pre start.............")
       super.preStart()(globalContext)
       // calling to read from MaprDB per provId
       /*val localScoSegList = this.getClass.getResourceAsStream("/EPDERK4/EPDE_RK4_Seg_List.txt" )
       val inputScoSegList =scala.io.Source.fromInputStream(localScoSegList).getLines.toList
       println("entity list-- " + inputScoSegList)
       /* commenting PJS related code
       val localPjsProvList = this.getClass.getResourceAsStream("/EPDERK4/PJS_EPDE_PROVIDER_JSON_LIST.txt" )
       val inputPjsProvList =scala.io.Source.fromInputStream(localPjsProvList).getLines.toList
       println("Pjs Prov list-- " + inputPjsProvList)*/

       for(i <- 0 to inputScoSegList.size - 1) {
         println("i--" + i)
         var j = inputScoSegList(i).split('|')(2)
         println("inputScoSeg(i)--" + inputScoSegList(i))
         println("inputScoSeg(i)--" + j)
         /*commenting PJS related code
          if(!inputPjsProvList.contains(j)){*/

         val entityArr: Array[String] = inputScoSegList(i).mkString("").split('|')

         val ent = entityArr(2).trim
         CommonUtil.getCommonSnapshotPerEntity(ent)
         // for first time
        // createCommonSnapshot(inputScoSegList(i))

         // commenting PJS related code
         // }
       }
       var provId="108"*/
       //if-else, read sco, check in pjs

       //  val readMapdbFlg=readFromMaprDB(provId)

       //   println(".......read mapr db flag......"+readMapdbFlg)
       Logger.log.info(s" Scanning PEI HBase Table $peiTabName for ROWKEY :  ${peiRowKey} ")



     }
     //import com.uhg.optum.protocols.PEIProtocol._
     /* peTable.get[PEI](peiRowKey,"pei") match {
        case Success(instance) =>
          this.pei = instance
          Success()
        case Failure(ex) =>
          Failure(new PEIInstanceEmpty("Exception while getting the columns info from PEI Table", ex))
      }*/
   }*/
  /*  def getProvContDF(env:String,provTypCd:String,vndrCd:String): Try[Unit] = {
      Try {
        Logger.log.info(s"INFO : inside getProvContDF for $env ; $provTypCd ; $vndrCd")
  /*      val inboxPath = readProperties(s"inboxDir", env)
        val provider_par = readProperties(s"provider_par", env)
        val contract_par = readProperties(s"contract_par", env)
        val provDFNm = readProperties(s"provDF", env)
        val contDFNm = readProperties(s"contDF", env)*/
        val provPath = inboxDir + DPOConstants.SLASH + vndrCd + DPOConstants.SLASH + provTypCd + DPOConstants.SLASH +provider_par
        val contPath = inboxDir + DPOConstants.SLASH + vndrCd + DPOConstants.SLASH + provTypCd + DPOConstants.SLASH +contract_par
        val provDf = createDataFrameFromParquet(provPath)
        provDf.show()
        val contDf = createDataFrameFromParquet(contPath)
        contDf.show()
        createOrReplaceTempViewFn(provDf, provDF)
        Logger.log.info(s"INFO created Provider temp view $provDF for $vndrCd ; $provTypCd")
        createOrReplaceTempViewFn(contDf, contDF)
        Logger.log.info(s"INFO created Contract temp view $contDF for $vndrCd ; $provTypCd")
      }
    }*/
  def getSnapShotParquetFilesForAllEntities(pitRowKey:String, refreshFlag:String,eitFlag:String):Boolean={

    //val entitiesStream = this.getClass.getResourceAsStream("/EPDERK4/Entities.txt" )
    val entitiesStream = this.getClass.getResourceAsStream(snapshotEntitiesFile )
    val entitiesList =scala.io.Source.fromInputStream(entitiesStream).getLines.toList
    val rawExtractProvider=new RawExtractProvider()(globalContext,pei)
    Logger.log.info("Pit Row Key : "+pitRowKey)
    EPDECommonUtil.getSnapShotParquetFiles(pei.feedName+"-"+pei.extractName+"-xyzw",entitiesList,refreshFlag,eitFlag)(globalContext ,pei,rawExtractProvider)
    true
  }

  def readFromMaprDB (doc_id:String): Boolean = {

    val x=globalContext.sparkContext.loadFromMapRDB("/datalake/uhclake/tst/t_hdfs/uhg/Enriched/standard_access/pjs/ndb/data/EPDE_PROV_JSON_snapshot").where(field("_id") === doc_id)
    val readJsonDF = x.toDF()
    readJsonDF.columns.foreach(a => {
      val colName = a.toString;
      println("Entity / Table Name : "+colName);
      if(colName != "_id" && colName != "doc_crt_ts"  ){
        println("in if ==>"+ colName )
        var colNameRes="";
        val entityDType = readJsonDF.select(colName).schema.map(_.dataType.typeName).take(1).mkString;
        if(entityDType.equals("array") ){
          println("dtype is array")
          val arrayLen=readJsonDF.select(size(readJsonDF.col(colName))).first
          val len=arrayLen(0).toString.toInt
          //println(arrayLen.apply(0))
          var z: org.apache.spark.sql.types.StructType=null
          var lst = new ListBuffer[Row]()
          for( a <- 0 until len){
            println(colName+"=========="+a)
            readJsonDF.select(col(colName).getItem(a)).toDF("xdf").createOrReplaceTempView("maprdbview");
            colNameRes="xdf"
            var entitySelectStr="select "+colNameRes.toString+".* from maprdbview";
            var colNameDF = globalContext.sqlContext.sql(entitySelectStr).first
            lst+=colNameDF
            z=colNameDF.schema
            //var temp=colNameDF
          }
          val rdd = globalContext.sparkContext.parallelize(lst.toSeq)
          val outputDf = globalContext.sqlContext.createDataFrame(rdd,z)
          //spark.catalog.dropTempView(doc_id+"_"+colName)
          outputDf.createOrReplaceTempView(doc_id+"_"+colName);
        }else{
          readJsonDF.select(colName).createOrReplaceTempView("maprdbview");
          colNameRes=colName
          println("dtype is struct")
          println("column to be considered for array type is : "+colNameRes)
          var entitySelectStr="select "+colNameRes.toString+".* from maprdbview";
          println("CONSTRUCTED SQL String to create Entity specific dataframe with respective columns   : "+entitySelectStr);
          var colNameDF = globalContext.sqlContext.sql(entitySelectStr)
          colNameDF.createOrReplaceTempView(doc_id+"_"+colName);
        }
      }})

    true
  }

  override def postStart()(implicit context: GlobalContext): Try[Unit] = {
    Try {
      Logger.log.info("Starting Job!!")


      /* val outFileNamelen = pei.outFileName.split('|').size
       val zipFileName = if (outFileNamelen > 1) pei.outFileName.split('|')(1) else ""
       val outFileName = pei.outFileName.split('|')(0)
     val outFileDelim = if (pei.outFileRowDelim == "NA") "\\n" else pei.outFileRowDelim*/
      //
      Logger.log.info(s"Job Started. Updating PIT table")
      context.pitTable.put(pitRowKey, "exi", "provCompSts", "inProgress")
      context.pitTable.put(pitRowKey, "fi", "provFeedName", pei.feedName)
      context.pitTable.put(pitRowKey, "fi", "provExtractName", pei.extractName)
      context.pitTable.put(pitRowKey, "fi", "provOutFileColDelim", pei.outFileColDelim)
      context.pitTable.put(pitRowKey, "fi", "srcCd", pei.srcCd)
      context.pitTable.put(pitRowKey, "fi", "prtnCd", pei.prtnrCd)
      context.pitTable.put(pitRowKey, "fi", "consumingApp", pei.consumingApp)
      context.pitTable.put(pitRowKey, "fi", "inputFileName", pei.inputFileName)

      /*  context.pitTable.put(
          (pitRowKey, "exi", "provCompSts", "inProgress"),
          (pitRowKey, "fi", "provFeedName", pei.feedName),
          (pitRowKey, "fi", "provExtractName", pei.extractName),
          (pitRowKey, "fi", "provOutFileColDelim", pei.outFileColDelim),
          (pitRowKey, "fi", "srcCd", pei.srcCd),
          (pitRowKey, "fi", "prtnCd", pei.prtnrCd),
          (pitRowKey, "fi", "consumingApp", pei.consumingApp),
          (pitRowKey, "fi", "inputFileName", pei.inputFileName)
          //        (pitRowKey, "fi", "inputFileLocation", pei.inputFileLocation),
          //        (pitRowKey, "fi", "entitySet", pei.entitySet),
          //        (pitRowKey, "fi", "provOutFileRowDelim", outFileDelim),
          //        (pitRowKey, "fi", "provOutFileLoc", pei.outFileLoc),
          //        (pitRowKey, "fi", "provOutFileNm", pei.outFileName)
          //      )
        )*/
      //  Logger.log.info(s"Updated PIT table with inprogress")
    }match{
      case Success(instance) =>
      {
        Logger.log.info("RK4 : EPDERK4JobRunner.postStart() : Updated PIT table with inprogress")
        Success()
      }
      case Failure(ex) => {
        Logger.log.info("RK4 : EPDERK4JobRunner.postStart() : " + ex.getMessage)
        throw ex
      }
    }
  }

  override def run(): Try[Unit] = {
    Try {
      val jsonFile= Some(readJsonFile())
      /*      if (!(pei.inputFileName.isEmpty() || pei.inputFileName.equalsIgnoreCase("NA"))) {
              Logger.log.info(s" Generating View by considering  the inputFileName provided : " + pei.inputFileName)
              val inputFileDetails = jsonFile.get.InputFileDetails.head
              if (inputFileDetails.isInputFileValidationRequired == "Y") {
                validateSrcFile(inputFileDetails)
              }
            }*/
      /*val refreshFlag="Y"
      val eitFlag="Y"*/
      //getProvContDF(env,provTypCd,vndrCd)
      getSnapShotParquetFilesForAllEntities(pitRowKey,refreshFlag,eitFlag)
      val extractProvider = new EPDERK4ExtractProvider

      //      val extractProvider = pei.snapBuildType match{
      //        case "raw"|"parquet" =>  new /*RawExtractProvider*/ EPDERK4ExtractProvider
      //        case "pjs" =>  new PJSExtractProvider
      //        case _ => new DefaultExtractProvider
      //      }

      // val outputFiles = extractProvider.extractEPDERK4(jsonFile,peiRowKey) //TODO: peiRowKey is being defined as job name. To check if this can be made available globally
      //val typFrm=Array("GROUP","PHYSICIAN","FACILITIES")

      //val lastRunPlc=CommonUtil.fetchPLCLastRunDt("EPDE-"+vndrCd)
      var lastRunPlc=CommonUtil.fetchPLCLastRunDt(peiRowKey)
      if(vndrCd.equalsIgnoreCase("CCN_MONTHLY")){
        lastRunPlc=CommonUtil.fetchPLCLastRunDt("EPDE-CCN_DAILY")
      }
      //val currentTime=CommonUtil.getDateTimeFormatET("YYYY-MM-dd HH:mm:ss")
      Logger.log.info(s"RK4 JobRunner ===> lastRunPlc for $peiRowKey <=="+lastRunPlc)
      //Logger.log.info(s"RK4 JobRunner ===> currentTime for $peiRowKey <=="+currentTime)
      val typFrm=Array(groupTypFrm,physicianTypFrm,facilitiesTypFrm)
      //val typFrm=Array(facilitiesTypFrm)
      var  peioutLocVal = ArrayBuffer[String]()
      val peiOutFileLocs = pei.outFileLoc.split(DPOConstants.SEMI_COLON)
      val peiExtractName=pei.consumingApp
      peiOutFileLocs.foreach(x=> peioutLocVal+=x.reverse.split('/')(1).reverse)
      // added to handle skipping of the typFRm based on pei entries

      var sftpFileDestinationList: List[String] = List.empty[String]

      //for(provTypCd<- typFrm) {
        if(peioutLocVal.contains(provTypCd)){
          //   var provTypCd="GROUP"
          Logger.log.info(s"INFO : Starting the extractEPDERK4 for $vndrCd and $provTypCd")
          Logger.log.info(s"INFO : Starting the extractEPDERK4 ;  ExtractName is  $peiExtractName")
          val outputFiles = extractProvider.extractEPDERK4(jsonFile, peiRowKey, vndrCd, provTypCd.toUpperCase,lastRunPlc,varfeedName,peiExtractName)
          val sftpFile = extractProvider.createZipFiles(vndrCd,provTypCd.toUpperCase)
          sftpFileDestinationList=sftpFileDestinationList:+sftpFile
          //extractProvider.createSftpFileForDestination(vndrCd,sftpFile)
          //TODO: Handle what is to be done with the result of the extraction and handle exception accordingly.
        }else{
          Logger.log.info(s"INFO :: Entry in PEI does NOT contains path for $provTypCd; entry in pei is --> ${pei.outFileLoc}")
        }
      //}
      extractProvider.createSftpFileForDestination(sftpFileDestinationList,vndrCd)
      extractProvider.createTouchFiles(vndrCd)
      val sftpTouchFile = ApplicationConfig.dataDir + DPOConstants.SLASH + vndrCd + DPOConstants.SLASH + ApplicationConfig.touchFileName
      extractProvider.createSftpFileForSource(vndrCd,sftpTouchFile)
      extractProvider.createMetaFile(vndrCd)
      //Update PLC table
      val stdLastRunPlc=CommonUtil.fetchPLCLastRunDt("EPDE-STANDARD")
      Logger.log.info(s"RK4 JobRunner ===> stdLastRunPlc for $peiRowKey <=="+stdLastRunPlc)
      CommonUtil.updatePLCLastRunDt(peiRowKey,stdLastRunPlc)
    }match{
      case Success(instance) =>
      {
        Logger.log.info("RK4 : EPDERK4JobRunner.run() : Success")
        Success()
      }
      case Failure(ex) => {
        Logger.log.info("RK4 : EPDERK4JobRunner.run() : " + ex.getMessage)
        //throw ex
        Failure(ex)
      }
    }

  }

  def readJsonFile(): ExtractFileEntity = {
    Logger.log.info(s"readSrcAsFile inititated with values feedName : $pei.feedName ,  extractName : $pei.extractName , inputFileName : $pei.inputFileName , rootDir : $rootDir , inputFileLocation : $pei.inputFileLocation , jsonPropFileLoc : $pei.jsonPropFileLoc")
    val rk4JsonFileName=pei.jsonPropFileLoc.split(";").apply(2).trim
    val jsonFileLoc = ApplicationConfig.jsonPathPrefix + DPOConstants.SLASH + rk4JsonFileName
    Logger.log.info("JSON file:" + jsonFileLoc)
    val inputJson = Source.fromFile(jsonFileLoc)("UTF-8").getLines.mkString.parseJson
    //val localJsonFileLoc = mountPrefix + File.separator + pei.jsonPropFileLoc.replaceAll("\"", "")
    // val localJsonFileLoc = mountPrefix + File.separator + "Input_Json\\\\EPDERK4.json"
    //val localJsonFileLoc = this.getClass.getResourceAsStream("/JsonFile/"+env+"/" + "RK4Json1.json" )
    // val localJsonFileLoc = this.getClass.getResourceAsStream("/JsonFile/"+env+"/" + "EPDERK4.json" )
    //Logger.log.info("JSON file:"+localJsonFileLoc)
    //val inputJson = Source.fromFile(localJsonFileLoc)("UTF-8").getLines.mkString.parseJson //replace with variable
    //val inputJson =scala.io.Source.fromInputStream(localJsonFileLoc).getLines.mkString.parseJson
    import com.uhg.optum.protocols.EPDERK4InputProtocol._
    val inputEntity = inputJson.convertTo[EPDERK4InputExtractInfo]

    Logger.log.info("File Read Complete.")

    //Reading the value of inputFileColumns
    /*    //temp starts
        val varfeedName="EPDE_Extraction"
        val varextractName="F5938RK4"
        //temp ends*/
    val feed = inputEntity.filter(_.feedName == varfeedName).head
    val extractFileDetails = feed.extraction.filter(_.programName == varextractName).head

    extractFileDetails
  }

  /*
    def validateSrcFile(inputFileDetails: InputFileDetails): Unit = {
      //    try {
      //      Logger.log.info(s"srcFileValidations initiated with values inputFileLoc : ${pei.inputFileLocation} ")
      //      var inFileRDD = sparkContext.textFile(pei.inputFileLocation)
      //      val rmcharInputFileName = pei.inputFileName.replace("_*", "")
      //
      //      var hdrDataRDD = inFileRDD.filter(_.startsWith(DPOConstants.HDR))
      //      //val hdrSchema = SparkUtil.createDFSchema("desc",None)
      //      var hdrRDDWithSchema = hdrDataRDD.map(a => trlHdrSchema(a.toString))
      //      import sqlContext.implicits._ // Fix this import
      //      // val hdrDataDF = SparkUtil.createDataFrame(hdrDataRDD,DPOConstants.PIPE,hdrSchema,sqlContext)
      //      //println(hdrDataDF.schema)
      //      var hdrDataDF = hdrRDDWithSchema.toDF()
      //      hdrDataDF.createOrReplaceTempView("InHdrRec")
      //
      //      var trlDataRDD = inFileRDD.filter(_.startsWith(DPOConstants.TRL))
      //      var trlRDDWithSchema = trlDataRDD.map(a => trlHdrSchema(a.toString))
      //      var trlDataDF = trlRDDWithSchema.toDF()
      //      println(trlDataDF.schema)
      //      trlDataDF.createOrReplaceTempView("InTrlRec")
      //
      //      val inputCols = inputFileDetails.inputFileColumns
      //      //val inputColSchema = SparkUtil.createDFSchema(inputCols, Some(DPOConstants.SEMI_COLON))
      //      val inputColSchema = StructType(inputCols.split(";").map(fieldName => StructField(fieldName, StringType, true)))
      //
      //      val dataRDD = inFileRDD.filter(_.startsWith(DPOConstants.DTL))
      //      val arrayRDD = dataRDD.map(_.split(inputFileDetails.inputFileColumnDelimiter))
      //      val dataDF = sqlContext.createDataFrame(arrayRDD.map(row => Row(row: _*)), inputColSchema)
      //      //println(dataDF.select("PEREQ_SBSCR_REL_ID"))
      //      //val dataDF = SparkUtil.createDFFromRDD(dataRDD,DPOConstants.PIPE,inputColSchema,sqlContext)
      //
      //
      //      //      var loadinputFileColumn = sqlContext.read.format("csv").option("delimiter", ";").option("header", "true").load("/datalake/uhclake/tst/developer/pankaj/scripts/chy_extract/PE_Reporting/D5687P_CHACCUMRSP/InputSchemaLocation_2018050703564360")
      //      //            var inputFileColumnsschema = loadinputFileColumn.schema
      //      //      //      //var dataDF = sqlContext.read.format("csv").option("delimiter", inputFileColumnDelimiter).schema(inputFileColumnsschema).load(inputFileLocation.replace("/mapr", "")).filter($"DTL".contains("DTL"))
      //      //            var dataDFF = sqlContext.read.format("csv").option("delimiter", inputFileDetails.inputFileColumnDelimiter).schema(inputFileColumnsschema)
      //      //              .load(pei.inputFileLocation.replace("/mapr", "")).filter($"DTL".contains("DTL"))
      //      //      //      val dataDF = dataDFF.withColumn("SeqNumF", monotonically_increasing_id())
      //      println(dataDF.schema)
      //      dataDF.createOrReplaceTempView(rmcharInputFileName)
      //
      //      val validationRules = inputFileDetails.inputFileValidationRules.head
      //
      //      var InErrVal = sqlContext.sql(validationRules.InputHeaderValidationRule)
      //      var errorValidation = InErrVal.filter($"status".contains("FAILED INPUT HDR VALIDATION"))
      //      if (errorValidation.count >= 1) {
      //        println("FAILED INPUT HDR VALIDATION")
      //        globalContext.sparkContext.stop
      //      }
      //      InErrVal = sqlContext.sql(validationRules.InputDataValidationRule)
      //      errorValidation = InErrVal.filter($"status".contains("FAILED INPUT DTL VALIDATION"))
      //      if (errorValidation.count >= 1) {
      //        println("FAILED INPUT DTL VALIDATION")
      //        globalContext.sparkContext.stop
      //      }
      //      InErrVal = sqlContext.sql(validationRules.InputDataValidationRule)
      //      errorValidation = InErrVal.filter($"status".contains("FAILED INPUT TRL VALIDATION"))
      //      if (errorValidation.count >= 1) {
      //        println("FAILED INPUT TRL VALIDATION")
      //        globalContext.sparkSession.stop
      //      }
      //    } catch {
      //      case e: Exception => {
      //        Logger.log.info(" Exception at Src File Validation : " + e.getMessage)
      //        Logger.log.error("Error occured : " + e.getStackTrace.mkString("\n"))
      //      }
      //        throw e
      //    }
    }
  */







}
