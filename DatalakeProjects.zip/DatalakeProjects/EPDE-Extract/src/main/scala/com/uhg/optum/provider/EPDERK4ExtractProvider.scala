package com.uhg.optum.provider
import java.io.File

import com.uhg.optum.EPDERK4JobRunner.PSC
import com.uhg.optum.JobRunner.PEI
import com.uhg.optum.common.{BaseRepository, DPOConstants, EPDERK4BaseExtractor}
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.InputJsonSchema
import com.uhg.optum.provider.snapshot.CommonSnapshotProvider
import com.uhg.optum.conf.ApplicationConfig._
import com.uhg.optum.protocols.EPDERK4InputJsonSchema.ExtractFileEntity
import com.uhg.optum.provider.RawExtractProvider.RawExtractionFailed
import com.uhg.optum.provider.snapshot.CommonSnapshotProvider.CommonSnapshotFailed
import com.uhg.optum.provider.extractors.{EPDERK4JsonSourceExtractor, MetaSourceExtractor}
import com.uhg.optum.provider.output.OuptutGenerator
import com.uhg.optum.util.FileSystemUtil.mergeToOneFile
import com.uhg.optum.util.{CommonUtil, FileSystemUtil, Logger, SparkUtil}
import com.uhg.optum.conf.ApplicationConfig.{datafilesDir}
import scala.io.Source
import scala.util.{Failure, Success, Try}
class EPDERK4ExtractProvider extends EPDERK4BaseExtractor with EPDERK4JsonSourceExtractor with MetaSourceExtractor with OuptutGenerator{


  //override def extractEPDERK4(jsonFile: Option[ExtractFileEntity], arg1: String)(implicit context: GlobalContext): Tuple2[String,String]= {
  override def extractEPDERK4(jsonFile: Option[ExtractFileEntity], peiRowKey: String,vndrCd:String,provTypCd:String,lastRunPlc:String,varfeedName:String,peiExtractName:String)(implicit context: GlobalContext, pei: PEI): Tuple2[String,String]= {
    try {
      val inputEntity = jsonFile.get
      var srcPath = ""

      val outputFilePath=workingDir+DPOConstants.SLASH+DPOConstants.SEGMENTS+DPOConstants.SLASH+vndrCd+DPOConstants.SLASH+provTypCd
      //val outputFilePath=datafilesDir+DPOConstants.SLASH+vndrCd+DPOConstants.SLASH+provTypCd
      Logger.log.info(s"INFO : inside extractEPDERK4, the outputFilePath for segments is $outputFilePath")
      srcPath = generateExtractFromJson(inputEntity: ExtractFileEntity,peiRowKey,outputFilePath,vndrCd,provTypCd,lastRunPlc,varfeedName,peiExtractName)

      println(".......srcPath..........." + srcPath)

      //  mergeToOneFile(srcPath, outputFilePath +  DPOConstants.SLASH + "RK4.csv")

      (srcPath,outputFilePath)
    } catch
      {
        case e: Exception => {
          Logger.log.info("RK4 : EPDERK4ExtractProvider.extractEPDERK4 :  Error Occured : "+e.getMessage )
          throw e
        }
      }

  }
}
