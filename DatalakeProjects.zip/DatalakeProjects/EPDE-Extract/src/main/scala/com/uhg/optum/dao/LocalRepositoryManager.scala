package com.uhg.optum.dao

import java.io.InputStream
import java.util

import com.uhg.optum.JobRunner.{CompareOperations, CustomFilter, DPOException}
import com.uhg.optum.common.{BaseRepository, BaseRepositoryManager, DAOModel}
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.util.Logger
import org.apache.hadoop.hbase.KeyValue
import org.apache.hadoop.hbase.client.{Put, Result, Scan}
import org.apache.hadoop.hbase.filter.CompareFilter.CompareOp
import org.apache.hadoop.hbase.filter.{CompareFilter, FilterList, PrefixFilter, SingleColumnValueFilter}
import org.apache.hadoop.hbase.io.ImmutableBytesWritable
import org.apache.hadoop.hbase.mapreduce.TableInputFormat
import org.apache.hadoop.hbase.spark.NewHBaseRDD
import org.apache.hadoop.hbase.util.Bytes
import org.apache.spark
import org.apache.spark.{InterruptibleIterator, Partition, TaskContext, rdd}
import org.apache.spark.rdd.RDD
import spray.json._

import scala.collection.mutable.ListBuffer
import scala.io.Source
import scala.util.Try

/**
  *
  * @param jsObject
  */
class LocalDAOModel(val jsObject: JsObject, val colFm: String) extends DAOModel {

}

/**
  * Created by paror18 on 9/18/2018.
  */
trait LocalRepositoryManager extends BaseRepositoryManager {

  import DefaultJsonProtocol._

  def getRepository(fileName: String): LocalRepository = {
    val stream: InputStream = getClass.getResourceAsStream(fileName)
    val source = Source.fromInputStream(stream)("UTF-8")
    try {
      val json = source.mkString.parseJson.asJsObject("Json Object Expected")
      new LocalRepository(json.asJsObject())
    } finally {
      source.close()
    }
  }

  def closeRepository(repo: BaseRepository) = {
    repo.close()
  }

  class LocalRepository(jsObject: JsObject) extends BaseRepository {

    def getValueByRowKey(rowKey: String, colFm: String, colNm: String): String = {
      Logger.log.info(s"Fetching value for rowKey: $rowKey and colFam: $colFm")
      jsObject match {
        case JsObject(values) =>
          values.get(rowKey).get.asJsObject("Instance Not Found in Json") match {
            case JsObject(rows) =>
              val cols = rows.get(colFm).get
              cols match{
                case JsObject(cols) =>
                  cols.get(colNm).get.convertTo[String]
              }

          }
      }
    }
    //
    //    def getValueByRowKey(rowKey: String, colFm: String, colNm: String): String = {
    //      Logger.log.info(s"Fetching value for rowKey: $rowKey and colFm: $colFm")
    //      val row = hbaseModel.get(rowKey)
    //      val value = row match {
    //        case Some(row) => row.get(colFm).map((_.get(colNm))).map(_.get).get
    //        case None => throw new DeserializationException(s"Instance not found in Json for  $rowKey")
    //      }
    //      value
    //    }

    def put(rowKey: String, colFm: String, colNm: String, value: String): Unit = {
      Logger.log.info("Updating PIT for:" +  colFm + "-" + colNm + " with value" + value)
    }

    override def put(values: (String, String, String, String)*): Try[Unit] = {
      Try {
        Logger.log.info(s"Bstch Update ")
      }
    }


    def get(rowKey: String, colFm: String): Try[LocalDAOModel] = {
      import com.uhg.optum.protocols.PEIProtocol._
      Logger.log.info(s"Fetching value for rowKey: $rowKey")
      Try {
        jsObject match {
          case JsObject(values) =>
            val rows = values.get(rowKey).get.asJsObject("PEI Instance Not Found in Json")
            new LocalDAOModel(rows, colFm)
        }
      }
    }

    def getWithFilter(rowKey: String, colFm: String, filters: CustomFilter*): Option[LocalDAOModel] = {
      val row = jsObject match {
        case JsObject(values) =>
          values.get(rowKey).get.asJsObject(s"Instance Not Found in Json for rowKey: $rowKey")
      }

        val jsonFilter =  for (filter <- filters) yield {
          val compareOperator = filter.compareOp
          row match {
                case JsObject(row) =>
                  val cols = row.get(filter.colFm).get
                  cols match{
                    case JsObject(cols) =>
                      val colValue = cols.get(filter.colValue).get.convertTo[String]
                      compareOperator match {
                        case CompareOperations.EQUAL =>
                          if (colValue.equalsIgnoreCase(filter.valueToBeCompared)) true else false
                      }
                  }
          }
        }
      val filteredRow = jsonFilter.forall(_ == true)
      if (filteredRow)
        Some(new LocalDAOModel(row, colFm))
      else
        None
    }

    /**
      *
      * @param rowKey
      * @param filters
      * @param context
      * @return
      */
    def scan(rowKey: String, filters: CustomFilter*)(implicit context: GlobalContext): RDD[Result] = {

      val hbaseModel = parse(jsObject)

      val matchedRows = hbaseModel.toList.filter(kv => {
        Bytes.toString(kv.getRow).startsWith(rowKey) &&
          filters.count(fl => {
            Bytes.toString(kv.getFamily) == fl.colFm &&
              Bytes.toString(kv.getQualifier) == fl.colValue &&
              Bytes.toString(kv.getValue) == fl.valueToBeCompared
          }) == filters.length
      })

      val scannedResult = context.sparkContext.parallelize(matchedRows)
      import scala.collection.JavaConverters._
      scannedResult.map(result => new Result(List(result).asJava))

    }


    /**
      *
      * @param rowKey
      * @param startTime
      * @param endTime
      * @param filters
      * @param context
      * @return
      */
    //Ignoring time comparison in this method
    def scanWithTimeRange(rowKey: String, startTime:String, endTime: String, filters: CustomFilter*)(implicit context: GlobalContext): RDD[Result] = {
      val hbaseModel = parse(jsObject)
      //TODO:Move this code to parse itself

      val matchedRows = hbaseModel.filter(kv => {
        Bytes.toString(kv.getRow).startsWith(rowKey) &&
          filters.count(fl => {
            Bytes.toString(kv.getFamily) == fl.colFm &&
              Bytes.toString(kv.getQualifier) == fl.colValue &&
              Bytes.toString(kv.getValue) == fl.valueToBeCompared
          }) == filters.length
      })

      import scala.collection.JavaConverters._
      //      new NewHBaseRDD(context.sparkContext,
      //        classOf[TableInputFormat],
      //        classOf[ImmutableBytesWritable],
      //        classOf[Result],
      //        job.getConfiguration,
      //        this) {
      //        override def compute(theSplit: Partition, context: TaskContext): InterruptibleIterator[(ImmutableBytesWritable, Result)] = {
      //          matchedRows.map(r => (new ImmutableBytesWritable(r.getKey), new Result(List(r).asJava)))
      //          new InterruptibleIterator[(ImmutableBytesWritable, Result)]()
      //        }
      //      }
      val test =context.sparkContext.parallelize(Seq("1","2"))
      test.collect()

      context.sparkContext.parallelize(matchedRows.map(r => new Result(List(r).asJava)))
    }

    /**
      *
      * @param jsObject
      * @return
      */
    def parse(jsObject: JsObject): Seq[KeyValue] = {
      val hbaseModel = jsObject.convertTo[Map[String, Map[String, Map[String, String]]]]
      val keyValues = hbaseModel.foldLeft(ListBuffer.empty[KeyValue])((result, data) => {
        val rowKey = data._1
        for (rowData <- data._2) {
          val colFamily = rowData._1
          for (cfData <- rowData._2) {
            val colName = cfData._1
            val colValue = cfData._2
            result.append(new KeyValue(Bytes.toBytes(rowKey), Bytes.toBytes(colFamily), Bytes.toBytes(colName), Bytes.toBytes(colValue)))
          }
        }
        result
      })
      keyValues.toSeq
    }

    def close(): Unit = {}
  }

}
