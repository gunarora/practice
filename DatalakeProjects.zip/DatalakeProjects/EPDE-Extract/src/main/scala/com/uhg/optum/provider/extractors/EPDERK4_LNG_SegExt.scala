package com.uhg.optum.provider.extractors

import com.uhg.optum.common.{BaseExtractor, DPOConstants}
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDERK4InputJsonSchema.SegmentDetails
import com.uhg.optum.provider.output.OuptutGenerator
import com.uhg.optum.util.{CommonUtil, EPDECommonUtil, FileSystemUtil, Logger}
import com.uhg.optum.util.CommonUtil.{createOrReplaceTempViewFn, executeQry}
import com.uhg.optum.util.FileSystemUtil._
import com.uhg.optum.conf.ApplicationConfig.{workingDir,schema}
import scala.util.Try

/**
  * Created by paror18 on 5/2/2019.
  */
trait EPDERK4_LNG_SegExt  extends OuptutGenerator {
  def lngSegGen(segDtls: SegmentDetails, glblVarLst:scala.collection.mutable.Map[String,String], outputFilePath : String)(implicit context: GlobalContext): String = {
    try{
      Logger.log.info("Inside lngSegGen")
      Logger.log.info("Initializing variables..")
      var retStr = "N"
      /*
          var WS_ACTV_CD_1 = glblVarLst.get("WS_ACTV_CD_1")
          var WS_ACTV_CD_2 = glblVarLst.get("WS_ACTV_CD_2")
          var WS_UPDT_DT_1 = glblVarLst.get("WS_UPDT_DT_1") //PTA_LST_UPDT_DT
          var WS_UPDT_DT_2 = glblVarLst.get("WS_UPDT_DT_2") //ADR_LST_UPDT_DT
          var WS_PREV_RUN_DT_YMD = glblVarLst.get("WS_PREV_RUN_DT_YMD")*/

      //TODO : to be removed later
      //    var ADD_FNL_VIEW = context.sparkSession.read.format("parquet").load("/datalake/uhclakedev/dataplatform/epde/d_datafiles/EXMNR/GROUP/ADD_FNL_VIEW")
      //    ADD_FNL_VIEW.createOrReplaceTempView("ADD_FNL_VIEW")



      if (segDtls.equals("") || segDtls == null) {
        Logger.log.info("No segment details present for LNG Segment")
      }
      if (!context.sparkSession.catalog.tableExists("ADD_FNL_VIEW")) {
        Logger.log.info("The temporary view ADD_FNL_VIEW from ADD segment is required for LNG segment")
      }

      var SchemaNm = DPOConstants.SCHEMA
      Logger.log.info("SchemaNm: " + SchemaNm)
      if (segDtls.segName.equals("LNG")) {
        EPDECommonUtil.generateSegTables(segDtls.segTables,glblVarLst)
        val segNm = segDtls.segName
        val segSeq = segDtls.segSeq
        segDtls.segQueries.map { qryKey =>
          if (qryKey.name.matches("LNG_FNL_VIEW")) {
            val LNG_FNL_VIEW =executeQry(glblVarLst,qryKey)
            createOrReplaceTempViewFn(LNG_FNL_VIEW, qryKey.name)
            saveFileToMapRFS_noDropNoRepartitionParquet(LNG_FNL_VIEW,outputFilePath,qryKey.name,"",DPOConstants.PARQUET)
            //if(LNG_FNL_VIEW.count > 0){
              /*FileSystemUtil.saveFileToMapRFS(LNG_FNL_VIEW,outputFilePath,qryKey.name,"",DPOConstants.PARQUET)*/
              retStr = "Y"
            //}
          }else{
            val df = executeQry(glblVarLst, qryKey)
            createOrReplaceTempViewFn(df, qryKey.name)
            //saveFileToMapRFS_noDrop(df,glblVarLst.get("tmpVwPath").getOrElse(workingDir),qryKey.name,"",DPOConstants.PARQUET)
          }
        }
      } else {
        retStr
      }
      retStr

    }catch {

      case e: Exception => {
        Logger.log.info(s"RK4 : EPDERK4_LNG_SegExt.genLNGSeg() : "+e.getMessage)
        throw e
      }

    }
  }

}
