package com.uhg.optum.common

import com.uhg.optum.JobRunner.CustomFilter
import com.uhg.optum.executors.GlobalContext
import org.apache.hadoop.hbase.client.Result
import org.apache.spark.rdd.RDD

import scala.util.Try

trait DAOModel

/**
  * Created by paror18 on 9/12/2018.
  */
trait BaseRepository {

  def getValueByRowKey(rowKey: String, colFm: String, colNm: String): String
  def put(rowKey: String, colFm: String, colNm: String, value: String): Unit
  def put(values: Tuple4[String, String, String, String]*): Try[Unit]
  def get(rowKey: String, colFm: String): Try[DAOModel]
  def getWithFilter(rowKey: String, colFm: String, filters: CustomFilter*): Option[DAOModel]
  def close(): Unit
}
