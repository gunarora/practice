package com.uhg.optum.common

import com.uhg.optum.JobRunner.PEI
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDEInputJsonSchema

import scala.util.Try

/**
  * Created by paror18 on 10/19/2018.
  */
trait EPDEBaseExtractor {
  def extractEPDE( jsonFile: Option[EPDEInputJsonSchema.ExtractFileEntity], pitRowKey: String,fullFileParam: String,peiRowKey: String)(implicit context: GlobalContext,pei: PEI): Try[Tuple2[String,String]]
}
