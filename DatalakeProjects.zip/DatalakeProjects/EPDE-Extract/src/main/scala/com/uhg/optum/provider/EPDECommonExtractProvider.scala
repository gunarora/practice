package com.uhg.optum.provider

import com.uhg.optum.common.{DPOConstants, EPDECommonBaseExtractor}
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDECommonInputJsonSchema.ExtractFileEntity
import com.uhg.optum.provider.extractors.{EPDECommonJsonSourceExtractor, MetaSourceExtractor}
import com.uhg.optum.provider.output.OuptutGenerator
import com.uhg.optum.util.Logger

class EPDECommonExtractProvider extends EPDECommonBaseExtractor with EPDECommonJsonSourceExtractor with MetaSourceExtractor with OuptutGenerator{


  override def extractEPDECommon(jsonFile: Option[ExtractFileEntity], peiRowKey: String, inboxPath: String, vndrCdDir : String,vendor_cd: String)(implicit context: GlobalContext): Tuple2[String,String]= {
    try {
      val inputEntity = jsonFile.get
      var srcPath = ""
      val inputParquetFilePath = inboxPath + DPOConstants.SLASH + vndrCdDir
      //val inputParquetFilePath = inboxPath

      Logger.log.info(s"INFO : inside extractEPDECommon, commonOutPath is $inboxPath")
      //val outputFilePath = s"/datalake/uhclake/tst/t_inbound/uhg/ndb/inbound/VS/Shivani_1/${vndrCd}/Physician/Provider/"
      Logger.log.info(":Input Parquet file path: " + inputParquetFilePath)
      srcPath = generateExtractFromJson(inputEntity, peiRowKey, inputParquetFilePath, inboxPath, vndrCdDir, vendor_cd).get

      //  mergeToOneFile(srcPath, outputFilePath +  DPOConstants.SLASH + "RK4.csv")

      (srcPath, inboxPath)
    } catch {
      case e: Exception => {
        Logger.log.info("Common : EPDECommonExtractProvider.extractEPDECommon :  Error Occured : " + e.getMessage)
        throw e
      }
    }
  }
}
