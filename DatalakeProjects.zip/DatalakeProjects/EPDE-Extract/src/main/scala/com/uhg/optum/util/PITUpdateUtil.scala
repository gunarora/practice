package com.uhg.optum.util

import com.uhg.optum.common.DPOConstants
import com.uhg.optum.dao.{HbaseRepositoryManager, LocalRepositoryManager}
import com.uhg.optum.executors.GlobalContext
import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD

import scala.util.{Failure, Success, Try}


class PITUpdateUtil {


  def updatePIT(pitStatus: String, logFileName: String,globalContext: GlobalContext): Try[Unit] = {
    Try {
      val sparkContext = globalContext.sparkContext
      val logFile = getRDD(sparkContext,logFileName)
      val extractTempPath = getTempExtractPath(logFile)
      if (extractTempPath == null) {
        Logger.log.error(" Did not find extractMeta variable in Logfile , so will not be able to found extractmeta.txt file..")
        globalContext.sparkContext.stop()
        System.exit(1)
      }

      Logger.log.info(" Found extractMeta directory : " + extractTempPath)

      val txtPath = extractTempPath.get + "/extractmeta.txt"
      Logger.log.info(" extractmeta Path to load in RDD " + txtPath)
      val metaRDD = getRDD(sparkContext,txtPath)

      val metaRDD1 = metaRDD.map(x => x.split("="))
      val pitRowKey = extractRowWithFilter("pitRowKey", metaRDD1)

      val extractFilePath = extractRowWithFilter("extractFilePath", metaRDD1)

      Logger.log.info(" SC metaRDD count " + metaRDD.count())
      Logger.log.info(" tempory metadata file content for this extract are..")

      Logger.log.info("===> pitRowKey : " + pitRowKey)
      Logger.log.info("===> extractFilePath : " + extractFilePath)

      updateHBaseField(globalContext,pitRowKey.get,pitStatus)
      rmFileOrPath(extractFilePath.get)

    }
  }

  def getTempExtractPath(logFile: RDD[String]): Try[String] = {
    Try {
      val extractTempPath = logFile.filter(_.contains("extractFilePath : ")).map(_.split(":")).map(x => x(4)).first.trim
      extractTempPath
    }
  }

  def extractRowWithFilter(filterValue: String, rDD: RDD[Array[String]]): Try[String] = {
    Try {
      val fetchedValue = rDD.filter(_.contains(filterValue)).map(x => x(1)).first
      fetchedValue
    }
  }

  def getRDD(sparkContext: SparkContext,filePath: String) : RDD[String] = {
    sparkContext.textFile(filePath)
  }

  def updateHBaseField(globalContext: GlobalContext,pitRowKey: String, pitStatus: String) : Try[Boolean] = {
    Try{
      val pitTable = globalContext.pitTable
      val provStartTime = pitTable.getValueByRowKey(pitRowKey, DPOConstants.PITCFEXI, "provStrTs")
      val provEndTs = CommonUtil.getCurrentTimeFormat
      //val duration = CommonUtil.getDuration(provEndTs, provStartTime)  //correct statement
      val startTm = CommonUtil.getCurrentTimeFormat         //Test, Need to be replaced
      val duration = CommonUtil.getDuration(provEndTs, startTm)  //Test, Need to be replaced
      Logger.log.info("===> duration : " + duration)

      pitTable.put(pitRowKey, DPOConstants.PITCFEXI, "provCompSts", pitStatus)
      Logger.log.info("===> Updated provCompSts : " + pitStatus + "in PIT htable")

      if (!pitStatus.equalsIgnoreCase("Provisioned")) {
        pitTable.put(pitRowKey, DPOConstants.PITCFEXI, "provDur", duration)
        Logger.log.info("===> Updated duration : " + duration + " in PIT htable")
        pitTable.put(pitRowKey, DPOConstants.PITCFEXI, "provEndTs", provEndTs)
        Logger.log.info("===> Updated provEndTs : " + provEndTs + " in PIT htable")
      }
      true
    }
  }

  def rmFileOrPath(extractFilePath: String) : Try[Boolean] = {
    Try {
      FileSystemUtil.rmPathIfExist(extractFilePath)
      Logger.log.info("===> Temp directory $extractFilePath deleted")
      true
    }
  }



}

