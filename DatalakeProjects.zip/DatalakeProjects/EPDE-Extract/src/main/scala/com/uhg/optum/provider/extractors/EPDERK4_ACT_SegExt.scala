package com.uhg.optum.provider.extractors

import com.uhg.optum.conf.ApplicationConfig.workingDir
import com.uhg.optum.common.DPOConstants
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDERK4InputJsonSchema.SegmentDetails
import com.uhg.optum.util.CommonUtil.{createOrReplaceTempViewFn, executeQry}
import com.uhg.optum.util.{CommonUtil, EPDECommonUtil, FileSystemUtil, Logger}

trait EPDERK4_ACT_SegExt {
  def genACTSeg(segDtls: SegmentDetails,varLst:collection.mutable.Map[String, String],glblVarLst:collection.mutable.Map[String, String],outputFilePath:String)(implicit context: GlobalContext): String = {
try{
    Logger.log.info("inside ACT")

    var resStr="N"

    var df = context.sqlContext.emptyDataFrame
    EPDECommonUtil.generateSegTables(segDtls.segTables,glblVarLst)
    segDtls.segQueries.map { qryKey =>

      if (qryKey.name.equals("ACT_FNL_VIEW")) {
        df = executeQry(varLst, qryKey).dropDuplicates()
        createOrReplaceTempViewFn(df, qryKey.name)
        //df.show
        FileSystemUtil.saveFileToMapRFSNoRepartitionParquet(df,outputFilePath,qryKey.name,"",DPOConstants.PARQUET)

        //if (df.count > 0) {
          //RPAD QUERY -> result -> write df res in file
         /* val actDf = CommonUtil.generateRpadQry(segDtls.segTarCol, segDtls.segTarLen, segDtls.segTolLen, qryKey.name)
          actDf.show
          FileSystemUtil.saveFileToMapRFS(actDf,glblVarLst.get("tmpVwPath").getOrElse(workingDir),qryKey.name,"",DPOConstants.TEXT)*/
           // generateOpFile(actDf, outputFilePath, qryKey.name+"rpad")
          //FileSystemUtil.saveFileToMapRFS(prvDf,outputFilePath,qryKey.name,"",DPOConstants.CSV)
          //FileSystemUtil.saveFileToMapRFS(df,outputFilePath,qryKey.name,"",DPOConstants.PARQUET)
          resStr="Y"
        //}
      }
      else  {
        df = executeQry(varLst, qryKey)
        createOrReplaceTempViewFn(df, qryKey.name)
        /*df.show
        FileSystemUtil.saveFileToMapRFS(df,glblVarLst.get("tmpVwPath").getOrElse(workingDir),qryKey.name,"",DPOConstants.PARQUET)*/
      }
    }
    resStr
}catch {

  case e: Exception => {
    Logger.log.info(s"RK4 : EPDERK4_ACT_SegExt.genACTSeg() : "+e.getMessage)
    throw e
  }

}
  }

}
