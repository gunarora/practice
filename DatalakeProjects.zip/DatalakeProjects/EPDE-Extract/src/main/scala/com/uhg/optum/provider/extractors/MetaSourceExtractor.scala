package com.uhg.optum.provider.extractors

import com.uhg.optum.JobRunner.{DPOException, PEI}
import com.uhg.optum.common.DPOConstants
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.provider.output.OuptutGenerator
import com.uhg.optum.util.Logger
import org.apache.spark.sql.DataFrame

/**
  * Created by rkalra on 1/21/2019.
  */
trait MetaSourceExtractor extends OuptutGenerator{
  def generateExtractFromMetaData(pei: PEI)(implicit context : GlobalContext): DataFrame={
    null
  }
  def generateExtractFromMetaData(pitRowKey: String)(implicit context : GlobalContext, pei: PEI): DataFrame = {
    Logger.log.info(" This extract doesn't have Json file as input, " +
      "so continuing with sqlQuery parameter mentioned in PEI table")

    if (pei.sqlQuery == "NA" || !pei.sqlQuery.toLowerCase().contains("select")) {
      Logger.log.error(" sqlQuery parameter is empty, ending provisioning extract  ")
      throw new DPOException("sqlQuery parameter is empty or contains invalid query, " +
        "so ending provisioning extract")
    } else {
      val finalDFView = generateExtractFromSqlQuery()
      val transformedDF = generateTransformedExtract(pei.trgColumn, pei.trgDataTypeLen, finalDFView, pitRowKey)
      transformedDF
    }

  }

  /**
    *
    */
  def generateExtractFromSqlQuery()(implicit context : GlobalContext, pei: PEI): String = {
    val latestView = if (pei.transQuery == "NA") {
      Logger.log.info (" Additional transformations query(substr, case etc) is passed as empty string, latest view to be considered is from sql Query fetched from pei ")
      createView (pei.sqlQuery, DPOConstants.NORMAL_QUERY_VIEW)
    } else {
      createView (pei.sqlQuery, DPOConstants.NORMAL_QUERY_VIEW)
      createView (pei.transQuery, DPOConstants.TRANS_QUERY_VIEW)
    }
    latestView
  }

  /**
    *
    * @param query
    * @param viewName
    * @return
    */
  def createView(query: String, viewName: String)(implicit context : GlobalContext, pei: PEI) : String = {
    Logger.log.debug(s" sql Query Fetched From PEI is   : ${query}  ")
    val curExtDFT = context.sqlContext.sql(query)
    Logger.log.info(" Count for the query is   : " + curExtDFT.count())
    curExtDFT.createOrReplaceTempView(viewName)
    viewName
  }
}

