package com.uhg.optum.provider.snapshot

/**
  * Created by paror18 on 10/24/2018.
  */
trait ParquetSnapshotProvider {

}
