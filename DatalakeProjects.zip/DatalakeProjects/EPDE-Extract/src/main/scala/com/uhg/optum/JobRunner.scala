package com.uhg.optum

import java.io.File

import com.uhg.optum.JobRunner._
import com.uhg.optum.common._
import com.uhg.optum.conf.ApplicationConfig
import com.uhg.optum.conf.ApplicationConfig._
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.DomainModel
import com.uhg.optum.protocols.EPDEInputJsonSchema._
import com.uhg.optum.provider.{DefaultExtractProvider, EPDEExtractProvider, PJSExtractProvider, RawExtractProvider}
import com.uhg.optum.util.Logger
import spray.json._

import scala.io.Source
import scala.util.{Failure, Success, Try}
import com.uhg.optum.protocols.PEIProtocol._
import com.uhg.optum.util.exceptions.{QueryFailureException, VendorSetupException}
object JobRunner  {

  case class PEI(feedName: String,
                 extractName: String,
                 hdrDesc: String,
                 hdrDateFormat: String,
                 trlDesc: String,
                 isJsonProp: String,
                 jsonPropFileLoc: String,
                 sqlQuery: String,
                 transQuery: String,
                 trgColumn: String,
                 trgDataTypeLen: String,
                 outFileName: String,
                 outFileExt: String,
                 outFileLoc: String,
                 archLoc: String,
                 isOutFileColDelim: String,
                 outFileColDelim: String,
                 isFixedWidth: String,
                 srcCd: String,
                 prtnrCd: String,
                 entitySet: String,
                 snapBuildType: String,
                 isOutFileRowDelim: String,
                 outFileRowDelim: String,
                 consumingApp: String,
                 inputFileName: String,
                 inputFileLocation: String,
                 inputLandingLocation: String) extends DomainModel

  case class PSC(
                  feedName: String,
                  extractName: String,
                  entNm: String,
                  prikeycols: String,
                  dmlcol: String,
                  activeflag: String,
                  modtscol: String,
                  fullLoadflg: String
                ) extends DomainModel

  case class SnapshotFileName(
                               EPDE_1_Entity_List: String,
                               EPDE_2_Entity_List: String,
                               EPDE_3_Entity_List: String,
                               EPDE_4_Entity_List: String,
                               EPDE_5_Entity_List: String,
                               EPDE_6_Entity_List: String,
                               EPDE_7_Entity_List: String,
                               EPDE_8_Entity_List: String,
                               EPDE_9_Entity_List: String
                             ) extends DomainModel

  case class CustomFilter(
                           colFm: String,
                           colValue: String,
                           compareOp: CompareOperations.Value,
                           valueToBeCompared: String
                         )

  object CompareOperations extends Enumeration{
    val LESS, LESS_OR_EQUAL , EQUAL, NOT_EQUAL, GREATER_OR_EQUAL, GREATER, NO_OP = Value
  }

  case class trlHdrSchema(desc: String)

  class PEIInstanceEmpty(msg: String, th: Throwable) extends Exception(msg, th)
  class PSCInstanceEmpty(msg: String, th: Throwable) extends Exception(msg, th)
  class ValueNotFound(msg: String, th: Throwable) extends Exception(msg,th)
  class InputFileValidationFailedException(msg: String) extends Exception(msg)

  class DPOException(msg: String) extends Exception(msg)


}

/**
  * Created by paror18 on 9/11/2018.
  */
class JobRunner(peiRowKey: String, env: String,fullFileParam: String,loc_env: String)(implicit val globalContext: GlobalContext) extends Job {
  val peTable = globalContext.peTable
  val pscTable = globalContext.pscTable
  val pitTable = globalContext.pitTable
  val plcTable = globalContext.plcTable

  implicit var pei: PEI = _

  override def jobName: String = peiRowKey

  override def preStart()(implicit context: GlobalContext): Try[Unit] = { super.preStart()(context)
    Logger.log.info(s" Scanning PEI HBase Table $peiTabName for ROWKEY :  ${peiRowKey} ")
    import com.uhg.optum.protocols.PEIProtocol._
    peTable.get(peiRowKey,"pei") match {
      case Success(instance) =>
        this.pei = instance
        Success()
      case Failure(ex) =>
        Failure(new PEIInstanceEmpty("Exception while getting the columns info from PEI Table", ex))
    }
  }

  override def postStart()(implicit context: GlobalContext): Try[Unit] = {
    Try {
      Logger.log.info("Starting Job!!")
      /*val outFileNamelen = pei.outFileName.split('|').size
      val zipFileName = if (outFileNamelen > 1) pei.outFileName.split('|')(1) else ""
      val outFileName = pei.outFileName.split('|')(0)
      val outFileDelim = if (pei.outFileRowDelim == "NA") "\\n" else pei.outFileRowDelim*/
      val outFileNamelen = pei.outFileName.size
      val zipFileName = if (outFileNamelen > 1) pei.outFileName else ""
      val outFileName = pei.outFileName
      val outFileDelim = if (pei.outFileRowDelim == "NA") "\\n" else pei.outFileRowDelim

      Logger.log.info(s"Job Started. Updating PIT table")
      context.pitTable.put(pitRowKey, "exi", "provCompSts", "inProgress")
      context.pitTable.put(pitRowKey, "fi", "provFeedName", pei.feedName)
      context.pitTable.put(pitRowKey, "fi", "provExtractName", pei.extractName)
      context.pitTable.put(pitRowKey, "fi", "provOutFileColDelim", pei.outFileColDelim)
      context.pitTable.put(pitRowKey, "fi", "srcCd", pei.srcCd)
      context.pitTable.put(pitRowKey, "fi", "prtnCd", pei.prtnrCd)
      context.pitTable.put(pitRowKey, "fi", "consumingApp", pei.consumingApp)
      context.pitTable.put(pitRowKey, "fi", "inputFileName", pei.inputFileName)
      context.pitTable.put(pitRowKey, "fi", "inputFileLocation", pei.inputFileLocation)
      context.pitTable.put(pitRowKey, "fi", "entitySet", pei.entitySet)
      context.pitTable.put(pitRowKey, "fi", "provOutFileRowDelim", outFileDelim)
      context.pitTable.put(pitRowKey, "fi", "provOutFileLoc", pei.outFileLoc)
      context.pitTable.put(pitRowKey, "fi", "provOutFileNm", pei.outFileName)
/*

      pitTable.put(
        (pitRowKey, "exi", "provCompSts", "inProgress"),
        (pitRowKey, "fi", "provFeedName", pei.feedName),
        (pitRowKey, "fi", "provExtractName", pei.extractName),
        (pitRowKey, "fi", "provOutFileColDelim", pei.outFileColDelim),
        (pitRowKey, "fi", "srcCd", pei.srcCd),
        (pitRowKey, "fi", "prtnCd", pei.prtnrCd),
        (pitRowKey, "fi", "consumingApp", pei.consumingApp),
        (pitRowKey, "fi", "inputFileName", pei.inputFileName),
        (pitRowKey, "fi", "inputFileLocation", pei.inputFileLocation),
        (pitRowKey, "fi", "entitySet", pei.entitySet),
        (pitRowKey, "fi", "provOutFileRowDelim", outFileDelim),
        (pitRowKey, "fi", "provOutFileLoc", pei.outFileLoc),
        (pitRowKey, "fi", "provOutFileNm", pei.outFileName)
      )
*/
    }match{
      case Success(instance) =>
      {
        Logger.log.info("RKP : JobRunner.postStart() : Updated PIT table with inprogress")
        Success()
      }
      case Failure(ex) => {
        Logger.log.info("RKP : JobRunner.postStart() : " + ex.getMessage)
        throw ex
      }
    }
  }

  override def run(): Try[Unit] = {
    Try {
      val jsonFile = pei.isJsonProp match{
        case "Y" => Some(readJsonFile())
        case "N" =>  None
      }

      if (!(pei.inputFileName.isEmpty() || pei.inputFileName.equalsIgnoreCase("NA"))) {
        Logger.log.info(s" Generating View by considering  the inputFileName provided : " + pei.inputFileName)

        val inputFileDetails = jsonFile.get.inputFileDetails.head
        if (inputFileDetails.isInputFileValidationRequired == "Y") {
          validateSrcFile(inputFileDetails)
        }
      }

      val extractProvider = pei.snapBuildType match{
        case "raw"|"parquet" =>  new /*RawExtractProvider*/EPDEExtractProvider
        /*case "pjs" =>  new PJSExtractProvider
        case _ => new DefaultExtractProvider*/
      }

      // val extractProvider = new EPDEExtractProvider
      val outputFiles = extractProvider.extractEPDE(jsonFile, pitRowKey, fullFileParam, peiRowKey)
    } match {
      case Success(instance) =>
        Logger.log.info("RKP: JobRunner Success")
        Success()
      case Failure(ex: VendorSetupException) => {
        Logger.log.error("RKP: Job Runner: " + ex.getMessage)
        //Logger.log.error("Error occured : " + ex.getStackTrace.mkString("\n"))
        throw ex
      }
      case Failure(ex: QueryFailureException) => {
        Logger.log.error("RKP: Job Runner: " + ex.getMessage)
        //Logger.log.error("Error occured : " + ex.getStackTrace.mkString("\n"))
        throw ex
      }
      case Failure(ex) =>
        Logger.log.error("RKP: Job Runner: " + ex.getMessage)
        //Logger.log.error("Error occured : " + ex.getStackTrace.mkString("\n"))
        throw ex
    }
  }

  def readJsonFile(): ExtractFileEntity = {
    val rkpJsonFileName=pei.jsonPropFileLoc.split(";").apply(0).trim
    val jsonFileLoc = ApplicationConfig.jsonPathPrefix + DPOConstants.SLASH + rkpJsonFileName
    Logger.log.info("JSON file:" + jsonFileLoc)
    val inputJson = Source.fromFile(jsonFileLoc)("UTF-8").getLines.mkString.parseJson

    //    Logger.log.info(s"readSrcAsFile inititated with values feedName : $pei.feedName ,  extractName : $pei.extractName , inputFileName : $pei.inputFileName , rootDir : $rootDir , inputFileLocation : $pei.inputFileLocation , jsonPropFileLoc : $pei.jsonPropFileLoc")
    // val localJsonFileLoc = mountPrefix + File.separator + pei.jsonPropFileLoc.replaceAll("\"", "")
//    val localJsonFileLoc = this.getClass.getResourceAsStream("/JsonFile/"+loc_env+"/" + "EPDE_Map.json" ) //ToDo

    //val localJsonFileLoc = ApplicationConfig.jsonPathPrefix + "/"+ pei.jsonPropFileLoc.replaceAll("\"", "").split(";").apply(0)
    //Logger.log.info("================localJsonFileLoc======================" +localJsonFileLoc)
//    val inputJson =scala.io.Source.fromInputStream(localJsonFileLoc)("UTF-8").getLines.mkString.parseJson //ToDo
    //val inputJson = Source.fromFile(localJsonFileLoc)("UTF-8").getLines.mkString.parseJson //replace with variable
    import com.uhg.optum.protocols.EPDEInputProtocol._
    //spray-json
    val inputEntity = inputJson.convertTo[EPDEInputExtractInfo]
    Logger.log.info("Input Entity: "+inputEntity)
    Logger.log.info("File Read Complete."+pei.feedName)

    //Reading the value of inputFileColumns
    val feed = inputEntity.filter(_.feedName == pei.feedName).head
    Logger.log.info("Feed: "+feed)
    val extractFileDetails = feed.extraction.filter(_.programName == pei.feedName).head
    //val extractFileDetails = feed.extraction.filter(_.programName == pei.extractName).head
    extractFileDetails
  }

  def validateSrcFile(inputFileDetails: InputFileDetails): Unit = {

  }

}
