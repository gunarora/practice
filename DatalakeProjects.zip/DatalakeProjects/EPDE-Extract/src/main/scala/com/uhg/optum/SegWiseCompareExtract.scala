package com.uhg.optum

import com.uhg.optum.conf.ApplicationConfig
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.{col, regexp_replace, udf}

object SegWiseCompareExtract {
  val fsConf = new Configuration()
  val fileSystem = FileSystem.get(fsConf)

  def main(args: Array[String]): Unit = {


    if (args.length.equals(5)) {
      val ndbExtPath = args(0)
      val dlExtPath = args(1)
      val outFileLoc = args(2)
      val segments = args(3)
      val removeSpecialCharFlag = args(4)
      compareOnBasisOfSeg(ndbExtPath, dlExtPath, outFileLoc, segments, removeSpecialCharFlag)

    } else if (args.length.equals(4)) {
      val ndbExtPath = args(0)
      val dlExtPath = args(1)
      val outFileLoc = args(2)
      val regexEx = args(3)
      filterOnBasisOfRegex(ndbExtPath, dlExtPath, outFileLoc, regexEx)

    } else {
      throw new Exception("More or less arguments are passed than required")
    }
    /* val ndbExtPath = args(0)
     val dlExtPath = args(1)
     val outFileLoc = args(2)
     val segments = args(3)
     val removeSpecialCharFlag = args(4)
     val spark = SparkSession
       .builder()
       .appName("SegCompareExtract")
       .config("hive.metastore.uris", ApplicationConfig.metaUri)
       .enableHiveSupport()
       .getOrCreate()
     val NDB_DF = spark.read.text(ndbExtPath)
     val DL_DF = spark.read.text(dlExtPath)
     var mfDF, dlDF = spark.sqlContext.emptyDataFrame
     mfDF = NDB_DF
     dlDF = DL_DF
     val fsConf = new Configuration()
     val fileSystem = FileSystem.get(fsConf)

     if (removeSpecialCharFlag.equalsIgnoreCase("Y")) {
       dlDF = DL_DF.columns.foldLeft(DL_DF) { (memoDF, colName) =>
         memoDF.withColumn(
           colName,
           regexp_replace(col(colName), "[^a-zA-Z0-9.:-]", "")
         )
       }
       mfDF = NDB_DF.columns.foldLeft(NDB_DF) { (memoDF, colName) =>
         memoDF.withColumn(
           colName,
           regexp_replace(col(colName), "[^a-zA-Z0-9.:-]", "")
         )
       }


     }
     segments.split(",").foreach((segment: String) => {
       println("============" + segment + "============")
       val segDlDF = dlDF.filter(col("value").startsWith(segment))
       val segMfDF = mfDF.filter(col("value").startsWith(segment))
       println("segDlDF " + segDlDF.count + "============")
       println("segMfDF " + segMfDF.count + "============")
       val diffRec1 = segMfDF.except(segDlDF)
       val diffRec2 = segDlDF.except(segMfDF)
       println("========================= Missed records count for " + segment + "  " + diffRec1.count + "     ========================")
       println("========================= Mismatched records count for " + segment + "  " + diffRec2.count + " ========================")
       val mismatchedRec = outFileLoc + "/" + segment + "/Mismatched_Records"
       saveDFOutputToMapR(diffRec2, mismatchedRec)
       val missedRec = outFileLoc + "/" + segment + "/Missed_Records"
       saveDFOutputToMapR(diffRec1, missedRec)
     })
 */
    /*def delete(path: String): Unit = {
      if (fileSystem.exists(new Path(path))) {
        fileSystem.delete(new Path(path), true)
      }
    }

    def saveDFOutputToMapR(diffRec: DataFrame, outFileLoc: String): Unit = {
      val outLoc = outFileLoc.replace("/mapr/", "/")
      delete(outLoc)
      diffRec.repartition(1).write.mode("overwrite").text(outLoc)
    }*/


  }

  def delete(path: String): Unit = {
    if (fileSystem.exists(new Path(path))) {
      fileSystem.delete(new Path(path), true)
    }
  }

  def saveDFOutputToMapR(diffRec: DataFrame, outFileLoc: String): Unit = {
    val outLoc = outFileLoc.replace("/mapr/", "/")
    delete(outLoc)
    diffRec.repartition(1).write.mode("overwrite").text(outLoc)
  }

  def compareOnBasisOfSeg(ndbExtPath: String, dlExtPath: String, outFileLoc: String, segments: String, removeSpecialCharFlag: String): Unit = {

    val spark = SparkSession
      .builder()
      .appName("SegCompareExtract")
      .config("hive.metastore.uris", ApplicationConfig.metaUri)
      .enableHiveSupport()
      .getOrCreate()
    val NDB_DF = spark.read.text(ndbExtPath)
    val DL_DF = spark.read.text(dlExtPath)
    var mfDF, dlDF = spark.sqlContext.emptyDataFrame
    mfDF = NDB_DF
    dlDF = DL_DF
    /* val fsConf = new Configuration()
     val fileSystem = FileSystem.get(fsConf)*/

    if (removeSpecialCharFlag.equalsIgnoreCase("Y")) {
      dlDF = DL_DF.columns.foldLeft(DL_DF) { (memoDF, colName) =>
        memoDF.withColumn(
          colName,
          regexp_replace(col(colName), "[^a-zA-Z0-9.:-]", "")
        )
      }
      mfDF = NDB_DF.columns.foldLeft(NDB_DF) { (memoDF, colName) =>
        memoDF.withColumn(
          colName,
          regexp_replace(col(colName), "[^a-zA-Z0-9.:-]", "")
        )
      }


    }
    segments.split(",").foreach((segment: String) => {
      println("============" + segment + "============")
      val segDlDF = dlDF.filter(col("value").startsWith(segment))
      val segMfDF = mfDF.filter(col("value").startsWith(segment))
      println("segDlDF " + segDlDF.count + "============")
      println("segMfDF " + segMfDF.count + "============")
      val diffRec1 = segMfDF.except(segDlDF)
      val diffRec2 = segDlDF.except(segMfDF)
      val matched = segDlDF.intersect(segMfDF)
      println("========================= Missed records count for " + segment + "  " + diffRec1.count + "     ========================")
      println("========================= Mismatched records count for " + segment + "  " + diffRec2.count + " ========================")
      val mismatchedRec = outFileLoc + "/" + segment + "/Mismatched_Records"
      saveDFOutputToMapR(diffRec2, mismatchedRec)
      val missedRec = outFileLoc + "/" + segment + "/Missed_Records"
      saveDFOutputToMapR(diffRec1, missedRec)
      val matchedRec = outFileLoc + "/" + segment + "/Matched_Records"
      saveDFOutputToMapR(matched, matchedRec)
    })
    spark.stop()
  }

  def filterOnBasisOfRegex(ndbExtPath: String, dlExtPath: String, outFileLoc: String, pattern: String): Unit = {

    val spark = SparkSession
      .builder()
      .appName("SegCompareExtractRegex")
      .config("hive.metastore.uris", ApplicationConfig.metaUri)
      .enableHiveSupport()
      .getOrCreate()
    val NDB_DF = spark.read.text(ndbExtPath)
    val DL_DF = spark.read.text(dlExtPath)
    var mfDF, dlDF = spark.sqlContext.emptyDataFrame
    mfDF = NDB_DF
    dlDF = DL_DF
    /* val fsConf = new Configuration()
     val fileSystem = FileSystem.get(fsConf)*/
    def trimData: (String => String) = { r => {
      r.trim
    }

    }

    val trimDataUDF = udf(trimData)

    /*if (removeSpecialCharFlag.equalsIgnoreCase("Y")) {
      dlDF = DL_DF.columns.foldLeft(DL_DF) { (memoDF, colName) =>
        memoDF.withColumn(
          colName,
          regexp_replace(col(colName), "[^a-zA-Z0-9.:-]", "")
        )
      }
      mfDF = NDB_DF.columns.foldLeft(NDB_DF) { (memoDF, colName) =>
        memoDF.withColumn(
          colName,
          regexp_replace(col(colName), "[^a-zA-Z0-9.:-]", "")
        )
      }


    }*/

    println("============" + pattern + "============")
    val segDlDF = dlDF.filter(col("value") rlike pattern)
    val segMfDF = mfDF.filter(col("value") rlike pattern)
    println("Datalake records after application of regex:" + segDlDF.count + "============")
    println("Mainframe records after application of regex :" + segMfDF.count + "============")
    val dlDfTrimmed = segDlDF.select(
      trimDataUDF(col("value"))
    )
    val mfDfTrimmed = segMfDF.select(
      trimDataUDF(col("value"))
    )
    val diffRec1 = mfDfTrimmed.except(dlDfTrimmed)
    val diffRec2 = dlDfTrimmed.except(mfDfTrimmed)
    val matched = mfDfTrimmed.intersect(dlDfTrimmed)
    /*println("========================= Missed records count for " + segment + "  " + diffRec1.count + "     ========================")
    println("========================= Mismatched records count for " + segment + "  " + diffRec2.count + " ========================")*/
    val mfPath = outFileLoc + "/" + "/mainframe"
    saveDFOutputToMapR(segMfDF, mfPath)
    val dlPath = outFileLoc + "/" + "/datalake"
    saveDFOutputToMapR(segDlDF, dlPath)
    val mismatchedRec = outFileLoc + "/" + "/Mismatched_Records"
    saveDFOutputToMapR(diffRec2, mismatchedRec)
    val missedRec = outFileLoc + "/" + "/Missed_Records"
    saveDFOutputToMapR(diffRec1, missedRec)
    val matchedRec = outFileLoc + "/" + "/Matched_Records"
    saveDFOutputToMapR(matched, matchedRec)

  }
}
