package com.uhg.optum.util

import java.io.File

import com.uhg.optum.JobRunner.PEI
import com.uhg.optum.common.DPOConstants
import com.uhg.optum.conf.ApplicationConfig
import com.uhg.optum.conf.ApplicationConfig._
import com.uhg.optum.conf.ApplicationConfig.cmnSnapPath
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDEInputJsonSchema.{ExtractFileEntity, QueryDetail}
import com.uhg.optum.provider.RawExtractProvider
import com.uhg.optum.provider.snapshot.CommonSnapshotProvider
import com.uhg.optum.util.exceptions.{QueryFailureException, VendorSetupException}
import org.apache.spark.sql.DataFrame

import scala.io.Source
import scala.util.{Failure, Success, Try}

object EPDECommonUtil {

  /**
    * This method creates the temporary view
    * for the input table names (semi colon delimited).
    * It also takes checkCommonSnapshot flag to check if fresh scan
    * is required or not.
    *
    * @param pitRowKey
    * @param tables
    * @param checkCommonSnapshot
    * @param globalContext
    * @param pei
    * @return
    */
  def getOrCreateSnapShots( pitRowKey: String,tables:String,checkCommonSnapshot:String)(implicit globalContext: GlobalContext,pei:PEI,rawExtractProvider: RawExtractProvider):String={
    //val rawExtractProvider=new RawExtractProvider()
    val tableList=tables.split(";").toList
    val pitTable = globalContext.pitTable
    var retString = ""
    val peiRowKey = pitRowKey.split("-")(0)+"-"+pitRowKey.split("-")(1)
    val pscRowKeyPart1 = peiRowKey.split("-")(0)
    // val inputPath = "" + File.separator + pitRowKey.split("-")(0) + "-Entity_List"
    //var entityFileList = Source.fromFile(inputPath)("UTF-8").getLines.toList.filterNot(x => x.contains('#')) //TODO: Reading file from local again. Check issues
    //TODO: must check from location of snapshots instead of file
    /* if (!entityFileList.isEmpty) {
       Logger.log.info("in the if of entityFileList.isEmpty")
       entityFileList=entityFileList.map(entity => entity.split("""\|""").apply(2).trim)

     }
     entityFileList.foreach(println)*/
    tableList.foreach { entity =>
      val rowKeyConfig = pscRowKeyPart1 + "-" + entity
      // val checkCommonSnapshot = "N"
      if (ApplicationConfig.isTriggerJobType.equalsIgnoreCase(DPOConstants.BDPAAS) && FileSystemUtil.isNonEmptyDir("/mapr/"+workingDir+"/"+ snapshotDir +"/"+entity) && checkCommonSnapshot.trim()!="N") {
        // ?? //      if (entityFileList.contains(entity) && checkCommonSnapshot.trim()!="N") {
        Logger.log.info(s"BDPass: Snapshot already exists for Entity: $entity. Proceeding to create Dataframe")
        retString = rawExtractProvider.getCommonSnapshotPerEntity(entity) //TODO: Can we rename it to something : createDataFrameForSnapshot
      }else if((ApplicationConfig.isTriggerJobType.equalsIgnoreCase(DPOConstants.KUBERNETES) || ApplicationConfig.isTriggerJobType.equalsIgnoreCase(DPOConstants.K8S) ) && FileSystemUtil.isNotEmptyDirMaprfs("maprfs:///"+workingDir+"/"+ snapshotDir +"/"+entity) && checkCommonSnapshot.trim()!="N"){
        Logger.log.info(s"K8S: Snapshot already exists for Entity: $entity. Proceeding to create Dataframe")
        retString = rawExtractProvider.getCommonSnapshotPerEntity(entity)
      } else {
        Logger.log.info(s"Calling for snapshot generation for entity: $entity")
        retString = rawExtractProvider.getSnapshotExtractPerEntity(rowKeyConfig, entity, pei, pitRowKey)

      }

    }

    retString
  }
  /*
    def getCommonSnapshotPerEntity(entity: String,path:String)(implicit context: GlobalContext): Try[String] = {
      Try{
        /* println("in getCommonSnapshotPerEntity ==========" + workingDir + "/snapshot/" + entity + "----")
         val entityDF = context.sparkSession.sqlContext.read.parquet(workingDir + "/snapshot/" + entity)
         println("in getCommonSnapshotPerEntity ==========" + workingDir + "/snapshot/" + entity + "----")*/
        println("in getCommonSnapshotPerEntity ==========" + path + "----")
        val entityDF = context.sparkSession.sqlContext.read.parquet(path)
        println("in getCommonSnapshotPerEntity ==========" + path +"----")
        Logger.log.info(entity + s" count from common snapshot: " + entityDF.count())
        entityDF.createOrReplaceTempView(s"${entity}")
        "Y"}
    }*/
  def getCommonSnapshotPerEntity(entity: String,path:String)(implicit context: GlobalContext): Unit = {
    try{
      /* println("in getCommonSnapshotPerEntity ==========" + workingDir + "/snapshot/" + entity + "----")
       val entityDF = context.sparkSession.sqlContext.read.parquet(workingDir + "/snapshot/" + entity)
       println("in getCommonSnapshotPerEntity ==========" + workingDir + "/snapshot/" + entity + "----")*/
      Logger.log.info("EPDECommonUtil: in getCommonSnapshotPerEntity ==========" + path + "----")
      Logger.log.info("EPDECommonUtil: Directory to read Parquet file--"+path)
      val entityDF = context.sparkSession.sqlContext.read.parquet(path)
      Logger.log.info("in getCommonSnapshotPerEntity ==========" + path +"----")
      //Logger.log.info(entity + s" count from common snapshot: " + entityDF.count())
      CommonUtil.createOrReplaceTempViewFn(entityDF,s"${entity}")
      // entityDF.createOrReplaceTempView(s"${entity}")

    }
    catch{
      case e:Exception=> {
        Logger.log.info("No files are present for table " + entity + " at path " + path)
        Logger.log.error("Error: " + e.getMessage)

      }
    }
  }

  /**
    * This method replaces the vendor code and last run date
    * with required values and make the dataframe for
    * the same
    * @param queryMap
    * @param key
    * @param valueToBeChecked
    * @param vendorCode
    * @param context
    * @return
    */
  def getDataframe(queryMap: Map[String, String], key: String, valueToBeChecked: String, vendorCode: String,lastRunPlc:String)(implicit context: GlobalContext,pei:PEI): Try[DataFrame] = {
    Try {
      Logger.log.info(s"RKP: EPDECommonUtil: getDataframe: Query name--->${key}")
      val venCheckQuery = queryMap.get(key).head.toString
      val tables = queryMap.get(key+"_tables").head.toString
      var optiVenCheckQuery = EPDECommonUtil.optimiseQuery(venCheckQuery, vendorCode, valueToBeChecked)
      // var lastRunPlc=CommonUtil.fetchPLCLastRunDt("EPDE-"+vendorCode)
      //lastRunPlc="2019-03-01"
      optiVenCheckQuery = EPDECommonUtil.optimiseQuery(optiVenCheckQuery, lastRunPlc, "$last_run_date")
      if( tables!=null && tables.trim !="" ){
        val rawExtractProvider=new RawExtractProvider()
        EPDECommonUtil.getOrCreateSnapShots("EPDE-"+vendorCode+"-xyzw",tables,"")(context ,pei,rawExtractProvider)
      }

      val df = EPDECommonUtil.getDataframeFromQuery(optiVenCheckQuery).get
      //df.persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)
      //FileSystemUtil.saveFileToMapRFS(df.dropDuplicates(),"/datalake/uhclake/tst/developer/pankaj/TestPoorvi/RKP9May/OPTUM_TEST",key+".csv","",DPOConstants.CSV)
      //df.repartition(1).write.mode("overwrite").option("delimiter", ",").option("header", "true").option("quote","\u0000").csv("/datalake/uhclake/tst/developer/pankaj/TestPoorvi/RKP9May/OPTUM_TEST"+key)
      df
    } match {
      case Success(df) => Logger.log.info("Success")
        Success(df)
      case Failure(ex) => {
        Logger.log.error("RKP: EPDECommonUtil: getDataframe 5 params " + ex.getMessage)
        //Logger.log.error("Error occured : " + ex.getStackTrace.mkString("\n"))
        throw ex
      }
    }

  }

  /**
    * This method creates the temporay view and returns
    * dataframe
    *
    * @param queryMap
    * @param key
    * @param valueToBeChecked
    * @param vendorCode
    * @param context
    * @return
    */
  //@throws(classOf[Exception])
  def getTempView(queryMap: Map[String, String], key: String, valueToBeChecked: String, vendorCode: String,lastRunPlc: String)(implicit context: GlobalContext,pei:PEI): DataFrame = {
    try {

      val df = getDataframe(queryMap: Map[String, String], key: String, valueToBeChecked: String, vendorCode: String,lastRunPlc).get
      df.createOrReplaceTempView(key)
      Logger.log.info("RKP: EPDECommonUtil: Temp view created for the " + key)
      df
    }
    catch {
      case e: Exception => {
        Logger.log.error("EPDECommonUtil: getTempView " + e.getMessage)
        throw e
      }
    }


  }

  /**
    * This method returns common query details
    * contained in input json.
    * @param inputEntity
    * @return
    */
  def getCommonQueriesDetails(inputEntity: ExtractFileEntity): Try[Seq[QueryDetail]] = {
    Try{
      Logger.log.info("RKP: EPDECommonUtil: getCommonQueriesDetails")
      val commQueries = inputEntity.extractDetails.head.commonQueries
      commQueries
    }match {
      case Success(commQueries) => Logger.log.info("Success")
        Success(commQueries)
      case Failure(ex) => {
        Logger.log.error("RKP: EPDECommonUtil: getCommonQueriesDetails " + ex.getMessage)
        throw ex
      }
    }

  }

  /**
    * This method returns common query details
    * * contained in input json.
    *
    * @param inputEntity
    * @return
    */
  def getContractQueriesDetails(inputEntity: ExtractFileEntity): Try[Seq[QueryDetail]] = {
    Try {
      Logger.log.info("RKP: EPDECommonUtil: getContractQueriesDetails")
      val contQueriesDetails = inputEntity.extractDetails.head.contractQueries
      contQueriesDetails
    }match {
      case Success(contQueriesDetails) => Logger.log.info("RKP: EPDECommonUtil: getContractQueriesDetails: Success")
        Success(contQueriesDetails)
      case Failure(ex) => {
        Logger.log.error("RKP: EPDECommonUtil: getContractQueriesDetails: " + ex.getMessage)
        throw ex
      }
    }
  }

  /**
    * This method returns dataframe for
    * the input query
    * @param query
    * @param context
    * @return
    */
  //@throws(classOf[Exception])
  def getDataframeFromQuery(query: String)(implicit context: GlobalContext): Try[DataFrame] = {
    Try {
      Logger.log.info(s"RKP: EPDECommonUtil: getDataframeFromQuery method ")
      if (query == null || query.isEmpty || !query.trim.toUpperCase.startsWith("SELECT")) {
        throw new QueryFailureException("Cannot make DF as Query is empty or NULL")
      }
      val queryDF = context.sqlContext.sql(query)
      Logger.log.info(s"RKP: EPDECommonUtil: getDataframeFromQuery DF Query: "+query)
      //Logger.log.info(s"DF count: "+queryDF.count)
      //Logger.log.info(s"DF: "+queryDF.show(false))
      Logger.log.info(s"RKP: EPDECommonUtil: getDataframeFromQuery Done Register")
      queryDF
    } match {
      case Success(queryDF) => Logger.log.info("Success")
        Success(queryDF)
      case Failure(ex: QueryFailureException) => {
        Logger.log.error("RKP: EPDECommonUtil: getDataframeFromQuery " + ex.getMessage)
        //Logger.log.error("Error occured : " + ex.getStackTrace.mkString("\n"))
        throw ex
      }
      case Failure(ex) => {
        Logger.log.error("RKP: EPDECommonUtil: getDataframeFromQuery " + ex.getMessage)
        //Logger.log.error("Error occured : " + ex.getStackTrace.mkString("\n"))
        throw ex
      }
    }
  }

  /**
    * This method optimises the input query
    * as per the vendor code and last run date
    * by replacing the values
    * @param query
    * @param newValue
    * @param oldValue
    * @return
    */
  def optimiseQuery(query: String, newValue: String, oldValue: String): String = {
    val retVal = query.replace(oldValue, newValue)
    retVal
  }

  /**
    * This method loads the include table into
    * the datafarme for the input contract queries
    *
    * @param contQueries
    * @param vendorCode
    * @param inputEntity
    * @param context
    *
    * @return
    */
  @throws[Exception]
  def loadIncludeTable(contQueries: Map[String, String], vendorCode: String, inputEntity: ExtractFileEntity,lastRunPlc:String)(implicit context: GlobalContext,pei:PEI): DataFrame = {
    Logger.log.info("RKP: EPDECommonUtil: loadIncludeTable: TR6")
    val df6 = EPDECommonUtil.getDataframe(contQueries, "df6_query", "$vendor_cd", vendorCode: String,lastRunPlc:String).get
    //df6.show
    val df6Cnt= df6.count
    Logger.log.info("RKP: EPDECommonUtil: loadIncludeTable: TR6 Counts: "+df6Cnt)
    if (df6Cnt > 3000) {
      Logger.log.info("RKP: EPDECommonUtil: TR6 :Cannot have count more than 3000 records")
      throw new VendorSetupException("Vendor Setup Error : Load include table count more than 3000")
    }
    df6
  }

  /**
    * This method loads the exclude table into
    * the dataframe for the input contract queries
    *
    * @param contQueries
    * @param vendorCode
    * @param inputEntity
    * @param context
    * @return
    */
  def loadExcludeTable(contQueries: Map[String, String], vendorCode: String, inputEntity: ExtractFileEntity,lastRunPlc:String)(implicit context: GlobalContext,pei:PEI): DataFrame = {

    val df7 = EPDECommonUtil.getDataframe(contQueries, "df7_query", "$vendor_cd", vendorCode: String,lastRunPlc:String ).get
    val df7Cnt= df7.count
    Logger.log.info("RKP: EPDECommonUtil: loadExcludeTable: TR7 Counts: "+df7Cnt)
    if (df7Cnt > 3000) {
      Logger.log.info("RKP: EPDECommonUtil: TR7 :Cannot have count more than 3000 records")
      throw new VendorSetupException("Vendor Setup Error : Load exclude table count more than 3000")
    }
    df7
  }
  /**
    * This method replaces the vendor code and last run date
    * with required values and make the dataframe for
    * the same
    * @param queryMap
    * @param key
    * @param valueToBeChecked
    * @param vendorCode
    * @param nonParToBeChecked
    * @param nonParInd
    * @param context
    * @return
    */
  def getDataframe(queryMap: Map[String, String], key: String, valueToBeChecked: String, vendorCode: String,nonParToBeChecked: String, nonParInd: String,lastRunPlc:String)(implicit context: GlobalContext,pei:PEI): Try[DataFrame] = {
    Try {
      val venCheckQuery = queryMap.get(key).head.toString
      val tables = queryMap.get(key+"_tables").head.toString
      var optiVenCheckQuery = EPDECommonUtil.optimiseQuery(venCheckQuery, vendorCode, valueToBeChecked)
      var optiNonParCheckQuery = EPDECommonUtil.optimiseQuery(optiVenCheckQuery, nonParInd, nonParToBeChecked)
      //var lastRunPlc=CommonUtil.fetchPLCLastRunDt("EPDE-"+vendorCode)
      //lastRunPlc="2019-03-01"
      optiVenCheckQuery = EPDECommonUtil.optimiseQuery(optiNonParCheckQuery, lastRunPlc, "$last_run_date")
      if( tables!=null && tables.trim !="" ){
        val rawExtractProvider=new RawExtractProvider()
        EPDECommonUtil.getOrCreateSnapShots("EPDE-"+vendorCode+"-xyzw",tables,"")(context ,pei,rawExtractProvider)
      }
      val df = EPDECommonUtil.getDataframeFromQuery(optiVenCheckQuery).get
      Logger.log.info("EPDECommonUtil: Received df from getDataframeFromQuery")
      //df.persist(org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK)
      //df.repartition(1).write.mode("overwrite").option("delimiter", ",").option("header", "true").option("quote","\u0000").csv("/datalake/uhclake/tst/developer/pankaj/TestPoorvi/RKP9May/OPTUM_TEST"+key)
      df
    } match {
      case Success(df) => Logger.log.info("getDataframe: Success")
        Success(df)
      case Failure(ex) => {
        Logger.log.error("RKP: EPDECommonUtil: getDataframe 7 params " + ex.getMessage)
        //Logger.log.error("Error occured : " + ex.getStackTrace.mkString("\n"))
        throw ex
      }
    }
  }


  def getSnapShotParquetFiles(pitRowKey: String, tables: List[String], refreshFlag: String, eitFlag: String)(implicit globalContext: GlobalContext, pei: PEI, rawExtractProvider: RawExtractProvider): String = {
    var retString = ""
    //val peiRowKey = pitRowKey.split("-")(0) + "-" + pitRowKey.split("-")(1)
    val pscRowKeyPart1 = pitRowKey.split("-")(0)
    //val pscRowKeyPart1 = peiRowKey
    tables.foreach { entity =>
      val tableName = schema + "_" + entity
      //val rowKeyConfig = peiRowKey + "-" + tableName
      val rowKeyConfig = pscRowKeyPart1 + "-" + tableName

      if (ApplicationConfig.isTriggerJobType.equalsIgnoreCase(DPOConstants.BDPAAS) && (!FileSystemUtil.isNonEmptyDir(mountPrefix + "/"+workingDir + "/"+snapshotDir +"/"+ tableName)) || refreshFlag.trim().equals("Y")) {
        Logger.log.info(s"Calling for snapshot generation for entity: $tableName")
        retString = rawExtractProvider.getSnapshotExtractPerEntity(rowKeyConfig, tableName, pei, pitRowKey, eitFlag)
      }else if ((ApplicationConfig.isTriggerJobType.equalsIgnoreCase(DPOConstants.KUBERNETES) || ApplicationConfig.isTriggerJobType.equalsIgnoreCase(DPOConstants.K8S) ) && (!FileSystemUtil.isNotEmptyDirMaprfs(  "maprfs:///"+workingDir + "/"+snapshotDir +"/"+ tableName)) || refreshFlag.trim().equals("Y")) {
      Logger.log.info(s"Calling for snapshot generation for entity: $tableName")
      retString = rawExtractProvider.getSnapshotExtractPerEntity(rowKeyConfig, tableName, pei, pitRowKey, eitFlag)
    }
      /*      ///VS TEMP
            else{
              Logger.log.info("INFO : Inside else")
              var path="/mapr/"+workingDir+"/snapshot/"+tableName
              var df=globalContext.sqlContext.read.parquet(path.replace("/mapr/", "/"))
              df.createOrReplaceTempView(tableName)
            }
            ///VS TEMP*/

    }

    retString
  }


  def generateSegTables(pipeDeliTables: String,globalVarLst: collection.mutable.Map[String, String])(implicit context: GlobalContext): Unit = {
    try {
      if (pipeDeliTables.trim.length != 0) {
        val vendorCode:String=globalVarLst("${ACTUAL_VENDR_CD}")
        val provTypCd:String=globalVarLst("provTypCd")
        val outputFilePath :String=globalVarLst("outputFilePath")
        val tmpVwPath :String=globalVarLst("tmpVwPath")

        context.sparkSession.sqlContext.clearCache()
        var counter = 0
        pipeDeliTables.split("\\|").foreach((tables: String) => {
          var path=""
          tables.split(";").foreach((tableName: String) => {
            if (!tableName.trim.equals("")) {

              if (context.sparkSession.catalog.tableExists(s"${schema}_${tableName.trim}")) {
                Logger.log.info(s"INFO : The temporary view ${schema}_${tableName.trim} EXISTS ")
              }else{
                if (counter == 0) {
                  Logger.log.info("Generating the dataframe from the parquet files of DL Table entities used in this segment")
                  path = workingDir + DPOConstants.SLASH + snapshotDir + DPOConstants.SLASH + schema + "_" + tableName.trim()
                  Logger.log.info("counter " + counter + " path " + path)
                  EPDECommonUtil.getCommonSnapshotPerEntity(schema + "_" + tableName, path)
                } else if (counter == 1) {
                  Logger.log.info("Generating the dataframe from the parquet files of Segment Views used in this segment")

                  //path=workingDir+DPOConstants.SLASH+"segments"+"/"+vendorCode+"/"+provTypCd+"/"+tableName
                  path = outputFilePath + DPOConstants.SLASH + tableName

                  Logger.log.info("counter " + counter + " path " + path)
                  //context.sparkSession.sqlContext.clearCache()
                  EPDECommonUtil.getCommonSnapshotPerEntity(tableName, path)
                } else if (counter == 2) {
                  Logger.log.info("Generating the dataframe from the parquet files of Temporay View used in this segment")

                  //            path=workingDir+"/"+vendorCode+"/"+provTypCd+"/"+tableName
                  path = tmpVwPath + DPOConstants.SLASH + tableName

                  Logger.log.info("counter " + counter + " path " + path)
                  //context.sparkSession.sqlContext.clearCache()
                  EPDECommonUtil.getCommonSnapshotPerEntity(tableName, path)
                } else if (counter == 3) {
                  Logger.log.info("Generating the dataframe from the parquet files for RKP Common Provider Contracter file used in this segment" + tableName)
                  if (tableName.equalsIgnoreCase("SELPROV")) {
                    //val pPath = inboxDir + "/" + vendorCode + "/" + provTypCd + "/" + provider_par
                    val pPath = inboxDir + "/" + vendorCode + "/" + provTypCd + "/" + provider_par
                    Logger.log.info("counter " + counter + " path " + pPath)
                    getCommonSnapshotPerEntity(tableName, pPath)
                  }
                  if (tableName.equalsIgnoreCase("SELCONT")) {
                    val cPath = inboxDir + "/" + vendorCode + "/" + provTypCd + "/" + contract_par
                    //context.sparkSession.sqlContext.clearCache()
                    Logger.log.info("counter " + counter + " path " + cPath)
                    getCommonSnapshotPerEntity(tableName, cPath)
                  }
                }
              }
            }
          }
          )
          counter=counter+1
        })




        /*s.segTables.split(";").foreach((tableName:String)=>{
          context.sparkSession.sqlContext.clearCache()
          EPDECommonUtil.getCommonSnapshotPerEntity(schema+"_"+tableName)})*/
      }

    }
    catch{
      case e: Exception => {
        Logger.log.error("EPDECommonUtil.generateSegTables() "+e.getMessage )
        throw e
      }
    }
  }

}
