package com.uhg.optum.provider

import com.uhg.optum.JobRunner.PEI
import com.uhg.optum.common.BaseExtractor
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.provider.extractors.{JsonSourceExtractor, MetaSourceExtractor}
import com.uhg.optum.protocols.EPDEInputJsonSchema.{ExtractDetail, ExtractFileEntity}
import com.uhg.optum.provider.DefaultExtractProvider.{ExtractOutput, ProvExtractOutput, ProvNContExtractOutput}
import com.uhg.optum.provider.output.OuptutGenerator
import com.uhg.optum.util.Logger
import org.apache.spark.sql.DataFrame

/**
  * Created by paror18 on 10/19/2018.
  */
object DefaultExtractProvider {

  case class ProvExtractOutput(provCount: Long,
                               provLoc: String,
                               provFileName: String,
                               isMetaFileCreated: Boolean
                              )

  case class ProvNContExtractOutput(provCount: Long,
                                    provFileName: String,
                                    contCount: Long,
                                    contFileName: String,
                                    outLoc: String
                                   )

  case class ExtractOutput(
                            extractLocation: String,
                            extractFiles: String
                          )

}


class DefaultExtractProvider(implicit val context: GlobalContext, pei: PEI) extends BaseExtractor with JsonSourceExtractor with MetaSourceExtractor with OuptutGenerator {

  val pitTable = context.pitTable



  /**
    * This method generates the output files for the
    * input provider and contractor dataframes at
    * location given in json file
    *
    * @param provDataFrame
    * @param contDataframe
    * @param inputEntity
    * @param pitRowKey
    * @return
    */
  def generateJsonExtract(provDataFrame: DataFrame, contDataframe: DataFrame, inputEntity: ExtractDetail, pitRowKey: String): ProvNContExtractOutput = {
    generateFilesForProvNCont(provDataFrame: DataFrame, contDataframe: DataFrame, inputEntity: ExtractDetail, pitRowKey: String)
  }


  override def extract(jsonFile: Option[ExtractFileEntity], pitRowKey: String): ExtractOutput = {
    jsonFile match {
      case Some(inputEntity) => {
        generateJsonExtract(inputEntity, pitRowKey)
      }
      case None => {
        val extractOp = generateExtractFromMetaData(pitRowKey)
        generateOpForMetaExtract(extractOp, pitRowKey)
      }
    }
  }

  /**
    *
    * @param inputEntity
    * @param pitRowKey
    * @return
    */
  def generateJsonExtract(inputEntity: ExtractFileEntity, pitRowKey: String): ExtractOutput = {
    var partFileNameLen = 0
    val provsOutput = inputEntity.extractDetails.map(prov => {
      partFileNameLen = prov.provName.split('|').length
      generateJsonExtractForEachProv(inputEntity, prov.provNo.toInt, prov.provName, pitRowKey)
    })

    val provCount = inputEntity.extractDetails.size
    val extractOutput = if (provCount > 1) createMergedOpForAllProvs(inputEntity, provsOutput, provCount, pitRowKey, partFileNameLen) else (provsOutput(0).provLoc, provsOutput(0).provFileName)

    val isMetaFileCreated = provsOutput.map(provOp => provOp.isMetaFileCreated)
    //This assumes if metaFileCreated is true or false for one element, it will be same for all
    if (!isMetaFileCreated(0)) {
      createMetaFile(pei.outFileName, extractOutput._1, extractOutput._2, pitRowKey)
    }

    ExtractOutput(extractOutput._1, extractOutput._2)
  }

  /**
    *
    * @param inputEntity
    * @param provNo
    * @param provName
    * @param pitRowKey
    * @param pei
    * @return
    */
  def generateJsonExtractForEachProv(inputEntity: ExtractFileEntity, provNo: Int, provName: String, pitRowKey: String)(implicit pei: PEI): ProvExtractOutput = {
    val provOp = generateExtractFromJson(inputEntity, provNo, pitRowKey)
    generateOpForEachProv(inputEntity, provOp, provNo, provName, pitRowKey)
  }


  /**
    *
    * @param inputEntity
    * @param provsOutput
    * @param provCount
    * @param pitRowKey
    * @param partFileNameLen
    * @return
    */
  def createMergedOpForAllProvs(inputEntity: ExtractFileEntity, provsOutput: Seq[ProvExtractOutput], provCount: Int, pitRowKey: String, partFileNameLen: Int): Tuple2[String, String] = {
    val mergedOp = generateMergedOpForJsonExtract(inputEntity, provsOutput, partFileNameLen)
    val provFileNames = provsOutput.map(prov => prov.provFileName)
    pitTable.put(pitRowKey, "fi", "provFileNames", provFileNames.mkString(";"))
    pitTable.put(pitRowKey, "fi", "provFileCnt", provCount.toString)
    pitTable.put(pitRowKey, "fi", "provCompSts", "extracted")

    mergedOp
  }

  /**
    *
    * @param inputEntity
    * @param provOp
    * @param provNo
    * @param provName
    * @param pitRowKey
    * @return
    */
  def generateOpForEachProv(inputEntity: ExtractFileEntity, provOp: DataFrame, provNo: Int, provName: String, pitRowKey: String): ProvExtractOutput = {
    val provResult = generateOpForProv(inputEntity, provNo, provOp)
    val metaFileCreated = createMetaFileForProv(inputEntity.isOutputMerge, provName, provResult, pitRowKey)
    //Case classes are immutable entities, therefore variables cannot be changed. So,
    // a new instance is created by updating a value and keeping remaining smae
    val updatedProvResult = provResult.copy(isMetaFileCreated = metaFileCreated)
    updatedProvResult
  }

  /**
    *
    * @param isOutputMerge
    * @param prtFileName
    * @param provResult
    * @param pitRowKey
    * @return
    */
  def createMetaFileForProv(isOutputMerge: String, prtFileName: String, provResult: ProvExtractOutput, pitRowKey: String): Boolean = {
    var isMetaFileCreated = false
    if (!isOutputMerge.equalsIgnoreCase("yes")) {
      val prtFileNameLen = prtFileName.split('|').length
      if (prtFileNameLen > 1) {
        Logger.log.info(s" Generating separate meta file : ${provResult.provLoc} :: ::${provResult.provFileName}")
        val metaContent = createMetaFile(prtFileName, provResult.provLoc, provResult.provFileName, pitRowKey)
        isMetaFileCreated = true
      }
    }
    isMetaFileCreated
  }

  /**
    *
    * @param extractOp
    * @param pei
    * @return
    */
  def generateOpForMetaExtract(extractOp: DataFrame, pitRowKey: String)(implicit pei: PEI): ExtractOutput = {
    val extractOutput = outputGenratorForMetaExtract(extractOp)
    val metaContent = createMetaFile(pei.outFileName, extractOutput.provLoc, extractOutput.provFileName, pitRowKey)
    //This has been added to a Seq to make the output same as generateOpForJsonExtract
    ExtractOutput(extractOutput.provLoc, extractOutput.provFileName)
  }
}

/*
package com.uhg.optum.provider

import com.uhg.optum.JobRunner.PEI
import com.uhg.optum.common.BaseExtractor
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDEInputJsonSchema.{EPDEInputExtractInfo, ExtractFileEntity}

import com.uhg.optum.provider.extractors.{JsonSourceExtractor, MetaSourceExtractor}

import com.uhg.optum.provider.output.OuptutGenerator

import scala.util.Try

/**
  * Created by paror18 on 10/19/2018.
  */
class DefaultExtractProvider extends BaseExtractor with JsonSourceExtractor with MetaSourceExtractor with OuptutGenerator{

  override def extract(pei:PEI, jsonFile: Option[ExtractFileEntity], pitRowKey: String)(implicit context: GlobalContext): Try[Tuple2[String,String]] = {
    Try {
      val extractDF = jsonFile match {
        case Some(inputEntity) => generateExtractFromJson(pei: PEI, inputEntity: ExtractFileEntity)

        case None => generateExtractFromMetaData(pei: PEI)
      }

 /*     extractDF.createOrReplaceTempView("extractOp")
      val outputFilePath = generateOpFile("extractOp")
      val metaFilePath = createMetaFile

      (outputFilePath, metaFilePath)*/
      ("","")
    }
  }
}

*/
