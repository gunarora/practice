package com.uhg.optum

import java.io.File

import com.uhg.optum.EPDECommonJobRunner._
import com.uhg.optum.JobRunner.PEIInstanceEmpty
import com.uhg.optum.JobRunner.{PEI, PEIInstanceEmpty}
import com.uhg.optum.common._
import com.uhg.optum.conf.ApplicationConfig
import com.uhg.optum.conf.ApplicationConfig.peiTabName
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDECommonInputJsonSchema.EPDECommonInputExtractInfo
import com.uhg.optum.protocols.EPDECommonInputJsonSchema._
import com.uhg.optum.provider._
import com.uhg.optum.util.Logger
import spray.json._

import scala.io.Source
import scala.util.{Failure, Success, Try}
object EPDECommonJobRunner  {

  case class PEI(feedName: String,
                 extractName: String,
                 hdrDesc: String,
                 hdrDateFormat: String,
                 trlDesc: String,
                 isJsonProp: String,
                 jsonPropFileLoc: String,
                 sqlQuery: String,
                 transQuery: String,
                 trgColumn: String,
                 trgDataTypeLen: String,
                 outFileName: String,
                 outFileExt: String,
                 outFileLoc: String,
                 archLoc: String,
                 isOutFileColDelim: String,
                 outFileColDelim: String,
                 isFixedWidth: String,
                 srcCd: String,
                 prtnrCd: String,
                 entitySet: String,
                 snapBuildType: String,
                 isOutFileRowDelim: String,
                 outFileRowDelim: String,
                 consumingApp: String,
                 inputFileName: String,
                 inputFileLocation: String,
                 inputLandingLocation: String)

  case class PSC(
                  feedName: String,
                  extractName: String,
                  entNm: String,
                  prikeycols: String,
                  dmlcol: String,
                  activeflag: String,
                  modtscol: String,
                  fullLoadflg: String
                )

  case class CustomFilter(
                           colFm: String,
                           colValue: String,
                           compareOp: CompareOperations.Value,
                           valueToBeCompared: String
                         )

  object CompareOperations extends Enumeration{
    val LESS, LESS_OR_EQUAL , EQUAL, NOT_EQUAL, GREATER_OR_EQUAL, GREATER, NO_OP = Value
  }

  case class trlHdrSchema(desc: String)

  class PEIInstanceEmpty(msg: String, th: Throwable) extends Exception(msg, th)
  class PSCInstanceEmpty(msg: String, th: Throwable) extends Exception(msg, th)
  class ValueNotFound(msg: String, th: Throwable) extends Exception(msg,th)
  class InputFileValidationFailedException(msg: String) extends Exception(msg)

  class DPOException(msg: String) extends Exception(msg)


}

/**
  * Created by paror18 on 9/11/2018.
  */
class EPDECommonJobRunner(peiRowKey: String, env: String, inboxPath: String, vndrCdDir : String)(implicit val globalContext: GlobalContext) extends Job {
  val peTable = globalContext.peTable
  val pscTable = globalContext.pscTable
  val pitTable = globalContext.pitTable
  val plcTable = globalContext.plcTable

  implicit var pei: PEI = _

  override def jobName: String = peiRowKey


  override def preStart()(implicit context: GlobalContext): Try[Unit] = { super.preStart()(context)
    Logger.log.info(s" Scanning PEI HBase Table $peiTabName for ROWKEY :  ${peiRowKey} ")
    import com.uhg.optum.protocols.PEIProtocol._
    peTable.get(peiRowKey,"pei") match {
      case Success(instance) =>
        this.pei = instance
        Success()
      case Failure(ex) =>
        Failure(new PEIInstanceEmpty("Exception while getting the columns info from PEI Table", ex))
    }
  }

  /* override def preStart()(implicit context: GlobalContext): Try[Unit] = {
     Try {
       super.preStart()(context)
     }
   }*/

  override def postStart()(implicit context: GlobalContext): Try[Unit] = {
    Try {
    }
  }

  override def run(): Try[Unit] = {
    Try {
      val jsonFile= Some(readJsonFile())
      val extractProvider = new EPDECommonExtractProvider
      val vendor_cd = pei.consumingApp.trim.toUpperCase
      val outputFiles = extractProvider.extractEPDECommon(jsonFile,peiRowKey, inboxPath, vndrCdDir,vendor_cd) //TODO: peiRowKey is being defined as job name. To check if this can be made available globally
      //TODO: Handle what is to be done with the result of the extraction and handle exceptio accordingly.
    }match{
      case Success(instance) =>
      {
        Logger.log.info("Common : EPDECommonJobRunner.run() : Success")
        Success()
      }
      case Failure(ex) => {
        Logger.log.info("Common : EPDECommonJobRunner.run() : " + "Failure")
        Failure(ex)
      }
    }
  }

  def readJsonFile(): ExtractFileEntity = {
    println("--------Inside readJsonFile()---------")
    val commonJsonFileName=pei.jsonPropFileLoc.split(";").apply(1).trim
    val jsonFileLoc = ApplicationConfig.jsonPathPrefix + DPOConstants.SLASH + commonJsonFileName
    Logger.log.info("JSON file:" + jsonFileLoc)
    val inputJson = Source.fromFile(jsonFileLoc)("UTF-8").getLines.mkString.parseJson
    /*val localJsonFileLoc = this.getClass.getResourceAsStream("/JsonFile/"+env+"/" + "EPDECommon.json" )
    val inputJson =scala.io.Source.fromInputStream(localJsonFileLoc).getLines.mkString.parseJson*/
    println("-----inputJson--------"+inputJson)
    import com.uhg.optum.protocols.EPDECommonInputProtocol._
    val inputEntity = inputJson.convertTo[EPDECommonInputExtractInfo]
    println("Input Entity: "+inputEntity)
    Logger.log.info("File Read Complete.")
    val varfeedName="EPDE_Extraction"
    val varextractName="EPDE_Common"
    val feed = inputEntity.filter(_.feedName == varfeedName).head
    println("Feed: "+feed)
    val extractFileDetails = feed.extraction.filter(_.programName == varextractName).head
    extractFileDetails
  }

}
