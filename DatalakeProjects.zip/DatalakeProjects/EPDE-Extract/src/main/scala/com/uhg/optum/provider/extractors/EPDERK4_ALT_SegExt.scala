package com.uhg.optum.provider.extractors

import com.uhg.optum.common.DPOConstants
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDERK4InputJsonSchema.SegmentDetails
import com.uhg.optum.provider.output.OuptutGenerator
import com.uhg.optum.util.CommonUtil.{createOrReplaceTempViewFn, executeQry}
import com.uhg.optum.util.{CommonUtil, EPDECommonUtil, FileSystemUtil, Logger}
import com.uhg.optum.conf.ApplicationConfig.workingDir

trait EPDERK4_ALT_SegExt extends OuptutGenerator {
  def genALTSeg(segDtls: SegmentDetails,varLst:collection.mutable.Map[String, String],glblVarLst:collection.mutable.Map[String, String],outputFilePath:String)(implicit context: GlobalContext): String = {
    try{
    var resStr="N"

    var df = context.sqlContext.emptyDataFrame
    EPDECommonUtil.generateSegTables(segDtls.segTables,glblVarLst)
    segDtls.segQueries.map { qryKey =>

      if (qryKey.name.equals("ALT_FNL_VIEW")) {
        df = executeQry(varLst, qryKey).dropDuplicates()
        // df = executeQry(qryKey'')
        createOrReplaceTempViewFn(df, qryKey.name)
        //df.show
        FileSystemUtil.saveFileToMapRFSNoRepartitionParquet(df,outputFilePath,qryKey.name,"",DPOConstants.PARQUET)

        //if (df.count > 0) {
          //RPAD QUERY -> result -> write df res in file
         /* val altDf = CommonUtil.generateRpadQry(segDtls.segTarCol, segDtls.segTarLen, segDtls.segTolLen, qryKey.name)
          altDf.show
            generateOpFile(altDf, outputFilePath, qryKey.name+"rpad")
          //FileSystemUtil.saveFileToMapRFS(prvDf,outputFilePath,qryKey.name,"",DPOConstants.CSV)*/
          /*FileSystemUtil.saveFileToMapRFS(df,outputFilePath,qryKey.name,"",DPOConstants.PARQUET)*/
          resStr="Y"
        //}
      }
      else  {
        df = executeQry(varLst, qryKey)
        // df = executeQry(qryKey'')
        createOrReplaceTempViewFn(df, qryKey.name)
        //df.show
        //FileSystemUtil.saveFileToMapRFS(df,glblVarLst.get("tmpVwPath").getOrElse(workingDir),qryKey.name,"",DPOConstants.PARQUET)
      }
    }
    resStr
    }catch {

      case e: Exception => {
        Logger.log.info(s"RK4 : EPDERK4_ADD_SegExt.genADDSeg() : "+e.getMessage)
        throw e
      }

    }
  }

}
