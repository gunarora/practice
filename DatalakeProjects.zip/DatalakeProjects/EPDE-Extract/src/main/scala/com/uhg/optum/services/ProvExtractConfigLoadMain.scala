package com.uhg.optum.services

import com.uhg.optum.conf.ApplicationConfig.{peiFileName, pitFileName, plcFileName, pitTabName, peiTabName, pscTabName, plcTabName,
      pscFileName}
import com.uhg.optum.dao.{HbaseRepositoryManager, LocalRepositoryManager}
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.util.{Logger, PEConfigLoadUtil}
import org.apache.hadoop.hbase.TableName

import scala.util.{Failure, Success}

object ProvExtractConfigLoadMain {
  def main(args: Array[String]): Unit = {
    try {

      Logger.log.info("=============> Starting ProvExtract Configuration Load WorkFlow <=============")

      if (args.length != 3) {
        Logger.log.info("===> Please pass <env>, <hbase table name> & <master> as arguments e.g. \"tst pei local\" <===")
        Logger.log.error("===> Since args passed are invalid; ending ProvExtractConfigLoadMain <===")
        System.exit(1)
      }

      val env = args(0).trim.toLowerCase
      val tableNameAsString = args(1).trim.toLowerCase
      val master = args(2).trim.toLowerCase

      Logger.log.info(s"=============> Before creation of connection :${env} :${tableNameAsString} :${master}<=============")

      implicit val globalContext = if(env.equalsIgnoreCase("local")) {
          new GlobalContext("ProvExtractConfigLoadMain","local") with LocalRepositoryManager
        } else {
          new GlobalContext("ProvExtractConfigLoadMain","yarn") with HbaseRepositoryManager
      }

      val peiTabNameObj = TableName.valueOf(peiTabName)
      Logger.log.info(s"=============> PEI :${peiTabNameObj} <=============")
      val pscTabNameObj = TableName.valueOf(pscTabName)
      Logger.log.info(s"=============> PSC :${pscTabNameObj} <=============")
      val plcTabNameObj = TableName.valueOf(plcTabName)
      Logger.log.info(s"=============> PLC :$plcTabNameObj{} <=============")
      val pitTabNameObj = TableName.valueOf(pitTabName)
      Logger.log.info(s"=============> PIT :${pitTabNameObj} <=============")

      val tableName = TableName.valueOf(tableNameAsString)
      Logger.log.info(s"=============> Starting HBase Config Load For Hbase Table :${tableName} <=============")

      val peConfigLoadUtil = new PEConfigLoadUtil

      val result = tableNameAsString.toLowerCase() match {
        case "pei" => peConfigLoadUtil.loadDSVToHbase("pei", peiFileName, peiTabNameObj)
        case "psc" => peConfigLoadUtil.loadDSVToHbase("psc", pscFileName, pscTabNameObj)
        case "plc" => peConfigLoadUtil.loadDSVToHbase("plc", plcFileName, plcTabNameObj)
        case "pit" => peConfigLoadUtil.loadDSVToHbase("pit", pitFileName, pitTabNameObj)
      }

      result match {
        case Success(result) =>
          Logger.log.info(" HBASE table data successfully loaded")
          globalContext.sparkContext.stop()
        case Failure(ex) =>
          Logger.log.error(" Exception occured during HBASE load process :" + ex.getMessage)
          globalContext.sparkContext.stop()
      }
    }
    catch {
      case e: Exception =>
        Logger.log.error("Exception while reading/loading the DSV Config. Please check if DSV File exists" + e.getMessage)
        throw e
    }
  }
}
