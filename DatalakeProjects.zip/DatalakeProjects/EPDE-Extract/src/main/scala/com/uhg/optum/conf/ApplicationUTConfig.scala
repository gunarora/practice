package com.uhg.optum.conf

import com.typesafe.config.ConfigFactory

object ApplicationUTConfig {

  val conf = ConfigFactory.parseResources("application.ut.conf")

  // Global
  val appName = conf.getString("global.appName")

  // pitUpdateTest
  val peiRowKey = conf.getString("pitUpdate.test1.peiRowKey")
  val logFileName = conf.getString("pitUpdate.test1.logFileName")
  val extractPath = conf.getString("pitUpdate.test1.extractPath")
  val pitRowKeyRdd = conf.getString("pitUpdate.test1.pitRowKeyRdd")
  val extractMeta = conf.getString("pitUpdate.test1.extractMeta")
  val pitRowKeyCF = conf.getString("pitUpdate.test1.pitRowKeyCF")
  val extractFilePathCF = conf.getString("pitUpdate.test1.extractFilePathCF")
  val status = conf.getString("pitUpdate.test1.status")

  // ProvExtracConfigLoadTest
  val rowKey = conf.getString("ProvExtracConfigLoad.test1.rowKey")
  val dsvHeader = conf.getString("ProvExtracConfigLoad.dsvHeader")
  val dsvLine = conf.getString("ProvExtracConfigLoad.dsvLine")
  val cfName = conf.getString("ProvExtracConfigLoad.test2.cfName")
  val hdrCol1 = conf.getString("ProvExtracConfigLoad.test2.hdrCol1")
  val hdrCol2 = conf.getString("ProvExtracConfigLoad.test2.hdrCol2")
  val hdrCol3 = conf.getString("ProvExtracConfigLoad.test2.hdrCol3")
  val hdrCol4 = conf.getString("ProvExtracConfigLoad.test2.hdrCol4")
  val dsvVal1 = conf.getString("ProvExtracConfigLoad.test2.dsvVal1")
  val dsvVal2 = conf.getString("ProvExtracConfigLoad.test2.dsvVal2")
  val dsvVal3 = conf.getString("ProvExtracConfigLoad.test2.dsvVal3")
  val dsvVal4 = conf.getString("ProvExtracConfigLoad.test2.dsvVal4")
  val tableToLoad = conf.getString("ProvExtracConfigLoad.test3.tableToLoad")
  val tableName = conf.getString("ProvExtracConfigLoad.test3.tableName")
  val dsvFileName = conf.getString("ProvExtracConfigLoad.test3.dsvFileName")
}
