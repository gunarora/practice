package com.uhg.optum.provider.extractors

import com.uhg.optum.common.DPOConstants
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDERK4InputJsonSchema.SegmentDetails
import com.uhg.optum.provider.output.OuptutGenerator
import com.uhg.optum.util.CommonUtil.{createOrReplaceTempViewFn, executeQry}
import com.uhg.optum.util.{EPDECommonUtil, FileSystemUtil, Logger}

import scala.util.Try

/**
  * Created by paror18 on 5/6/2019.
  */
trait EPDERK4_PLI_SegExt extends OuptutGenerator {

  def pliSegGen(segDtls: SegmentDetails, glblVarLst:scala.collection.mutable.Map[String,String],outputFilePath : String)(implicit context: GlobalContext): String = {
    try{
    Logger.log.info("Inside pliSegGen")
    Logger.log.info("Initializing variables..")
    var retStr = "N"

      if (segDtls.equals("") || segDtls == null) {
        Logger.log.info("No segment details present for PLI Segment")
      }
      if (!context.sparkSession.catalog.tableExists("PRV_FNL_VIEW")) {
        Logger.log.info("The temporary view PRV_FNL_VIEW from PRV segment is required for PLI segment")
      }
        val SchemaNm = DPOConstants.SCHEMA
        Logger.log.info("SchemaNm: " + SchemaNm)
        if (segDtls.segName.equals("PLI")) {
          EPDECommonUtil.generateSegTables(segDtls.segTables,glblVarLst)
          val segNm = segDtls.segName
          val segSeq = segDtls.segSeq
          segDtls.segQueries.map { qryKey =>
            if (qryKey.name.matches("PLI_FNL_VIEW")) {
              val LNG_FNL_VIEW =executeQry(glblVarLst,qryKey)
              createOrReplaceTempViewFn(LNG_FNL_VIEW, qryKey.name)
              FileSystemUtil.saveFileToMapRFSNoRepartitionParquet(LNG_FNL_VIEW,outputFilePath,qryKey.name,"",DPOConstants.PARQUET)
              //if(LNG_FNL_VIEW.count > 0){
                /*FileSystemUtil.saveFileToMapRFS(LNG_FNL_VIEW,outputFilePath,qryKey.name,"",DPOConstants.PARQUET)*/
                retStr = "Y"
              //}
            }else{
              val df = executeQry(glblVarLst, qryKey)
              createOrReplaceTempViewFn(df, qryKey.name)
            }
          }
        } else {
          retStr
        }
      retStr
    }catch {

      case e: Exception => {
        Logger.log.info(s"RK4 : EPDERK4_PLI_SegExt.genPLISeg() : "+e.getMessage)
        throw e
      }

    }

  }

}
