package com.uhg.optum.provider.extractors

import com.uhg.optum.common.DPOConstants
import com.uhg.optum.conf.ApplicationConfig.datafilesDir
import com.uhg.optum.executors.GlobalContext
import com.uhg.optum.protocols.EPDERK4InputJsonSchema.SegmentDetails
import com.uhg.optum.provider.output.OuptutGenerator
import com.uhg.optum.util.CommonUtil.{createOrReplaceTempViewFn, executeQry}
import com.uhg.optum.util.{CommonUtil, EPDECommonUtil, FileSystemUtil, Logger}

trait EPDERK4_HAS_SegExt extends OuptutGenerator {
  def hasSegGen(segDetails: SegmentDetails, outputFilePath: String, glblVarLst: collection.mutable.Map[String, String])(implicit context: GlobalContext): String = {
try {
  var retStr = "N"
  /* import context.sparkSession.implicits._
    val seq = Seq(5170631, 5170635, 5170644, 5170647, 5170650, 5170660, 5170662, 5170664, 5170670)
    val df = seq.toDF("PROV_ID")
    //df.createOrReplaceTempView("PRV_FNL_VIEW")
    df.show
    val path=datafilesDir+"/"+glblVarLst("${WS_VENDR_CD}")+"/"+glblVarLst("provTypCd")+"/"
    Logger.log.info("path in the has for PRV_FNL_VIEW  "+path)
    generateOpFile(df, path, "PRV_FNL_VIEW")*/
  /*if (!context.sparkSession.catalog.tableExists("PRV_FNL_VIEW")) {
      throw new Exception("The temporary view PRV_FNL_VIEW from PRV segment is required for HAS segment")
    }*/

  EPDECommonUtil.generateSegTables(segDetails.segTables, glblVarLst)
  segDetails.segQueries.map { qryKey =>
    Logger.log.info("qryKey.name --> " + qryKey.name)
    if (qryKey.name.equals("HAS_FNL_VIEW")) {
      Logger.log.info("HAS_FNL_VIEW " + qryKey.name)
      val df = executeQry(glblVarLst, qryKey)
      createOrReplaceTempViewFn(df, qryKey.name)
      FileSystemUtil.saveFileToMapRFSNoRepartitionParquet(df.dropDuplicates(), outputFilePath, qryKey.name, "", DPOConstants.PARQUET)
      //if (df.count > 0) {
        /*FileSystemUtil.saveFileToMapRFS(df, outputFilePath, qryKey.name, "", DPOConstants.PARQUET)*/
        retStr = "Y"
      //}
    }
    else {
      val df = executeQry(glblVarLst, qryKey)
      createOrReplaceTempViewFn(df, qryKey.name)
    }
  }
  retStr
}catch {

  case e: Exception => {
    Logger.log.info(s"RK4 : EPDERK4_HAS_SegExt.genHASSeg() : "+e.getMessage)
    throw e
  }

}
  }
}
