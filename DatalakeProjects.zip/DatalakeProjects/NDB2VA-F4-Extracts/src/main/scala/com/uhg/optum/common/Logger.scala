package com.uhg.optum.common

import org.apache.log4j.Level

/**
  * created by NDB_DevOps
  */
object Logger {
  @transient lazy val log: org.apache.log4j.Logger = org.apache.log4j.LogManager.getLogger("Logger")
  //log.setLevel(Level.ALL)
}