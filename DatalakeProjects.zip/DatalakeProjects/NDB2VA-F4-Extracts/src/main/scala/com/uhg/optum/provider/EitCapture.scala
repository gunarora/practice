package com.uhg.optum.provider

import java.text.SimpleDateFormat

import com.uhg.optum.common.CustomFunctions.{filterList, globalContext, hBaseConf}
import com.uhg.optum.common.{CustomFunctions, DPOConstants, Logger}
import org.apache.hadoop.hbase.TableName
import org.apache.hadoop.hbase.client.Scan
import org.apache.hadoop.hbase.filter.CompareFilter.CompareOp
import org.apache.hadoop.hbase.filter.{PrefixFilter, SingleColumnValueFilter}
import org.apache.hadoop.hbase.mapreduce.TableInputFormat
import org.apache.hadoop.hbase.util.Bytes

  object EitCapture{
def main (args: Array[String]): Unit ={

  Logger.log.info("=============> Starting EIT Capture Workflow <=============")
  if (args.length != 3) {
    Logger.log.info("===> Please Pass Arg1: Feed name for properties path Arg2: Environment <===")
    Logger.log.error("===> Since No args(Feed Name,Environment)  is Passed ending Eit Capture creation <===")
    //System.exit(-1)
  }

  val fdNm = args(0).trim
  val env = args(1).trim
  DPOConstants.METAURI =args(2).trim.toUpperCase()
  DPOConstants.PEIROWKEY = "NDB2VA_F4_Reporting-All_Extracts_Generation_Bootstrap"


  val eitCaptureFlg = CustomFunctions.readFeedBasedProperties(s"common_snapshot",fdNm,s"eitCaptureFlg",env)
  val workingDir = CustomFunctions.readProperties(s"workingDir", env)

  if(eitCaptureFlg.equalsIgnoreCase("Y"))
    {
      Logger.log.info(s"Since  eitCaptureFlg is $eitCaptureFlg, proceeding towards capturing the eit into HBASEEit.txt file")

  val allExtractsPitRowKeys = CustomFunctions.readProperties(s"allExtractsPitRowKeys", env)
  try {

    Logger.log.info(s"Removing from rootDir(if present)${allExtractsPitRowKeys.replace("/mapr/", "/")}")
    CustomFunctions.rmPathIfExist(allExtractsPitRowKeys.replace("/mapr/", "/"))

    hBaseConf.set(TableInputFormat.SCAN_COLUMNS, "fi:entprtnfldr fi:entNm exi:ingEndTs");

    val scan = new Scan()
    val ptnr = CustomFunctions.readFeedBasedProperties(s"common_snapshot",fdNm,s"prtnrCd",env)
    val src = CustomFunctions.readFeedBasedProperties(s"common_snapshot",fdNm,s"srcCd",env)
    val eitschema = CustomFunctions.readFeedBasedProperties(s"common_snapshot",fdNm,s"eitschema",env)

    val lakeEitTableName = CustomFunctions.readProperties(s"lakeEitTableName", env)
    Logger.log.info("lakeEitTableName Considered is :"+lakeEitTableName)
    Logger.log.info("Schema Considered is :"+eitschema)
    Logger.log.info("prtnrCd Considered is :"+ptnr)
    Logger.log.info("srcCd Considered is :"+src)

    val filter = new PrefixFilter(Bytes.toBytes(s"${ptnr}-${src}-${eitschema}_"))
    val filter1 = new SingleColumnValueFilter(Bytes.toBytes("exi"), Bytes.toBytes("ingProcLogSts"), CompareOp.EQUAL, Bytes.toBytes("Success"));
    scan.setCaching(10000)
    scan.setCacheBlocks(false)
    filter1.setFilterIfMissing(true)
    scan.setFilter(filterList(filter,filter1))

    val eitVal = globalContext.hbaseContext.hbaseRDD(TableName.valueOf(lakeEitTableName), scan).cache
    val eitCnt=eitVal.count()
    Logger.log.info(s"EIT count is :: ${eitCnt}")

    val eitInfo = eitVal.map(tuple => {
      val result = tuple._2
      ( Bytes.toString(result.getRow()),Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("entprtnfldr"))), Bytes.toString(result.getValue(Bytes.toBytes("fi"), Bytes.toBytes("entNm"))),Bytes.toString(result.getValue(Bytes.toBytes("exi"), Bytes.toBytes("ingEndTs")))) })


    val eitInfoFinal=eitInfo.filter(x=>x._4!=null)
    val eitInfoFinalCnt= eitInfoFinal.count()
    Logger.log.info(s"FInal EIT count is :: ${eitInfoFinalCnt}")

    if(eitInfoFinalCnt>0) {

      CustomFunctions.rmPathIfExist(workingDir + "/EIT")
      //val saveEit =eitInfo.filter(x=>x._3=="F5938DBJ_MKT_IPA").map(x=> getEitEpochFrmt(x._1,x._2,x._3,x._4)).repartition(1).saveAsTextFile(s"${workingDir}/EIT")
      val saveEit = eitInfoFinal.map(x => getEitEpochFrmt(x._1, x._2, x._3, x._4)).repartition(1).saveAsTextFile(s"${workingDir}/EIT")

      //val eitSchm = StructType(List(StructField("eitRowKey", StringType, true),StructField("prtnFldr", StringType, true),StructField("entNm", StringType, true),StructField("endTsEpoch", StringType, true)))
      // val eitSchm = StructType(List(StructField("eitRowKey", StringType, true)))
      //val abc =globalContext.sparkSession.sqlContext.createDataFrame(globalContext.spark.parallelize(eitInfo.filter(x=>x._3=="F5938DBJ_MKT_IPA").map(x=> getEitEpochFrmt(x._1,x._2,x._3,x._4))).collect().toList).repartition(1).write.mode("overwrite").csv(s"${workingDir}/EIT")


      CustomFunctions.renamePath(workingDir + "/EIT/part-00000", workingDir + "/EIT/HbaseEit.txt")
      CustomFunctions.rmPathIfExist(workingDir + "/EIT/_SUCCESS")
      Logger.log.info(s"===================> completed  EIT capture workflow <===================")
    }
    else{
      Logger.log.info(s"Since FInal EIT count is :: ${eitInfoFinalCnt} , then exiting EIT capture workflow")

    }
  } catch {
    case e: Exception => Logger.log.info(s" Exception while capturing EIT" :+ e.getStackTrace.mkString)
      CustomFunctions.rmPathIfExist(workingDir + "/EIT")
      throw e
  }
    }
  else{

    Logger.log.info(s"Since  eitCaptureFlg is $eitCaptureFlg, NOT proceeding towards capturing the eit into HBASEEit.txt file")
    CustomFunctions.rmPathIfExist(workingDir + "/EIT")
  }




}
    /** Purpose : Def to convert the timestamp to epoche time
      * input : eitRowKey : String,ptrnFldr:String,entNm:String,dtStr:String
      * output: eitRowKey : String,ptrnFldr:String,entNm:String,dtStr In epochFormat:String */
    def getEitEpochFrmt (eitRowKey : String,ptrnFldr:String,entNm:String,dtStr:String):String = {
      Logger.log.info("dtStr :: "+dtStr)
      val epochVal=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(dtStr).getTime().toString;
      eitRowKey+"|"+ptrnFldr+"|"+entNm+"|"+epochVal
    }

  }