import React from 'react';
import axios from 'axios';
import {SearchResult} from './SearchResult';

var header = ["Zip","State","County","Market", "Market Type", "Market Name", "Effective Date"];
class SearchForm extends React.Component {

  constructor(props) {
    super(props);
    this.state = { marketNumber: '', product: 'POS', marketType: '', zipCode: '', state: '',commonData:[]
                   , stateDropdown:[], marketTypeDropdown:[]};
    this.handleChangeMarketNumber = this.handleChangeMarketNumber.bind(this);
    this.handleChangeProduct = this.handleChangeProduct.bind(this);
    this.handleChangeMarketType = this.handleChangeMarketType.bind(this);
    this.handleChangeZipcode = this.handleChangeZipcode.bind(this);
    this.handleChangeState = this.handleChangeState.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleReset = this.handleReset.bind(this);
  }

  componentWillMount(){
    
    //State Code Dropdown
    var url1 = 'http://localhost:8080/api/states';
    axios.get(url1)
      .then(res => {
        console.log("Data Fetched from the State Service", res.data);
        this.setState({ stateDropdown: res.data });
        console.log();
      })
      .catch(error => {
        console.log(error);
      })
      
      //MarketType Dropdown
      url1='http://localhost:8080/api/markettypes';
      axios.get(url1)
      .then(res => {
        console.log("Data Fetched from the Market Type Service", res.data);
        this.setState({ marketTypeDropdown: res.data });
        console.log();
      })
      .catch(error => {
        console.log(error);
      })

  }

  handleChangeMarketNumber(event) {
    const re = /^[0-9\b]+$/;
    // if value is not blank, then test the regex
    if (event.target.value === '' || re.test(event.target.value)) {
       this.setState({marketNumber: event.target.value})
    }
    else{
      alert("Please enter Number only");
    }
    //this.setState({ marketNumber: event.target.value })
  }
  handleChangeProduct(event){
    this.setState({ product: event.target.value })
    console.log(this.state.product);
  }
  handleChangeMarketType(event){
    this.setState({ marketType: event.target.value })
  }
  handleChangeZipcode(event){
    const re = /^[0-9\b]+$/;
    // if value is not blank, then test the regex
    if (event.target.value === '' || re.test(event.target.value)) {
       this.setState({zipCode: event.target.value})
    }
    else{
      alert("Please enter Number only");
    }
  }
  handleChangeState(event){
    this.setState({ state: event.target.value })
    console.log(this.state.state);
  }

  handleSubmit(event) {
    
    if(this.state.marketNumber!=='' || this.state.zipCode!=='' || this.state.state!==''){
      var url = 'http://localhost:8080/api/search';
      var jsonInputSearchData= {
        mktNbr:this.state.marketNumber,
        product:this.state.product,
        marketType:this.state.marketType,
        zipCode:this.state.zipCode,
        state:this.state.state
      };
      let axiosConfig = {
        headers: {
            'Content-Type': 'application/json;charset=UTF-8',
            "Access-Control-Allow-Origin": "*",
        }
      };

      
      console.log(url,jsonInputSearchData,axiosConfig);
      axios.post(url,jsonInputSearchData,axiosConfig)
        .then(res => {
        console.log("Data Fetched from the Search Service", res.data);
          this.setState({ commonData: res.data });
          document.getElementById("resultSearchFormDiv").style.display = "block";
        })
        .catch(error => {
          console.log(error);
        })
      }
      else{
        alert("Enter Market Number or Zip Code or State")
      }
     event.preventDefault();
  }

  handleReset(){
    this.setState ({ marketNumber: '', product: 'POS', marketType: '', zipCode: '', state: '',commonData:[] });
    document.getElementById("resultSearchFormDiv").style.display = "none";
  }
  
  render() {
    return (
      <div className="searchFormDiv">
        <div className="inputSearchFormDiv">
        <form className="searchTable" onSubmit={this.handleSubmit } id='form' onReset={this.handleReset}>
          <h2 className="searchHeader">Search by Zipcode or State or Market Number</h2>
          <table width='100%' cellPadding="1" cellSpacing='5'>
            <tbody>
              <tr><td>Market Number</td>
                <td><input
                  type="text"
                  value={this.state.marketNumber}
                  onChange={this.handleChangeMarketNumber}
                  placeholder="1234567"
                  maxLength="7"
                /></td></tr>
              <tr><td><label>Product</label></td>
                <td>
                  <select value={this.state.product} onChange={this.handleChangeProduct} className="productDropDown" >
                    <option value="POS">POS</option>
                    <option value="EPO" >EPO</option>
                    <option value="HMO" >HMO</option>
                    <option value="PPO" >PPO</option>
                    <option value="IND" >IND</option>
                  </select>
                </td></tr>
              <tr>
                <td><label>Market Type</label></td>
                <td>
                <select value={this.state.marketType} onChange={this.handleChangeMarketType} className="marketTypeDropdown" >
                    {
                      //(this.state.stateDropdown && this.state.stateDropdown.length>0 
                        //&& 
                        Object.entries(this.state.marketTypeDropdown).map(([key, value1], i) => {
                          return (
                            <option value={value1.marketTypeCode} key={key}>
                              {value1.marketTypeCode}
                            </option>
                        )
                      })
                      //)
                     //optionItems
                    }
                  </select>
                </td>
              </tr>
              <tr><td>
                <label>Zip Code</label></td>
                <td><input
                  type="text"
                  value={this.state.zipCode}
                  onChange={this.handleChangeZipcode}
                  maxLength='5'
                  placeholder="12345"
                /></td></tr>
              <tr><td>
                <label>State</label></td>
                <td>
                  <select value={this.state.state} onChange={this.handleChangeState} className="stateDropDown" >
                    {
                      //(this.state.stateDropdown && this.state.stateDropdown.length>0 
                        //&& 
                        Object.entries(this.state.stateDropdown).map(([key, value1], i) => {
                          return (
                            <option value={value1.stateCode} key={key}>
                              {value1.stateCode}
                            </option>
                        )
                      })
                      //)
                     //optionItems
                    }
                  </select>
                  </td></tr>
                <tr><td colSpan="2"><input type="submit" value="Submit" /><span>      </span>
                <input type="reset" value="Reset" /></td></tr>
            </tbody>
          </table>
          
        </form>
        </div>

        <div className="resultSearchFormDiv" id="resultSearchFormDiv" hidden>
          <SearchResult
            header={header}
            commonData = {this.state.commonData}
          />    
        </div>
      </div>
    )
  }
}

export default SearchForm;