import React from 'react';

function Markets(props) {
    console.log("Inside Market:  ", props);

    var header = [];
    var message= "";
    if (props.flag === "markets") {
        header = ["Market Number", "Market Name", "Effective Date", "Cancel Date"];
        message= "Markets Data";
    }
    else if (props.flag === 'markettypes') {
        header = ["Market Type", "Type", "Active Indicator", "Description"];
        message= "Markets Types Data";
    }
    else if (props.flag === 'states') {
        header = ["Abbreviation", "Name"];
        message= "States Data";
    }
    else if (props.flag === 'home') {
        header = [];
    }
    return (
        <div>
            <h2 className="genericHeader">{message}</h2>
        <table className="genericTable">
            <thead>
                <tr>
                    {header.map((h, i) => <th key={i}>{h}</th>)}
                </tr>
            </thead>
            <tbody>
                {
                    Object.entries(props.markets).map(([key, value], i) => {
                        if (props.flag === "markets")
                            return (
                                <tr key={key}>
                                    <td>{value.mktNbr}</td>
                                    <td>{value.mktNm}</td>
                                    <td>{value.effDt}</td>
                                    <td>{value.cancDt}</td>
                                </tr>
                            )
                        else if (props.flag === "markettypes")
                            return (
                                <tr key={key}>
                                    <td>{value.marketTypeCode}</td>
                                    <td>{value.productCategoryCode}</td>
                                    <td>{value.activeCode}</td>
                                    <td>{value.marketTypeDescription}</td>
                                </tr>
                            )
                        if (props.flag === "states")
                            return (
                                <tr key={key}>
                                    <td>{value.stateCode}</td>
                                    <td>{value.stateName}</td>
                                </tr>
                            )
                        return []
                    })
                }
            </tbody>
        </table>
        </div>
    )
}
export default Markets;