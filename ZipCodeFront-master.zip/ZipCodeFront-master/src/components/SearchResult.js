import React from 'react'

export const SearchResult = ({header,commonData}) => {
    return (
        <div>
            <table className="genericTable">
            <thead>
                <tr>
                    {header.map((h, i) => <th key={i}> {h} </th>)}
                </tr>
            </thead>
            <tbody>
                {
                    Object.entries(commonData).map(([key, value], i) => {
                        return (
                                <tr key={key}>
                                    <td>{value.zipCode}</td>
                                    <td>{value.state}</td>
                                    <td>{value.county}</td>
                                    <td>{value.mktNbr}</td>
                                    <td>{value.marketType}</td>
                                    <td>{value.marketName}</td>
                                    <td>{value.effDate}</td>
                                </tr>
                        )
                        //return []
                    })
                }
            </tbody>
        </table>
        </div>
    )
}
