import React from 'react';
import './App.css';
import Markets from './components/Market.js';
import axios from 'axios';
import SearchForm from './components/SearchForm';
import ReactDOM from 'react-dom';

class App extends React.Component {

  constructor(props) {
    super(props);
    this.state = { commonData: [], flag: [] };//{ attribute : "value" }; 
    this.onClickEvent = this.onClickEvent.bind(this);
    this.onSearchClickEvent = this.onSearchClickEvent.bind(this);
    this.onHomeClickEvent = this.onHomeClickEvent.bind(this);
    this.onAboutClickEvent=this.onAboutClickEvent.bind(this);
    this.onHelpClickEvent= this.onHelpClickEvent.bind(this);
  }

  componentDidMount() {

  }

  onClickEvent(event) {

    var url = 'http://localhost:8080/api/' + event.currentTarget.id;
    this.setState({
      flag: event.currentTarget.id
    })

    axios.get(url)
      .then(res => {
        //const markets = res.data;
        console.log("Data Fetched from the Service", res.data);
        this.setState({ commonData: res.data });
        ReactDOM.render(<Markets markets={this.state.commonData} flag={this.state.flag} />, document.getElementById('content'));
      })
      .catch(error => {
        console.log(error);
      })
    
    //console.log(this.state.flag + ' :: The link was clicked. :: ' + this.state.markets + event.currentTarget.id);
  }

  onSearchClickEvent(event) {

    this.setState({
      flag: event.currentTarget.id
    });
    document.getElementById("content").style.display = "block";
    ReactDOM.render(<SearchForm />, document.getElementById('content'));
  }

  onAboutClickEvent(event){

  }

  onHelpClickEvent(event){

  }

  onHomeClickEvent(event){
    //this.forceUpdate();
    //ReactDOM.render(<App />, document.getElementById('content'));
    document.getElementById("content").style.display = "none";
  }

  render() {
    return (
      <div className="App" id="App">
        <header>
          <div className="top"></div>
          <div className="topnav">
            <a className="active" href="#home" id="home" onClick={this.onHomeClickEvent}>Home</a>
            <a href="#search" id="search" onClick={this.onSearchClickEvent}>Search</a>
            <a href="#marketTypes" id="markettypes" onClick={this.onClickEvent}>MarketTypes</a>
            <a href="#markets" id="markets" onClick={this.onClickEvent}>Markets</a>
            <a href="#states" id="states" onClick={this.onClickEvent}>States</a>
            <a href="#help" id="help" onClick={this.onHelpClickEvent}>Help</a>
            <a href="#about" id="about" onClick={this.onAboutClickEvent}>About</a>
          </div>

          <div className="content" id='content'>
            <p>Hello dummy test</p>
          </div>

          <div className="bottom">
            <p>Edit Maintained by NDB.</p>
            <p>Copyright © 2019 UnitedHealth Group.</p>
          </div>
        </header>
      </div>
    )
  }
}

export default App;
