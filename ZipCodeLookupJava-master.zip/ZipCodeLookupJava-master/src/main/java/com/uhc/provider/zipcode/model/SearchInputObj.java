package com.uhc.provider.zipcode.model;

public class SearchInputObj {

	private String mktNbr;
	private String product;
	private String marketType;
	private String zipCode;
	private String state;
	
	/**
	 * @return the mktNbr
	 */
	public String getMktNbr() {
		return mktNbr;
	}
	/**
	 * @param mktNbr the mktNbr to set
	 */
	public void setMktNbr(String mktNbr) {
		this.mktNbr = mktNbr;
	}
	/**
	 * @return the product
	 */
	public String getProduct() {
		return product;
	}
	/**
	 * @param product the product to set
	 */
	public void setProduct(String product) {
		this.product = product;
	}
	/**
	 * @return the marketType
	 */
	public String getMarketType() {
		return marketType;
	}
	/**
	 * @param marketType the marketType to set
	 */
	public void setMarketType(String marketType) {
		this.marketType = marketType;
	}
	/**
	 * @return the zipCode
	 */
	public String getZipCode() {
		return zipCode;
	}
	/**
	 * @param zipCode the zipCode to set
	 */
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}
	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}
	
	/**
	 * @param mktNbr
	 * @param product
	 * @param marketType
	 * @param zipCode
	 * @param state
	 */
	public SearchInputObj(String mktNbr, String product, String marketType, String zipCode, String state) {
		super();
		this.mktNbr = mktNbr;
		this.product = product;
		this.marketType = marketType;
		this.zipCode = zipCode;
		this.state = state;
	}
	/**
	 * 
	 */
	public SearchInputObj() {
		super();
	}
	
	
	
}
