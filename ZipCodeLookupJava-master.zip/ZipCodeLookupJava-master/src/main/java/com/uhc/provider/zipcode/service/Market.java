package com.uhc.provider.zipcode.service;

import java.sql.Connection;
import java.util.List;

import com.uhc.provider.zipcode.model.MarketDesiredObj;
import com.uhc.provider.zipcode.model.MarketObj;

public interface Market {
	/**
	 * 
	 * @return MultipleMarketObj
	 */
	public List<MarketObj> getMarket(Connection connection);
	
	/**
	 * 
	 * @return MultipleMarketObj
	 */
	public List<MarketDesiredObj> getDesiredMarket(Connection connection);
}
