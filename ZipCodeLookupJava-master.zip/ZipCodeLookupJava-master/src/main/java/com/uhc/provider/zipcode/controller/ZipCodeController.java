package com.uhc.provider.zipcode.controller;

import com.uhc.provider.zipcode.config.YamlConfig;
import com.uhc.provider.zipcode.model.*;
import com.uhc.provider.zipcode.model.repository.ZipCodeRepositroy;
import com.uhc.provider.zipcode.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.sql.Connection;
import java.util.List;

@Controller
@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequestMapping(path = "/api")
public class ZipCodeController {
	@Autowired
	YamlConfig yamlConfig;

	@Autowired
	ZipCodeRepositroy repositroy;

	@GetMapping(path = "/test")
	public String getTest() {
		System.out.println("Testing the Code");
		return "Hello"+yamlConfig.getUserId();
	}
	
	@GetMapping(path = "/markettypes")
	public List<MarketTypesObj> getMarketTypes() {
		System.out.println("In the Market Types");
		MarketTypes marketTypes = new MarketTypesImpl();
		Connection connection = getConnection();
		return marketTypes.getMarketTypes(connection);
	}
	
	@GetMapping(path = "/market")
	public List<MarketObj> getMarket() {
		System.out.println("In the Complete Market");
		Market market = new MarketImpl();
		Connection connection = getConnection();
		return market.getMarket(connection);
	}
	
	@GetMapping(path = "/markets")
	public List<MarketDesiredObj> getMarkets() {
		System.out.println("In the desired Markets");
		Market market = new MarketImpl();
		Connection connection = getConnection();
		return market.getDesiredMarket(connection);
	}
	
	@PostMapping(path = "/search")
	public List<SearchOutputObj> search(@RequestBody SearchInputObj searchInputObj) {
		System.out.println("In the Search");
		Search search = new SearchImpl();
		System.out.println(searchInputObj.getMarketType()+"  ::  "+searchInputObj.getMktNbr()+"  ::  "+searchInputObj.getProduct()+"  ::  "+searchInputObj.getState()+"  ::  "+searchInputObj.getZipCode());
		Connection connection = getConnection();
		return search.getZipCode(searchInputObj,connection);
	}
	
	@GetMapping(path = "/states")
	public List<StatesObj> getStates() {
		System.out.println("In the States");
		State state = new StatesImpl();
		Connection connection = getConnection();
		return state.getStates(connection);
	}

	private Connection getConnection(){
		return repositroy.getMySQLDBConn(yamlConfig.getClassForName()
				,yamlConfig.getDb2ServerURLString()
				,yamlConfig.getUserId()
				,yamlConfig.getPassword());
	}
}
