package com.uhc.provider.zipcode.service;

import com.uhc.provider.zipcode.model.MarketTypesObj;
import com.uhc.provider.zipcode.model.repository.ZipCodeRepositroy;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MarketTypesImpl implements MarketTypes {


	ZipCodeRepositroy zipCodeRepositroy = new ZipCodeRepositroy();
	@Override
	public List<MarketTypesObj> getMarketTypes(Connection connection) {
		// To Do Logic
		//Logic: A loop of below objects will be populated with values from DB
		MarketTypesObj marketTypesObj;
		List<MarketTypesObj> marketTypesObjs = new ArrayList<MarketTypesObj>();

		try {

			if(connection==null) {
				System.out.println("Connection Issue");
			}
			PreparedStatement selectState = connection.prepareStatement("select * from f5938dbj.mkt_typ with ur");
			ResultSet rs = selectState.executeQuery();
			while (rs.next()) {
				marketTypesObj =new MarketTypesObj();
				
				marketTypesObj.setActiveCode(rs.getString("ACTV_CD"));
				marketTypesObj.setApplicationNonStdProductGroupInd(rs.getString("APPL_NON_STD_PRDCT_GRP_IND"));
				marketTypesObj.setLasteUpdateTimestamp(rs.getTimestamp("LST_UPDT_TM"));
				marketTypesObj.setLastUpdateDate(rs.getDate("LST_UPDT_DT"));
				marketTypesObj.setMarketTypeCode(rs.getString("MKT_TYP_CD"));
				marketTypesObj.setMarketTypeDescription(rs.getString("MKT_TYP_DESC"));
				marketTypesObj.setProductCategoryCode(rs.getString("PRDCT_CATGY_CD"));
				marketTypesObj.setUserID(rs.getString("USER_ID"));
				marketTypesObj.setUserOficeCode(rs.getString("USER_OFC_CD"));
				
				marketTypesObjs.add(marketTypesObj);
			}
			//multipleMarketTypesObj.setMarketTypesObj(marketTypesObjs);
		}
		catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (connection != null) {
				System.out.println("Connected successfully.");
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
		return marketTypesObjs;
	}

}
