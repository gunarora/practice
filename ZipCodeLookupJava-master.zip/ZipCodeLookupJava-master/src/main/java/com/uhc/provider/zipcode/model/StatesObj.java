package com.uhc.provider.zipcode.model;

public class StatesObj {

	private String stateCode;
	private String stateName;
	private String countryCode;
	private String cdsLicenceIndicator;
	private int timeZonePrrNbr;
	/**
	 * @return the stateCode
	 */
	public String getStateCode() {
		return stateCode;
	}
	/**
	 * @param stateCode the stateCode to set
	 */
	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}
	/**
	 * @return the stateName
	 */
	public String getStateName() {
		return stateName;
	}
	/**
	 * @param stateName the stateName to set
	 */
	public void setStateName(String stateName) {
		this.stateName = stateName;
	}
	/**
	 * @return the countryCode
	 */
	public String getCountryCode() {
		return countryCode;
	}
	/**
	 * @param countryCode the countryCode to set
	 */
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	/**
	 * @return the cdsLicenceIndicator
	 */
	public String getCdsLicenceIndicator() {
		return cdsLicenceIndicator;
	}
	/**
	 * @param cdsLicenceIndicator the cdsLicenceIndicator to set
	 */
	public void setCdsLicenceIndicator(String cdsLicenceIndicator) {
		this.cdsLicenceIndicator = cdsLicenceIndicator;
	}
	/**
	 * @return the timeZonePrrNbr
	 */
	public int getTimeZonePrrNbr() {
		return timeZonePrrNbr;
	}
	/**
	 * @param timeZonePrrNbr the timeZonePrrNbr to set
	 */
	public void setTimeZonePrrNbr(int timeZonePrrNbr) {
		this.timeZonePrrNbr = timeZonePrrNbr;
	}
	/**
	 * @param stateCode
	 * @param stateName
	 * @param countryCode
	 * @param cdsLicenceIndicator
	 * @param timeZonePrrNbr
	 */
	public StatesObj(String stateCode, String stateName, String countryCode, String cdsLicenceIndicator,
			int timeZonePrrNbr) {
		super();
		this.stateCode = stateCode;
		this.stateName = stateName;
		this.countryCode = countryCode;
		this.cdsLicenceIndicator = cdsLicenceIndicator;
		this.timeZonePrrNbr = timeZonePrrNbr;
	}
	/**
	 * 
	 */
	public StatesObj() {
		super();
	}
	
	
}
