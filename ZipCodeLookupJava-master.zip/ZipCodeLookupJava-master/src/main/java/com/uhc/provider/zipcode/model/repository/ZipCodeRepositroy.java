package com.uhc.provider.zipcode.model.repository;

import com.uhc.provider.zipcode.config.YamlConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.sql.Connection;
import java.sql.DriverManager;
@Component
public class ZipCodeRepositroy {

	@Autowired
	YamlConfig yamlConfig;

	private  Connection db2Connection = null;
	public  Connection getMySQLDBConn(String className,String url,String userName,String password) {
			try {
				Class.forName(className);
				db2Connection = DriverManager.getConnection(url, userName, password);
				db2Connection.setAutoCommit(true);
			} catch (Exception e) {
				e.printStackTrace();
			}
		return db2Connection;
	}
}
