package com.uhc.provider.zipcode.model;

import java.sql.Date;
import java.sql.Timestamp;

public class MarketObj {

	private int mktNbr;
	private String userId;
	private String userOfcCd;
	private Date lstUpdtDt;
	private Timestamp lstUpdtTm;
	private String mktNm;
	private Date effDt;
	private Date cancDt;
	private String uhgBusUnitId;
	private String prtlEligInd;
	private String eligListRllpInd;
	private String tmlnRsnTypCd;
	private String uhnInd;
	private String dirLstNm;
	private String dirFstNm;
	private String mgrLstNm;
	private String mgrFstNm;
	private String vpLstNm;
	private String vpFstNm;
	private String areaCd;
	private int telNbr;
	private String telExtNbr;
	private String faxAreaCd;
	private int faxTelNbr;
	private String lglNm;
	private String adrLn1Txt;
	private String adrLn2Txt;
	private String ctyNm;
	private String stCd;
	private int zipCd;
	private int zipPls4Cd;
	private String lglEntyCd;
	private String homCosDivCd;
	private String commtTxt;
	private Date creatDt;
	private String mktNbrApplStCd;
	/**
	 * @return the mktNbr
	 */
	public int getMktNbr() {
		return mktNbr;
	}
	/**
	 * @param mktNbr the mktNbr to set
	 */
	public void setMktNbr(int mktNbr) {
		this.mktNbr = mktNbr;
	}
	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}
	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	/**
	 * @return the userOfcCd
	 */
	public String getUserOfcCd() {
		return userOfcCd;
	}
	/**
	 * @param userOfcCd the userOfcCd to set
	 */
	public void setUserOfcCd(String userOfcCd) {
		this.userOfcCd = userOfcCd;
	}
	/**
	 * @return the lstUpdtDt
	 */
	public Date getLstUpdtDt() {
		return lstUpdtDt;
	}
	/**
	 * @param lstUpdtDt the lstUpdtDt to set
	 */
	public void setLstUpdtDt(Date lstUpdtDt) {
		this.lstUpdtDt = lstUpdtDt;
	}
	/**
	 * @return the lstUpdtTm
	 */
	public Timestamp getLstUpdtTm() {
		return lstUpdtTm;
	}
	/**
	 * @param lstUpdtTm the lstUpdtTm to set
	 */
	public void setLstUpdtTm(Timestamp lstUpdtTm) {
		this.lstUpdtTm = lstUpdtTm;
	}
	/**
	 * @return the mktNm
	 */
	public String getMktNm() {
		return mktNm;
	}
	/**
	 * @param mktNm the mktNm to set
	 */
	public void setMktNm(String mktNm) {
		this.mktNm = mktNm;
	}
	/**
	 * @return the effDt
	 */
	public Date getEffDt() {
		return effDt;
	}
	/**
	 * @param effDt the effDt to set
	 */
	public void setEffDt(Date effDt) {
		this.effDt = effDt;
	}
	/**
	 * @return the cancDt
	 */
	public Date getCancDt() {
		return cancDt;
	}
	/**
	 * @param cancDt the cancDt to set
	 */
	public void setCancDt(Date cancDt) {
		this.cancDt = cancDt;
	}
	/**
	 * @return the uhgBusUnitId
	 */
	public String getUhgBusUnitId() {
		return uhgBusUnitId;
	}
	/**
	 * @param uhgBusUnitId the uhgBusUnitId to set
	 */
	public void setUhgBusUnitId(String uhgBusUnitId) {
		this.uhgBusUnitId = uhgBusUnitId;
	}
	/**
	 * @return the prtlEligInd
	 */
	public String getPrtlEligInd() {
		return prtlEligInd;
	}
	/**
	 * @param prtlEligInd the prtlEligInd to set
	 */
	public void setPrtlEligInd(String prtlEligInd) {
		this.prtlEligInd = prtlEligInd;
	}
	/**
	 * @return the eligListRllpInd
	 */
	public String getEligListRllpInd() {
		return eligListRllpInd;
	}
	/**
	 * @param eligListRllpInd the eligListRllpInd to set
	 */
	public void setEligListRllpInd(String eligListRllpInd) {
		this.eligListRllpInd = eligListRllpInd;
	}
	/**
	 * @return the tmlnRsnTypCd
	 */
	public String getTmlnRsnTypCd() {
		return tmlnRsnTypCd;
	}
	/**
	 * @param tmlnRsnTypCd the tmlnRsnTypCd to set
	 */
	public void setTmlnRsnTypCd(String tmlnRsnTypCd) {
		this.tmlnRsnTypCd = tmlnRsnTypCd;
	}
	/**
	 * @return the uhnInd
	 */
	public String getUhnInd() {
		return uhnInd;
	}
	/**
	 * @param uhnInd the uhnInd to set
	 */
	public void setUhnInd(String uhnInd) {
		this.uhnInd = uhnInd;
	}
	/**
	 * @return the dirLstNm
	 */
	public String getDirLstNm() {
		return dirLstNm;
	}
	/**
	 * @param dirLstNm the dirLstNm to set
	 */
	public void setDirLstNm(String dirLstNm) {
		this.dirLstNm = dirLstNm;
	}
	/**
	 * @return the dirFstNm
	 */
	public String getDirFstNm() {
		return dirFstNm;
	}
	/**
	 * @param dirFstNm the dirFstNm to set
	 */
	public void setDirFstNm(String dirFstNm) {
		this.dirFstNm = dirFstNm;
	}
	/**
	 * @return the mgrLstNm
	 */
	public String getMgrLstNm() {
		return mgrLstNm;
	}
	/**
	 * @param mgrLstNm the mgrLstNm to set
	 */
	public void setMgrLstNm(String mgrLstNm) {
		this.mgrLstNm = mgrLstNm;
	}
	/**
	 * @return the mgrFstNm
	 */
	public String getMgrFstNm() {
		return mgrFstNm;
	}
	/**
	 * @param mgrFstNm the mgrFstNm to set
	 */
	public void setMgrFstNm(String mgrFstNm) {
		this.mgrFstNm = mgrFstNm;
	}
	/**
	 * @return the vpLstNm
	 */
	public String getVpLstNm() {
		return vpLstNm;
	}
	/**
	 * @param vpLstNm the vpLstNm to set
	 */
	public void setVpLstNm(String vpLstNm) {
		this.vpLstNm = vpLstNm;
	}
	/**
	 * @return the vpFstNm
	 */
	public String getVpFstNm() {
		return vpFstNm;
	}
	/**
	 * @param vpFstNm the vpFstNm to set
	 */
	public void setVpFstNm(String vpFstNm) {
		this.vpFstNm = vpFstNm;
	}
	/**
	 * @return the areaCd
	 */
	public String getAreaCd() {
		return areaCd;
	}
	/**
	 * @param areaCd the areaCd to set
	 */
	public void setAreaCd(String areaCd) {
		this.areaCd = areaCd;
	}
	/**
	 * @return the telNbr
	 */
	public int getTelNbr() {
		return telNbr;
	}
	/**
	 * @param telNbr the telNbr to set
	 */
	public void setTelNbr(int telNbr) {
		this.telNbr = telNbr;
	}
	/**
	 * @return the telExtNbr
	 */
	public String getTelExtNbr() {
		return telExtNbr;
	}
	/**
	 * @param telExtNbr the telExtNbr to set
	 */
	public void setTelExtNbr(String telExtNbr) {
		this.telExtNbr = telExtNbr;
	}
	/**
	 * @return the faxAreaCd
	 */
	public String getFaxAreaCd() {
		return faxAreaCd;
	}
	/**
	 * @param faxAreaCd the faxAreaCd to set
	 */
	public void setFaxAreaCd(String faxAreaCd) {
		this.faxAreaCd = faxAreaCd;
	}
	/**
	 * @return the faxTelNbr
	 */
	public int getFaxTelNbr() {
		return faxTelNbr;
	}
	/**
	 * @param faxTelNbr the faxTelNbr to set
	 */
	public void setFaxTelNbr(int faxTelNbr) {
		this.faxTelNbr = faxTelNbr;
	}
	/**
	 * @return the lglNm
	 */
	public String getLglNm() {
		return lglNm;
	}
	/**
	 * @param lglNm the lglNm to set
	 */
	public void setLglNm(String lglNm) {
		this.lglNm = lglNm;
	}
	/**
	 * @return the adrLn1Txt
	 */
	public String getAdrLn1Txt() {
		return adrLn1Txt;
	}
	/**
	 * @param adrLn1Txt the adrLn1Txt to set
	 */
	public void setAdrLn1Txt(String adrLn1Txt) {
		this.adrLn1Txt = adrLn1Txt;
	}
	/**
	 * @return the adrLn2Txt
	 */
	public String getAdrLn2Txt() {
		return adrLn2Txt;
	}
	/**
	 * @param adrLn2Txt the adrLn2Txt to set
	 */
	public void setAdrLn2Txt(String adrLn2Txt) {
		this.adrLn2Txt = adrLn2Txt;
	}
	/**
	 * @return the ctyNm
	 */
	public String getCtyNm() {
		return ctyNm;
	}
	/**
	 * @param ctyNm the ctyNm to set
	 */
	public void setCtyNm(String ctyNm) {
		this.ctyNm = ctyNm;
	}
	/**
	 * @return the stCd
	 */
	public String getStCd() {
		return stCd;
	}
	/**
	 * @param stCd the stCd to set
	 */
	public void setStCd(String stCd) {
		this.stCd = stCd;
	}
	/**
	 * @return the zipCd
	 */
	public int getZipCd() {
		return zipCd;
	}
	/**
	 * @param zipCd the zipCd to set
	 */
	public void setZipCd(int zipCd) {
		this.zipCd = zipCd;
	}
	/**
	 * @return the zipPls4Cd
	 */
	public int getZipPls4Cd() {
		return zipPls4Cd;
	}
	/**
	 * @param zipPls4Cd the zipPls4Cd to set
	 */
	public void setZipPls4Cd(int zipPls4Cd) {
		this.zipPls4Cd = zipPls4Cd;
	}
	/**
	 * @return the lglEntyCd
	 */
	public String getLglEntyCd() {
		return lglEntyCd;
	}
	/**
	 * @param lglEntyCd the lglEntyCd to set
	 */
	public void setLglEntyCd(String lglEntyCd) {
		this.lglEntyCd = lglEntyCd;
	}
	/**
	 * @return the homCosDivCd
	 */
	public String getHomCosDivCd() {
		return homCosDivCd;
	}
	/**
	 * @param homCosDivCd the homCosDivCd to set
	 */
	public void setHomCosDivCd(String homCosDivCd) {
		this.homCosDivCd = homCosDivCd;
	}
	/**
	 * @return the commtTxt
	 */
	public String getCommtTxt() {
		return commtTxt;
	}
	/**
	 * @param commtTxt the commtTxt to set
	 */
	public void setCommtTxt(String commtTxt) {
		this.commtTxt = commtTxt;
	}
	/**
	 * @return the creatDt
	 */
	public Date getCreatDt() {
		return creatDt;
	}
	/**
	 * @param creatDt the creatDt to set
	 */
	public void setCreatDt(Date creatDt) {
		this.creatDt = creatDt;
	}
	/**
	 * @return the mktNbrApplStCd
	 */
	public String getMktNbrApplStCd() {
		return mktNbrApplStCd;
	}
	/**
	 * @param mktNbrApplStCd the mktNbrApplStCd to set
	 */
	public void setMktNbrApplStCd(String mktNbrApplStCd) {
		this.mktNbrApplStCd = mktNbrApplStCd;
	}
	/**
	 * @param mktNbr
	 * @param userId
	 * @param userOfcCd
	 * @param lstUpdtDt
	 * @param lstUpdtTm
	 * @param mktNm
	 * @param effDt
	 * @param cancDt
	 * @param uhgBusUnitId
	 * @param prtlEligInd
	 * @param eligListRllpInd
	 * @param tmlnRsnTypCd
	 * @param uhnInd
	 * @param dirLstNm
	 * @param dirFstNm
	 * @param mgrLstNm
	 * @param mgrFstNm
	 * @param vpLstNm
	 * @param vpFstNm
	 * @param areaCd
	 * @param telNbr
	 * @param telExtNbr
	 * @param faxAreaCd
	 * @param faxTelNbr
	 * @param lglNm
	 * @param adrLn1Txt
	 * @param adrLn2Txt
	 * @param ctyNm
	 * @param stCd
	 * @param zipCd
	 * @param zipPls4Cd
	 * @param lglEntyCd
	 * @param homCosDivCd
	 * @param commtTxt
	 * @param creatDt
	 * @param mktNbrApplStCd
	 */
	public MarketObj(int mktNbr, String userId, String userOfcCd, Date lstUpdtDt, Timestamp lstUpdtTm, String mktNm,
			Date effDt, Date cancDt, String uhgBusUnitId, String prtlEligInd, String eligListRllpInd,
			String tmlnRsnTypCd, String uhnInd, String dirLstNm, String dirFstNm, String mgrLstNm, String mgrFstNm,
			String vpLstNm, String vpFstNm, String areaCd, int telNbr, String telExtNbr, String faxAreaCd,
			int faxTelNbr, String lglNm, String adrLn1Txt, String adrLn2Txt, String ctyNm, String stCd, int zipCd,
			int zipPls4Cd, String lglEntyCd, String homCosDivCd, String commtTxt, Date creatDt, String mktNbrApplStCd) {
		super();
		this.mktNbr = mktNbr;
		this.userId = userId;
		this.userOfcCd = userOfcCd;
		this.lstUpdtDt = lstUpdtDt;
		this.lstUpdtTm = lstUpdtTm;
		this.mktNm = mktNm;
		this.effDt = effDt;
		this.cancDt = cancDt;
		this.uhgBusUnitId = uhgBusUnitId;
		this.prtlEligInd = prtlEligInd;
		this.eligListRllpInd = eligListRllpInd;
		this.tmlnRsnTypCd = tmlnRsnTypCd;
		this.uhnInd = uhnInd;
		this.dirLstNm = dirLstNm;
		this.dirFstNm = dirFstNm;
		this.mgrLstNm = mgrLstNm;
		this.mgrFstNm = mgrFstNm;
		this.vpLstNm = vpLstNm;
		this.vpFstNm = vpFstNm;
		this.areaCd = areaCd;
		this.telNbr = telNbr;
		this.telExtNbr = telExtNbr;
		this.faxAreaCd = faxAreaCd;
		this.faxTelNbr = faxTelNbr;
		this.lglNm = lglNm;
		this.adrLn1Txt = adrLn1Txt;
		this.adrLn2Txt = adrLn2Txt;
		this.ctyNm = ctyNm;
		this.stCd = stCd;
		this.zipCd = zipCd;
		this.zipPls4Cd = zipPls4Cd;
		this.lglEntyCd = lglEntyCd;
		this.homCosDivCd = homCosDivCd;
		this.commtTxt = commtTxt;
		this.creatDt = creatDt;
		this.mktNbrApplStCd = mktNbrApplStCd;
	}
	/**
	 * 
	 */
	public MarketObj() {
		super();
	}
	/**
	 * @param mktNbr
	 * @param mktNm
	 * @param effDt
	 * @param cancDt
	 */
	public MarketObj(int mktNbr, String mktNm, Date effDt, Date cancDt) {
		super();
		this.mktNbr = mktNbr;
		this.mktNm = mktNm;
		this.effDt = effDt;
		this.cancDt = cancDt;
	}

	
	

}
