package com.uhc.provider.zipcode.model;

import java.sql.Date;

public class MarketDesiredObj {

	private int mktNbr;
	private String mktNm;
	private Date effDt;
	private Date cancDt;
	/**
	 * @return the mktNbr
	 */
	public int getMktNbr() {
		return mktNbr;
	}
	/**
	 * @param mktNbr the mktNbr to set
	 */
	public void setMktNbr(int mktNbr) {
		this.mktNbr = mktNbr;
	}
	/**
	 * @return the mktNm
	 */
	public String getMktNm() {
		return mktNm;
	}
	/**
	 * @param mktNm the mktNm to set
	 */
	public void setMktNm(String mktNm) {
		this.mktNm = mktNm;
	}
	/**
	 * @return the effDt
	 */
	public Date getEffDt() {
		return effDt;
	}
	/**
	 * @param effDt the effDt to set
	 */
	public void setEffDt(Date effDt) {
		this.effDt = effDt;
	}
	/**
	 * @return the cancDt
	 */
	public Date getCancDt() {
		return cancDt;
	}
	/**
	 * @param cancDt the cancDt to set
	 */
	public void setCancDt(Date cancDt) {
		this.cancDt = cancDt;
	}
	/**
	 * @param mktNbr
	 * @param mktNm
	 * @param effDt
	 * @param cancDt
	 */
	public MarketDesiredObj(int mktNbr, String mktNm, Date effDt, Date cancDt) {
		super();
		this.mktNbr = mktNbr;
		this.mktNm = mktNm;
		this.effDt = effDt;
		this.cancDt = cancDt;
	}
	/**
	 * 
	 */
	public MarketDesiredObj() {
		super();
	}
	
}
