package com.uhc.provider.zipcode.service;

import java.sql.Connection;
import java.util.List;

import com.uhc.provider.zipcode.model.SearchInputObj;
import com.uhc.provider.zipcode.model.SearchOutputObj;

public interface Search {
	/**
	 * 
	 * @param searchInputObj
	 * @return SearchOutputObj
	 */
	public List<SearchOutputObj> getZipCode(SearchInputObj searchInputObj, Connection connection) ;
	
	
}
