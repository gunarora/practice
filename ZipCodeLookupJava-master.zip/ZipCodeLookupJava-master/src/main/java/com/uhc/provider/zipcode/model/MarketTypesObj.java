package com.uhc.provider.zipcode.model;

import java.sql.Date;
import java.sql.Timestamp;

public class MarketTypesObj {

	private String marketTypeCode;
	private String userID;
	private String userOficeCode;
	private Date lastUpdateDate;
	private Timestamp lasteUpdateTimestamp;
	private String productCategoryCode;
	private String activeCode;
	private String marketTypeDescription;
	private String applicationNonStdProductGroupInd;

	/**
	 * @return the marketTypeCode
	 */
	public String getMarketTypeCode() {
		return marketTypeCode;
	}

	/**
	 * @param marketTypeCode
	 *            the marketTypeCode to set
	 */
	public void setMarketTypeCode(String marketTypeCode) {
		this.marketTypeCode = marketTypeCode;
	}

	/**
	 * @return the userID
	 */
	public String getUserID() {
		return userID;
	}

	/**
	 * @param userID
	 *            the userID to set
	 */
	public void setUserID(String userID) {
		this.userID = userID;
	}

	/**
	 * @return the userOficeCode
	 */
	public String getUserOficeCode() {
		return userOficeCode;
	}

	/**
	 * @param userOficeCode
	 *            the userOficeCode to set
	 */
	public void setUserOficeCode(String userOficeCode) {
		this.userOficeCode = userOficeCode;
	}

	/**
	 * @return the lastUpdateDate
	 */
	public Date getLastUpdateDate() {
		return lastUpdateDate;
	}

	/**
	 * @param lastUpdateDate
	 *            the lastUpdateDate to set
	 */
	public void setLastUpdateDate(Date lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	/**
	 * @return the lasteUpdateTimestamp
	 */
	public Timestamp getLasteUpdateTimestamp() {
		return lasteUpdateTimestamp;
	}

	/**
	 * @param lasteUpdateTimestamp
	 *            the lasteUpdateTimestamp to set
	 */
	public void setLasteUpdateTimestamp(Timestamp lasteUpdateTimestamp) {
		this.lasteUpdateTimestamp = lasteUpdateTimestamp;
	}

	/**
	 * @return the productCategoryCode
	 */
	public String getProductCategoryCode() {
		return productCategoryCode;
	}

	/**
	 * @param productCategoryCode
	 *            the productCategoryCode to set
	 */
	public void setProductCategoryCode(String productCategoryCode) {
		this.productCategoryCode = productCategoryCode;
	}

	/**
	 * @return the activeCode
	 */
	public String getActiveCode() {
		return activeCode;
	}

	/**
	 * @param activeCode
	 *            the activeCode to set
	 */
	public void setActiveCode(String activeCode) {
		this.activeCode = activeCode;
	}

	/**
	 * @return the marketTypeDescription
	 */
	public String getMarketTypeDescription() {
		return marketTypeDescription;
	}

	/**
	 * @param marketTypeDescription
	 *            the marketTypeDescription to set
	 */
	public void setMarketTypeDescription(String marketTypeDescription) {
		this.marketTypeDescription = marketTypeDescription;
	}

	/**
	 * @return the applicationNonStdProductGroupInd
	 */
	public String getApplicationNonStdProductGroupInd() {
		return applicationNonStdProductGroupInd;
	}

	/**
	 * @param applicationNonStdProductGroupInd
	 *            the applicationNonStdProductGroupInd to set
	 */
	public void setApplicationNonStdProductGroupInd(String applicationNonStdProductGroupInd) {
		this.applicationNonStdProductGroupInd = applicationNonStdProductGroupInd;
	}

	/**
	 * @param marketTypeCode
	 * @param userID
	 * @param userOficeCode
	 * @param lastUpdateDate
	 * @param lasteUpdateTimestamp
	 * @param productCategoryCode
	 * @param activeCode
	 * @param marketTypeDescription
	 * @param applicationNonStdProductGroupInd
	 */
	public MarketTypesObj(String marketTypeCode, String userID, String userOficeCode, Date lastUpdateDate,
			Timestamp lasteUpdateTimestamp, String productCategoryCode, String activeCode, String marketTypeDescription,
			String applicationNonStdProductGroupInd) {
		super();
		this.marketTypeCode = marketTypeCode;
		this.userID = userID;
		this.userOficeCode = userOficeCode;
		this.lastUpdateDate = lastUpdateDate;
		this.lasteUpdateTimestamp = lasteUpdateTimestamp;
		this.productCategoryCode = productCategoryCode;
		this.activeCode = activeCode;
		this.marketTypeDescription = marketTypeDescription;
		this.applicationNonStdProductGroupInd = applicationNonStdProductGroupInd;
	}

	/**
	 * 
	 */
	public MarketTypesObj() {
		super();
	}

	/**
	 * @param marketTypeCode
	 * @param productCategoryCode
	 * @param activeCode
	 * @param marketTypeDescription
	 */
	public MarketTypesObj(String marketTypeCode, String productCategoryCode, String activeCode,
			String marketTypeDescription) {
		super();
		this.marketTypeCode = marketTypeCode;
		this.productCategoryCode = productCategoryCode;
		this.activeCode = activeCode;
		this.marketTypeDescription = marketTypeDescription;
	}

}
