package com.uhc.provider.zipcode.service;

import java.sql.Connection;
import java.util.List;

import com.uhc.provider.zipcode.model.StatesObj;

public interface State {
	/**
	 * 
	 * @return StatesObj
	 */
	public List<StatesObj> getStates(Connection connection);
}
