package com.uhc.provider.zipcode.service;

import java.sql.Connection;
import java.util.List;

import com.uhc.provider.zipcode.model.MarketTypesObj;

public interface MarketTypes {
	/**
	 * 
	 * @return MarketTypesObj
	 */
	public List<MarketTypesObj> getMarketTypes(Connection connection);
}
