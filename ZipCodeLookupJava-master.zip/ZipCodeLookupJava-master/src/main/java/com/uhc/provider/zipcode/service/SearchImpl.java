package com.uhc.provider.zipcode.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.uhc.provider.zipcode.model.SearchInputObj;
import com.uhc.provider.zipcode.model.SearchOutputObj;
import com.uhc.provider.zipcode.model.repository.ZipCodeRepositroy;
import org.springframework.beans.factory.annotation.Autowired;

public class SearchImpl implements Search {

	@Autowired
	ZipCodeRepositroy zipCodeRepositroy;
	/* (non-Javadoc)
	 * @see com.uhc.provider.zipcode.service.Search#getZipCode(com.uhc.provider.zipcode.model.SearchInputObj)
	 */

	@Override
	public List<SearchOutputObj> getZipCode(SearchInputObj searchInputObj,Connection connection) {
		// TODO Auto-generated method stub
		SearchOutputObj searchOutputObj=null;
		validateRequest(searchInputObj,searchOutputObj);
		List<SearchOutputObj> searchOutputObjs = new ArrayList<SearchOutputObj>();
		//Connection connection = null;
		try {
			// Establish connection
			//connection =zipCodeRepositroy.getMySQLDBConn();
			if(connection==null) {
				System.out.println("Connection Issue");
			}
			
			String queryPart1=	"select digits(zh.ziph_zip) as zipcode\r\n" + 
					"        ,cz.czip_state as state\r\n" + 
					"        ,cz.czip_county as county\r\n" + 
					"        ,substr(digits(zh.ziph_hcn_num),6,5) as market\r\n" + 
					"        ,zh.ziph_market_type as markettype\r\n" + 
					"        ,mk.mkt_nm as marketname ";
			
			//LOGIC for building queryPart2
			/*	--POS
	        		,zh.ziph_pos_eff_date
			     --HMO
			        ,zh.ziph_hmo_eff_date
			     --EPO
			        ,zh.ziph_epo_eff_date
			     --PPO
			        ,zh.ziph_ppo_eff_date
			     --IND
			        ,zh.ziph_ind_eff_date
			 */
			/*LOGIC for building queryPart4
			 * 	--POS Logic
				        and zh.ziph_pos_flag = 'Y' 
				        and zh.ziph_pos_can_date = '12/31/9999'
				--HMO Logic
				        and ziph_hmo_flag = 'Y' 
				        and ziph_hmo_can_date = '12/31/9999'
				--EPO Logic
				        and ziph_epo_flag = 'Y' 
				        and ziph_epo_can_date = '12/31/9999'
				--PPO Logic
				        and ziph_ppo_flag = 'Y' 
				        and ziph_ppo_can_date = '12/31/9999'
				--IND Logic
				        and ziph_ind_flag = 'Y' 
				        and ziph_ind_can_date = '12/31/9999'

			 */
			
			String queryPart2="",queryPart4="",queryPart5="";
			if(null!=searchInputObj.getProduct() && "POS".equalsIgnoreCase(searchInputObj.getProduct())) {
				queryPart2=" ,zh.ziph_pos_eff_date as effdate ";
				queryPart4=" and zh.ziph_pos_flag = 'Y' \r\n" + 
						" and zh.ziph_pos_can_date = '12/31/9999'";
			}
			if(null!=searchInputObj.getProduct() && "HMO".equalsIgnoreCase(searchInputObj.getProduct())) {
				queryPart2=",zh.ziph_hmo_eff_date as effdate ";
				queryPart4=" and zh.ziph_hmo_flag = 'Y' \r\n" + 
						" and zh.ziph_hmo_can_date = '12/31/9999' ";
			}
			if(null!=searchInputObj.getProduct() && "EPO".equalsIgnoreCase(searchInputObj.getProduct())) {
				queryPart2=",zh.ziph_epo_eff_date as effdate ";
				queryPart4=" and zh.ziph_epo_flag = 'Y' \r\n" + 
						" and zh.ziph_epo_can_date = '12/31/9999' ";
			}
			if(null!=searchInputObj.getProduct() && "PPO".equalsIgnoreCase(searchInputObj.getProduct())) {
				queryPart2=",zh.ziph_ppo_eff_date as effdate ";
				queryPart4=" and zh.ziph_ppo_flag = 'Y' \r\n" + 
						" and zh.ziph_ppo_can_date = '12/31/9999' ";
			}
			if(null!=searchInputObj.getProduct() && "IND".equalsIgnoreCase(searchInputObj.getProduct())) {
				queryPart2=",zh.ziph_ind_eff_date as effdate ";
				queryPart4=" and zh.ziph_ind_flag = 'Y' \r\n" + 
						" and zh.ziph_ind_can_date = '12/31/9999' ";
			}
			
			
			String queryPart3="from f5938dbj.tpvziph zh \r\n" + 
					"        ,f5938dbj.tpvczip cz\r\n" + 
					"        ,f5938dbj.mkt mk\r\n" + 
					"where \r\n" + 
					"        zh.ziph_zip = cz.czip_zip\r\n" + 
					"        and zh.ziph_hcn_num = mk.mkt_nbr";
			
			if(null!=searchInputObj.getZipCode() && !(searchInputObj.getZipCode().isEmpty())){
				if("".equalsIgnoreCase(queryPart5)) {
					queryPart5=" and zh.ziph_zip = ? ";
				}
				else {
					queryPart5=queryPart5+" and ziph_zip = ? ";
				}
			}
			if(null!=searchInputObj.getMktNbr() && !(searchInputObj.getMktNbr().isEmpty())) {
				if("".equalsIgnoreCase(queryPart5)) {
					queryPart5=" and zh.ziph_hcn_num = ? ";
				}
				else {
					queryPart5=queryPart5+" and zh.ziph_hcn_num = ? ";
				}
			}		
			if(null!=searchInputObj.getMarketType() && !searchInputObj.getMarketType().isEmpty()) {
				if("".equalsIgnoreCase(queryPart5)) {
					queryPart5=" and zh.ziph_market_type = ? ";
				}
				else {
					queryPart5=queryPart5+" and zh.ziph_market_type = ? ";
				}
			}			
			if(null!=searchInputObj.getState() && !searchInputObj.getState().isEmpty()) {
				if("".equalsIgnoreCase(queryPart5)) {
					queryPart5="and cz.czip_state = ? ";
				}
				else {
					queryPart5=queryPart5+"and cz.czip_state = ? ";
				}
			}			
			
			
			String finalQuery=queryPart1+queryPart2+queryPart3+queryPart4+queryPart5+" with ur ";
			System.out.println("FinalQuery ::::: "+finalQuery);
			PreparedStatement selectState = connection.prepareStatement(finalQuery);
			int countValue=1;
			if(null!=searchInputObj.getZipCode() && !(searchInputObj.getZipCode().isEmpty())){
				selectState.setString(countValue, searchInputObj.getZipCode());
				countValue++;
				System.out.println(countValue+"Zip Code ::::: "+searchInputObj.getZipCode());
			}
			if(null!=searchInputObj.getMktNbr() && !(searchInputObj.getMktNbr().isEmpty())){
				System.out.println(countValue+"Market Number ::::: "+searchInputObj.getMktNbr());
				selectState.setString(countValue, searchInputObj.getMktNbr());
				countValue++;
				System.out.println(countValue+"Market Number ::::: "+searchInputObj.getMktNbr());
			}
			if(null!=searchInputObj.getMarketType() && !searchInputObj.getMarketType().isEmpty()){
				selectState.setString(countValue, searchInputObj.getMarketType());
				countValue++;
				System.out.println(countValue+"Market Type ::::: "+searchInputObj.getMarketType());
			}
			if(null!=searchInputObj.getState() && !searchInputObj.getState().isEmpty()){
				selectState.setString(countValue, searchInputObj.getState());
				countValue++;
				System.out.println(countValue+"State ::::: "+searchInputObj.getState());
			}
			
			System.out.println("With ParametersFinalQuery ::::: "+finalQuery);
			ResultSet rs = selectState.executeQuery();
			int count=0;
			while (rs.next()) {
				searchOutputObj=new SearchOutputObj();
				count++;
				searchOutputObj.setCounty(rs.getString("county"));
				searchOutputObj.setEffDate(rs.getDate("effdate"));
				searchOutputObj.setMktNbr(rs.getInt("market"));
				searchOutputObj.setMarketName(rs.getString("marketname"));
				searchOutputObj.setMarketType(rs.getString("markettype"));
				searchOutputObj.setState(rs.getString("state"));
				searchOutputObj.setZipCode(rs.getString("zipcode"));
								
				searchOutputObjs.add(searchOutputObj);
				System.out.println(count);
			}
		}
		catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (connection != null) {
				System.out.println("Connected successfully.");
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}	
		
		return searchOutputObjs;
	}
	
	public void validateRequest(SearchInputObj searchInputObj, SearchOutputObj searchOutputObj){
		if(null==searchInputObj.getMarketType()
				&& null==searchInputObj.getProduct()
				&& null==searchInputObj.getState()
				&& null==searchInputObj.getZipCode()
				&& null==searchInputObj.getMktNbr()) {
			System.out.println("Empty Input recieved");
		}
		
		
	}
	
}
