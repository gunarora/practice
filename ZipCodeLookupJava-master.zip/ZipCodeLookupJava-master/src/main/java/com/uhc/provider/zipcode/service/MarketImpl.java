package com.uhc.provider.zipcode.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.uhc.provider.zipcode.config.YamlConfig;
import com.uhc.provider.zipcode.model.MarketDesiredObj;
import com.uhc.provider.zipcode.model.MarketObj;
import com.uhc.provider.zipcode.model.repository.ZipCodeRepositroy;
import org.springframework.beans.factory.annotation.Autowired;

public class MarketImpl implements Market {

	@Autowired
	ZipCodeRepositroy zipCodeRepositroy;
	//private MultipleMarketObj multipleMarketObj = new MultipleMarketObj();
	//private MultipleMarketDesiredObj multipleMarketDesiredObj = new MultipleMarketDesiredObj();
	@Override
	public List<MarketObj> getMarket(Connection connection) {
		// To Do Logic
		//Logic: A loop of below objects will be populated with values from DB

		MarketObj marketObj;
		List<MarketObj> marketObjs = new ArrayList<MarketObj>();
		//Connection connection = null;
		try {
			// Establish connection
			//connection =zipCodeRepositroy.getMySQLDBConn();
			if(connection==null) {
				System.out.println("Connection Issue");
			}
			PreparedStatement selectState = connection.prepareStatement("select * from f5938dbj.mkt with ur");
			ResultSet rs = selectState.executeQuery();
			while (rs.next()) {
				marketObj =new MarketObj();
				
				marketObj.setAdrLn1Txt(rs.getString("ADR_LN_1_TXT"));
				marketObj.setAdrLn2Txt(rs.getString("ADR_LN_2_TXT"));
				marketObj.setAreaCd(rs.getString("AREA_CD"));
				marketObj.setCancDt(rs.getDate("CANC_DT"));
				marketObj.setCommtTxt(rs.getString("COMMT_TXT"));
				marketObj.setCreatDt(rs.getDate("CREAT_DT"));
				marketObj.setCtyNm(rs.getString("CTY_NM"));
				marketObj.setDirFstNm(rs.getString("DIR_FST_NM"));
				marketObj.setDirLstNm(rs.getString("DIR_LST_NM"));
				marketObj.setEffDt(rs.getDate("EFF_DT"));
				marketObj.setEligListRllpInd(rs.getString("ELIG_LIST_RLLP_IND"));
				marketObj.setFaxAreaCd(rs.getString("FAX_AREA_CD"));
				marketObj.setFaxTelNbr(rs.getInt("FAX_TEL_NBR"));
				marketObj.setHomCosDivCd(rs.getString("HOM_COS_DIV_CD"));
				marketObj.setLglEntyCd(rs.getString("LGL_ENTY_CD"));
				marketObj.setLglNm(rs.getString("LGL_NM"));
				marketObj.setLstUpdtDt(rs.getDate("LST_UPDT_DT"));
				marketObj.setLstUpdtTm(rs.getTimestamp("LST_UPDT_TM"));
				marketObj.setMgrFstNm(rs.getString("MGR_FST_NM"));
				marketObj.setMgrLstNm(rs.getString("MGR_LST_NM"));
				marketObj.setMktNbr(rs.getInt("MKT_NBR"));
				marketObj.setMktNbrApplStCd(rs.getString("MKT_NBR_APPL_ST_CD"));
				marketObj.setMktNm(rs.getString("MKT_NM"));
				marketObj.setPrtlEligInd(rs.getString("PRTL_ELIG_IND"));
				marketObj.setStCd(rs.getString("ST_CD"));
				marketObj.setTelExtNbr(rs.getString("TEL_EXT_NBR"));
				marketObj.setTelNbr(rs.getInt("TEL_NBR"));
				marketObj.setTmlnRsnTypCd(rs.getString("TMLN_RSN_TYP_CD"));
				marketObj.setUhgBusUnitId(rs.getString("UHG_BUS_UNIT_ID"));
				marketObj.setUhnInd(rs.getString("UHN_IND"));
				marketObj.setUserId(rs.getString("USER_ID"));
				marketObj.setUserOfcCd(rs.getString("USER_OFC_CD"));
				marketObj.setVpFstNm(rs.getString("VP_FST_NM"));
				marketObj.setVpLstNm(rs.getString("VP_LST_NM"));
				marketObj.setZipCd(rs.getInt("ZIP_CD"));
				marketObj.setZipPls4Cd(rs.getInt("ZIP_PLS_4_CD"));
				
				
				marketObjs.add(marketObj);
			}
		}
		catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (connection != null) {
				System.out.println("Connected successfully.");
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
		return marketObjs;
	}
	
	@Override
	public List<MarketDesiredObj> getDesiredMarket(Connection connection) {

		// To Do Logic
		//Logic: A loop of below objects will be populated with values from DB
		MarketDesiredObj marketObj;
		List<MarketDesiredObj> marketObjs = new ArrayList<MarketDesiredObj>();

		//Connection connection = null;
		try {
			// Establish connection
			//connection =zipCodeRepositroy.getMySQLDBConn();
			if(connection==null) {
				System.out.println("Connection Issue");
			}
			PreparedStatement selectState = connection.prepareStatement("select CANC_DT,EFF_DT,MKT_NBR,MKT_NM from f5938dbj.mkt with ur");
			ResultSet rs = selectState.executeQuery();
			while (rs.next()) {
				marketObj =new MarketDesiredObj();
				
				marketObj.setCancDt(rs.getDate("CANC_DT"));
				marketObj.setEffDt(rs.getDate("EFF_DT"));
				marketObj.setMktNbr(rs.getInt("MKT_NBR"));
				marketObj.setMktNm(rs.getString("MKT_NM"));
								
				marketObjs.add(marketObj);
			}
		}
		catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (connection != null) {
				System.out.println("Connected successfully.");
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return marketObjs;
	}
}
