package com.uhc.provider.zipcode.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

@Component
@Configuration
@EnableConfigurationProperties
@ConfigurationProperties
public class YamlConfig {

	
	private String classForName;
	private String db2ServerURLString;
	private String userId;
	private String password;
	
	public String getClassForName() {
		return classForName;
	}

	public void setClassForName(String classForName) {
		this.classForName = classForName;
	}

	public String getDb2ServerURLString() {
		return db2ServerURLString;
	}

	public void setDb2ServerURLString(String db2ServerURLString) {
		this.db2ServerURLString = db2ServerURLString;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}
