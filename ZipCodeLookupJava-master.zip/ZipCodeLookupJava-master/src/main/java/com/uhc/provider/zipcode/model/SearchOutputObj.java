package com.uhc.provider.zipcode.model;

import java.util.Date;

public class SearchOutputObj {

	private String zipCode;
	private String state;
	private String county;
	private int mktNbr;
	private String marketType;
	private String marketName;
	private Date effDate;
	/**
	 * @return the zipCode
	 */
	public String getZipCode() {
		return zipCode;
	}
	/**
	 * @param zipCode the zipCode to set
	 */
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}
	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}
	/**
	 * @return the county
	 */
	public String getCounty() {
		return county;
	}
	/**
	 * @param county the county to set
	 */
	public void setCounty(String county) {
		this.county = county;
	}
	/**
	 * @return the mktNbr
	 */
	public int getMktNbr() {
		return mktNbr;
	}
	/**
	 * @param mktNbr the mktNbr to set
	 */
	public void setMktNbr(int mktNbr) {
		this.mktNbr = mktNbr;
	}
	/**
	 * @return the marketType
	 */
	public String getMarketType() {
		return marketType;
	}
	/**
	 * @param marketType the marketType to set
	 */
	public void setMarketType(String marketType) {
		this.marketType = marketType;
	}
	/**
	 * @return the marketName
	 */
	public String getMarketName() {
		return marketName;
	}
	/**
	 * @param marketName the marketName to set
	 */
	public void setMarketName(String marketName) {
		this.marketName = marketName;
	}
	/**
	 * @return the effDate
	 */
	public Date getEffDate() {
		return effDate;
	}
	/**
	 * @param effDate the effDate to set
	 */
	public void setEffDate(Date effDate) {
		this.effDate = effDate;
	}
	/**
	 * @param zipCode
	 * @param state
	 * @param county
	 * @param mktNbr
	 * @param marketType
	 * @param marketName
	 * @param effDate
	 */
	public SearchOutputObj(String zipCode, String state, String county, int mktNbr, String marketType,
			String marketName, Date effDate) {
		super();
		this.zipCode = zipCode;
		this.state = state;
		this.county = county;
		this.mktNbr = mktNbr;
		this.marketType = marketType;
		this.marketName = marketName;
		this.effDate = effDate;
	}
	/**
	 * 
	 */
	public SearchOutputObj() {
		super();
	}
	
	
	
	
}
