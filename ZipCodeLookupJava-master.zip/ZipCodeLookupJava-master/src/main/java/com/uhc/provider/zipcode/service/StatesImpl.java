package com.uhc.provider.zipcode.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.uhc.provider.zipcode.model.StatesObj;
import com.uhc.provider.zipcode.model.repository.ZipCodeRepositroy;
import org.springframework.beans.factory.annotation.Autowired;

public class StatesImpl implements State {

	@Autowired
	ZipCodeRepositroy zipCodeRepositroy;

	@Override
	public List<StatesObj> getStates(Connection connection) {
		// TODO Auto-generated method stub
		StatesObj statesObj;
		List<StatesObj> statesObjs = new ArrayList<StatesObj>();
		//Connection connection = null;
		try {
			// Establish connection
			//connection =zipCodeRepositroy.getMySQLDBConn();
			if(connection==null) {
				System.out.println("Connection Issue");
			}
			PreparedStatement selectState = connection.prepareStatement("select * from f5938dbj.state with ur");
			ResultSet rs = selectState.executeQuery();
			while (rs.next()) {
				statesObj =new StatesObj();
				statesObj.setStateCode(rs.getString("ST_CD"));
				statesObj.setStateName(rs.getString("ST_NM"));
				statesObj.setCountryCode(rs.getString("CNTRY_CD"));
				statesObj.setCdsLicenceIndicator(rs.getString("CDS_LIC_IND"));
				statesObj.setTimeZonePrrNbr(rs.getInt("TM_ZONE_PRR_NBR"));
				statesObjs.add(statesObj);
			}
		}
		catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (connection != null) {
				System.out.println("Connected successfully.");
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
		return statesObjs;
	}

	
	
}
