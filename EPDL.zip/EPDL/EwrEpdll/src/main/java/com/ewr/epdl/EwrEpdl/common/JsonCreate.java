package com.ewr.epdl.EwrEpdl.common;


import org.apache.avro.LogicalTypes;
import org.apache.avro.Schema;
import org.apache.commons.lang3.StringEscapeUtils;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.nio.charset.Charset;
import java.util.Base64;

@Configuration
    @ComponentScan(basePackages = "com.ewr.epdl")
    public class JsonCreate  {
        public   String jsonConvert (String jsond) throws JSONException, UnsupportedEncodingException {
            JSONObject jsonval= null;

//            jsonObject = new JSONObject(jsond);

//            String dval = jsonObject.get("data").toString();
            jsonval = new JSONObject(jsond);
            String pqid = jsonval.get("PROC_ERR_QUE_ID").toString();
            String status = jsonval.get("ERR_QUE_STS_TYP_CD").toString();
            String srcTyp = jsonval.get("PROC_SRC_TYP_CD").toString();
            String vendorType = jsonval.get("OPER_AREA_TYP_CD").toString();
            String roleTypCd = jsonval.get("OPER_ROLE_TYP_CD").toString();
            String taxIdNbr = jsonval.get("TAX_ID_NBR").toString();

//            String lstUpdtDt = jsonval.get("LST_UPDT_DT").toString();
//            String lstUpdtTm = jsonval.get("LST_UPDT_TM").toString();
            return pqid+";"+status+";"+srcTyp +";" + vendorType+";" + roleTypCd+ ";" +taxIdNbr ;


        }
    }

