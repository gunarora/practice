package com.ewr.epdl.EwrEpdl.Controller;

import com.ewr.epdl.EwrEpdl.Producer.KafkaEPDLProducer;
import org.apache.avro.generic.GenericRecord;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;

import java.sql.*;
import java.util.ArrayList;


import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.TimeZone;
import java.util.Date;

@Component
@ComponentScan(basePackages = "com.ewr.epdl")
public class KafkaController {

    @Autowired
    KafkaEPDLProducer kafkaEPDLProducer;

    @Value("${dbconn.qualifier}")
    private String qualifier;

    @Value("${dbconn.user}")
    private String user;

    @Value("${dbconn.dbPassword}")
    private String dbPassword;

    @Value("${dbconn.url}")
    private String url;

    @Value("${dbconn.driver}")
    private String driver;

    KafkaConsumer<GenericRecord, GenericRecord> consumer = null;

    //    private static Connection connection = null;
//    private static Connection db2Connection = null;
    private String dataVendCd = "", specialTypCd = "", orgTypCd = "", provTypCd = "", srcTyp = "",vendorTyp = "", srcTypDesc = "", degreeTypDesc = ""  , roleType = "";
    private int seqNum = 0 , flagDVCS = 0 , addCount = 0  ;
    private String sqlDegreeDesc = "", sql= "", sqlPVDM = "", sqlDV = "", sqlDVR = "", sqlDVCS = "", sqlDVPS = "", sqlOrgT = "", sqlSpclTypDesc = "";
    private Statement selectState=null,  selectPVDM=null,  selectDV=null, selectDVR=null,  selectDVCS=null,  selectDVPS=null,  selectOrg=null,  selectSpclTypDesc=null,  selectDegreeTypDesc=null;

    private static String currentdate;
    private static String currentime;

    private static Connection connection = null;
    private static Connection db2Connection = null;

    private String var1 = "" ;
    private String var2 = "" ;
    private String var3 = "" ;
    private String var4 = "" ;
    private String var5 = "" ;
    private String var6 = "" ;
    private String var7 = "" ;
    private String var8 = "" ;
    private String var9 = "" ;
    //    private String var10 = "" ;
//    private String var11 = "" ;
    private ArrayList<String> var10 = new ArrayList<String>();

    private String var12 = "" ;
    private String var13 = "" ;
    private String var14 = "" ;
    private String var15 = "" ;
    private String var16 = "" ;
    private String var17 = "" ;
    private String var18 = "" ;
    private String var19 = "" ;
    private String var20 = "" ;
    private String var21 = "" ;
    private String var22 = "" ;
    private String var23 = "" ;
    private String var24 = "" ;
    private String var25 = "" ;
    private String var26 = "" ;
    private String var27 = "" ;
    private String var28 = "" ;
    private String var29 = "" ;
    private String var30 = "" ;
    private String var31 = "" ;
    private String var32 = "" ;
    private String var33 = "" ;
    private String var34 = "" ;
    private String var35 = "" ;
    private String var36 = "" ;
    private String var37 = "" ;
    private String var38 = "" ;
    private String var39 = "" ;
    private String var40 = "" ;
    private String var41 = "" ;
    private String var42 = "" ;
    private String var43 = "" ;
    private String var44 = "" ;
    private String var45 = "" ;
    private String var46 = "" ;
    private String var47 = "" ;
    private String var48 = "" ;
    private String var49 = "" ;
    private String var50 = "" ;
    private String var51 = "" ;
    private String var52 = "" ;
    private String var53 = "" ;
    private String var54 = "" ;
    private String var55 = "" ;
    private String var56 = "" ;
    private String var57 = "" ;
    private String var58 = "" ;
    private String var59 = "" ;
    private String var60 = "" ;
    private String var61 = "" ;
    private String var62 = "" ;
    private String var63 = "" ;
    private String var64 = "" ;
    private String var65 = "" ;
    private String var66 = "" ;
    private String var67 = "" ;
    private String var68 = "" ;
    private String var69 = "" ;
    private String var70 = "" ;
    private String var71 = "" ;
    private String var72 = "" ;
    private String var73 = "" ;
    private String var74 = "" ;
    private String var75 = "" ;
    private String var76 = "" ;
    private String var77 = "" ;
    private String var78 = "" ;
    private String var79 = "" ;
    private String var80 = "" ;
    private String var81 = "" ;
    private String var82 = "" ;
    private String var83 = "" ;
    private String var84 = "" ;
    private String var85 = "" ;
    private String var86 = "" ;
    private String var87 = "" ;
    private String var88 = "" ;
    private String var89 = "" ;
    private String var90 = "" ;
    private String var91 = "" ;
    private String var92 = "" ;
    private String var93 = "" ;
    private String var94 = "" ;
    private String var95 = "" ;
    private String var96 = "" ;
    private String var97 = "" ;
    private String var98 = "" ;
    private String var99 = "" ;
    private String var100 = "" ;
    private String var101 = "" ;
    private String var102 = "" ;
    private String var103 = "" ;
    private String var104 = "" ;
    private String var105 = "" ;
    private String var106 = "" ;
    private String var107 = "" ;
    private String var108 = "" ;
    private String var109 = "" ;
    private String var110 = "" ;
    private String var111 = "" ;
    private String var112 = "" ;
    private String var113 = "" ;
    private String var114 = "" ;
    private String var115 = "" ;
    private String var116 = "" ;
    private String var117 = "" ;
    private String var118 = "" ;
    private String var119 = "" ;
    private String var120 = "" ;
    private String var121 = "" ;
    private String var122 = "" ;
    private String var123 = "0001-01-01";
    private String var124 = "";
    private String var125 = "";
    private String var126 = "";
    private String var127 = "";
    private String var128 = "00";
    private String var129 = "00";
    private String var130 = "";
    private String var131 = "00";
    private String var132 = "00";
    private String var133 = "";
    private String var134 = "00";
    private String var135 = "00";
    private String var136 = "";
    private String var137 = "";
    private String var138 = "";
    private String var139 = "";
    private String var140 = "";
   private int peqVerNbr = 0, up = 0;
    private Statement sqlResolve = null;

    static TimeZone etTimeZone = TimeZone.getTimeZone("America/New_York");

    DateFormat datef = new SimpleDateFormat("yyyy-MM-dd");
    DateFormat datet = new SimpleDateFormat("HH:mm:ss");

    //    private static String loc = System.getProperty("user.dir") + "\\src\\main\\resources\\";
    private static String loc = System.getProperty("user.dir") ;
    JSONObject finalData = new JSONObject();
    private static final Logger logger = LoggerFactory.getLogger(KafkaController.class);

    //    public void createEnrichmentData(String filterVal, Connection connection) throws Exception {
    public void createEnrichmentData(String filterVal) throws Exception {

        String pqid = null, status = null;
        connection = null;
//        boolean append = true;
//
//        FileHandler handler = new FileHandler(loc+"/"+"epdlewr.log", append);
//
//        Logger logger = Logger.getLogger("com.ewr.epdl.EwrEpdl.Controller");
//        logger.addHandler(handler);

//        System.out.println("Tin is "+ tin);

        try {

            degreeTypDesc = "";dataVendCd = ""; specialTypCd = "" ; orgTypCd = ""; provTypCd = ""; srcTyp = "" ; vendorTyp = ""; srcTypDesc = ""; roleType = "";
            seqNum= 0; flagDVCS = 0 ; addCount = 0  ;
            sqlDegreeDesc = ""; sql= ""; sqlPVDM = ""; sqlDV = ""; sqlDVR = ""; sqlDVCS = ""; sqlDVPS = ""; sqlOrgT = ""; sqlSpclTypDesc = "" ;
            selectState=null;  selectPVDM=null ;  selectDV=null ; selectDVR=null ;  selectDVCS=null ;  selectDVPS=null ;  selectOrg=null ;  selectSpclTypDesc=null ;  selectDegreeTypDesc=null ;

            var1 = "" ;
            var2 = "" ;
            var3 = "" ;
            var4 = "" ;
            var5 = "" ;
            var6 = "" ;
            var7 = "" ;
            var8 = "" ;
            var9 = "" ;
            var10.clear();
//                    var10 = "" ;
//                    var11 = "" ;
            var12 = ""  ;
            var13 = "" ;
            var14 = "" ;
            var15 = "" ;
            var16 = "" ;
            var17 = "" ;
            var18 = "" ;
            var19 = "" ;
            var20 = "" ;
            var21 = "" ;
            var22 = "" ;
            var23 = "" ;
            var24 = "" ;
            var25 = "" ;
            var26 = "" ;
            var27 = "" ;
            var28 = "" ;
            var29 = "" ;
            var30 = "" ;
            var31 = "" ;
            var32 = "" ;
            var33 = "" ;
            var34 = "" ;
            var35 = "" ;
            var36 = "" ;
            var37 = "" ;
            var38 = "" ;
            var39 = "" ;
            var40 = "" ;
            var41 = "" ;
            var42 = "" ;
            var43 = "" ;
            var44 = "" ;
            var45 = "" ;
            var46 = "" ;
            var47 = "" ;
            var48 = "" ;
            var49 = "" ;
            var50 = "" ;
            var51 = "" ;
            var52 = "" ;
            var53 = "" ;
            var54 = "" ;
            var55 = "" ;
            var56 = "" ;
            var57 = "" ;
            var58 = "" ;
            var59 = "" ;
            var60 = "" ;
            var61 = "" ;
            var62 = "" ;
            var63 = "" ;
            var64 = "" ;
            var65 = "" ;
            var66 = "" ;
            var67 = "" ;
            var68 = "" ;
            var69 = "" ;
            var70 = "" ;
            var71 = "" ;
            var72 = "" ;
            var73 = "" ;
            var74 = "" ;
            var75 = "" ;
            var76 = "" ;
            var77 = "" ;
            var78 = "" ;
            var79 = "" ;
            var80 = "" ;
            var81 = "" ;
            var82 = "" ;
            var83 = "" ;
            var84 = "" ;
            var85 = "" ;
            var86 = "" ;
            var87 = "" ;
            var88 = "" ;
            var89 = "" ;
            var90 = "" ;
            var91 = "" ;
            var92 = "" ;
            var93 = "" ;
            var94 = "" ;
            var95 = "" ;
            var96 = "" ;
            var97 = "" ;
            var98 = "" ;
            var99 = "" ;
            var100 = "" ;
            var101 = "" ;
            var102 = "" ;
            var103 = "" ;
            var104 = "" ;
            var105 = "" ;
            var106 = "" ;
            var107 = "" ;
            var108 = "" ;
            var109 = "" ;
            var110 = "" ;
            var111 = "" ;
            var112 = "" ;
            var113 = "" ;
            var114 = "" ;
            var115 = "" ;
            var116 = "" ;
            var117 = "" ;
            var118 = "" ;
            var119 = "" ;
            var120 = "" ;
            var121 = "" ;
            var122 = "" ;
            var123 = "0001-01-01" ;
            var124 = ""  ;
            var125 = ""  ;
            var126 = ""  ;
            var140 = ""  ;
            var127 = "" ;
            var128 = "00" ;
            var129 = "00"  ;
            var130 = ""  ;
            var131 = "00";
            var132 = "00";
            var133 = ""  ;
            var134 = "00";
            var135 = "00"  ;
            var136 = "";
            var137 = "" ;
            var138 = ""  ;
            var139 = ""  ;

            long startTime = System.currentTimeMillis();

            String[] results = filterVal.split(";");
            for (int i = 0; i < results.length; i++) {
                if (i == 0) {
                    pqid = results[0].trim();
                } else if (i == 1) {

                    status = results[1].trim();
                } else if (i == 2 ) {
                    srcTyp = results[2].trim();
                }else if (i == 3 ) {
                    vendorTyp = results[3].trim();
                }else {
                    roleType = results[4].trim();
                }
            }

            if (status.trim().equals("O") && srcTyp.trim().equals("BB") &&
                    (vendorTyp.trim().equals("MEDI") || vendorTyp.trim().equals("LABC") || vendorTyp.trim().equals("ACN") || vendorTyp.trim().equals("HPHC") || vendorTyp.trim().equals("MPN")) &&
                    (roleType.trim().equals("SDLA") || roleType.trim().equals("SPUR") || roleType.trim().equals("EEBD") || roleType.trim().equals("NTAN") || roleType.trim().equals("LSNT") || roleType.trim().equals("TMLD") || roleType.trim().equals("SDLO") || roleType.trim().equals("DLO") || roleType.trim().equals("DLA") ))
            {
                //***************************Concept to enrichment the record
                if (connection == null) {
                    System.out.println("In connection ");
                    connection = getDB2Conn();

                    if (connection == null) {
//                            System.out.println("Connection Issue");
                        logger.info("Connection Issue");
                    }
                }
                else
                {
                    System.out.println(" Connection is not null "+ connection);

                }
                try {
                    sql = " SELECT DATA_VEND_CD  \n" +
                            "       , SEQ_NBR       \n" +
                            " , PERRQ.PROC_ERR_QUE_ID" +
                            ", PERRQ.LST_UPDT_DT" +
                            ", PERRQ.PRR_LVL_NBR" +
                            ", PERRQ.ERR_QUE_STS_TYP_CD" +
                            ", PERRQ.OPER_ROLE_TYP_CD" +
                            "   FROM " + qualifier + ".PROC_ERR_QUE     PERRQ    \n" +
                            "       ," + qualifier + ".DATA_VEND_ERR_QUE    VERRQ    \n" +
                            "  WHERE PERRQ.PROC_ERR_QUE_ID        = " + pqid +
                            "    AND PERRQ.PROC_SRC_TYP_CD        = 'BB'                   \n" +
                            "    AND VERRQ.PROC_ERR_QUE_ID        = PERRQ.PROC_ERR_QUE_ID    \n" +
                            "   WITH UR    ";

//                            logger.info(sql);

                    selectState = connection.createStatement();

                    ResultSet m = selectState.executeQuery(sql);

                    while (m.next()) {
                        dataVendCd = m.getString("DATA_VEND_CD");
                        seqNum = m.getInt("SEQ_NBR");
                        var1 = m.getString("PROC_ERR_QUE_ID");
                        var7 = m.getString("LST_UPDT_DT");

                        var19 = m.getString("PRR_LVL_NBR");
                        var20 = m.getString("ERR_QUE_STS_TYP_CD");
                        var21 = m.getString("OPER_ROLE_TYP_CD");

                    }

                    if (!dataVendCd.equals("")) {
                        sqlPVDM = "SELECT PVDS.DATA_VEND_CD" +
                                ", PVDS.VEND_KEY_NBR" +
                                ", PVDS.REC_TYP_CD" +
                                ", PVDS.CREAT_DT" +
                                ", PVDS.BIL_EPD_ADR_SQ_NBR" +
                                ", PVDS.POS_EPD_ADR_SQ_NBR" +
                                ", PVDS.FST_NM" +
                                ", PVDS.MDL_NM" +
                                ", PVDS.LST_NM" +
                                ", PVDS.NM_SUFX_CD" +
                                ", PVDS.PROV_ID" +
                                ", PVDS.TAX_ID_NBR" +
                                ", PVDS.SOC_SECUR_NBR" +
                                ", PVDS.CANC_DT" +
                                ", PVDS.DEL_RSN_CD" +
                                ", PVDS.BIL_ADR_CARE_NM" +
                                ", PVDS.POS_ST_CD" +
                                ", PVDS.POS_ZIP_CD" +
                                ", PVDS.POS_ZIP_PLS_4_CD" +
                                ", PVDS.POS_AREA_CD" + ", PVDS.POS_TEL_NBR" +
                                ", PVDS.TEL_PRI_PLSV_CD" +
                                ", PVDS.PROV_BTH_DT" +
                                ", PVDS.PROV_GDR_CD" +
                                ", PVDS.NPI_ID" +
                                ", PVDS.DEG_CD" +
                                ", PVDS.SPCL_TYP_CD" +
                                ", PVDS.TAX_ID_TYP_CD" +
                                ", PVDS.POS_ADR_LN_1_TXT" +
                                ", PVDS.POS_ADR_LN_2_TXT" +
                                ", PVDS.POS_CTY_NM" +
                                ", PVDS.POS_ST_CD" +
                                ", PVDS.POS_ZIP_CD" +
                                ", PVDS.POS_ZIP_PLS_4_CD" +
                                ", PVDS.POS_ADR_TYP_CD" +
                                ", PVDS.POS_EPD_ADR_SQ_NBR" +
                                ", PVDS.POS_AREA_CD" +
                                ", PVDS.POS_TEL_NBR" +
                                ", PVDS.POS_ADR_TYP_CD" +
                                ", PVDS.POS_ADR_LN_1_TXT" +
                                ", PVDS.POS_ADR_LN_2_TXT" +
                                ", PVDS.POS_CTY_NM" +
                                ", PVDS.POS_ST_CD" +
                                ", PVDS.POS_ZIP_CD" +
                                ", PVDS.POS_ZIP_PLS_4_CD" +
                                ", PVDS.POS_ADR_TYP_CD" +
                                ", PVDS.POS_EPD_ADR_SQ_NBR" +
                                ", PVDS.POS_FAX_AREA_CD" +
                                ", PVDS.POS_FAX_TEL_NBR" +
                                ", PVDS.POS_ADR_TYP_CD" +
                                ", PVDS.POS_ADR_LN_1_TXT" +
                                ", PVDS.POS_ADR_LN_2_TXT" +
                                ", PVDS.POS_CTY_NM" +
                                ", PVDS.POS_ST_CD" +
                                ", PVDS.POS_ZIP_CD" +
                                ", PVDS.POS_ZIP_PLS_4_CD" +
                                ", PVDS.POS_ADR_TYP_CD" +
                                ", PVDS.POS_EPD_ADR_SQ_NBR" +
                                ", PVDS.POS_2_AREA_CD" +
                                ", PVDS.POS_2_TEL_NBR" +
                                ", PVDS.POS_ADR_TYP_CD" +
                                ", PVDS.POS_ADR_LN_1_TXT" +
                                ", PVDS.POS_ADR_LN_2_TXT" +
                                ", PVDS.POS_CTY_NM" +
                                ", PVDS.POS_ST_CD" +
                                ", PVDS.POS_ZIP_CD" +
                                ", PVDS.POS_ZIP_PLS_4_CD" +
                                ", PVDS.POS_ADR_TYP_CD" +
                                ", PVDS.POS_EPD_ADR_SQ_NBR" +
                                ", PVDS.POS_3_AREA_CD" +
                                ", PVDS.POS_3_TEL_NBR" +
                                ", PVDS.POS_ADR_TYP_CD" +
                                ", PVDS.BIL_ADR_LN_1_TXT" +
                                ", PVDS.BIL_ADR_LN_2_TXT" +
                                ", PVDS.BIL_CTY_NM" +
                                ", PVDS.BIL_ST_CD" +
                                ", PVDS.BIL_ZIP_CD" +
                                ", PVDS.BIL_ZIP_PLS_4_CD" +
                                ", PVDS.BIL_ADR_TYP_CD" +
                                ", PVDS.BIL_EPD_ADR_SQ_NBR" +
                                ", PVDS.BIL_AREA_CD" +
                                ", PVDS.BIL_TEL_NBR" +
                                ", PVDS.BIL_ADR_TYP_CD" +
                                ", PVDS.BIL_ADR_LN_1_TXT" +
                                ", PVDS.BIL_ADR_LN_2_TXT" +
                                ", PVDS.BIL_CTY_NM" +
                                ", PVDS.BIL_ST_CD" +
                                ", PVDS.BIL_ZIP_CD" +
                                ", PVDS.BIL_ZIP_PLS_4_CD" +
                                ", PVDS.BIL_ADR_TYP_CD" +
                                ", PVDS.BIL_EPD_ADR_SQ_NBR" +
                                ", PVDS.BIL_FAX_AREA_CD" +
                                ", PVDS.BIL_FAX_TEL_NBR" +
                                ", PVDS.BIL_ADR_TYP_CD" +
                                ", PVDS.BIL_ADR_LN_1_TXT" +
                                ", PVDS.BIL_ADR_LN_2_TXT" +
                                ", PVDS.BIL_CTY_NM" +
                                ", PVDS.BIL_ST_CD" +
                                ", PVDS.BIL_ZIP_CD" +
                                ", PVDS.BIL_ZIP_PLS_4_CD" +
                                ", PVDS.BIL_ADR_TYP_CD" +
                                ", PVDS.BIL_EPD_ADR_SQ_NBR" +
                                ", PVDS.BIL_2_AREA_CD" +
                                ", PVDS.BIL_2_TEL_NBR" +
                                ", PVDS.BIL_ADR_TYP_CD" +
                                ", PVDS.BIL_ADR_LN_1_TXT" +
                                ", PVDS.BIL_ADR_LN_2_TXT" +
                                ", PVDS.BIL_CTY_NM" +
                                ", PVDS.BIL_ST_CD" +
                                ", PVDS.BIL_ZIP_CD" +
                                ", PVDS.BIL_ZIP_PLS_4_CD" +
                                ", PVDS.BIL_ADR_TYP_CD" +
                                ", PVDS.BIL_EPD_ADR_SQ_NBR" +
                                ", PVDS.BIL_3_AREA_CD" +
                                ", PVDS.BIL_3_TEL_NBR" +
                                ", PVDS.BIL_ADR_TYP_CD" +
                                ", PVDS.PDE_DIV_1_CD" +
                                ", PVDS.PDE_PROV_1_CD" +
                                ", PVDS.PDE_PROV_1_NBR " +
                                ", PVDS.PDE_DIV_2_CD" +
                                ", PVDS.PDE_PROV_2_CD " +
                                ", PVDS.PDE_PROV_2_NBR " +
                                ", PVDS.PDE_DIV_3_CD" +
                                ", PVDS.PDE_PROV_3_CD" +
                                ", PVDS.PDE_PROV_3_NBR" +
                                " FROM " + qualifier + ".DATA_VEND_PVDM_STG PVDS" +
                                " WHERE PVDS.DATA_VEND_CD= " + "'" + dataVendCd.trim() + "' " +
                                " AND PVDS.SEQ_NBR= " + seqNum + " WITH UR";

//                                logger.info(sqlPVDM);

                        ResultSet m1 = selectState.executeQuery(sqlPVDM);
                        while (m1.next()) {
                            var3 = m1.getString("DATA_VEND_CD");
                            var4 = m1.getString("VEND_KEY_NBR");
                            var5 = m1.getString("REC_TYP_CD");
                            var6 = m1.getString("CREAT_DT");
                            var8 = m1.getString("BIL_EPD_ADR_SQ_NBR");
                            var9 = m1.getString("POS_EPD_ADR_SQ_NBR");
                            var12 = m1.getString("FST_NM");
                            var13 = m1.getString("MDL_NM");
                            var14 = m1.getString("LST_NM");
                            var15 = m1.getString("NM_SUFX_CD");
                            var16 = m1.getString("PROV_ID");
                            var17 = m1.getString("TAX_ID_NBR");
                            var18 = m1.getString("SOC_SECUR_NBR");
                            var22 = m1.getString("CANC_DT");
                            var23 = m1.getString("DEL_RSN_CD");
                            var24 = m1.getString("BIL_ADR_CARE_NM");
                            var25 = m1.getString("POS_ST_CD");
                            var26 = m1.getString("POS_ZIP_CD");
                            var27 = m1.getString("POS_ZIP_PLS_4_CD");
                            var28 = m1.getString("POS_AREA_CD");
                            var29 = m1.getString("POS_TEL_NBR");
                            var30 = m1.getString("TEL_PRI_PLSV_CD");
                            var31 = m1.getString("PROV_BTH_DT");
                            var32 = m1.getString("PROV_GDR_CD");
                            var33 = m1.getString("NPI_ID");
                            var34 = m1.getString("DEG_CD");
                            specialTypCd = m1.getString("SPCL_TYP_CD");
                            var35 = m1.getString("TAX_ID_TYP_CD");
                            var36 = m1.getString("POS_ADR_LN_1_TXT");
                            var37 = m1.getString("POS_ADR_LN_2_TXT");
                            var38 = m1.getString("POS_CTY_NM");
                            var39 = m1.getString("POS_ST_CD");
                            var40 = m1.getString("POS_ZIP_CD");
                            var41 = m1.getString("POS_ZIP_PLS_4_CD");
                            var42 = m1.getString("POS_ADR_TYP_CD");
                            var43 = m1.getString("POS_EPD_ADR_SQ_NBR");
                            var44 = m1.getString("POS_AREA_CD");
                            var45 = m1.getString("POS_TEL_NBR");
//                                var46 = m1.getString("POS_ADR_TYP_CD");
                            var46 = "POS";
                            var47 = m1.getString("POS_ADR_LN_1_TXT");
                            var48 = m1.getString("POS_ADR_LN_2_TXT");
                            var139 = m1.getString("POS_CTY_NM");
                            var49 = m1.getString("POS_ST_CD");
                            var50 = m1.getString("POS_ZIP_CD");
                            var51 = m1.getString("POS_ZIP_PLS_4_CD");
                            var52 = m1.getString("POS_ADR_TYP_CD");
                            var53 = m1.getString("POS_EPD_ADR_SQ_NBR");
                            var54 = m1.getString("POS_FAX_AREA_CD");
                            var55 = m1.getString("POS_FAX_TEL_NBR");
//                                var56 = m1.getString("POS_ADR_TYP_CD");
                            var56 = "FAX";
                            var57 = m1.getString("POS_ADR_LN_1_TXT");
                            var58 = m1.getString("POS_ADR_LN_2_TXT");
                            var59 = m1.getString("POS_CTY_NM");
                            var60 = m1.getString("POS_ST_CD");
                            var61 = m1.getString("POS_ZIP_CD");
                            var62 = m1.getString("POS_ZIP_PLS_4_CD");
                            var63 = m1.getString("POS_ADR_TYP_CD");
                            var64 = m1.getString("POS_EPD_ADR_SQ_NBR");
                            var65 = m1.getString("POS_2_AREA_CD");
                            var66 = m1.getString("POS_2_TEL_NBR");
//                                var67 = m1.getString("POS_ADR_TYP_CD");
                            var67 = "POS";
                            var68 = m1.getString("POS_ADR_LN_1_TXT");
                            var69 = m1.getString("POS_ADR_LN_2_TXT");
                            var70 = m1.getString("POS_CTY_NM");
                            var71 = m1.getString("POS_ST_CD");
                            var72 = m1.getString("POS_ZIP_CD");
                            var73 = m1.getString("POS_ZIP_PLS_4_CD");
                            var74 = m1.getString("POS_ADR_TYP_CD");
                            var75 = m1.getString("POS_EPD_ADR_SQ_NBR");
                            var76 = m1.getString("POS_3_AREA_CD");
                            var77 = m1.getString("POS_3_TEL_NBR");
//                                var78 = m1.getString("POS_ADR_TYP_CD");
                            var78 = "POS";
                            var79 = m1.getString("BIL_ADR_LN_1_TXT");
                            var80 = m1.getString("BIL_ADR_LN_2_TXT");
                            var81 = m1.getString("BIL_CTY_NM");
                            var82 = m1.getString("BIL_ST_CD");
                            var83 = m1.getString("BIL_ZIP_CD");
                            var84 = m1.getString("BIL_ZIP_PLS_4_CD");
                            var85 = m1.getString("BIL_ADR_TYP_CD");
                            var86 = m1.getString("BIL_EPD_ADR_SQ_NBR");
                            var87 = m1.getString("BIL_AREA_CD");
                            var88 = m1.getString("BIL_TEL_NBR");
//                                var89 = m1.getString("BIL_ADR_TYP_CD");
                            var89 = "BILL";
                            var90 = m1.getString("BIL_ADR_LN_1_TXT");
                            var91 = m1.getString("BIL_ADR_LN_2_TXT");
                            var92 = m1.getString("BIL_CTY_NM");
                            var93 = m1.getString("BIL_ST_CD");
                            var94 = m1.getString("BIL_ZIP_CD");
                            var95 = m1.getString("BIL_ZIP_PLS_4_CD");
                            var96 = m1.getString("BIL_ADR_TYP_CD");
                            var97 = m1.getString("BIL_EPD_ADR_SQ_NBR");
                            var98 = m1.getString("BIL_FAX_AREA_CD");
                            var99 = m1.getString("BIL_FAX_TEL_NBR");
//                                var100 = m1.getString("BIL_ADR_TYP_CD");
                            var100 = "FAX";
                            var101 = m1.getString("BIL_ADR_LN_1_TXT");
                            var102 = m1.getString("BIL_ADR_LN_2_TXT");
                            var103 = m1.getString("BIL_CTY_NM");
                            var104 = m1.getString("BIL_ST_CD");
                            var105 = m1.getString("BIL_ZIP_CD");
                            var106 = m1.getString("BIL_ZIP_PLS_4_CD");
                            var107 = m1.getString("BIL_ADR_TYP_CD");
                            var108 = m1.getString("BIL_EPD_ADR_SQ_NBR");
                            var109 = m1.getString("BIL_2_AREA_CD");
                            var110 = m1.getString("BIL_2_TEL_NBR");
//                                var111 = m1.getString("BIL_ADR_TYP_CD");
                            var111 = "BILL";
                            var112 = m1.getString("BIL_ADR_LN_1_TXT");
                            var113 = m1.getString("BIL_ADR_LN_2_TXT");
                            var114 = m1.getString("BIL_CTY_NM");
                            var115 = m1.getString("BIL_ST_CD");
                            var116 = m1.getString("BIL_ZIP_CD");
                            var117 = m1.getString("BIL_ZIP_PLS_4_CD");
                            var118 = m1.getString("BIL_ADR_TYP_CD");
                            var119 = m1.getString("BIL_EPD_ADR_SQ_NBR");
                            var120 = m1.getString("BIL_3_AREA_CD");
                            var121 = m1.getString("BIL_3_TEL_NBR");
//                                var122 = m1.getString("BIL_ADR_TYP_CD");
                            var121 = "BILL";
                            var128 = m1.getString("PDE_DIV_1_CD");
                            var129 = m1.getString("PDE_PROV_1_CD");
                            var130 = m1.getString("PDE_PROV_1_NBR");
                            var131 = m1.getString("PDE_DIV_2_CD");
                            var132 = m1.getString("PDE_PROV_2_CD");
                            var133 = m1.getString("PDE_PROV_2_NBR");
                            var134 = m1.getString("PDE_DIV_3_CD");
                            var135 = m1.getString("PDE_PROV_3_CD");
                            var136 = m1.getString("PDE_PROV_3_NBR");
                        }

                        sqlDV = "SELECT DATA_VEND_DESC" +
                                " FROM " + qualifier + ".DATA_VEND DV" +
                                " WHERE DV.DATA_VEND_CD= " + "'" + dataVendCd.trim() + "' " +
                                " WITH UR";
//                                logger.info(sqlDV);

                        ResultSet mDV = selectState.executeQuery(sqlDV);
                        while (mDV.next()) {

                            var2 = mDV.getString("DATA_VEND_DESC");

                        }

                        sqlDVR = "SELECT DVR.RPT_TYP_CD , " +
                                "DVR.COMMT_TXT" +
                                " FROM " + qualifier + ".DATA_VEND_RPT DVR" +
                                " WHERE DVR.DATA_VEND_CD= " + "'" + dataVendCd.trim() + "' " +
                                " AND DVR.SEQ_NBR= " + seqNum + " WITH UR";
//                                logger.info(sqlDVR);

                        ResultSet mDVR = selectState.executeQuery(sqlDVR);
                        while (mDVR.next()) {
                            var10.add(mDVR.getString("RPT_TYP_CD")+" - "+ mDVR.getString("COMMT_TXT").trim() )  ;

//                                    var10 = mDVR.getString("RPT_TYP_CD");
//                                    var11 = mDVR.getString("COMMT_TXT");

                        }

                        sqlDVCS = "SELECT DVCS.VEND_CONTR_EFF_DT  " +
                                ", DVCS.PROV_CONTR_ROLE_CD " +
                                ", DVCS.VEND_SCHED_NBR " +
                                ", DVCS.VEND_CSU_NBR " +
                                ", DVCS.TMLY_FL_DAY_NBR " +
                                ", DVCS.VEND_NTWK_PRDCT_ID " +
                                " FROM " + qualifier + ".DATA_VEND_CONT_STG DVCS" +
                                " WHERE DVCS.DATA_VEND_CD= " + "'" + dataVendCd.trim() + "' " +
                                " AND DVCS.SEQ_NBR= " + seqNum + " WITH UR";
//                                logger.info(sqlDVCS);

                        ResultSet mDVCS = selectState.executeQuery(sqlDVCS);
                        while (mDVCS.next()) {
                            flagDVCS++;
                            var123 = mDVCS.getString("VEND_CONTR_EFF_DT");
                            var124 = mDVCS.getString("PROV_CONTR_ROLE_CD");
                            var125 = mDVCS.getString("VEND_SCHED_NBR");
                            var126 = mDVCS.getString("VEND_CSU_NBR");
                            var140 = mDVCS.getString("VEND_NTWK_PRDCT_ID");
                            var127 = mDVCS.getString("TMLY_FL_DAY_NBR");

                        }

                        sqlDVPS = "SELECT DVPS.HOSP_ADMIT_1_CD  " +
                                ", DVPS.HOSP_AFFIL_1_ID" +
                                " FROM " + qualifier + ".DATA_VEND_PROV_STG DVPS" +
                                " WHERE DVPS.DATA_VEND_CD= " + "'" + dataVendCd.trim() + "' " +
                                " AND DVPS.SEQ_NBR= " + seqNum + " WITH UR";
//                                logger.info(sqlDVPS);

                        ResultSet mDVPS = selectState.executeQuery(sqlDVPS);
                        while (mDVPS.next()) {

                            var137 = mDVPS.getString("HOSP_AFFIL_1_ID");
                            var138 = mDVPS.getString("HOSP_ADMIT_1_CD");

                        }

//                                logger.info("First Name " + var12 + " is");

                        if (var12.trim().equals("")) {
                            provTypCd = "O";
                        } else {
                            provTypCd = "P";
                        }

                        if (provTypCd.equals("O") && !specialTypCd.trim().equals("")) {
                            sqlOrgT = " SELECT ORG_TYP_CD  \n" +
                                    "   FROM " + qualifier + ".AMA_SPCL_XREF_TYP \n" +
                                    "  WHERE SPCL_TYP_CD        = " + "'" + specialTypCd + "' " +
                                    "    AND PROV_TYP_CD  = 'A' \n" +
                                    "    AND ACTV_CD  = 'A' \n" +
                                    "   WITH UR  \n";


//                                    logger.info(sqlOrgT);

                            ResultSet m2 = selectState.executeQuery(sqlOrgT);

                            while (m2.next()) {

                                orgTypCd = m2.getString("ORG_TYP_CD");
//                                        System.out.println("datavendcd in first query " + orgTypCd);

                            }

                        }

                        sqlSpclTypDesc = " SELECT SPCL_TYP_SHRT_DESC  \n" +
                                "   FROM " + qualifier + ".SPCL_TYP \n" +
                                "  WHERE SPCL_TYP_CD = " + "'" + specialTypCd + "' " +
                                "   WITH UR  \n";


//                                logger.info(sqlSpclTypDesc);

                        ResultSet mSpclTypDesc = selectState.executeQuery(sqlSpclTypDesc);

                        while (mSpclTypDesc.next()) {

                            srcTypDesc = mSpclTypDesc.getString("SPCL_TYP_SHRT_DESC");

                        }

                        sqlDegreeDesc = " SELECT DEG_DESC  \n" +
                                "   FROM " + qualifier + ".DEG \n" +
                                "  WHERE DEG_CD = " + "'" + var34.trim() + "' " +
                                "   WITH UR  \n";


//                                logger.info(sqlDegreeDesc);

                        ResultSet mDegTypDesc = selectState.executeQuery(sqlDegreeDesc);

                        while (mDegTypDesc.next()) {

                            degreeTypDesc = mDegTypDesc.getString("DEG_DESC");

                        }

                        if (selectState != null) {
                            selectState.close();
                        }
                        DatabaseMetaData metaData = connection.getMetaData();
                        int max = metaData.getMaxConnections();

                        if (connection != null) {
                            try {
                                connection.close();
                                logger.info("Connection Closed");
                            } catch (Exception exception) {
                                logger.info(exception.getCause().toString());
                            }
                        }

                        JSONObject finalData = new JSONObject();
                        finalData.put("correlationId", var1.trim());
                        finalData.put("Vendor Name", var2.trim());
                        finalData.put("Vendor Code", var3.trim());
                        finalData.put("Vendor ID", var4.trim());
                        finalData.put("Record Type", var5);
                        finalData.put("Run Date", var6);
                        finalData.put("File Creation Date", var7);
                        finalData.put("Seq", var8);
                        finalData.put("Seq2", var9);
//                                finalData.put("Error", var10 + " - " + var11.trim());
                        finalData.put("Error", var10);
                        finalData.put("First Name", var12.trim());
                        finalData.put("Middle Name", var13.trim());
                        finalData.put("Last Name", var14.trim());
                        finalData.put("Name Suffix", var15);
                        finalData.put("MPIN", var16);
                        finalData.put("TIN", var17);
                        finalData.put("SSN", var18);
                        finalData.put("Priority", var19);
                        if (var20.trim().equals("O")) {
                            finalData.put("Status", "OPEN");

                        }
                        finalData.put("Role", var21);
                        finalData.put("Cancel Date", var22);
                        finalData.put("Delete Rsn Cd", var23);
                        finalData.put("DBA", var24.trim());
                        finalData.put("Bill State", var25);
                        finalData.put("Zip", var26);
                        finalData.put("Zip + 4", var27);
                        finalData.put("Phone", var28 + var29);
                        finalData.put("Phone Act Code", var30);
                        finalData.put("DOB", var31);
                        finalData.put("Gender", var32);
                        finalData.put("NPI", var33);
                        finalData.put("Prov Type", provTypCd);
                        finalData.put("Facility Type", orgTypCd);

                        if( var34.trim().equals("") && degreeTypDesc.trim().equals(""))
                        {
                            finalData.put("Degree", var34.trim() + degreeTypDesc.trim());
                        }
                        else {
                            finalData.put("Degree", var34.trim() + " - " + degreeTypDesc.trim());
                        }

                        if(specialTypCd.trim().equals("") && srcTypDesc.trim().equals("") )
                        {
                            finalData.put("Specialty", specialTypCd +  srcTypDesc.trim());
                        }
                        else {
                            finalData.put("Specialty", specialTypCd + " - " + srcTypDesc.trim());
                        }

                        finalData.put("Tin Type", var35);

                        if ((var44.trim().equals("") && var54.trim().equals("") && var65.trim().equals("") && var76.trim().equals(""))
                                || (var44.trim().equals("000") && var54.trim().equals("000") && var65.trim().equals("000") && var76.trim().equals("000"))
                                || (var54.trim().equals("") && var65.trim().equals("") && var76.trim().equals(""))
                                || (var54.trim().equals("000") && var65.trim().equals("000") && var76.trim().equals("000"))
                                || (!var44.trim().equals("") && !var44.trim().equals("000"))) {
                            addCount++;
                            finalData.put("Line"+ addCount +" Address Line 1", var36.trim());
                            finalData.put("Line"+ addCount +" Address Line 2", var37.trim());
                            finalData.put("Line"+ addCount +" City", var38.trim());
                            finalData.put("Line"+ addCount +" State", var39.trim());
                            finalData.put("Line"+ addCount +" Zip", var40);
                            finalData.put("Line"+ addCount +" Zip + 4", var41);
                            finalData.put("Line"+ addCount +" Address Type", var42);
                            finalData.put("Line"+ addCount +" EPD SEQ", var43);
                            finalData.put("Line"+ addCount +" Area Code", var44);
                            finalData.put("Line"+ addCount +" Phone", var45);
                            finalData.put("Line"+ addCount +" Phone Type", var46);
                        }

                        if (!var54.trim().equals("") && !var54.trim().equals("000") ) {
                            addCount++;
                            finalData.put("Line"+ addCount +" Address Line 1", var47.trim());
                            finalData.put("Line"+ addCount +" Address Line 2", var48.trim());
                            finalData.put("Line"+ addCount +" City", var139.trim());
                            finalData.put("Line"+ addCount +" State", var49.trim());
                            finalData.put("Line"+ addCount +" Zip", var50);
                            finalData.put("Line"+ addCount +" Zip + 4", var51);
                            finalData.put("Line"+ addCount +" Address Type", var52);
                            finalData.put("Line"+ addCount +" EPD SEQ", var53);
                            finalData.put("Line"+ addCount +" Area Code", var54);
                            finalData.put("Line"+ addCount +" Phone", var55);
                            finalData.put("Line"+ addCount +" Phone Type", var56);
                        }

                        if (!var65.trim().equals("") && !var65.trim().equals("000")) {
                            addCount++;
                            finalData.put("Line"+ addCount +" Address Line 1", var57.trim());
                            finalData.put("Line"+ addCount +" Address Line 2", var58.trim());
                            finalData.put("Line"+ addCount +" City", var59.trim());
                            finalData.put("Line"+ addCount +" State", var60.trim());
                            finalData.put("Line"+ addCount +" Zip", var61);
                            finalData.put("Line"+ addCount +" Zip + 4", var62);
                            finalData.put("Line"+ addCount +" Address Type", var63);
                            finalData.put("Line"+ addCount +" EPD SEQ", var64);
                            finalData.put("Line"+ addCount +" Area Code", var65);
                            finalData.put("Line"+ addCount +" Phone", var66);
                            finalData.put("Line"+ addCount +" Phone Type", var67);
                        }

                        if (!var76.trim().equals("") && !var76.trim().equals("000")) {
                            addCount++;
                            finalData.put("Line"+ addCount +" Address Line 1", var68.trim());
                            finalData.put("Line"+ addCount +" Address Line 2", var69.trim());
                            finalData.put("Line"+ addCount +" City", var70.trim());
                            finalData.put("Line"+ addCount +" State", var71.trim());
                            finalData.put("Line"+ addCount +" Zip", var72);
                            finalData.put("Line"+ addCount +" Zip + 4", var73);
                            finalData.put("Line"+ addCount +" Address Type", var74);
                            finalData.put("Line"+ addCount +" EPD SEQ", var75);
                            finalData.put("Line"+ addCount +" Area Code", var76);
                            finalData.put("Line"+ addCount +" Phone", var77);
                            finalData.put("Line"+ addCount +" Phone Type", var78);
                        }

                        if ((var87.trim().equals("") && var98.trim().equals("") && var109.trim().equals("") && var120.trim().equals(""))
                                || (var87.trim().equals("000") && var98.trim().equals("000") && var109.trim().equals("000") && var120.trim().equals("000"))
                                || (var98.trim().equals("") && var109.trim().equals("") && var120.trim().equals(""))
                                || (var98.trim().equals("000") && var109.trim().equals("000") && var120.trim().equals("000"))
                                || (!var87.trim().equals("") && !var87.trim().equals("000")))  {
                            addCount++;
                            finalData.put("Line"+ addCount +" Address Line 1", var79.trim());
                            finalData.put("Line"+ addCount +" Address Line 2", var80.trim());
                            finalData.put("Line"+ addCount +" City", var81.trim());
                            finalData.put("Line"+ addCount +" State", var82.trim());
                            finalData.put("Line"+ addCount +" Zip", var83);
                            finalData.put("Line"+ addCount +" Zip + 4", var84);
                            finalData.put("Line"+ addCount +" Address Type", var85);
                            finalData.put("Line"+ addCount +" EPD SEQ", var86);
                            finalData.put("Line"+ addCount +" Area Code", var87);
                            finalData.put("Line"+ addCount +" Phone", var88);
                            finalData.put("Line"+ addCount +" Phone Type", var89);
                        }
                        if (!var98.trim().equals("") && !var98.trim().equals("000")) {
                            addCount++;
                            finalData.put("Line"+ addCount +" Address Line 1", var90.trim());
                            finalData.put("Line"+ addCount +" Address Line 2", var91.trim());
                            finalData.put("Line"+ addCount +" City", var92.trim());
                            finalData.put("Line"+ addCount +" State", var93.trim());
                            finalData.put("Line"+ addCount +" Zip", var94);
                            finalData.put("Line"+ addCount +" Zip + 4", var95);
                            finalData.put("Line"+ addCount +" Address Type", var96);
                            finalData.put("Line"+ addCount +" EPD SEQ", var97);
                            finalData.put("Line"+ addCount +" Area Code", var98);
                            finalData.put("Line"+ addCount +" Phone", var99);
                            finalData.put("Line"+ addCount +" Phone Type", var100);
                        }
                        if ((!var109.trim().equals("")  && !var109.trim().equals("000") ) && (addCount < 6)) {
                            addCount++;
                            finalData.put("Line"+ addCount +" Address Line 1", var101.trim());
                            finalData.put("Line"+ addCount +" Address Line 2", var102.trim());
                            finalData.put("Line"+ addCount +" City", var103.trim());
                            finalData.put("Line"+ addCount +" State", var104.trim());
                            finalData.put("Line"+ addCount +" Zip", var105);
                            finalData.put("Line"+ addCount +" Zip + 4", var106);
                            finalData.put("Line"+ addCount +" Address Type", var107);
                            finalData.put("Line"+ addCount +" EPD SEQ", var108);
                            finalData.put("Line"+ addCount +" Area Code", var109);
                            finalData.put("Line"+ addCount +" Phone", var110);
                            finalData.put("Line"+ addCount +" Phone Type", var111);
                        }
                        else if(!var109.trim().equals("")  && !var109.trim().equals("000"))
                        {
                            addCount++;
                        }
                        if ((!var120.trim().equals("") && !var120.trim().equals("000")  ) && (addCount < 6)) {
                            addCount++;
                            finalData.put("Line"+ addCount +" Address Line 1", var112.trim());
                            finalData.put("Line"+ addCount +" Address Line 2", var113.trim());
                            finalData.put("Line"+ addCount +" City", var114.trim());
                            finalData.put("Line"+ addCount +" State", var115.trim());
                            finalData.put("Line"+ addCount +" Zip", var116);
                            finalData.put("Line"+ addCount +" Zip + 4", var117);
                            finalData.put("Line"+ addCount +" Address Type", var118);
                            finalData.put("Line"+ addCount +" EPD SEQ", var119);
                            finalData.put("Line"+ addCount +" Area Code", var120);
                            finalData.put("Line"+ addCount +" Phone", var121);
                            finalData.put("Line"+ addCount +" Phone Type", var122);
                        }
                        else if(!var120.trim().equals("") && !var120.trim().equals("000"))
                        {
                            addCount++;
                        }

//                                System.out.println("Count " + addCount);
//                                logger.info("Count " + addCount);

                        if(addCount > 6 )
                        {
                            finalData.put("Comment", "Few Address lines has been truncated as it is having more than 6 Address Lines ");

                        }
                        else {
                            finalData.put("Comment",   "All "+addCount+" Addresses included no truncation needed" );

                        }
                        for( int i = ++addCount ; i <= 6; i++)
                        {
                            finalData.put("Line"+ i +" Address Line 1", "");
                            finalData.put("Line"+ i +" Address Line 2", "");
                            finalData.put("Line"+ i +" City", "");
                            finalData.put("Line"+ i +" State", "");
                            finalData.put("Line"+ i +" Zip", "");
                            finalData.put("Line"+ i +" Zip + 4", "");
                            finalData.put("Line"+ i +" Address Type", "");
                            finalData.put("Line"+ i +" EPD SEQ", "");
                            finalData.put("Line"+ i +" Area Code", "");
                            finalData.put("Line"+ i +" Phone", "");
                            finalData.put("Line"+ i +" Phone Type", "");
                        }
                        String var129pad = String.format("%04d", Integer.parseInt(var129));
                        String var130pad = String.format("%07d", Integer.parseInt(var130));
                        String var132pad = String.format("%04d", Integer.parseInt(var132));
                        String var133pad = String.format("%07d", Integer.parseInt(var133));
                        String var135pad = String.format("%04d", Integer.parseInt(var135));
                        String var136pad = String.format("%07d", Integer.parseInt(var136));

                        finalData.put("Effective Date", var123);
                        finalData.put("PCP Ind", var124);
                        finalData.put("Vend Sched", var125.trim());
                        finalData.put("Vend IPA", var126.trim());
                        finalData.put("Vend Prd", var140.trim());
                        finalData.put("Timely Filing", var127);
                        finalData.put("UHCID 1", var128 + var129pad + var130pad);
                        finalData.put("UHCID 2", var131 + var132pad + var133pad);
                        finalData.put("UHCID 3", var134 + var135pad + var136pad);

                        finalData.put("Hospital MPIN", var137);
                        finalData.put("Admit Priv", var138);


                        //***************************Concept to enrichment the record
//                                logger.info("Final Data " + finalData.toString());

                        kafkaEPDLProducer.produceWithEnrichmentData(finalData);

                        addCount = 0;
                    } else {
                        logger.info("Datavend field is empty so it has not send to EWD topic");
                    }

                } catch (SQLException e) {
                    e.printStackTrace();
                    logger.info(e.getCause().toString());

                }
                finally {
//                            if (connection != null) {
//                                connection.close();
//                            }

                }
            }
            else{
                logger.info("Consumed ProcErrorQueid " + pqid+ " does not fulfill required Criteria for EPDL inventory, As its Status is "+status +" Vendor is "+ vendorTyp + " And Role is "+ roleType);
            }
//                }
//            }
        } catch (Exception e) {
            e.printStackTrace();
            logger.info(e.getCause().toString());
        }
    }

    public Connection getDB2Conn() {
        try {

            if (connection == null) {

                Class.forName(driver);
                db2Connection = DriverManager.getConnection(url, user, dbPassword);
                db2Connection.setAutoCommit(true);
                connection = db2Connection;
            }


        } catch (Exception e) {
//            LOGGER.error("Exception in getDB2connection Method: ", e);
            e.printStackTrace();
        }
        return connection;
    }


    public void autoResolve(String pqid) {

        connection = null;
        peqVerNbr = 0 ; up =0;

        Date date = new Date();
        datet.setTimeZone(etTimeZone);
        datef.setTimeZone(etTimeZone);
        currentdate = datef.format(date);
        currentime = datet.format(date);

        try {
            if (connection == null) {
                System.out.println("In connection ");
                connection = getDB2Conn();

                if (connection == null) {
//                            System.out.println("Connection Issue");
                    logger.info("Connection Issue");
                }
            } else {
                System.out.println(" Connection is not null " + connection);

            }
            String sqlVersionNumber = "SELECT VER_NBR FROM " + qualifier + ".PROC_ERR_QUE WHERE PROC_ERR_QUE_ID= " + pqid;
//              System.out.println(sqlVersionNumber);
            selectState = connection.createStatement();
            ResultSet msqlVersion = selectState.executeQuery(sqlVersionNumber);
            //   System.out.println("Result Set " + msqlVersion);
            if (msqlVersion.next()) {
                peqVerNbr = msqlVersion.getInt("VER_NBR");
            }

            peqVerNbr = peqVerNbr + 1;

            String sqlReleaseUpdate = "UPDATE F5938DBF.PROC_ERR_QUE " +
                    "SET LST_UPDT_TYP_CD = 'U' ," +
                    "ASGN_USER_ID = 'EWL' , " +
                    "ASGN_USER_OFC_CD = '938' , " +
                    "USER_ID= 'EWL' , " +
                    "USER_OFC_CD = '938' , " +
                    "LST_UPDT_DT= " +"'" +currentdate +"', "  +
                    "LST_UPDT_TM= "+"'"+ currentime + "', " +
                    "VER_NBR= " + peqVerNbr + ", " +
//                    "CLA_ID = '" + claID + "', " +
                    "ERR_QUE_STS_TYP_CD= 'R' , " +
                    "Q_APPL_STS_RSN_CD= 'P6' , " +
                    "COMMT_TXT= 'Empire Non-workable TIN', " +
//                    "PRI_CD = '" + transferComments + "' , " +
                    "MAIN_PROC_ERR_QUE_ID = 0" + " , " +
                    "Q_BUS_STS_RSN_CD = 'P6' " +
                    "WHERE PROC_ERR_QUE_ID ='" + pqid + "'";
            System.out.println(sqlReleaseUpdate);
            //logger.info(sqlReleaseUpdate);
            sqlResolve = null;

            PreparedStatement sqlResolve = connection.prepareStatement(sqlReleaseUpdate);
            up = sqlResolve.executeUpdate();

            if (up < 1) {
                logger.info("Nothing Resolved for Correlation ID " + pqid);
            } else {
                logger.info("Resolved no. of records " + up + " for Correlation ID " + pqid);
            }


        if(sqlResolve != null)
        {
            sqlResolve.close();
        }
        if (selectState != null) {
            selectState.close();
        }
        }
        catch (Exception e)
        {
            logger.info(e.getCause().toString());
        }
        if (connection != null) {
            try {
                connection.close();
                logger.info("Connection Closed");
            } catch (Exception exception) {
                logger.info(exception.getCause().toString());
            }
        }

    }
}

