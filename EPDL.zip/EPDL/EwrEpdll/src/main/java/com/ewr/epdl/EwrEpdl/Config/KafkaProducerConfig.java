package com.ewr.epdl.EwrEpdl.Config;

import io.confluent.kafka.serializers.AbstractKafkaAvroSerDeConfig;
import io.confluent.kafka.serializers.KafkaAvroDeserializer;
import io.confluent.kafka.serializers.KafkaAvroSerializer;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.config.SslConfigs;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.config.KafkaListenerContainerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.listener.ConcurrentMessageListenerContainer;
import org.springframework.kafka.listener.LoggingErrorHandler;
import org.springframework.scheduling.annotation.EnableAsync;

import java.util.HashMap;
import java.util.Map;

@Configuration
@EnableAsync
public class KafkaProducerConfig {

    @Value("${kafka.boot.server}")
    private String kafkaServer;

    @Value("${kafka.consumer.group.id}")
    private String kafkaGroupId;

    @Value("${kafka.securityprotocol}")
    private String securityprotocol;

    @Value("${kafka.keystore.type}")
    private String keystoreType;

    @Value("${kafka.keystore.producer.location}")
    private String keystoreProducerLocation;

    @Value("${kafka.keystore.producer.password}")
    private String keystoreProducerPassword;

    @Value("${kafka.truststore.producer.location}")
    private String truststoreProducerlocation;

    @Value("${kafka.truststore.producer.password}")
    private String truststoreProducerPassword;

    @Value("${kafka.autocommit}")
    private String autocommit;

    @Value("${kafka.maxpoll}")
    private String maxpoll;

    @Value("${kafka.autooffsetreset}")
    private String autooffsetreset;

    @Value("${kafka.schemaRegistry}")
    private String schemaRegistry;

    @Value("${kafka.sessionTimeoutMS}")
    private String sessionTimeoutMS;

    @Value("${kafka.specificAvroReader}")
    private String specificAvroReader;

    @Value("${kafka.retries}")
    private String retries;

    @Value("${kafka.ack}")
    private String ack;

    @Value("${kafka.batchsize}")
    private String batchsize;

    @Value("${kafka.lingerms}")
    private String lingerms;

    @Value("${kafka.buffermemory}")
    private String buffermemory;


    @Bean
    public KafkaTemplate<String, String> kafkaTemplate() {
        return new KafkaTemplate<String, String>(producerFactory());
    }

    @Bean
    public DefaultKafkaProducerFactory producerFactory() {
        // TODO Auto-generated method stub
        return new DefaultKafkaProducerFactory(producerConfigs());
    }

//    private static String loc = System.getProperty("user.dir") + "\\src\\main\\resources";
    private static String loc = System.getProperty("user.dir") ;

    @Bean
    public Map<String, String> producerConfigs() {

        Map<String, String> propsproducer = new HashMap<>();
        propsproducer.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaServer );
        propsproducer.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, securityprotocol);
        propsproducer.put(SslConfigs.SSL_KEYSTORE_TYPE_CONFIG, keystoreType);
        propsproducer.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, loc + truststoreProducerlocation);
        propsproducer.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, truststoreProducerPassword);
        propsproducer.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG, loc + keystoreProducerLocation);
        propsproducer.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, keystoreProducerPassword);
        propsproducer.put(SslConfigs.SSL_KEY_PASSWORD_CONFIG, keystoreProducerPassword);
        propsproducer.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        propsproducer.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, KafkaAvroSerializer.class.getName());
        propsproducer.put(ProducerConfig.RETRIES_CONFIG, retries);
        propsproducer.put(ProducerConfig.ACKS_CONFIG, ack);
        propsproducer.put(ProducerConfig.BATCH_SIZE_CONFIG, batchsize);
        propsproducer.put(ProducerConfig.LINGER_MS_CONFIG, lingerms);
        propsproducer.put(ProducerConfig.BUFFER_MEMORY_CONFIG, buffermemory);
        propsproducer.put(AbstractKafkaAvroSerDeConfig.AUTO_REGISTER_SCHEMAS, "true");
        propsproducer.put("schema.registry.url", schemaRegistry);
        return propsproducer;
    }

}