package com.ewr.epdl.EwrEpdl.Config;

import io.confluent.kafka.serializers.KafkaAvroDeserializer;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.config.SslConfigs;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.config.KafkaListenerContainerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.listener.ConcurrentMessageListenerContainer;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.kafka.listener.LoggingErrorHandler;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.HashMap;
import java.util.Map;

@Configuration
@EnableKafka
public class KafkaConsumerConfig {

    @Value("${kafka.boot.server}")
    private String kafkaServer;

    @Value("${kafka.consumer.group.id}")
    private String kafkaGroupId;

    @Value("${kafka.securityprotocol}")
    private String securityprotocol;

    @Value("${kafka.keystore.type}")
    private String keystoreType;

    @Value("${kafka.keystore.consumer.location}")
    private String keystoreLocation;

    @Value("${kafka.keystore.consumer.password}")
    private String keystorePassword;

    @Value("${kafka.truststore.consumer.location}")
    private String truststoreLocation;

    @Value("${kafka.truststore.consumer.password}")
    private String truststorePassword;

    @Value("${kafka.autocommit}")
    private String autocommit;

    @Value("${kafka.maxpoll}")
    private String maxpoll;

    @Value("${kafka.autooffsetreset}")
    private String autooffsetreset;

    @Value("${kafka.schemaRegistry}")
    private String schemaRegistry;

    @Value("${kafka.sessionTimeoutMS}")
    private String sessionTimeoutMS;

    @Value("${kafka.specificAvroReader}")
    private String specificAvroReader;

//    private static String loc = System.getProperty("user.dir") + "\\src\\main\\resources";
    private static String loc = System.getProperty("user.dir") ;



    @Bean
    public DefaultKafkaConsumerFactory consumerFactory() {
        // TODO Auto-generated method stub
        return new DefaultKafkaConsumerFactory(consumerConfigs());
    }

    @Bean
    public Map<String, Object> consumerConfigs() {

        Map<String, Object> props = new HashMap<>();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaServer);
        props.put(ConsumerConfig.GROUP_ID_CONFIG, kafkaGroupId);
        props.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, securityprotocol);
        props.put(SslConfigs.SSL_KEYSTORE_TYPE_CONFIG, keystoreType);
        props.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, loc+truststoreLocation);
        props.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, truststorePassword);
        props.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG, loc+keystoreLocation);
        props.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, keystorePassword);
        props.put(SslConfigs.SSL_KEY_PASSWORD_CONFIG, keystorePassword);
        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, autocommit);
        props.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, maxpoll);
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, autooffsetreset);
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, org.apache.kafka.common.serialization.StringDeserializer.class.getName());
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, KafkaAvroDeserializer.class.getName());
        props.put("schema.registry.url", schemaRegistry);
        props.put(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, sessionTimeoutMS);
        props.put("specific.avro.reader", specificAvroReader);
        return props;
    }

    @Bean
    public KafkaListenerContainerFactory<ConcurrentMessageListenerContainer<String, String>> kafkaListenerContainerFactory() {
        ConcurrentKafkaListenerContainerFactory<String, String> listener = new ConcurrentKafkaListenerContainerFactory<>();
        listener.setConsumerFactory(consumerFactory());
        listener.setErrorHandler(new LoggingErrorHandler());   // ps::logger
//        listener.getContainerProperties().setIdleEventInterval(100000L);
        listener.getContainerProperties().setAckMode(ContainerProperties.AckMode.BATCH);
        return listener;
    }



}