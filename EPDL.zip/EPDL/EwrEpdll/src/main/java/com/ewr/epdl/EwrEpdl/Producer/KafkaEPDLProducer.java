package com.ewr.epdl.EwrEpdl.Producer;

import com.optum.ewdkafka.EwdNdmMessage;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.kafka.support.SendResult;
import org.springframework.messaging.support.GenericMessage;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;

import java.io.IOException;
import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

@Service
public class KafkaEPDLProducer {

    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    @Value("${kafka.topic.producername}")
    private String topicproducername;

    //    private static String loc = System.getProperty("user.dir") + "\\src\\main\\resources\\";
//    private static String loc = System.getProperty("user.dir") ;
    private static final Logger logger = LoggerFactory.getLogger(KafkaEPDLProducer.class);

    @Async
    public void produceWithEnrichmentData(JSONObject finalData) throws JSONException, IOException {
        // TODO Auto-generated method stub
//        boolean append = true;
//        FileHandler handler = new FileHandler(loc+"/"+"epdlewr.producer", append);
//
//        Logger logger = Logger.getLogger("com.ewr.epdl.EwrEpdl.Producer");
//        logger.addHandler(handler);

        JSONObject loadData = null;

        loadData = new JSONObject(finalData.toString());
        EwdNdmMessage ewdNdmMessage = new EwdNdmMessage();
        ewdNdmMessage.setWorkItemType("NDM");
        ewdNdmMessage.setEwdIlId("SRC0001073");
        ewdNdmMessage.setCorrelationId(loadData.get("correlationId").toString());
        ewdNdmMessage.setNdmVendorName(loadData.get("Vendor Name").toString());
        ewdNdmMessage.setNdmVendorCode(loadData.get("Vendor Code").toString());
        ewdNdmMessage.setNdmVendorId(loadData.get("Vendor ID").toString());
        ewdNdmMessage.setRecordFormatType(loadData.get("Record Type").toString());
        ewdNdmMessage.setUhcDepartmentReceivedDate(Instant.parse(loadData.get("Run Date").toString() + "T00:00:00.000Z"));
        ewdNdmMessage.setUhgReceivedDate(Instant.parse(loadData.get("File Creation Date").toString() + "T00:00:00.000Z"));
        ewdNdmMessage.setSeq(loadData.get("Seq").toString());
        ewdNdmMessage.setSeq2(loadData.get("Seq2").toString());
        ewdNdmMessage.setErrorDescription(loadData.get("Error").toString());
        ewdNdmMessage.setProviderFirstname(loadData.get("First Name").toString());
        ewdNdmMessage.setProviderMiddlename(loadData.get("Middle Name").toString());
        ewdNdmMessage.setProviderLastname(loadData.get("Last Name").toString());
        ewdNdmMessage.setProviderSuffix(loadData.get("Name Suffix").toString());
        ewdNdmMessage.setMpin(loadData.get("MPIN").toString());
        ewdNdmMessage.setTin(loadData.get("TIN").toString());
        ewdNdmMessage.setReferenceNumber(loadData.get("SSN").toString());
        ewdNdmMessage.setNdmPriority(loadData.get("Priority").toString());
        ewdNdmMessage.setNdmStatus(loadData.get("Status").toString());
        ewdNdmMessage.setNdmRole(loadData.get("Role").toString());
        ewdNdmMessage.setCancelDate(Instant.parse(loadData.get("Cancel Date").toString() + "T00:00:00.000Z"));
        ewdNdmMessage.setDeleterSncd(loadData.get("Delete Rsn Cd").toString());
        ewdNdmMessage.setDba(loadData.get("DBA").toString());
        ewdNdmMessage.setBillState(loadData.get("Bill State").toString());
        ewdNdmMessage.setBillZip(loadData.get("Zip").toString());
        ewdNdmMessage.setBillZipPlus4(loadData.get("Zip + 4").toString());
        ewdNdmMessage.setPhone(loadData.get("Phone").toString());
        ewdNdmMessage.setPhoneactCode(loadData.get("Phone Act Code").toString());
        ewdNdmMessage.setDob(loadData.get("DOB").toString());
        ewdNdmMessage.setGender(loadData.get("Gender").toString());
        ewdNdmMessage.setNpi(loadData.get("NPI").toString());
        ewdNdmMessage.setProviderType(loadData.get("Prov Type").toString());
        ewdNdmMessage.setFacilityType(loadData.get("Facility Type").toString());
        ewdNdmMessage.setDegree(loadData.get("Degree").toString());
        ewdNdmMessage.setProviderSpecialityType(loadData.get("Specialty").toString());
        ewdNdmMessage.setTinType(loadData.get("Tin Type").toString());
        ewdNdmMessage.setLine1AddressLine1(loadData.get("Line1 Address Line 1").toString());
        ewdNdmMessage.setLine1AddressLine2(loadData.get("Line1 Address Line 2").toString());
        ewdNdmMessage.setLine1City(loadData.get("Line1 City").toString());
        ewdNdmMessage.setLine1State(loadData.get("Line1 State").toString());
        ewdNdmMessage.setLine1Zip(loadData.get("Line1 Zip").toString());
        ewdNdmMessage.setLine1ZipPlus4(loadData.get("Line1 Zip + 4").toString());
        ewdNdmMessage.setLine1AddressType(loadData.get("Line1 Address Type").toString());
        ewdNdmMessage.setLine1EpdSeq(loadData.get("Line1 EPD SEQ").toString());
        ewdNdmMessage.setLine1AreaCode(loadData.get("Line1 Area Code").toString());
        ewdNdmMessage.setLine1Phone(loadData.get("Line1 Phone").toString());
        ewdNdmMessage.setLine1PhoneType(loadData.get("Line1 Phone Type").toString());
        ewdNdmMessage.setLine2AddressLine1(loadData.get("Line2 Address Line 1").toString());
        ewdNdmMessage.setLine2addressLine2(loadData.get("Line2 Address Line 2").toString());
        ewdNdmMessage.setLine2City(loadData.get("Line2 City").toString());
        ewdNdmMessage.setLine2State(loadData.get("Line2 State").toString());
        ewdNdmMessage.setLine2Zip(loadData.get("Line2 Zip").toString());
        ewdNdmMessage.setLine2ZipPlus4(loadData.get("Line2 Zip + 4").toString());
        ewdNdmMessage.setLine2AddressType(loadData.get("Line2 Address Type").toString());
        ewdNdmMessage.setLine2EpdSeq(loadData.get("Line2 EPD SEQ").toString());
        ewdNdmMessage.setLine2AreaCode(loadData.get("Line2 Area Code").toString());
        ewdNdmMessage.setLine2Phone(loadData.get("Line2 Phone").toString());
        ewdNdmMessage.setLine2PhoneType(loadData.get("Line2 Phone Type").toString());
        ewdNdmMessage.setLine3AddressLine1(loadData.get("Line3 Address Line 1").toString());
        ewdNdmMessage.setLine3AddressLine2(loadData.get("Line3 Address Line 2").toString());
        ewdNdmMessage.setLine3City(loadData.get("Line3 City").toString());
        ewdNdmMessage.setLine3State(loadData.get("Line3 State").toString());
        ewdNdmMessage.setLine3Zip(loadData.get("Line3 Zip").toString());
        ewdNdmMessage.setLine3ZipPlus4(loadData.get("Line3 Zip + 4").toString());
        ewdNdmMessage.setLine3AddressType(loadData.get("Line3 Address Type").toString());
        ewdNdmMessage.setLine3EpdSeq(loadData.get("Line3 EPD SEQ").toString());
        ewdNdmMessage.setLine3AreaCode(loadData.get("Line3 Area Code").toString());
        ewdNdmMessage.setLine3Phone(loadData.get("Line3 Phone").toString());
        ewdNdmMessage.setLine3PhoneType(loadData.get("Line3 Phone Type").toString());
        ewdNdmMessage.setLine4AddressLine1(loadData.get("Line4 Address Line 1").toString());
        ewdNdmMessage.setLine4AddressLine2(loadData.get("Line4 Address Line 2").toString());
        ewdNdmMessage.setLine4City(loadData.get("Line4 City").toString());
        ewdNdmMessage.setLine4State(loadData.get("Line4 State").toString());
        ewdNdmMessage.setLine4Zip(loadData.get("Line4 Zip").toString());
        ewdNdmMessage.setLine4ZipPlus4(loadData.get("Line4 Zip + 4").toString());
        ewdNdmMessage.setLine4AddressType(loadData.get("Line4 Address Type").toString());
        ewdNdmMessage.setLine4EpdSeq(loadData.get("Line4 EPD SEQ").toString());
        ewdNdmMessage.setLine4AreaCode(loadData.get("Line4 Area Code").toString());
        ewdNdmMessage.setLine4Phone(loadData.get("Line4 Phone").toString());
        ewdNdmMessage.setLine4PhoneType(loadData.get("Line4 Phone Type").toString());
        ewdNdmMessage.setLine5AddressLine1(loadData.get("Line5 Address Line 1").toString());
        ewdNdmMessage.setLine5AddressLine2(loadData.get("Line5 Address Line 2").toString());
        ewdNdmMessage.setLine5City(loadData.get("Line5 City").toString());
        ewdNdmMessage.setLine5State(loadData.get("Line5 State").toString());
        ewdNdmMessage.setLine5Zip(loadData.get("Line5 Zip").toString());
        ewdNdmMessage.setLine5ZipPlus4(loadData.get("Line5 Zip + 4").toString());
        ewdNdmMessage.setLine5AddressType(loadData.get("Line5 Address Type").toString());
        ewdNdmMessage.setLine5EpdSeq(loadData.get("Line5 EPD SEQ").toString());
        ewdNdmMessage.setLine5AreaCode(loadData.get("Line5 Area Code").toString());
        ewdNdmMessage.setLine5Phone(loadData.get("Line5 Phone").toString());
        ewdNdmMessage.setLine5PhoneType(loadData.get("Line5 Phone Type").toString());
        ewdNdmMessage.setLine6AddressLine1(loadData.get("Line6 Address Line 1").toString());
        ewdNdmMessage.setLine6AddressLine2(loadData.get("Line6 Address Line 2").toString());
        ewdNdmMessage.setLine6City(loadData.get("Line6 City").toString());
        ewdNdmMessage.setLine6State(loadData.get("Line6 State").toString());
        ewdNdmMessage.setLine6Zip(loadData.get("Line6 Zip").toString());
        ewdNdmMessage.setLine6ZipPlus4(loadData.get("Line6 Zip + 4").toString());
        ewdNdmMessage.setLine6AddressType(loadData.get("Line6 Address Type").toString());
        ewdNdmMessage.setLine6EpdSeq(loadData.get("Line6 EPD SEQ").toString());
        ewdNdmMessage.setLine6AreaCode(loadData.get("Line6 Area Code").toString());
        ewdNdmMessage.setLine6Phone(loadData.get("Line6 Phone").toString());
        ewdNdmMessage.setLine6PhoneType(loadData.get("Line6 Phone Type").toString());
        ewdNdmMessage.setComment(loadData.get("Comment").toString());
        ewdNdmMessage.setEffectiveDate(Instant.parse(loadData.get("Effective Date").toString() + "T00:00:00.000Z"));
        ewdNdmMessage.setPcpIndicator(loadData.get("PCP Ind").toString());
        ewdNdmMessage.setVendSched(loadData.get("Vend Sched").toString());
        ewdNdmMessage.setIpa(loadData.get("Vend IPA").toString());
        ewdNdmMessage.setTimelyFiling(loadData.get("Timely Filing").toString());
//        ewdNdmMessage.setNdmVendorProduct(loadData.get("Vend Prd").toString());
        ewdNdmMessage.setUhcId(loadData.get("UHCID 1").toString());
        ewdNdmMessage.setUhcId2(loadData.get("UHCID 2").toString());
        ewdNdmMessage.setUhcId3(loadData.get("UHCID 3").toString());
        ewdNdmMessage.setLine1HospitalMpin(loadData.get("Hospital MPIN").toString());
        ewdNdmMessage.setLine1AdmitPriv(loadData.get("Admit Priv").toString());

        Map<String, Object> headers = new HashMap<>();
        headers.put(KafkaHeaders.TOPIC, topicproducername);
        ProducerRecord<Object, EwdNdmMessage> producerRecord = new ProducerRecord<Object, EwdNdmMessage>(topicproducername, ewdNdmMessage);
        ListenableFuture<SendResult<String, String>> ackBack = kafkaTemplate.send(new GenericMessage<EwdNdmMessage>(ewdNdmMessage, headers));
        ackBack.addCallback(new ListenableFutureCallback<SendResult<String, String>>() {

            @Override
            public void onSuccess(final SendResult<String, String> message) {
//                logger.info("sent message: " + message + " with offset: " + message.getRecordMetadata().offset() );
                logger.info("sent message: CorrelationID " + ewdNdmMessage.getCorrelationId() + " Status " + ewdNdmMessage.getNdmStatus() +" Vendor "+ewdNdmMessage.getNdmVendorCode() +" with offset: " + message.getRecordMetadata().offset() );
            }

            @Override
            public void onFailure(final Throwable throwable) {

                logger.info("unable to send message= " + ewdNdmMessage.toString()+ throwable + "CorrelationID " + ewdNdmMessage.getCorrelationId() + " Status " + ewdNdmMessage.getNdmStatus() +" Vendor "+ewdNdmMessage.getNdmVendorCode()  );
            }
        });
    }


}
