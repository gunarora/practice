package com.ewr.epdl.EwrEpdl.common;

import org.apache.avro.*;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.generic.GenericRecordBuilder;
import org.joda.time.format.DateTimeFormatter;

import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class ConvertToDecimal {

    public static GenericRecord convert(GenericRecord oldAvrodata) {
        GenericData.Record clonedRecord = (new GenericRecordBuilder((GenericData.Record)oldAvrodata)).build();
        List<Schema.Field> convertedAvroSchemaFields = getConvertedValueAndSchemaFields(clonedRecord, false);
        GenericRecord newAvrodata = getConvertedGenericRecord(oldAvrodata.getSchema(), clonedRecord, convertedAvroSchemaFields, false);
        return newAvrodata;
    }

    private static List<Schema.Field> getConvertedValueAndSchemaFields(GenericRecord originalRecord, boolean isCached) {
        List<Schema.Field> convertedFields = new ArrayList();
        Schema originalSchema = originalRecord.getSchema();
        List<Schema.Field> originalFields = originalSchema.getFields();
        Iterator var6 = originalFields.iterator();

        while(var6.hasNext()) {
            Schema.Field field = (Schema.Field)var6.next();
            LogicalType logicalType = getLogicalType(field);
            convertToString(originalRecord, originalSchema, field, logicalType, (DateTimeFormatter)null);
            if (!isCached) {
                Schema.Field convertedField = toStringSchema(field);
                convertedFields.add(convertedField);
            }
        }

        return convertedFields;
    }

    public static Schema.Field toStringSchema(Schema.Field field) {
        Schema fieldSchema = field.schema();
        Schema stringSchema;
        if (fieldSchema.getType() == Schema.Type.UNION) {
            List<Schema> fields = new ArrayList();
            Iterator var4 = fieldSchema.getTypes().iterator();

            while(var4.hasNext()) {
                Schema fieldType = (Schema)var4.next();
                if (fieldType.getType() == Schema.Type.NULL) {
                    fields.add(fieldType);
                } else {
                    fields.add(Schema.create(Schema.Type.STRING));
                }
            }

            stringSchema = Schema.createUnion(fields);
        } else {
            stringSchema = Schema.create(Schema.Type.STRING);
        }

        return new Schema.Field(field.name(), stringSchema, field.doc(), field.defaultVal());
    }

    private static void convertToString(GenericRecord originalRecord, Schema originalSchema, Schema.Field field, LogicalType logicalType, DateTimeFormatter dateTimeFormatter) {
        if (logicalType instanceof LogicalTypes.Decimal) {
            convertDecimalToString(originalRecord, originalSchema, field, (LogicalTypes.Decimal)logicalType);
        }  else if (logicalType == null && getNonNullFieldSchemaType(field) == Schema.Type.BYTES) {
            convertBytesToString(originalRecord, field);
        }

    }

    private static GenericRecord getConvertedGenericRecord(Schema schema, GenericRecord record, List<Schema.Field> convertedFields, boolean isSchemaCached) {
        Schema convertedSchema = Schema.createRecord(schema.getName(), schema.getDoc(), schema.getNamespace(), false);
        convertedSchema.setFields(convertedFields);
        GenericRecord convertedRecord = new GenericData.Record(convertedSchema);
        schema.getFields().forEach((field) -> {
            convertedRecord.put(field.name(), record.get(field.name()));
        });
        return convertedRecord;
    }



    public static void convertDecimalToString(GenericRecord avrodata, Schema avroSchema, Schema.Field field, LogicalTypes.Decimal type) {
        String fieldName = field.name();
        long startTimeInMs = System.currentTimeMillis();
        Object avroDataFieldValue = avrodata.get(fieldName);
        ByteBuffer byteBuffer = avroDataFieldValue instanceof byte[] ? ByteBuffer.wrap((byte[])((byte[])avroDataFieldValue)) : (ByteBuffer)avroDataFieldValue;
        if (null != byteBuffer) {
            Conversion<BigDecimal> bigDecimalConversion = new Conversions.DecimalConversion();
            BigDecimal bigDecimal = (BigDecimal)bigDecimalConversion.fromBytes(byteBuffer, avroSchema, type);
            String d1BigDecimalAsString = String.valueOf(bigDecimal);
            avrodata.put(fieldName, d1BigDecimalAsString);
        } else {
//            logger.debug("field={}: field value is null so no value conversion", fieldName);
        }

    }

    public static void convertBytesToString(GenericRecord avroData, Schema.Field field) {
        String fieldName = field.name();
        long startTimeInMs = System.currentTimeMillis();
        String fieldValue = null;
        Object genericValue = avroData.get(fieldName);
        if (genericValue != null) {
            if (genericValue instanceof byte[]) {
                byte[] byteArray = (byte[])((byte[])genericValue);
                fieldValue = new String(byteArray, StandardCharsets.UTF_8);
            }

            if (genericValue instanceof ByteBuffer) {
                ByteBuffer byteBuffer = (ByteBuffer)genericValue;
                fieldValue = convertByteBufferToString(byteBuffer);
            }
        }

        if (null != fieldValue) {
            avroData.put(fieldName, fieldValue);
        }

    }

    public static String convertByteBufferToString(ByteBuffer byteBuffer) {
        String str = null;
        if (byteBuffer != null) {
            byte[] bytes;
            if (byteBuffer.hasArray()) {
                bytes = byteBuffer.array();
            } else {
                bytes = new byte[byteBuffer.remaining()];
                byteBuffer.get(bytes);
            }

            str = new String(bytes, Charset.defaultCharset());
        }

        return str;
    }

    public static Schema.Type getNonNullFieldSchemaType(Schema.Field field) {
        Schema fieldSchema = field.schema();
        Schema.Type fieldSchemaType = fieldSchema.getType();
        if (fieldSchemaType == Schema.Type.UNION) {
            Iterator var3 = fieldSchema.getTypes().iterator();

            while(var3.hasNext()) {
                Schema schema = (Schema)var3.next();
                if (Schema.Type.NULL != schema.getType()) {
                    fieldSchemaType = schema.getType();
                }
            }
        }

        return fieldSchemaType;
    }

    public static LogicalType getLogicalType(Schema.Field field) {
        LogicalType logicalType = null;
        Schema fieldSchema = field.schema();
        if (fieldSchema.getType() == Schema.Type.UNION) {
            Iterator var3 = fieldSchema.getTypes().iterator();

            while(var3.hasNext()) {
                Schema schema = (Schema)var3.next();
                if (schema.getLogicalType() != null) {
                    logicalType = schema.getLogicalType();
                } else if (schema.getType() != Schema.Type.NULL) {
                    logicalType = LogicalTypes.fromSchemaIgnoreInvalid(schema);
                    if (logicalType == null) {
                        logicalType = getLogicalTypeFromProps(schema.getObjectProps());
                    }

                    if (logicalType != null) {
                        break;
                    }
                }
            }
        } else {
            logicalType = LogicalTypes.fromSchemaIgnoreInvalid(fieldSchema);
        }

        if (logicalType == null) {
            logicalType = getLogicalTypeFromProps(field.getObjectProps());
        }

        return logicalType;
    }

    public static LogicalType getLogicalTypeFromProps(Map<String, Object> props) {
        LogicalType logicalType = null;
        Object typeName = props.get("logicalType");
        if (typeName == null) {
            typeName = props.get("avro.logicalType");
        }

        if ("timestamp-millis".equals(typeName)) {
            logicalType = LogicalTypes.timestampMillis();
        } else if ("decimal".equals(typeName)) {
            int p = (Integer)props.get("precision");
            int s = (Integer)props.get("scale");
            logicalType = LogicalTypes.decimal(p, s);
        } else if ("uuid".equals(typeName)) {
            logicalType = LogicalTypes.uuid();
        } else if ("date".equals(typeName)) {
            logicalType = LogicalTypes.date();
        } else if ("timestamp-micros".equals(typeName)) {
            logicalType = LogicalTypes.timestampMicros();
        } else if ("time-millis".equals(typeName)) {
            logicalType = LogicalTypes.timeMillis();
        } else if ("time-micros".equals(typeName)) {
            logicalType = LogicalTypes.timeMicros();
        }

        return (LogicalType)logicalType;
    }

}
