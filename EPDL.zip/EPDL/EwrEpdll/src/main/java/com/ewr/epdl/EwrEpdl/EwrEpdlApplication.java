package com.ewr.epdl.EwrEpdl;

import com.ewr.epdl.EwrEpdl.Controller.KafkaController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


@SpringBootApplication
@ComponentScan(basePackages = "com.ewr.epdl")
//public class EwrEpdlApplication  implements CommandLineRunner {
public class EwrEpdlApplication  {

//	@Autowired
//	private KafkaController kafkaController;
	private static final Logger LOGGER = LoggerFactory.getLogger(EwrEpdlApplication.class);

	public static void main(String[] args) {
		LOGGER.info("Message logged at INFO level & SpringBoot application started");
		SpringApplication.run(EwrEpdlApplication.class, args);
	}


//	public void run(String... args) throws Exception {
//		System.out.println("In Start");
//		kafkaController.createConsumer();
//		System.out.println("In End");
//
//	}
}
