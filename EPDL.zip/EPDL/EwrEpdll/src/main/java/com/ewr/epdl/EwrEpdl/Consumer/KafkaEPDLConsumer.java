package com.ewr.epdl.EwrEpdl.Consumer;

import com.ewr.epdl.EwrEpdl.Controller.KafkaController;
import com.ewr.epdl.EwrEpdl.common.JsonCreate;
import org.apache.avro.generic.GenericRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.event.EventListener;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.config.KafkaListenerEndpointRegistry;
import org.springframework.kafka.event.ConsumerFailedToStartEvent;
import org.springframework.kafka.event.ListenerContainerIdleEvent;
import org.springframework.kafka.event.NonResponsiveConsumerEvent;
import org.springframework.kafka.listener.MessageListenerContainer;
import org.springframework.stereotype.Service;


import java.sql.Connection;
import java.sql.DriverManager;


import static com.ewr.epdl.EwrEpdl.common.ConvertToDecimal.convert;

@Service
public class KafkaEPDLConsumer {

    @Value("${dbconn.user}")
    private String user;

    @Value("${dbconn.dbPassword}")
    private String dbPassword;

    @Value("${dbconn.qualifier}")
    private String qualifier;

    @Value("${dbconn.url}")
    private String url;

    @Value("${dbconn.driver}")
    private String driver;

    @Value("${kafka.tin}")
    private String tin;


    @Autowired
    private JsonCreate jsonCreate;

    @Autowired
    private KafkaListenerEndpointRegistry registry;

    @Autowired
    private KafkaController kafkaController;

    private static final Logger LOGGER = LoggerFactory.getLogger(KafkaEPDLConsumer.class);     //ps::this will take logs
    private static Connection connection = null;
    private static Connection db2Connection = null;
    public String pqid = "", status = "", srcTyp = "", vendorTyp = "", roleType ="", taxIdNbr="";


    @KafkaListener(id="EPDLContainer",topics = "${kafka.topic.consumername}", groupId = "${kafka.consumer.group.id}")
//    public void receive(Object message) throws Exception {
    public void receive(GenericRecord message) throws Exception {

        GenericRecord convertedRecord = (GenericRecord) message.get("data");
        String dataRecord = convert(convertedRecord).toString().trim();
        System.out.println("dataRecord "+ dataRecord);
        String valproducer = jsonCreate.jsonConvert(dataRecord.toString());
        String[] results = valproducer.split(";");
        for (int i = 0; i < results.length; i++) {
            if (i == 0) {
                pqid = results[0].trim();
            } else if (i == 1) {

                status = results[1].trim();
            } else if (i == 2 ) {
                srcTyp = results[2].trim();
            }else if (i == 3 ) {
                vendorTyp = results[3].trim();
            }else if (i == 4 ) {
                roleType = results[4].trim();
            }else {
                taxIdNbr = results[5].trim();
            }
        }
        LOGGER.info("Correlation ID "+ pqid + " Status "+ status+ " SourceType "+ srcTyp + " vendorTyp "+ vendorTyp +" roleType "+ roleType);
//        kafkaController.createEnrichmentData(valproducer, connection);
        System.out.println(" Consumer TIN "+ taxIdNbr +" File TIN "+ tin);
        if(taxIdNbr.trim().equals(tin.trim()) && vendorTyp.trim().equals("MPN"))
        {
            kafkaController.autoResolve(pqid);
        }
        else {
            kafkaController.createEnrichmentData(valproducer);
        }
    }


    @EventListener
    public void eventHandler(NonResponsiveConsumerEvent event) {

        LOGGER.info("Topic is non-responsive. " );
        MessageListenerContainer listenerContainer = this.registry.getListenerContainer("EPDLContainer");
        listenerContainer.pause();
        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        listenerContainer.resume();

    }

//    @EventListener
//    public void eventHandler(ConsumerStartingEvent event) {
//        try {
//            connection = getDB2Conn();
//            if (connection == null) {
//                LOGGER.info("Connection Issue");
//            }
//            else{
//                LOGGER.info("Connection Established Successfully");
//
//            }
//
//        }
//        catch (Exception e)
//        {
//            LOGGER.info("Catching Connection Issue"+ e);
//
//        }
//
//
//        LOGGER.info("Starting Consumer for EPDL Project");
//    }

    @EventListener
    public void eventHandler(ConsumerFailedToStartEvent event) {
        LOGGER.info("Failed to start Consumer. ");
        MessageListenerContainer listenerContainer = this.registry.getListenerContainer("EPDLContainer");
        listenerContainer.pause();
        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        listenerContainer.resume();

    }

    @EventListener
    public void eventHandler(ListenerContainerIdleEvent event) {
        LOGGER.info("No messages received for " + event.getIdleTime() + " milliseconds");
    }

    public Connection getDB2Conn() {
        try {

            if (connection == null) {

//                Class.forName(yconfig.getDriver());
//                db2Connection = DriverManager.getConnection(yconfig.getUrl(), yconfig.getUser(), yconfig.getDbPassword());
                Class.forName(driver);
                db2Connection = DriverManager.getConnection(url, user, dbPassword);
                db2Connection.setAutoCommit(true);
                connection = db2Connection;
            }


        } catch (Exception e) {
//            LOGGER.error("Exception in getDB2connection Method: ", e);
            e.printStackTrace();
        }
        return connection;
    }
}
