package com.ewr.epdl.EwrEpdlFeedback.config;

import io.confluent.kafka.serializers.KafkaAvroDeserializer;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.config.SslConfigs;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import io.confluent.kafka.serializers.KafkaAvroSerializer;

import java.util.Properties;

@Configuration
@ComponentScan(basePackages = "com.ewr.epdl")
public class KafkaConsumerConfig {
    @Autowired
    private YamlConfig yconfig;
    //private static String loc = System.getProperty("user.dir") + "/src/main/resources";
    private static String loc = System.getProperty("user.dir");//+"\\src\\main\\resources";

   // @Bean
    public Properties createKafkaConsumerConfigurationProperties() {
        Properties props = new Properties();
        try {
            props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, yconfig.getServer());
            props.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, yconfig.getSecurityprotocol());
            props.put(SslConfigs.SSL_KEYSTORE_TYPE_CONFIG, yconfig.getKeystoretype());
            props.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, loc + yconfig.getTruststorelocation());
            props.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, yconfig.getTruststorepassword());
            props.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG, loc  +  yconfig.getKeystorelocation());
            props.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, yconfig.getKeystorepassword());
            props.put(SslConfigs.SSL_KEY_PASSWORD_CONFIG, yconfig.getKeypassword());
            props.put(ConsumerConfig.GROUP_ID_CONFIG, yconfig.getGroupid());
            props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "true");
            props.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, "1");
            props.put(ConsumerConfig.MAX_POLL_INTERVAL_MS_CONFIG, "600000");
            props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, yconfig.getAutooffset());
            props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
            props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, KafkaAvroDeserializer.class.getName());
            props.put("schema.registry.url", yconfig.getSchemaRegistry());
            props.put(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, yconfig.getSessionTimeoutMS());
            props.put("specific.avro.reader", yconfig.getSpecificAvroReader());
            System.out.println("All Properties loaded for kafka Consumer");
        } catch (Exception e) {
            e.printStackTrace();

        }
        return props;
    }
}
