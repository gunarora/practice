package com.ewr.epdl.EwrEpdlFeedback;

import com.ewr.epdl.EwrEpdlFeedback.KafkaConsumer.KafkaEPDLFeedbackConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController
@ComponentScan(basePackages = "com.ewr.epdl")
public class EwrEpdlFeedbackApplication implements CommandLineRunner{

	@Autowired
	private KafkaEPDLFeedbackConsumer kafkaEPDLFeedbackConsumer;

	private static final Logger logger = LoggerFactory.getLogger(KafkaEPDLFeedbackConsumer.class);

	public static void main(String[] args) {

		logger.info("Message logged at INFO level & SpringBoot application started");
		SpringApplication.run(EwrEpdlFeedbackApplication.class, args);
	}



	public void run(String... args) throws Exception {
		System.out.println("run() In Start");
		logger.info("Message logged at INFO level & SpringBoot application started");
		kafkaEPDLFeedbackConsumer.createConsumer();
		logger.info("run() In End");
		System.out.println("In End");

	}
}
