package com.ewr.epdl.EwrEpdlFeedback.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

@Component
@Configuration
@EnableConfigurationProperties
@ConfigurationProperties
public class YamlConfig {

    private String environment;
    private String endpoint;
    private String resource;
    private String topicname;
    private String server;
    //private String serverProdElr;
    private String securityprotocol;
    private String keystoretype;
    private String truststorelocation;
    private String truststorepassword;
    private String keystorelocation;
    private String keystorepassword;
    private String keypassword;
    private String retries;
    private String batchsize;
    private String lingerms;
    private String buffermemory;
    private String keyserializer;
    private String valueserializer;
    private String groupid;
    private String autooffset;
    private String keydeserializer;
    private String valuedeserializer;

    private String schemaRegistry;
    private String schemaProducerRegistry;
    private String sessionTimeoutMS;
    private String specificAvroReader;


   /* private String truststoreProducerlocation;
    private String truststoreProducerpassword;
    private String keystoreProducerlocation;
    private String keystoreProducerpassword;
    private String keyProducerpassword;*/

    private String qualifier;
    private String qualifierusec;
    private String user;
    private String dbPassword;
    private String platform;
    private String url;
    private String driver;

   /* private String ack;

    public String getAck() {
        return ack;
    }

    public void setAck(String ack) {
        this.ack = ack;
    }

    public String getSchemaProducerRegistry() {
        return schemaProducerRegistry;
    }

    public void setSchemaProducerRegistry(String schemaProducerRegistry) {
        this.schemaProducerRegistry = schemaProducerRegistry;
    }*/

    public String getQualifier() {
        return qualifier;
    }

    public void setQualifier(String qualifier) {
        this.qualifier = qualifier;
    }

    public String getQualifierusec() {
        return qualifierusec;
    }

    public void setQualifierusec(String qualifierusec) {
        this.qualifierusec = qualifierusec;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getDbPassword() {
        return dbPassword;
    }

    public void setDbPassword(String dbPassword) {
        this.dbPassword = dbPassword;
    }

    public String getPlatform() {
        return platform;
    }

    public void setPlatform(String platform) {
        this.platform = platform;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getDriver() {
        return driver;
    }

    public void setDriver(String driver) {
        this.driver = driver;
    }

    public String getTopicProducername() {
        return topicProducername;
    }

    public void setTopicProducername(String topicProducername) {
        this.topicProducername = topicProducername;
    }

    private String topicProducername;

    /*public String getTruststoreProducerlocation() {
        return truststoreProducerlocation;
    }

    public void setTruststoreProducerlocation(String truststoreProducerlocation) {
        this.truststoreProducerlocation = truststoreProducerlocation;
    }

    public String getTruststoreProducerpassword() {
        return truststoreProducerpassword;
    }

    public void setTruststoreProducerpassword(String truststoreProducerpassword) {
        this.truststoreProducerpassword = truststoreProducerpassword;
    }

    public String getKeystoreProducerlocation() {
        return keystoreProducerlocation;
    }

    public void setKeystoreProducerlocation(String keystoreProducerlocation) {
        this.keystoreProducerlocation = keystoreProducerlocation;
    }

    public String getKeystoreProducerpassword() {
        return keystoreProducerpassword;
    }

    public void setKeystoreProducerpassword(String keystoreProducerpassword) {
        this.keystoreProducerpassword = keystoreProducerpassword;
    }

    public String getKeyProducerpassword() {
        return keyProducerpassword;
    }

    public void setKeyProducerpassword(String keyProducerpassword) {
        this.keyProducerpassword = keyProducerpassword;
    }*/

    public String getEnvironment() {
        return environment;
    }

    public void setEnvironment(String environment) {
        this.environment = environment;
    }

    public String getEndpoint() {
        return endpoint;
    }

    public void setEndpoint(String endpoint) {
        this.endpoint = endpoint;
    }

    public String getResource() {
        return resource;
    }

    public void setResource(String resource) {
        this.resource = resource;
    }

    public String getTopicname() {
        return topicname;
    }

    public void setTopicname(String topicname) {
        this.topicname = topicname;
    }

    public String getServer() {
        return server;
    }

    public void setServer(String server) {
        this.server = server;
    }

    /*public String getServerProdElr() {
        return serverProdElr;
    }

    public void setServerProdElr(String serverProdElr) {
        this.serverProdElr = serverProdElr;
    }
public String getServer1() {
        return server1;
    }

    //public void setServer1(String server1) {
        this.server1 = server1;
    }*/

    public String getSecurityprotocol() {
        return securityprotocol;
    }

    public void setSecurityprotocol(String securityprotocol) {
        this.securityprotocol = securityprotocol;
    }

    public String getKeystoretype() {
        return keystoretype;
    }

    public void setKeystoretype(String keystoretype) {
        this.keystoretype = keystoretype;
    }

    public String getTruststorelocation() {
        return truststorelocation;
    }

    public void setTruststorelocation(String truststorelocation) {
        this.truststorelocation = truststorelocation;
    }

    public String getTruststorepassword() {
        return truststorepassword;
    }

    public void setTruststorepassword(String truststorepassword) {
        this.truststorepassword = truststorepassword;
    }

    public String getKeystorelocation() {
        return keystorelocation;
    }

    public void setKeystorelocation(String keystorelocation) {
        this.keystorelocation = keystorelocation;
    }

    public String getKeystorepassword() {
        return keystorepassword;
    }

    public void setKeystorepassword(String keystorepassword) {
        this.keystorepassword = keystorepassword;
    }

    public String getKeypassword() {
        return keypassword;
    }

    public void setKeypassword(String keypassword) {
        this.keypassword = keypassword;
    }

    public String getRetries() {
        return retries;
    }

    public void setRetries(String retries) {
        this.retries = retries;
    }

    public String getBatchsize() {
        return batchsize;
    }

    public void setBatchsize(String batchsize) {
        this.batchsize = batchsize;
    }

    public String getLingerms() {
        return lingerms;
    }

    public void setLingerms(String lingerms) {
        this.lingerms = lingerms;
    }

    public String getBuffermemory() {
        return buffermemory;
    }

    public void setBuffermemory(String buffermemory) {
        this.buffermemory = buffermemory;
    }

    public String getKeyserializer() {
        return keyserializer;
    }

    public void setKeyserializer(String keyserializer) {
        this.keyserializer = keyserializer;
    }

    public String getValueserializer() {
        return valueserializer;
    }

    public void setValueserializer(String valueserializer) {
        this.valueserializer = valueserializer;
    }

    public String getGroupid() {
        return groupid;
    }

    public void setGroupid(String groupid) {
        this.groupid = groupid;
    }

    public String getAutooffset() {
        return autooffset;
    }

    public void setAutooffset(String autooffset) {
        this.autooffset = autooffset;
    }

    public String getKeydeserializer() {
        return keydeserializer;
    }

    public void setKeydeserializer(String keydeserializer) {
        this.keydeserializer = keydeserializer;
    }

    public String getValuedeserializer() {
        return valuedeserializer;
    }

    public void setValuedeserializer(String valuedeserializer) {
        this.valuedeserializer = valuedeserializer;
    }

    public String getSchemaRegistry() {
		return schemaRegistry;
	}

	public void setSchemaRegistry(String schemaRegistry) {
		this.schemaRegistry = schemaRegistry;
	}

   public String getSessionTimeoutMS() {
		return sessionTimeoutMS;
	}

	public void setSessionTimeoutMS(String sessionTimeoutMS) {
		this.sessionTimeoutMS = sessionTimeoutMS;
	}

	public String getSpecificAvroReader() {
		return specificAvroReader;
	}

	public void setSpecificAvroReader(String specificAvroReader) {
		this.specificAvroReader = specificAvroReader;
	}
}
