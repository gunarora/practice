package com.ewr.epdl.EwrEpdlFeedback.KafkaConsumer;


import com.ewr.epdl.EwrEpdlFeedback.config.JsonCreate;
import com.ewr.epdl.EwrEpdlFeedback.config.KafkaConsumerConfig;
import com.ewr.epdl.EwrEpdlFeedback.config.YamlConfig;
import org.apache.commons.lang3.StringUtils;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.avro.generic.GenericRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.*;
import java.util.Date;

@Service
@Component
@ComponentScan(basePackages = "com.ewr.epdl")
public class KafkaEPDLFeedbackConsumer {

    @Autowired
    private YamlConfig yconfig;

    @Autowired
    KafkaConsumerConfig kafkaConsumerConfig;

    @Autowired
    private JsonCreate jsonCreate;

    private static final Logger logger = LoggerFactory.getLogger(KafkaEPDLFeedbackConsumer.class);

    org.apache.kafka.clients.consumer.KafkaConsumer<GenericRecord, GenericRecord> consumer = null;

    //Varaibles Declaration
    private static Connection connection = null;
    private static Connection db2Connection = null;
    private String workItemType = "", ewdIlId = "", application = "";
    private Statement selectState = null;
    private Statement rsql = null;
    private Statement psql = null;

    String pqid = null, status = null, resolutionReasonCode = null, claID = null, actionDate = null, transferComments = null, resolutionComments = null, actionStatus = null, empID = null;
    String opid = null,    ofccd = null, lstUpdtTypCd =null;
    String peqApplStsRsnCd = null;
    String lstUpdatedDate = "", lstUpdatedTime = "";
    Map<String, List<String>> dataMap = new HashMap<String, List<String>>();
    List<String> corelationIDList = new ArrayList<String>();
    int peqVerNbr = 0,  up =0;

    public void createConsumer() {
        System.out.println("Create Consumer");
        KafkaConsumer<String, GenericRecord> consumer = null;
        try {
            Properties kafkaConfig = kafkaConsumerConfig.createKafkaConsumerConfigurationProperties();
            consumer = new KafkaConsumer<>(kafkaConfig);
            consumer.subscribe(Collections.singletonList(yconfig.getTopicname()));
            consumer.subscribe(Arrays.asList(yconfig.getTopicname()));
            while (true) {
                ConsumerRecords<String, GenericRecord> records = consumer.poll(100);
                for (ConsumerRecord<String, GenericRecord> record : records) {
                    peqVerNbr = 0;  up =0;
                    //System.out.println("In Consumer Loop Request");
                    long startTime = System.currentTimeMillis();
                    String g = record.value().toString();
                   // System.out.println("records received Prod" + g.toString());
                    String valproducer = jsonCreate.jsonConvert(g);
                    String[] results = valproducer.split(";");
                    //System.out.println("result length = " + results.length);
                    workItemType = results[0].trim();
                    ewdIlId = results[1].trim();
                    application = results[2].trim();
                    empID = results[3].trim();
                    resolutionReasonCode = results[4].trim();
                    claID = results[5].trim();
                    actionDate = results[6].trim();
                    transferComments = results[7].trim();
                    resolutionComments = results[8].trim();
                    //added as part of code changes defect  DE434883 and DE434884 of comment length and allow to added appostrophie:
                   // System.out.println("Length of a resolutionComments is: " + resolutionComments.length());
                    if(resolutionComments.length()>250)
                    {
                        resolutionComments = resolutionComments.substring(0, 200);
                        resolutionComments = resolutionComments + "...To see the full comment check in EWD";
                       // System.out.println("resolutionComments altered - "+resolutionComments);
                    }
                    resolutionComments = resolutionComments.replace("'","''");
                    resolutionComments = resolutionComments.replace("\\u2026",".");
                    resolutionComments = resolutionComments.replace("\u2026",".");
                    resolutionComments = resolutionComments.replace("\u2022","\"");
                   // System.out.println("resolutionComments alterted - "+resolutionComments);
                    actionStatus = results[9].trim();
                    pqid = results[10].trim();
                    if(!resolutionReasonCode.equals(""))
                        resolutionReasonCode = resolutionReasonCode.substring(0, 2);
                    if(!actionDate.equals("") && (!actionDate.equals(null)) && (!actionDate.matches("^[a-zA-Z]*$")) )
                    {
                        long unixSeconds = Long.parseLong(actionDate);
                        // the format of your date
                        SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss z");
                        // give a timezone reference for formatting (see comment at the bottom)
                        sdf.setTimeZone(java.util.TimeZone.getTimeZone("America/New_York"));
                        String formattedDate = sdf.format(unixSeconds);
                        String SplitDate[] = formattedDate.split(" ");
                        lstUpdatedDate = SplitDate[0];
                        lstUpdatedTime = SplitDate[1];
                    }
                    if (workItemType.trim().equals("NDM Work Q") && application.trim().equals("NDM") &&  !lstUpdatedDate.equals("")
                            && !lstUpdatedTime.equals("")
                            && !resolutionReasonCode.equals("") && !pqid.equals("") && StringUtils.isNumeric(pqid) && !actionStatus.equals("")
                            && !actionDate.equals("") && !claID.equals("")) {
                        if (connection == null) {
                            connection = getDB2Conn();
                        }
                        try {
                            String sql = "SELECT B.IDOPER AS USER_ID,B.CDOFFICE AS USER_OFC_CD,A.EMPLOYEE_TYP_CD AS LST_UPDT_TYP_CD" +
                                    " FROM F6438DB.USEC_DEMO_MAIN A ,  F6438DB.USEC_EPD_DEMO B        " +
                                    " WHERE A.EMPLOYEE_ID = '" + empID + "' AND A.IDUSEC = B.IDUSEC WITH UR";
                            // logger.info(sql);
                            selectState = null;
                            selectState = connection.createStatement();
                            ResultSet m = selectState.executeQuery(sql);
                            if(m.next()){
                                opid = m.getString("USER_ID");
                                ofccd = m.getString("USER_OFC_CD");
                            }
                            else{
                                opid = "EWL";
                                ofccd = "938";
                            }

                            lstUpdtTypCd = "U";

                            String sqlVersionNumber = "select VER_NBR from f5938DB.Proc_err_que where proc_err_que_id= "+ pqid + " WITH UR";
                            //  System.out.println(sqlVersionNumber);
                            ResultSet msqlVersionNumber = selectState.executeQuery(sqlVersionNumber);
                            if (msqlVersionNumber.next()) {
                                peqVerNbr = msqlVersionNumber.getInt("VER_NBR");
                                peqVerNbr = peqVerNbr + 1;

                                if (actionStatus.equals("P")) {
                                    String sqlPendedUpdate = "UPDATE F5938DB.PROC_ERR_QUE " +
                                            "SET LST_UPDT_TYP_CD = '" + lstUpdtTypCd + "' , " +
                                            "ASGN_USER_ID = '" + opid + "' , " +
                                            "ASGN_USER_OFC_CD = '" + ofccd + "' , " +
                                            "USER_ID= '" + opid + "', " +
                                            "USER_OFC_CD = '" + ofccd + "' , " +
                                            "LST_UPDT_DT= '" + lstUpdatedDate + "', " +
                                            "LST_UPDT_TM= '" + lstUpdatedTime + "', " +
                                            "VER_NBR= " + peqVerNbr + ", " +
                                            "CLA_ID = '" + claID + "', " +
                                            "ERR_QUE_STS_TYP_CD= '" + actionStatus + "', " +
//                                            "Q_APPL_STS_RSN_CD= '" + peqApplStsRsnCd + "', " +
//                                            "COMMT_TXT= '" + transferComments + "', " +
                                            "COMMT_TXT= '" + resolutionComments + "', " +
                                            "Q_BUS_STS_RSN_CD = '" + resolutionReasonCode + "' " +
                                            "WHERE PROC_ERR_QUE_ID ='" + pqid + "'  AND OPER_AREA_TYP_CD IN ('ACN', 'HPHC', 'MPN','LABC','MEDI'); COMMIT";
                                    //logger.info(sqlPendedUpdate);
                                    psql = null;
                                    PreparedStatement psql = connection.prepareStatement(sqlPendedUpdate);
                                    up = psql.executeUpdate();
                                    if (up < 1) {
                                        logger.info("Nothing Pended for Correlation ID " + pqid);
                                    } else {
                                        logger.info("Pended no. of records " + up + " for Correlation ID " + pqid);
                                    }

                                } else if (actionStatus.equals("R")) {
                                    if(!transferComments.isEmpty()) {

                                        String sqlApplStsRsnCd = "SELECT QBA.Q_APPL_STS_RSN_CD  FROM f5938db.PROC_ERR_QUE  PEQ  JOIN f5938db.Q_BUS_STS_APPL_DRV   QBA \n" +
                                                " ON QBA.Q_APPL_DRV_TYP_CD  = PEQ.Q_APPL_DRV_TYP_CD  WHERE PEQ.PROC_ERR_QUE_ID = '" + pqid + "' AND PEQ.PROC_SRC_TYP_CD    = 'BB' \n" +
                                                " AND QBA.Q_BUS_STS_RSN_CD   = '" + resolutionReasonCode + "' WITH UR";
                                        // logger.info(sqlApplStsRsnCd);
                                        ResultSet msqlApplStsRsnCd = selectState.executeQuery(sqlApplStsRsnCd);
                                        if (msqlApplStsRsnCd.next()) {
                                            peqApplStsRsnCd = msqlApplStsRsnCd.getString("Q_APPL_STS_RSN_CD").trim();

                                            String sqlReleaseUpdate = "UPDATE F5938DB.PROC_ERR_QUE " +
                                                    "SET LST_UPDT_TYP_CD = '" + lstUpdtTypCd + "' , " +
                                                    "ASGN_USER_ID = '" + opid + "' , " +
                                                    "ASGN_USER_OFC_CD = '" + ofccd + "' , " +
                                                    "USER_ID= '" + opid + "' , " +
                                                    "USER_OFC_CD = '" + ofccd + "' , " +
                                                    "LST_UPDT_DT= '" + lstUpdatedDate + "' , " +
                                                    "LST_UPDT_TM= '" + lstUpdatedTime + "' , " +
                                                    "VER_NBR= " + peqVerNbr + ", " +
                                                    "CLA_ID = '" + claID + "', " +
                                                    "ERR_QUE_STS_TYP_CD= '" + actionStatus + "' , " +
                                                    "Q_APPL_STS_RSN_CD= '" + peqApplStsRsnCd + "' , " +
                                                    "COMMT_TXT= '" + resolutionComments + "', " +
                                                    "PRI_CD = '" + transferComments + "' , " +
                                                    "MAIN_PROC_ERR_QUE_ID = 0" + " , " +
                                                    "Q_BUS_STS_RSN_CD = '" + resolutionReasonCode + "' " +
                                                    "WHERE PROC_ERR_QUE_ID ='" + pqid + "' AND OPER_AREA_TYP_CD IN ('ACN', 'HPHC', 'MPN','LABC','MEDI'); COMMIT";
                                            //logger.info(sqlReleaseUpdate);
                                            rsql = null;

                                            PreparedStatement rsql = connection.prepareStatement(sqlReleaseUpdate);
                                            up = rsql.executeUpdate();

                                            if (up < 1) {
                                                logger.info("Nothing Resolved into NDM end for Correlation ID " + pqid+" and CLA ID "+ claID);
                                            } else {
                                                logger.info("Resolved no. of records " + up + " for Correlation ID " + pqid +" and CLA ID "+ claID);
                                            }
                                        } else {
                                            logger.info("APPL_STS_RSN_CD :"+ peqApplStsRsnCd +" is not valid against of BUS_STS_RSN_CD :  " + resolutionReasonCode + " and Correlation ID " + pqid + " Not possible to resolve claim into NDM end");
                                        }
                                    }
                                    else
                                    {
                                        logger.info("Primary Code (P/S) should not be blank " + transferComments + " Not possible to resolve claim into NDM end ");
                                    }
                                } else {
                                    logger.info("Status is not correct  "+ actionStatus + " Not possible to take any action from NDM end");
                                }
                            }
                            else
                            {
                                logger.info("Consumed Correlation ID does not exist in NDM "+ pqid);
                            }

                            if(rsql != null)
                            {
                                rsql.close();
                            }
                            if(psql != null)
                            {
                                psql.close();
                            }
                            if (selectState != null) {
                                selectState.close();
                            }
                            if(connection != null)
                            {
                                connection.close();
                                connection = null;

                            }
                        } catch (SQLException e) {
                            e.printStackTrace();
                            logger.info("Exception "+ e);
                        }
                        catch (Exception e) {
                            e.printStackTrace();
                            logger.info("Exception "+ e);
                        }
                    }
                    else
                    {
                        logger.info("One of the Required field is missing/incorrect as worktype : "+ workItemType +" application : "+ application + " EMPID : "+ empID +" resolutionReasonCode : "+ resolutionReasonCode + " Correlation ID : " + pqid + " Status : " + actionStatus + " transferComments : "+ transferComments + " CLA ID : "+ claID +" ResolutionReasonCode : "+ resolutionReasonCode + " Action Date : "+ lstUpdatedDate +" "+ lstUpdatedTime+" Resolution Comments : "+ resolutionComments);
                    }


            } //for loop
           } //While Loop
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }finally
        {
            consumer.close();
        }
    }
    public Connection getDB2Conn() {
        try {
            if (connection == null) {

                Class.forName(yconfig.getDriver());
                db2Connection = DriverManager.getConnection(yconfig.getUrl(), yconfig.getUser(), yconfig.getDbPassword());
                db2Connection.setAutoCommit(true);
                connection = db2Connection;
                if (connection == null)
                {
                    logger.info("Connection Issue");
                }
            }

        } catch (Exception e) {  logger.info("Exception in getDB2connection Method: ", e);
            e.printStackTrace();
        }
        return connection;
    }

}