package com.ewr.epdl.EwrEpdlFeedback.config;



//import jdk.nashorn.internal.parser.JSONParser;
import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

//Get records and create JSON
@Configuration
@ComponentScan(basePackages = "com.ewr.epdl.EwrEpdlFeedback")
public class JsonCreate {
    public String jsonConvert (String jsond) throws JSONException {
         JSONObject jsonObj = new JSONObject(jsond.toString());
        //Header
        String resolutionReasonCode = "" , transferComments = "";
        String workItemType = (jsonObj.getString("workItemType").equals("null") || jsonObj.getString("workItemType").isEmpty()) ? "" : jsonObj.getString("workItemType") ;
        String ewdIlId = (jsonObj.getString("ewdIlId").equals("null") || jsonObj.getString("ewdIlId").isEmpty()) ? "" : jsonObj.getString("ewdIlId") ;
        String application = (jsonObj.getString("application").equals("null") || jsonObj.getString("application").isEmpty()) ? "" : jsonObj.getString("application") ;
        //Work Item Required Fields
        String peqID = (jsonObj.getString("correlationId").equals("null") || jsonObj.getString("correlationId").isEmpty()) ? "" : jsonObj.getString("correlationId"); //PEQID //170392037bat24tess1mail1
        if(peqID.contains("SF")) {
            peqID = peqID.substring(2);
        }

        //Feedback Resolution Fields
        String claID = (jsonObj.getString("assignmentBatch").equals("null") || jsonObj.getString("assignmentBatch").isEmpty()) ? "" :  jsonObj.getString("assignmentBatch");
        String actionDate = (jsonObj.getString("actionDate").equals("null") || jsonObj.getString("actionDate").isEmpty()) ? "" : jsonObj.getString("actionDate"); //LastUpdateDt+Time
        String resolutionComments = (jsonObj.getString("resolutionComments").equals("null") || jsonObj.getString("resolutionComments").isEmpty()) ? "" : jsonObj.getString("resolutionComments") ;
        String actionStatus = (jsonObj.getString("action").equals("null") || jsonObj.getString("action").isEmpty()) ? "" : jsonObj.getString("action") ;//reslved = "R"

        if(actionStatus.trim().equals("resolved")) {
            actionStatus = "R";
            resolutionReasonCode = (jsonObj.getString("resolutionReasonCode").equals("null") || jsonObj.getString("resolutionReasonCode").isEmpty()) ? "" : jsonObj.getString("resolutionReasonCode");//Q_BUS_STS_RSN_CD
            transferComments = (jsonObj.getString("transferComments").equals("null") ||jsonObj.getString("transferComments").isEmpty()) ? "" : jsonObj.getString("transferComments");
        }

        else if (actionStatus.trim().equals("Pended"))
        {
            actionStatus = "P";
            resolutionReasonCode = (jsonObj.getString("transferComments").equals("null") ||jsonObj.getString("transferComments").isEmpty()) ? "" : jsonObj.getString("transferComments").substring(0,2); //P or S
        }
        System.out.println(" resolutionComments "+ resolutionComments);

        String empID = (jsonObj.getString("assignedTo").equals("null") || jsonObj.getString("assignedTo").isEmpty()) ? "0" : jsonObj.getString("assignedTo");

        return workItemType+";"+ ewdIlId+";"+application+";"+empID+";"+resolutionReasonCode+";"+claID +";" + actionDate+";"+transferComments+";"+resolutionComments+";"+actionStatus+";"+peqID;
    }
}




