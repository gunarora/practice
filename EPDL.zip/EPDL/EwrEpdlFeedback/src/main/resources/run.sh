#!/bin/sh

/opt/splunk/splunkforwarder/bin/splunk start --accept-license

#/opt/dynatrace/oneagent/dynatrace-agent64.sh java "-XX:+UnlockExperimentalVMOptions" "-XX:+UseCGroupMemoryLimitForHeap" "-XX:+PrintGCDetails" "-XX:+PrintGCDateStamps" "-Xloggc:/com/optum/gclogs/gc.log" "-XX:+ExitOnOutOfMemoryError" "-Duser.timezone=America/Chicago" "-jar"  "/com/optum/app.jar"

java "-jar" "/com/optum/ewrepdlfeedback.jar"

