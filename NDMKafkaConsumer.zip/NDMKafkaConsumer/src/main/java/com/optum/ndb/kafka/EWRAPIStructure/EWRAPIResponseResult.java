package com.optum.ndb.kafka.EWRAPIStructure;

public class EWRAPIResponseResult {

	private String transform_map;
    private String table;
    private String display_name;
    private String display_value;
    private String record_link;
    private String status;
    private String sys_id;
    private String status_message;
    private String return_message;
    private String return_code;
	public String getTransform_map() {
		return transform_map;
	}
	public void setTransform_map(String transform_map) {
		this.transform_map = transform_map;
	}
	public String getTable() {
		return table;
	}
	public void setTable(String table) {
		this.table = table;
	}
	public String getDisplay_name() {
		return display_name;
	}
	public void setDisplay_name(String display_name) {
		this.display_name = display_name;
	}
	public String getDisplay_value() {
		return display_value;
	}
	public void setDisplay_value(String display_value) {
		this.display_value = display_value;
	}
	public String getRecord_link() {
		return record_link;
	}
	public void setRecord_link(String record_link) {
		this.record_link = record_link;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getSys_id() {
		return sys_id;
	}
	public void setSys_id(String sys_id) {
		this.sys_id = sys_id;
	}
	public String getStatus_message() {
		return status_message;
	}
	public void setStatus_message(String status_message) {
		this.status_message = status_message;
	}
	public String getReturn_message() {
		return return_message;
	}
	public void setReturn_message(String return_message) {
		this.return_message = return_message;
	}
	public String getReturn_code() {
		return return_code;
	}
	public void setReturn_code(String return_code) {
		this.return_code = return_code;
	}
	
	public EWRAPIResponseResult(String transform_map, String table, String display_name, String display_value,
			String record_link, String status, String sys_id, String status_message, String return_message,
			String return_code) {
		super();
		this.transform_map = transform_map;
		this.table = table;
		this.display_name = display_name;
		this.display_value = display_value;
		this.record_link = record_link;
		this.status = status;
		this.sys_id = sys_id;
		this.status_message = status_message;
		this.return_message = return_message;
		this.return_code = return_code;
	}
	
	public EWRAPIResponseResult() {
		super();
	}
	public EWRAPIResponseResult(String return_message, String return_code) {
		super();
		this.return_message = return_message;
		this.return_code = return_code;
	}

    
}
