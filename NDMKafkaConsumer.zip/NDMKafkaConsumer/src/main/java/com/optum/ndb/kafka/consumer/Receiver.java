package com.optum.ndb.kafka.consumer;

import java.util.Arrays;
import java.util.Properties;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;

import com.optum.ndb.kafka.api.APICall;
/*import com.optum.ndb.kafka.api.Error;
import com.optum.ndb.kafka.api.Notification;
import com.optum.ndb.kafka.api.SplitRequest;*/
import com.optum.ndb.kafka.config.YamlConfig;

@Component
@ComponentScan(basePackages = "com.optum.ndb.kafka.consumer,com.optum.ndb.kafka.config,com.optum.ndb.kafka.api,com.optum.ndb.kafka.repository")
public class Receiver {
	@Autowired
	private ReceiverConfig receiverConfig;

	@Autowired
	private YamlConfig yconfig;

/*	@Autowired
	private SplitRequest splitreq;

	@Autowired
	private Error error;
*/
	@Autowired
	private APICall apiCall;
	
	/*private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH.mm.ss.SSS");
	private static String status = "FAIL";
*/
	public void createConsumer() {
		KafkaConsumer<String, String> consumer = null;
		try {
			Properties kafkaConfig = receiverConfig.createKafkaConsumerProperties();
			consumer = new KafkaConsumer<>(kafkaConfig);
			consumer.subscribe(Arrays.asList(yconfig.getTopicname()));
			System.out.println("in consumer");
			while (true) {
				ConsumerRecords<String, String> records = consumer.poll(100);
				for (ConsumerRecord<String, String> record : records) {
					System.out.println("Got Request");
					long startTime = System.currentTimeMillis();
					System.out.printf("consumer_print_offset = %d, key = %s, value = %s\n", record.offset(), record.key(), record.value());
		            //get The Token from the API
		            apiCall.getEWRAPI(record.value(),startTime,record.offset());
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
        	consumer.close();
        }
	}
}
