package com.optum.ndb.kafka.EWRAPIStructure;

public class EWRAPIResponse {

	private String import_set;
	private String staging_table;
	private EWRAPIResponseResult responseResult;
	public String getImport_set() {
		return import_set;
	}
	public void setImport_set(String import_set) {
		this.import_set = import_set;
	}
	public String getStaging_table() {
		return staging_table;
	}
	public void setStaging_table(String staging_table) {
		this.staging_table = staging_table;
	}
	public EWRAPIResponseResult getResponseResult() {
		return responseResult;
	}
	public void setResponseResult(EWRAPIResponseResult responseResult) {
		this.responseResult = responseResult;
	}
	
	public EWRAPIResponse() {
		super();
	}
	public EWRAPIResponse(String import_set, String staging_table, EWRAPIResponseResult responseResult) {
		super();
		this.import_set = import_set;
		this.staging_table = staging_table;
		this.responseResult = responseResult;
	}
	
	
}
