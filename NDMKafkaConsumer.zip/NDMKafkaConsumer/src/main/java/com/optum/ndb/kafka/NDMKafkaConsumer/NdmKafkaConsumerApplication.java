package com.optum.ndb.kafka.NDMKafkaConsumer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import com.optum.ndb.kafka.consumer.Receiver;

@SpringBootApplication
@ComponentScan(basePackages = "com.optum.ndb.kafka.consumer")
public class NdmKafkaConsumerApplication implements CommandLineRunner {

	@Autowired
	private Receiver receiver;
	
	public static void main(String[] args) {
		SpringApplication.run(NdmKafkaConsumerApplication.class, args);
	}

	public void run(String... args) throws Exception {
		receiver.createConsumer();
	}
}
