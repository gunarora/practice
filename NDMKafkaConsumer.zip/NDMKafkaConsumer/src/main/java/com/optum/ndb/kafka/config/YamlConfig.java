package com.optum.ndb.kafka.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

@Component
@Configuration
@EnableConfigurationProperties
@ConfigurationProperties
public class YamlConfig {

	private String environment;
	private String endpoint;
	private String resource;
	private String topicname;
	private String server;
	private String securityprotocol;
	private String keystoretype;
	private String truststorelocation;
	private String truststorepassword;
	private String keystorelocation;
	private String keystorepassword;
	private String keypassword;
	private String retries;
	private String batchsize;
	private String lingerms;
	private String buffermemory;
	private String keyserializer;
	private String valueserializer;
	private String groupid;
	private String autooffset;
	private String keydeserializer;
	private String valuedeserializer;
	
	private String classForName;
	private String db2ServerURLString;
	private String userId;
	private String password;
	private String ewrAuthURL;
	private String ewrAuthParamter;
	private String ewrResolvedURL;
	private String ewrPendedURL;
	private String ewrDisassociateURL;

	public String getClassForName() {
		return classForName;
	}

	public void setClassForName(String classForName) {
		this.classForName = classForName;
	}

	public String getDb2ServerURLString() {
		return db2ServerURLString;
	}

	public void setDb2ServerURLString(String db2ServerURLString) {
		this.db2ServerURLString = db2ServerURLString;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEwrAuthURL() {
		return ewrAuthURL;
	}

	public void setEwrAuthURL(String ewrAuthURL) {
		this.ewrAuthURL = ewrAuthURL;
	}

	public String getEwrAuthParamter() {
		return ewrAuthParamter;
	}

	public void setEwrAuthParamter(String ewrAuthParamter) {
		this.ewrAuthParamter = ewrAuthParamter;
	}

	public String getEwrResolvedURL() {
		return ewrResolvedURL;
	}

	public void setEwrResolvedURL(String ewrResolvedURL) {
		this.ewrResolvedURL = ewrResolvedURL;
	}

	public String getEwrPendedURL() {
		return ewrPendedURL;
	}

	public void setEwrPendedURL(String ewrPendedURL) {
		this.ewrPendedURL = ewrPendedURL;
	}

	public String getEwrDisassociateURL() {
		return ewrDisassociateURL;
	}

	public void setEwrDisassociateURL(String ewrDisassociateURL) {
		this.ewrDisassociateURL = ewrDisassociateURL;
	}

	public String getEnvironment() {
		return environment;
	}

	public void setEnvironment(String environment) {
		this.environment = environment;
	}

	public String getTopicname() {
		return topicname;
	}

	public void setTopicname(String topicname) {
		this.topicname = topicname;
	}

	public String getServer() {
		return server;
	}

	public void setServer(String server) {
		this.server = server;
	}

	public String getSecurityprotocol() {
		return securityprotocol;
	}

	public void setSecurityprotocol(String securityprotocol) {
		this.securityprotocol = securityprotocol;
	}

	public String getKeystoretype() {
		return keystoretype;
	}

	public void setKeystoretype(String keystoretype) {
		this.keystoretype = keystoretype;
	}

	public String getTruststorelocation() {
		return truststorelocation;
	}

	public void setTruststorelocation(String truststorelocation) {
		this.truststorelocation = truststorelocation;
	}

	public String getTruststorepassword() {
		return truststorepassword;
	}

	public void setTruststorepassword(String truststorepassword) {
		this.truststorepassword = truststorepassword;
	}

	public String getKeystorelocation() {
		return keystorelocation;
	}

	public void setKeystorelocation(String keystorelocation) {
		this.keystorelocation = keystorelocation;
	}

	public String getKeystorepassword() {
		return keystorepassword;
	}

	public void setKeystorepassword(String keystorepassword) {
		this.keystorepassword = keystorepassword;
	}

	public String getKeypassword() {
		return keypassword;
	}

	public void setKeypassword(String keypassword) {
		this.keypassword = keypassword;
	}

	public String getRetries() {
		return retries;
	}

	public void setRetries(String retries) {
		this.retries = retries;
	}

	public String getBatchsize() {
		return batchsize;
	}

	public void setBatchsize(String batchsize) {
		this.batchsize = batchsize;
	}

	public String getLingerms() {
		return lingerms;
	}

	public void setLingerms(String lingerms) {
		this.lingerms = lingerms;
	}

	public String getBuffermemory() {
		return buffermemory;
	}

	public void setBuffermemory(String buffermemory) {
		this.buffermemory = buffermemory;
	}

	public String getKeyserializer() {
		return keyserializer;
	}

	public void setKeyserializer(String keyserializer) {
		this.keyserializer = keyserializer;
	}

	public String getValueserializer() {
		return valueserializer;
	}

	public void setValueserializer(String valueserializer) {
		this.valueserializer = valueserializer;
	}

	public String getGroupid() {
		return groupid;
	}

	public void setGroupid(String groupid) {
		this.groupid = groupid;
	}

	public String getAutooffset() {
		return autooffset;
	}

	public void setAutooffset(String autooffset) {
		this.autooffset = autooffset;
	}

	public String getKeydeserializer() {
		return keydeserializer;
	}

	public void setKeydeserializer(String keydeserializer) {
		this.keydeserializer = keydeserializer;
	}

	public String getValuedeserializer() {
		return valuedeserializer;
	}

	public void setValuedeserializer(String valuedeserializer) {
		this.valuedeserializer = valuedeserializer;
	}

	public String getEndpoint() {
		return endpoint;
	}

	public void setEndpoint(String endpoint) {
		this.endpoint = endpoint;
	}

	public String getResource() {
		return resource;
	}

	public void setResource(String resource) {
		this.resource = resource;
	}

}
