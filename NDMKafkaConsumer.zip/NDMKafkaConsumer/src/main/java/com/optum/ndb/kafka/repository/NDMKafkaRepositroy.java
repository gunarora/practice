package com.optum.ndb.kafka.repository;

//import java.io.FileInputStream;
//import java.io.IOException;
//import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
//import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.optum.ndb.kafka.config.YamlConfig;

@Configuration
@ComponentScan(basePackages = "com.optum.ndb.kafka.config,com.optum.ndb.kafka.api")
public class NDMKafkaRepositroy {
	
	@Autowired
	private YamlConfig yconfig;
	
	/*private static Properties properties = null;
	public static String getProperty(String prop){
		if(properties == null){
			InputStream input = null;
			String env = System.getenv("server-env");
			if(env == null){
				env ="stage";//stage,dev,test
			}
			properties = new Properties();
			try{
				input = new FileInputStream("src/main/resources/ewr-"+env+".properties");
				properties.load(input);
				input.close();
			} catch (IOException e){
				e.printStackTrace();
			}
		}
		
		return properties.getProperty(prop);
	}*/
	
	private Connection db2Connection = null;
	public Connection getDB2Conn() {
			try {
				
				Class.forName(yconfig.getClassForName());//getProperty("classForName"));
				String url = yconfig.getDb2ServerURLString();//getProperty("db2ServerURLString");
				db2Connection = DriverManager.getConnection(url,yconfig.getUserId(),yconfig.getPassword());//getProperty("userId"), getProperty("password"));			
				db2Connection.setAutoCommit(true);
			} catch (Exception e) {
				e.printStackTrace();
			}
		return db2Connection;
	}
	
	/*Start up SQL Connection*/
	private Connection mySQLConnection = null;
	/**
	 * Connection for MySQL connection for New DB
	 * @return
	 */
	public  Connection getMySQLDBConn() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			// dev
			String unicode="useSSL=false&autoReconnect=true&useUnicode=yes&characterEncoding=UTF-8";
			String url = "jdbc:mysql://DBVRT59071:3306/ndba02?"+unicode;
			mySQLConnection = DriverManager.getConnection(url, "ndba02_own", "G5S7rf6%");
			return mySQLConnection;
			//mySQLConnection.setAutoCommit(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	
		return mySQLConnection;
	}
}
