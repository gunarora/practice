package com.optum.ndb.kafka.consumer;

import java.util.Properties;

import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.config.SslConfigs;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/*import com.optum.api.Error;
import com.optum.api.Notification;
*/import com.optum.ndb.kafka.config.YamlConfig;

@Configuration
@ComponentScan(basePackages = "com.optum.config,com.optum.api")
public class ReceiverConfig {

	@Autowired
	private YamlConfig yconfig;

	private static String loc = System.getProperty("user.dir");
	//private static String loc = System.getProperty("user.dir") + "\\src\\main\\resources";

	public Properties createKafkaConsumerProperties() {
		Properties props = new Properties();
		try {
			props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, yconfig.getServer());
			props.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, yconfig.getSecurityprotocol());
			props.put(SslConfigs.SSL_KEYSTORE_TYPE_CONFIG, yconfig.getKeystoretype());
			props.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, loc + yconfig.getTruststorelocation());
			props.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, yconfig.getTruststorepassword());
			props.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG, loc + yconfig.getKeystorelocation());
			props.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, yconfig.getKeystorepassword());
			props.put(SslConfigs.SSL_KEY_PASSWORD_CONFIG, yconfig.getKeypassword());
			props.put(ConsumerConfig.GROUP_ID_CONFIG, yconfig.getGroupid());
			props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "true");
			props.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, "1");
			props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, yconfig.getAutooffset());
			props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, yconfig.getKeydeserializer());
			props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, yconfig.getValuedeserializer());
		} catch (Exception e) {
			e.printStackTrace();
			/*error.setId("001");
			error.setTimeStamp(sdf.format(new Date()));
			error.setMessage(e.getMessage());
			error.setCode("CONSUMER-Properties-001");
			notify.notifyError(Arrays.asList(error));*/
		}
		return props;
	}
}
