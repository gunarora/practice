package com.optum.ndb.kafka.api;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.net.ssl.HttpsURLConnection;


import org.json.JSONObject;
import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;

import com.optum.ndb.kafka.EWRAPIStructure.EWRAPIResponse;
import com.optum.ndb.kafka.config.YamlConfig;
import com.optum.ndb.kafka.repository.NDMKafkaRepositroy;

@Component
@ComponentScan(basePackages = "com.optum.ndb.kafka.api")
public class APICall {

	@Autowired
	private NDMKafkaRepositroy repo;

	@Autowired
	private YamlConfig yconfig;
	/**
	 * This method is used to return the Token based authentication for the EWR
	 * 
	 * @return String Token
	 */
	public String getToken() {
		String token = null;
		try {
			long startTime = System.currentTimeMillis();
			System.out.println("EWR Token Process Start : "+ new Timestamp(startTime));
			String url = yconfig.getEwrAuthURL();//NDMKafkaRepositroy.getProperty("ewrAuthURL");
			URL obj = new URL(url);
			HttpsURLConnection con = (HttpsURLConnection) obj.openConnection();
			con.setRequestMethod("POST");
			con.setRequestProperty("User-Agent","Mozilla/5.0 (Windows NT 6.3; Win64; x64; rv:27.0) Gecko/20100101 Firefox/27.0.2 Waterfox/27.0");
			con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			String urlParameters = yconfig.getEwrAuthParamter();//NDMKafkaRepositroy.getProperty("ewrAuthParamter");
			//Setting Maximum timeout at 1 seconds for Authentication
			con.setConnectTimeout(1000);
			con.setReadTimeout(1000);
			// Send post request
			con.setDoOutput(true);
			DataOutputStream wr = new DataOutputStream(con.getOutputStream());
			wr.writeBytes(urlParameters);
			wr.flush();
			wr.close();
			int responseCode = con.getResponseCode();
			System.out.println("\nSending 'POST' request to URL : " + url);
			System.out.println("Post parameters : " + urlParameters);
			System.out.println("Response Code : " + responseCode);
			BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();
			// print result
			System.out.println(response.toString());

			// below code converts the json response to json object and reads each values
			JSONObject jsonObj = new JSONObject(response.toString());
			String access_token = jsonObj.getString("access_token");
			System.out.println("access_token : " + access_token);
			long endTime = System.currentTimeMillis();
			System.out.println("EWR Token Process End : "+ new Timestamp(endTime));
			System.out.println("Total time in Authentication : "+ (float) (endTime-startTime)/1000);
			return access_token;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return token;
	}

	/**
	 * This method is to trigger the EWR API on the basis of the Status received in the Request from Mainframe
	 * Parsing the JSON object and then triggering the API with JSON present
	 * @param request
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public EWRAPIResponse getEWRAPI(String request, long startTime,long offset) {
		String procID = null,claID= null,sourceName = null,u_status = null,resolveDate=null;
		float elapsedErrorTime = 0;
		long startAPITime = 0;
		Connection connection = null;
		try {
			
			// Get the Token here for the API
			String token = getToken();
			// Reading the content from the JSON structure
			startAPITime = System.currentTimeMillis();
			JSONParser parser = new JSONParser();
			org.json.simple.JSONObject json = (org.json.simple.JSONObject) parser.parse(request);

			u_status = (String) json.get("u_status");
			System.out.println(u_status);
			sourceName=(String) json.get("sourceName");
			if(null==sourceName)
				sourceName = "RP";
			json.remove("sourceName");
			
			//Removing extra leading ZERO from the Proc Error Que ID if present
			String procErrID = (String) json.get("u_procerrqueid");
			procErrID = removeZero(procErrID);
			json.remove("u_procerrqueid");
			json.put("u_procerrqueid", procErrID);
			
			procID = (String) json.get("u_procerrqueid");
			claID = (String) json.get("u_cla_id");
			resolveDate = (String) json.get("u_resolved_date");
			// Deciding the URL to be used according to the STatus Code Sent
			String url = null;
			if ("R".equalsIgnoreCase(u_status)) {
				url = yconfig.getEwrResolvedURL();//NDMKafkaRepositroy.getProperty("ewrResolvedURL");
			} else if ("P".equalsIgnoreCase(u_status)) {
				url = yconfig.getEwrPendedURL();//NDMKafkaRepositroy.getProperty("ewrPendedURL");
			} else if ("O".equalsIgnoreCase(u_status)) {
				url = yconfig.getEwrDisassociateURL();//NDMKafkaRepositroy.getProperty("ewrDisassociateURL");
			} else {
				url = null;
				return null;
			}
			
			//Taking out the Complete Request that we get from the Producer from NDM System
			
			
			// Post Deciding the URL then proceed for the connection properties and setting up the bearer token

			System.out.println("Request Sent to EWR :::: " + json.toJSONString());
			URL obj = new URL(url);
			HttpsURLConnection con = (HttpsURLConnection) obj.openConnection();
			con.setRequestMethod("POST");
			con.setRequestProperty("Authorization", "Bearer " + token);
			con.setRequestProperty("Content-Type", "application/json");
			//Setting Maximum timeout at 1 seconds for API Call
			con.setConnectTimeout(1000);
			con.setReadTimeout(1000);
			con.setDoOutput(true);
			OutputStream os = con.getOutputStream();
			os.write(json.toString().getBytes());
			os.flush();
			os.close();
			int responseCode = con.getResponseCode();
			System.out.println("POST Response Code :  " + responseCode);
			System.out.println("POST Response Message : " + con.getResponseMessage());
			if (responseCode == HttpsURLConnection.HTTP_CREATED) { // success
				BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
				String inputLine;
				StringBuffer response = new StringBuffer();
				while ((inputLine = in.readLine()) != null) {
					response.append(inputLine);
				}
				in.close();
				// print result
				System.out.println(response.toString());
				//Logic to be build on the basis of What I get as a response Code form the EWR API
				JSONParser parser1 = new JSONParser();
				org.json.simple.JSONObject json1 = (org.json.simple.JSONObject) parser1.parse(response.toString());
				org.json.simple.JSONArray result = (JSONArray) json1.get("result");
				org.json.simple.JSONObject result1 = (org.json.simple.JSONObject) result.get(0);
				// errorCode = result1.getJSONObject("geometry");
				
				String errorCode="104";
				String errorMessage = result1.get("Message_Title").toString();
				if(errorMessage.equalsIgnoreCase("Successfully Updated"))
					errorCode="110";
				else
					errorCode="104";
				
				System.out.println("return_code :: " + errorCode);
				System.out.println("return_message :: " + errorMessage);
				
				if(null!=errorCode && !"".equalsIgnoreCase(errorCode)) {
					
					try {
						// Establish connection
						connection = repo.getMySQLDBConn();
						
						if(connection==null) {
							System.out.println("Connection Issue");
						}
						
						//To get the three fields value from the UHC ID after splitting it
						String uhcID= (String) json.get("u_uhc_id");
						String divCode = uhcID.substring(0, 3);
						String providerTypeCode = uhcID.substring(3, 7);
						String providerNumber = uhcID.substring(7, 14);
						
						long endTime = System.currentTimeMillis();
						
						float elapsedTime =  (float) (endTime-startTime)/1000;
						
						System.out.println("EWR API Process End : "+ new Timestamp(endTime));
						System.out.println("Total time in API : "+ (float) (endTime-startAPITime)/1000);
						
						
						System.out.println("Start Time Application:" + startTime);
						System.out.println("End Time Application:" + endTime);
						System.out.println("Elapsed Time Application:" + elapsedTime);
						
						String sql = "INSERT INTO NDM_EWR_LOGS (COMP_NM, SRC_TYP_CD, "
								+ "ERR_CD, PROC_ERR_QUE_ID, CLA_ID, STS_CD, "
								+ "REL_CD, PROV_ID, TIN_PRFX_CD, TIN_VAL, "
								+ "TIN_SUFX_CD, PND_CD, PND_COMMT, RSLV_DT, CREAT_DT, ELAPSED_TM, OFFSET, "
								//Start EWR Phase 2 for CPQ and Pend52
								+ "DIV_CD , PROV_TYP_CD, PROV_NBR, HLTH_PLN_OFC_CD "
								//End EWR Phase 2 for CPQ and Pend52
								+ " ) "
								+ "VALUES ('CONSUMER','"
								+ sourceName
								+ "',"
								+ errorCode
								+ ","
								+ (String) json.get("u_procerrqueid")
								+ ",'"
								+ (String) json.get("u_cla_id")
								+ "','"
								+ (String) json.get("u_status")
								+ "','"
								+ (String) json.get("u_release_code")
								+ "',"
								+ (String) json.get("u_mpin_selected")
								+ ",'"
								+ (String) json.get("u_prefix")
								+ "',"
								+ (String) json.get("u_tin")
								+ ","
								+ (String) json.get("u_suffix")
								+ ",'"
								+ (String) json.get("u_pend_code")
								+ "','"
								+ (String) json.get("u_comments")
								+ "','"
								+ formatDate((String) json.get("u_resolved_date"))
								+ "', CURRENT_TIMESTAMP,'"
								// Difference of the Start and End of the time taken by the transaction
								+ elapsedTime								
								+ "',"
								+ offset
								+ ",'"
								//CHecking few details
/*								+ divCode
								+ "',"
								+ providerTypeCode
								+ ","
								+ providerNumber
								+ ",'"
								+ (String) json.get("u_health_plan")*/
								+ (null!=divCode && !"".equalsIgnoreCase(divCode) ? removeZero(divCode):"")
								+ "',"
								+ (null!=providerTypeCode && !"".equalsIgnoreCase(providerTypeCode) ? removeZero(providerTypeCode).equalsIgnoreCase("")?0:removeZero(providerTypeCode):0)
								+ ","
								+ (null!=providerNumber && !"".equalsIgnoreCase(providerNumber) ? removeZero(providerNumber).equalsIgnoreCase("")?0:removeZero(providerNumber):0)
								+ ",'"
								+ (null!=(String) json.get("u_health_plan") && !"".equalsIgnoreCase((String) json.get("u_health_plan")) ? removeZero((String) json.get("u_health_plan")):"")
								+ "'"
								+ ")";
						System.out.println("Consumer Log SQL : " + sql);
						PreparedStatement selectState = connection.prepareStatement(sql);
						
						selectState.executeUpdate();
						selectState.close();
					}
					catch (SQLException e) {
						e.printStackTrace();
					} finally {
						/*if (connection != null) {
							System.out.println("Connected successfully.");
							try {
								connection.close();
							} catch (SQLException e) {
								e.printStackTrace();
							}
						}*/
					}
					
				}
				
			} else {
				System.out.println("POST NOT WORKED");
			}
		//Error handling done to handle the Socket Exception set for 1 second
		}catch (SocketTimeoutException e) {
			System.out.println("The API took more than 1 second to process so terminating the request"
					+procID+claID+sourceName+u_status);
			long endTime = System.currentTimeMillis();
			
			elapsedErrorTime =  (float) (endTime-startTime)/1000;
			
			System.out.println("EWR API Process End In Socket Timeout Error : "+ new Timestamp(endTime));
			System.out.println("Total time in API In Socket Timeout Error : "+ elapsedErrorTime);
			
			//procID,claID,sourceName,u_status
			String sql = "INSERT INTO NDM_EWR_LOGS (COMP_NM, SRC_TYP_CD, "
					+ "ERR_CD, PROC_ERR_QUE_ID, CLA_ID, STS_CD,"
					+ "RSLV_DT,CREAT_DT, ELAPSED_TM, OFFSET" 
					+ " ) "
					+ "VALUES ('CONSUMER','"
					+ sourceName
					+ "',"
					+ "30"
					+ ","
					+ procID
					+ ",'"
					+ claID
					+ "','"
					+ u_status
					+ "','"
					+ formatDate(resolveDate)
					+ "',CURRENT_TIMESTAMP,'"
					// Difference of the Start and End of the time taken by the transaction
					+ elapsedErrorTime								
					+ "',"
					+ offset
					+ ")";
			
			connection = repo.getMySQLDBConn();
			System.out.println("Consumer Log SQL : " + sql);
			PreparedStatement selectError;
			try {
				selectError = connection.prepareStatement(sql);
				selectError.executeUpdate();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
		} 
		catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return null;
	}
	
	
	/**
	 * 
	 * @param str
	 * @return
	 */
	public static String removeZero(String str) 
    { 
        // Count leading zeros 
        int i = 0; 
        while (i < str.length() && str.charAt(i) == '0') 
            i++; 
  
        // Convert str into StringBuffer as Strings 
        // are immutable. 
        StringBuffer sb = new StringBuffer(str); 
  
        // The  StringBuffer replace function removes 
        // i characters from given index (0 here) 
        sb.replace(0, i, ""); 
  
        return sb.toString();  // return in String 
    }
	
	public static String formatDate(String date) {
		
		String startDateString = date;
		String d =startDateString.replace("/", "-");
		
	    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-dd-yyyy");
	    DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	   return (LocalDate.parse(d, formatter).format(formatter2));
		
		//return null;
	}
	
}

