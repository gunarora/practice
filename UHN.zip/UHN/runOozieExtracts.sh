#########################################################################################################################
# Script Name                   : runOozieExtracts.sh
# Author Name                   : Pankaj Kumar Vashistha
# Execution        		        : runOozieExtracts.sh
##########################################################################################################################
# sh runOozieExtracts.sh
#!/bin/bash
## TEMP_PATH will check script being called or not.
TEMP_PATH=/mapr/datalake/uhclake/dataplatform/ndb/p_logs/runExtractLastRun.log
echo "Process Started at : " date | tee -ai $TEMP_PATH

echo "########################################################################################" | tee -ai $4
echo "Running all extracts Process Started" | tee -ai $4
echo "DEBUG : Inputs to the runOozieExtracts.sh "$1" :: "$2" :: "$3" :: "$4 | tee -ai $4

##===========================Assign Constant Val=======================================##
paramFileLoc=$1
propertyFilePrefix=$2
ooziHostURL=$3
logFileName=$4

echo "DEBUG : Inputs to the runOozieExtracts.sh "$paramFileLoc" :: "$propertyFilePrefix" :: "$logFileName | tee -ai ${logFileName}
##===========================Assign Constant Val=======================================##

source ${paramFileLoc}

#source /mapr/datalake/uhclake/dataplatform/ndb/p_scripts/genric_extract.param
#LogDate=`date '+%Y%m%d%H%M%S'`
#LogFile=logs/NDB_OOZIE_$LogDate.log
#process=running_process_$LogDate.txt

##=====================================================================================##
##========================== Logic For Reading All Batch file==========================##
#for input_property_file in `ls -1 ${batch_files_path}/batch*`
for input_property_file in `ls -1 ${batch_files_path}/${propertyFilePrefix}*`
do
 echo "Extract is started for ${input_property_file}"  | tee -ai ${logFileName}
 filName=`basename $input_property_file`
 echo "File Name is : ${filName}"  | tee -ai ${logFileName}
 echo "/opt/mapr/oozie/oozie-5.1.0/bin/oozie job -oozie="https://${ooziHostURL}:11443/oozie" -config ${batch_files_path}/$job_name_prefix-$filName.properties -run"  | tee -ai ${logFileName}
 execute=`/opt/mapr/oozie/oozie-5.1.0/bin/oozie job -oozie="https://${ooziHostURL}:11443/oozie" -config ${batch_files_path}/$job_name_prefix-$filName.properties -run` | tee -ai ${logFileName}
 echo $execute  | tee -ai ${logFileName}
 exe_val=`echo $execute | cut -d':' -f 2`
 echo $exe_val  | tee -ai ${logFileName}
done
##=====================================================================================##
echo "Process Ended"  | tee -ai ${logFileName}
echo "Running all extracts Process Ended" | tee -ai ${logFileName}
echo "########################################################################################" | tee -ai ${logFileName}
exit 0

