
from pyspark.sql import SparkSession
if __name__ == "__main__":
    spark = SparkSession.builder.appName("SparkSQL-Hive-Py").enableHiveSupport().getOrCreate()
    print spark.sql("select * from df2_chy_lakeprd.D5687CHY_ACCUM_CLM_DTL_INFO_snapshot limit 2").show()
    spark.stop()
