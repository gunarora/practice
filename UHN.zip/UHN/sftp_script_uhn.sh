#########################################################################################################################
# Script Name                   : sftp_script_uhn.sh
# Author Name                   : Pankaj Kumar Vashistha
# Execution        		        : sftp_script_uhn.sh <ctl_file_path> <ctl_file_name> <user_id> <destination_server> <logFileName>
##########################################################################################################################
# sh sftp_script_uhn.sh /mapr/datalake/uhclake/tst/developer/pankaj/scripts/ndb_extract/oozie/final /mapr/datalake/uhclake/tst/developer/pankaj/scripts/ndb_extract/oozie/final/test ZIP /mapr/datalake/uhclake/dataplatform/ndb/p_logs/UHN_Reporting-F5938P_PROD_LANTYP_ZIP_0000246-180730073548993-oozie-mapr-W.log
#!/bin/bash

echo "########################################################################################" | tee -ai $5
echo "SFTP Process Started" | tee -ai $5
echo "DEBUG : Inputs to the sftp_script_uhn.sh ctl_file_path "$1"  ctl_file_name:: "$2"  user_id:: "$3"  destination_server:: "$4"  logFileName:: "$5 | tee -ai $5

ctl_file_path=$1
ctl_file_name=$2
user_id=$3
destination_server=$4
logFileName=$5

echo "DEBUG : Inputs to the sftp_script_uhn.sh ctl_file_path "$1"  ctl_file_name:: "$2"  user_id:: "$3"  destination_server:: "$4"  logFileName:: "$5 | tee -ai ${logFileName}
##=====================================================================================##
cd ${ctl_file_path}

sftp -b ${ctl_file_name} ${user_id}@${destination_server}  <<SCRIPT
binary
echo "binary sftp"
quit
SCRIPT

EXITSTATUS=$?

if [ $EXITSTATUS != "0" ]
then
  echo $EXITSTATUS
  echo "ERROR OCCURRED DURING FILE TRANSFER" | tee -ai ${logFileName}
##  mail -s "FILE TRANSFER FAILED" "$email" < File $filename transfer failed.
  exit 49
else
  echo "FILE TRANSFERED" | tee -ai ${logFileName}
fi
##=====================================================================================##
echo "SFTP Process Ended" | tee -ai ${logFileName}
echo "########################################################################################" | tee -ai ${logFileName}
exit 0