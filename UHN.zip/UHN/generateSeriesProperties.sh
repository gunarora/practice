#########################################################################################################################
# Script Name                   : generateSeriesProperties.sh
# Author Name                   : Pankaj Kumar Vashistha
# Execution        		        : generateSeriesProperties.sh
##########################################################################################################################
# sh generateSeriesProperties.sh
#!/bin/bash
echo "Process Started"
##===========================Assign Constant Val=======================================##
source /mapr/datalake/uhclake/dataplatform/ndb/p_scripts/genric_extract.param
cur_date=`date +'%Y-%m-%d'`
##=====================================================================================##
##========================== Logic For Reading All Batch file==========================##
for input_property_file in `ls -1 ${batch_files_path}/batch*`
do
	echo "input_property_file--"$input_property_file
	common_prperty_file=${out_property_file_path}/UHN_Reporting-Common.properties
	filName=`basename $input_property_file`
	echo "filName--"$filName
	file_cnt=0
	cp $common_prperty_file $out_property_file_path/$job_name_prefix-$filName.properties
	echo "jobName=$job_name_prefix-$filName" >> $out_property_file_path/$job_name_prefix-$filName.properties
	echo "feedName=$feedName" >> $out_property_file_path/$job_name_prefix-$filName.properties
	echo "startTime=$execTime" >> $out_property_file_path/$job_name_prefix-$filName.properties
	##------------------Add Extract one after other-------------------------------------##
	for line in $(cat ${input_property_file}); do
		file_cnt=$(($file_cnt+1))
		extractname=`echo ${line} ` 
		echo "extractName_"$file_cnt"="$extractname >> $out_property_file_path/$job_name_prefix-$filName.properties		
	done	
	##----------------------------------------------------------------------------------##
done
##=====================================================================================##
echo "Process Ended" 
exit 1

