#remove snapshots
#!/bin/bash
echo "##==============Entering=======================================================================##"
logFileName=$1
fileloc="/mapr/datalake/uhclake/dataplatform/ndb/p_tmp"
echo "$fileloc" | tee -ai ${logFileName}


echo "UHN_Reporting-F5938P"  | tee -ai ${logFileName}


cd ${fileloc}
echo "Moved to tmp location to remove snapshot $fileloc" | tee -ai ${logFileName}


echo "UHNReporting dir path: "${fileloc}/$filestar* | tee -ai ${logFileName}
echo "F5938DB dir path: "${fileloc}/$filestart2* | tee -ai ${logFileName}

rm -rf *UHN_Reporting-F5938P*
exit 0

echo "#####################Job ENDED all snapshot has been removed######################"
#*************************************************




