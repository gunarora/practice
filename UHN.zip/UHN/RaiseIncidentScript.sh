#!/bin/bash


displayUsage()
{
    echo "ERROR : Please provide <FeedName-ExtractName>, <Jobid>, <Incident Parameter FileName>, <Error Message>,"\
    " <logfilePath>, <Application Name>, <EmailTo>, <EmailCc> & <Env> as input parameters "
    exit 1
}

sendEmail()
{
    emailBody=$1
    emailTo=$2
    emailCc=$3
    emailSubject="FAIL : Extract Generation Failed for $4"
    emailFrom="noreply@uhc.com"

    echo "${emailBody}"|mailx -s "${emailSubject}" -c "${emailCc}" -r "${emailFrom}" "${emailTo}"
}

if [ $# !=  9 ] ; then
    displayUsage
fi

touch $7
echo "---------------------------------------------------------------------------------"| tee -ai $7
echo "DEBUG : Inputs to the RaiseIncidentScript.sh" "$1" :: "$2" :: "$3" :: "$4" :: "$5" :: "$6" :: "$7" :: "$8" :: "$9"| tee -ai $7

appln=$1
fdExName=$2
env=$3
jobname=$4
incParmFile=$5
errmsg=$6
logFilePath=$7
emailTo=$8
emailCc=$9

source $incParmFile

shortdescription=`eval echo ${shortdesc}`
description=`eval echo ${desc}`

usrnam=`eval echo ${usrname}`
passwrd=`eval echo ${passwd}`


getRequest=$(curl "https://optum.service-now.com/api/now/table/incident?sysparm_query=sys_created_bySTARTSWITH700001251%5Eactive%3Dtrue%5Esys_created_onONToday%40javascript%3Ags.beginningOfToday()%40javascript%3Ags.endOfToday()&sysparm_fields=number%2Cshort_description" --request GET --header "Accept:application/json" --header "Content-Type:application/json" --user ${usrnam}:${passwrd})

lines=`echo ${getRequest} | cut -d "[" -f2 | cut -d "]" -f1`

if [ -z "$lines" ]
then
    echo "No previous incidents raised today with id 700001251" | tee -ai $7
    res1=$(curl "https://optum.service-now.com/api/now/import/u_incident?sysparm_fields=number%2Csys_created_by%2Cshort_description%2Csys_created_on%2Cactive%2Csys_id" --request POST --header "Accept:application/json" --header "Content-Type:application/json" --data "{\"u_type\":\"$incidentype\",\"category\":\"$category\",\"state\":\"$incstate\",\"priority\":\"$priority\",\"contact_type\":\"$contact_type\",\"assignment_group\":\"$assigngrp\",\"short_description\":\"$shortdescription\",\"description\":\"$description\"}" --user ${usrnam}:${passwrd})
    echo $res1 | tee -ai $7
    status1=`echo $res1| sed -e 's/[{}]/''/g' | sed s/\"//g | awk -v RS=',' -F: '$1=="status"{print $2}'`

    if [ "$status1" != "inserted" -a  "$status1" != "Inserted" ]
    then
        echo "Request for ServiceNow failed. Here is the response : " $res1| tee -ai $7
        echo "Status received from ServiceNow is : " $status1| tee -ai $7
        echo "Auto-incident process failed, so no incident raised"| tee -ai $7
        exit 1
    fi

    incidentN=`echo $res1| sed -e 's/[{}]/''/g' | sed s/\"//g | awk -v RS=',' -F: '$1=="display_value"{print $2}'`
    echo "Incident number is : " $incidentN| tee -ai $7

    incidentNum="Incident Raised : ${incidentN}"
    emailBody=`eval echo -e ${emailBdy}`
    sendEmail "${emailBody}" "${emailTo}" "${emailCc}" "${jobname}"

    echo "RaiseIncidentScript.sh script successfully ended"| tee -ai $7
else
    echo "Incidents raised by id 700001251 are present. Looking for matching incident " | tee -ai $7
    echo ${lines} | sed s/\"//g | awk -v RS='},' -F: '{print}'|sed -e 's/[{}]/''/g' > desc.txt

    while read -r line
    do
        lineShort=`echo ${line} | awk -v RS=',' -F: '$1=="short_description"{print $2}'`
        echo ${lineShort}| tee -ai $7
        echo $shortdescription| tee -ai $7
        if [ "${lineShort}" == "${shortdescription}" ]
        then
            echo "Description matching with short desciption found. Ending script" | tee -ai $7
            result="Description found"

            incidentN=`echo ${line} | awk -v RS=',' -F: '$1=="number"{print $2}'`
            incidentNum="Incident already present. Incident Number - ${incidentN}"
            emailBody=`eval echo -e ${emailBdy}`
            sendEmail "${emailBody}" "${emailTo}" "${emailCc}" "${jobname}"
            break
        fi
    done < desc.txt

    if [ -z "$result" ]
    then
        res2=$(curl "https://optum.service-now.com/api/now/import/u_incident?sysparm_fields=number%2Csys_created_by%2Cshort_description%2Csys_created_on%2Cactive%2Csys_id" --request POST --header "Accept:application/json" --header "Content-Type:application/json" --data "{\"u_type\":\"$incidentype\",\"category\":\"$category\",\"state\":\"$incstate\",\"priority\":\"$priority\",\"contact_type\":\"$contact_type\",\"assignment_group\":\"$assigngrp\",\"short_description\":\"$shortdescription\",\"description\":\"$description\",\"close_code\":\"${ccode}\"}" --user ${usrnam}:${passwrd})
        echo $res2| tee -ai $7

        status2=`echo $res2| sed -e 's/[{}]/''/g' | sed s/\"//g | awk -v RS=',' -F: '$1=="status"{print $2}'`
        if [ "$status2" != "inserted" -a  "$status2" != "Inserted" ]
        then
            echo "Request for ServiceNow failed. Here is the response : " $res2| tee -ai $7
            echo "Status received from ServiceNow is : " $status2| tee -ai $7
            echo "Auto-incident process failed, so no incident raised"| tee -ai $7
            exit 1
        fi

        incidentNm=`echo $res2| sed -e 's/[{}]/''/g' | sed s/\"//g | awk -v RS=',' -F: '$1=="display_value"{print $2}'`

        incidentNum="Incident Raised : ${incidentNm}"
        emailBody=`eval echo -e ${emailBdy}`
        sendEmail "${emailBody}" "${emailTo}" "${emailCc}" "${jobname}"
        echo incidentNum=$incidentNm|tee -ai $7

        echo "RaiseIncidentScript.sh script successfully ended"| tee -ai $7
    fi
fi