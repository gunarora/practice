#########################################################################################################################
# Script Name                   : post_extract_ctl_file_gen.sh
# Author Name                   : Pankaj Kumar Vashistha
# Execution        		        : post_extract_ctl_file_gen.sh <outFileLoc> <file_type> <ctl_file_name> <ctl_inner_used_path> <touch_file_name> <touch_file_sftp_name> <logFileName>
##########################################################################################################################
# sh post_extract_ctl_file_gen.sh /mapr/datalake/uhclake/tst/developer/pankaj/scripts/ndb_extract/oozie/final /mapr/datalake/uhclake/tst/developer/pankaj/scripts/ndb_extract/oozie/final/test ZIP /mapr/datalake/uhclake/dataplatform/ndb/p_logs/UHN_Reporting-F5938P_PROD_LANTYP_ZIP_0000246-180730073548993-oozie-mapr-W.log
#!/bin/bash

echo "########################################################################################" | tee -ai $7
echo "Post Extract CTL File Creation Process Started" | tee -ai $7
echo "DEBUG : outFileLoc "$1 "  file_type:: "$2 "  ctl_file_name:: "$3 "  ctl_inner_used_path:: "$4 "  touch_file_name:: "$5 "  touch_file_sftp_name:: "$6 "  cd_path_of_touch_file:: "$8 | tee -ai $7

##===========================Assign Constant Val=======================================##
outFileLoc=$1
file_type=$2
ctl_file_name=$3
ctl_inner_used_path=$4
touch_file_name=$5
touch_file_sftp_name=$6
logFileName=$7
touch_inner_used_path=$8
out_file_name=$outFileLoc$ctl_file_name

echo "DEBUG : Inputs to the post_extract_ctl_file_gen.sh outFileLoc "$1"  file_type:: "$2"  ctl_file_name:: "$3"  ctl_inner_used_path:: "$4 "  touch_file_name:: "$5 "  touch_file_sftp_name:: "$6 "  touch_inner_used_path:: "$8 | tee -ai ${logFileName}
##=====================================================================================##
##========================== Logic applied Below ======================================##
echo "DEBUG : CTL file creation for Extract SFTP Started" | tee -ai ${logFileName}
##--Loop and in 1st turn apply header, then normal put command"
cnt=0
#for input_property_file in `ls $outFileLoc/*.$file_type`
for input_property_file in `ls $outFileLoc*.$file_type`
do
	if [ $cnt -eq 0 ]; then
		echo "cd $ctl_inner_used_path" > $out_file_name | tee -ai ${logFileName}
	fi
	echo "put $input_property_file" >> $out_file_name | tee -ai ${logFileName}
	cnt=$(($cnt+1))
done

echo "DEBUG : CTL file creation for Extract SFTP Completed" | tee -ai ${logFileName}
echo "DEBUG : CTL file creation for touch file SFTP started" | tee -ai ${logFileName}

    echo "cd $touch_inner_used_path" > $outFileLoc/$touch_file_sftp_name
	echo "put $outFileLoc/$touch_file_name" >> $outFileLoc/$touch_file_sftp_name
echo "DEBUG : CTL file creation for touch file SFTP completed" | tee -ai ${logFileName}
##=====================================================================================##
echo "Post Extract CTL File Creation Process Ended" | tee -ai ${logFileName}
echo "########################################################################################" | tee -ai ${logFileName}
exit 0
