#!/usr/bin/ksh



OUTFILE=infofile

for i in /mapr/datalake/uhclake/dataplatform/ndb/p_outbox/*.ZIP; do
   ROW_COUNT=$(zcat "${i}" | wc -l)
   printf "%-10s%s\n" "${ROW_COUNT}" "$i" >> $OUTFILE
done

